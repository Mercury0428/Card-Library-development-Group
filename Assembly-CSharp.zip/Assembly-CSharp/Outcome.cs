﻿using System;
using System.Collections.Generic;

// Token: 0x0200002B RID: 43
[Serializable]
public class Outcome
{
	// Token: 0x06000134 RID: 308 RVA: 0x00006F50 File Offset: 0x00005150
	public Outcome()
	{
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00006F64 File Offset: 0x00005164
	public Outcome(Outcome outco)
	{
		this.variable = outco.variable;
		this.custom_name = outco.custom_name;
		this.value = outco.value;
		this.orlimit = outco.orlimit;
		this.display = outco.display;
		this.bearer = outco.bearer;
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00006FCA File Offset: 0x000051CA
	public Outcome(Variables var, int val)
	{
		this.variable = var;
		this.value = val;
	}

	// Token: 0x06000137 RID: 311 RVA: 0x00006FEB File Offset: 0x000051EB
	public Outcome(Variables var, string val, DataDisplay disp = DataDisplay.none)
	{
		this.variable = var;
		int.TryParse(val, out this.value);
		this.display = disp;
	}

	// Token: 0x06000138 RID: 312 RVA: 0x0000701C File Offset: 0x0000521C
	public Outcome(string var, string val, bool or = false)
	{
		this.orlimit = or;
		try
		{
			this.variable = (Variables)Enum.Parse(typeof(Variables), var);
			if (GameAct.diff)
			{
				GameAct.diff.AddKnownVariable(this.variable);
			}
		}
		catch
		{
			this.variable = Variables.custom;
			this.custom_name = var;
			if (GameAct.diff)
			{
				GameAct.diff.AddCustomVariable(this.custom_name);
			}
		}
		if (!int.TryParse(val, out this.value))
		{
			if (val == "lock")
			{
				this.display = DataDisplay.locked;
				this.value = 1;
				return;
			}
			if (val.Contains("?"))
			{
				string[] array = val.Split(new string[]
				{
					"?"
				}, StringSplitOptions.RemoveEmptyEntries);
				int num = this.ExtractInt(array[0]);
				if (array.Length > 1)
				{
					int num2 = this.ExtractInt(array[1]);
					this.value = ((num > num2) ? Util.RandInt(num2, num) : Util.RandInt(num, num2));
				}
				else
				{
					this.value = num;
				}
				this.display = DataDisplay.hidden;
				return;
			}
			string[] array2 = val.Split(new string[]
			{
				"*"
			}, StringSplitOptions.RemoveEmptyEntries);
			this.value = this.ExtractInt(array2[0]);
			this.display = DataDisplay.moving;
		}
	}

	// Token: 0x06000139 RID: 313 RVA: 0x00007178 File Offset: 0x00005378
	private int ExtractInt(string val)
	{
		int result;
		int.TryParse(val, out result);
		return result;
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00007190 File Offset: 0x00005390
	public Outcome(string var, bool or = false)
	{
		string s = "";
		this.orlimit = or;
		if (var.StartsWith(">"))
		{
			int num = -1;
			while (var.Contains(">"))
			{
				var = var.Substring(1, var.Length - 1);
				num++;
			}
			this.value = num;
			this.custom_name = var;
			if (this.custom_name == "")
			{
				this.custom_name = CardReader.diff.nextname;
			}
			this.variable = Variables.chain;
			return;
		}
		if (var.Contains("+"))
		{
			bool flag = true;
			int i = 1;
			while (i < var.Length - 2)
			{
				if (var.Substring(var.Length - i, 1) != "+")
				{
					if (flag)
					{
						string[] array = var.Split(new char[]
						{
							'+'
						});
						var = array[0];
						s = array[1];
						break;
					}
					s = (i - 1).ToString();
					var = var.Substring(0, var.Length - i + 1);
					break;
				}
				else
				{
					flag = false;
					i++;
				}
			}
		}
		else if (var.Contains("-"))
		{
			bool flag2 = true;
			int j = 1;
			while (j < var.Length - 2)
			{
				if (var.Substring(var.Length - j, 1) != "-")
				{
					if (flag2)
					{
						string[] array2 = var.Split(new char[]
						{
							'-'
						});
						var = array2[0];
						s = array2[1];
						break;
					}
					s = (1 - j).ToString();
					var = var.Substring(0, var.Length - j + 1);
					break;
				}
				else
				{
					flag2 = false;
					j++;
				}
			}
		}
		else
		{
			if (var.Contains("="))
			{
				string[] array3 = var.Split(new char[]
				{
					'='
				});
				try
				{
					this.variable = (Variables)Enum.Parse(typeof(Variables), array3[0]);
					this.display = DataDisplay.fullamount;
					int.TryParse(array3[1], out this.value);
				}
				catch
				{
				}
				return;
			}
			if (var.StartsWith("!"))
			{
				if (var.StartsWith("!nb_") || var.StartsWith("!inc_"))
				{
					s = "0";
				}
				else
				{
					s = "-1";
				}
				var = var.Substring(1);
			}
			else
			{
				if (var.StartsWith("add_"))
				{
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), var.Substring(4));
					this.variable = Variables.add;
					return;
				}
				if (var.StartsWith("set_"))
				{
					string[] array4 = var.Substring(4).Split(new char[]
					{
						'>'
					});
					if (array4.Length > 1)
					{
						int.TryParse(array4[1], out this.value);
					}
					else
					{
						this.value = 0;
					}
					this.custom_name = array4[0];
					this.variable = Variables.set;
					return;
				}
				if (var.Contains(">!"))
				{
					string[] array5 = var.Split(new string[]
					{
						">!"
					}, StringSplitOptions.None);
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), array5[1]);
					this.custom_name = array5[0];
					this.variable = Variables.remove;
					return;
				}
				if (var.Contains(">"))
				{
					string[] array6 = var.Split(new char[]
					{
						'>'
					});
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), array6[1]);
					this.custom_name = array6[0];
					this.variable = Variables.set;
					return;
				}
				if (var.StartsWith("kill_"))
				{
					try
					{
						this.bearer = (Bearers)Enum.Parse(typeof(Bearers), var.Substring(5));
						this.variable = Variables.destroy;
					}
					catch
					{
					}
					return;
				}
				if (var.StartsWith("del_"))
				{
					try
					{
						this.bearer = (Bearers)Enum.Parse(typeof(Bearers), var.Substring(4));
						this.variable = Variables.remove;
					}
					catch
					{
						s = "-1";
						var = var.Substring(4);
					}
					return;
				}
				if (var.StartsWith("mus_"))
				{
					this.custom_name = var;
					this.variable = Variables.custom;
					if (var == "mus_stop")
					{
						return;
					}
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), var.Substring(4));
					return;
				}
				else
				{
					if (var == "destroy")
					{
						this.variable = Variables.destroy;
						return;
					}
					s = "1";
				}
			}
		}
		try
		{
			this.variable = (Variables)Enum.Parse(typeof(Variables), var);
			if (GameAct.diff)
			{
				GameAct.diff.AddKnownVariable(this.variable);
			}
		}
		catch
		{
			if (var.Contains("_"))
			{
				string[] array7 = var.Split(new char[]
				{
					'_'
				});
				try
				{
					this.variable = (Variables)Enum.Parse(typeof(Variables), array7[0]);
					goto IL_4F1;
				}
				catch
				{
					this.variable = Variables.custom;
					goto IL_4F1;
				}
			}
			this.variable = Variables.custom;
			IL_4F1:
			this.custom_name = var;
			if (GameAct.diff)
			{
				GameAct.diff.AddCustomVariable(this.custom_name);
			}
		}
		int.TryParse(s, out this.value);
	}

	// Token: 0x0600013B RID: 315 RVA: 0x00007700 File Offset: 0x00005900
	public static List<Outcome> TreatOutcome(string val)
	{
		List<Outcome> list = new List<Outcome>();
		bool or = false;
		string[] array = val.Split(new string[]
		{
			" or "
		}, StringSplitOptions.RemoveEmptyEntries);
		for (int i = 0; i < array.Length; i++)
		{
			foreach (string var in array[i].Split(new string[]
			{
				" and "
			}, StringSplitOptions.RemoveEmptyEntries))
			{
				list.Add(new Outcome(var, or));
				or = false;
			}
			or = true;
		}
		return list;
	}

	// Token: 0x04000139 RID: 313
	public Variables variable;

	// Token: 0x0400013A RID: 314
	public string custom_name;

	// Token: 0x0400013B RID: 315
	public int value;

	// Token: 0x0400013C RID: 316
	public bool orlimit;

	// Token: 0x0400013D RID: 317
	public DataDisplay display;

	// Token: 0x0400013E RID: 318
	public Bearers bearer = Bearers.none;
}
