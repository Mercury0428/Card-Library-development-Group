﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000045 RID: 69
public class EffectsStats : MonoBehaviour
{
	// Token: 0x0600025D RID: 605 RVA: 0x0000E4A0 File Offset: 0x0000C6A0
	private void OnEnable()
	{
		List<Effect> liveEffects = this.scEf.GetLiveEffects();
		if (liveEffects.Count == 0)
		{
			this.noeffect.SetActive(true);
			return;
		}
		this.noeffect.SetActive(false);
		float num = 0f;
		float num2 = 160f;
		float num3 = 0f;
		foreach (Effect effect in liveEffects)
		{
			GameObject gameObject = Object.Instantiate<GameObject>(this.effectBoxPrefab);
			this.objs.Add(gameObject);
			gameObject.transform.SetParent(this.content, false);
			gameObject.GetComponent<EffectBox>().Init(effect);
			num3 = -num2 * num - 90f;
			gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, num3);
			num += 1f;
		}
		this.content.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, -num3 + num2);
	}

	// Token: 0x0600025E RID: 606 RVA: 0x0000E5AC File Offset: 0x0000C7AC
	private void OnDisable()
	{
		if (this.objs.Count > 0)
		{
			foreach (GameObject obj in this.objs)
			{
				Object.Destroy(obj);
			}
		}
		this.objs = new List<GameObject>();
	}

	// Token: 0x0400025A RID: 602
	public GameObject slide;

	// Token: 0x0400025B RID: 603
	public GameObject noeffect;

	// Token: 0x0400025C RID: 604
	public EffectAct scEf;

	// Token: 0x0400025D RID: 605
	public Transform content;

	// Token: 0x0400025E RID: 606
	public GameObject effectBoxPrefab;

	// Token: 0x0400025F RID: 607
	private List<GameObject> objs = new List<GameObject>();
}
