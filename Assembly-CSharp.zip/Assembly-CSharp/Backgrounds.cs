﻿using System;

// Token: 0x02000046 RID: 70
public enum Backgrounds
{
	// Token: 0x04000261 RID: 609
	defaut,
	// Token: 0x04000262 RID: 610
	forest = 2,
	// Token: 0x04000263 RID: 611
	kingslanding = 4,
	// Token: 0x04000264 RID: 612
	tavern = 8,
	// Token: 0x04000265 RID: 613
	wall = 10,
	// Token: 0x04000266 RID: 614
	winterfell = 12,
	// Token: 0x04000267 RID: 615
	maproom = 22,
	// Token: 0x04000268 RID: 616
	trone = 30,
	// Token: 0x04000269 RID: 617
	battle_after,
	// Token: 0x0400026A RID: 618
	battle_before = 33,
	// Token: 0x0400026B RID: 619
	godseye = 43,
	// Token: 0x0400026C RID: 620
	hills = 45,
	// Token: 0x0400026D RID: 621
	boats = 50,
	// Token: 0x0400026E RID: 622
	dungeon = 56,
	// Token: 0x0400026F RID: 623
	eternity = 69,
	// Token: 0x04000270 RID: 624
	invasion = 83,
	// Token: 0x04000271 RID: 625
	tourney = 95,
	// Token: 0x04000272 RID: 626
	casterly = 106,
	// Token: 0x04000273 RID: 627
	none
}
