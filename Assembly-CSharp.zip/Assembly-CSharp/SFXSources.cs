﻿using System;

// Token: 0x0200005A RID: 90
public enum SFXSources
{
	// Token: 0x04000413 RID: 1043
	sfx,
	// Token: 0x04000414 RID: 1044
	ui,
	// Token: 0x04000415 RID: 1045
	ambient,
	// Token: 0x04000416 RID: 1046
	vo,
	// Token: 0x04000417 RID: 1047
	songs
}
