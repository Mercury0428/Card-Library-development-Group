﻿using System;
using UnityEngine;

// Token: 0x02000021 RID: 33
public class ContentBox : MonoBehaviour
{
	// Token: 0x0600010D RID: 269 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void Validate()
	{
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void Close()
	{
	}

	// Token: 0x0600010F RID: 271 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void Init(object instance, string txtid, bool trig = false, bool stayHidden = false)
	{
	}
}
