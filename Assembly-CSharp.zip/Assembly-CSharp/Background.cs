﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x0200001D RID: 29
[Serializable]
public class Background
{
	// Token: 0x060000D4 RID: 212 RVA: 0x00002050 File Offset: 0x00000250
	public Background()
	{
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x000051E2 File Offset: 0x000033E2
	public Background(Backgrounds ty, SVGAsset im, SVGAsset alt, SVGAsset wint)
	{
		this.type = ty;
		this.image = im;
		if (alt != null)
		{
			this.alternative = alt;
		}
		if (wint != null)
		{
			wint = this.winter;
		}
	}

	// Token: 0x040000B7 RID: 183
	public Backgrounds type;

	// Token: 0x040000B8 RID: 184
	public SVGAsset image;

	// Token: 0x040000B9 RID: 185
	public SVGAsset alternative;

	// Token: 0x040000BA RID: 186
	public SVGAsset winter;

	// Token: 0x040000BB RID: 187
	public List<Vector3> spots;
}
