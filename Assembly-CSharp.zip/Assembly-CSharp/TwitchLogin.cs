﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000A1 RID: 161
public class TwitchLogin : MonoBehaviour
{
	// Token: 0x060004EC RID: 1260 RVA: 0x0001E03B File Offset: 0x0001C23B
	private IEnumerator Start()
	{
		yield return true;
		this.user.text = PlayerPrefs.GetString("user");
		this.oauth.text = PlayerPrefs.GetString("auth");
		this.irc = Object.FindObjectOfType<TwitchIRC>();
		if (this.user.text.Length > 2)
		{
			this.Submit();
		}
		yield break;
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x0001E04C File Offset: 0x0001C24C
	public void Submit()
	{
		if (this.irc == null)
		{
			Debug.LogError("No IRC client Found, make sure the 'TwitchPlays Client' prefab is in the scene!");
			return;
		}
		this.irc.Login(this.user.text, this.oauth.text);
		TwitchIRC twitchIRC = this.irc;
		twitchIRC.Connected = (TwitchIRC.didConnect)Delegate.Combine(twitchIRC.Connected, new TwitchIRC.didConnect(this.Connected));
		base.StopCoroutine("reconnect");
		base.StartCoroutine("reconnect");
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0001E0D1 File Offset: 0x0001C2D1
	private void Connected()
	{
		this.connected = true;
		Debug.Log("Connected to Chat");
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0001E0E4 File Offset: 0x0001C2E4
	private void Update()
	{
		if (this.connected)
		{
			PlayerPrefs.SetString("user", this.user.text);
			PlayerPrefs.SetString("auth", this.oauth.text);
			PlayerPrefs.Save();
			if (this.LoginPanel != null)
			{
				this.LoginPanel.SetActive(false);
			}
		}
	}

	// Token: 0x060004F0 RID: 1264 RVA: 0x0001E142 File Offset: 0x0001C342
	public void Disconnect()
	{
		this.connected = false;
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x0001E14B File Offset: 0x0001C34B
	private IEnumerator reconnect()
	{
		yield return new WaitForSeconds(5f);
		if (!this.connected)
		{
			Debug.Log("Failed to connect");
		}
		yield break;
	}

	// Token: 0x040005A9 RID: 1449
	public InputField user;

	// Token: 0x040005AA RID: 1450
	public InputField oauth;

	// Token: 0x040005AB RID: 1451
	private TwitchIRC irc;

	// Token: 0x040005AC RID: 1452
	private bool connected;

	// Token: 0x040005AD RID: 1453
	public GameObject LoginPanel;
}
