﻿using System;

// Token: 0x02000063 RID: 99
[Serializable]
public class Achievement
{
	// Token: 0x0600037E RID: 894 RVA: 0x00002050 File Offset: 0x00000250
	public Achievement()
	{
	}

	// Token: 0x0600037F RID: 895 RVA: 0x00016172 File Offset: 0x00014372
	public Achievement(string nam, AchieveTypes typ)
	{
		this.name = nam;
		this.type = typ;
	}

	// Token: 0x04000461 RID: 1121
	public string name;

	// Token: 0x04000462 RID: 1122
	public AchieveTypes type;
}
