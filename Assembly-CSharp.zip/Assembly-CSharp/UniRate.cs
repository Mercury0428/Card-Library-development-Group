﻿using System;
using System.Collections;
using System.Collections.Generic;
using UniRateMiniJSON;
using UnityEngine;

// Token: 0x020000A4 RID: 164
public class UniRate : MonoBehaviour
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000500 RID: 1280 RVA: 0x0001E67C File Offset: 0x0001C87C
	// (remove) Token: 0x06000501 RID: 1281 RVA: 0x0001E6B4 File Offset: 0x0001C8B4
	public event UniRate.OnUniRateFaildDelegate OnUniRateFaild;

	// Token: 0x14000002 RID: 2
	// (add) Token: 0x06000502 RID: 1282 RVA: 0x0001E6EC File Offset: 0x0001C8EC
	// (remove) Token: 0x06000503 RID: 1283 RVA: 0x0001E724 File Offset: 0x0001C924
	public event UniRate.OnDetectAppUpdatedDelegate OnDetectAppUpdated;

	// Token: 0x14000003 RID: 3
	// (add) Token: 0x06000504 RID: 1284 RVA: 0x0001E75C File Offset: 0x0001C95C
	// (remove) Token: 0x06000505 RID: 1285 RVA: 0x0001E794 File Offset: 0x0001C994
	public event UniRate.ShouldUniRatePromptForRatingDelegate ShouldUniRatePromptForRating;

	// Token: 0x14000004 RID: 4
	// (add) Token: 0x06000506 RID: 1286 RVA: 0x0001E7CC File Offset: 0x0001C9CC
	// (remove) Token: 0x06000507 RID: 1287 RVA: 0x0001E804 File Offset: 0x0001CA04
	public event UniRate.OnPromptedForRatingDelegate OnPromptedForRating;

	// Token: 0x14000005 RID: 5
	// (add) Token: 0x06000508 RID: 1288 RVA: 0x0001E83C File Offset: 0x0001CA3C
	// (remove) Token: 0x06000509 RID: 1289 RVA: 0x0001E874 File Offset: 0x0001CA74
	public event UniRate.OnUserAttemptToRateDelegate OnUserAttemptToRate;

	// Token: 0x14000006 RID: 6
	// (add) Token: 0x0600050A RID: 1290 RVA: 0x0001E8AC File Offset: 0x0001CAAC
	// (remove) Token: 0x0600050B RID: 1291 RVA: 0x0001E8E4 File Offset: 0x0001CAE4
	public event UniRate.OnUserDeclinedToRateDelegate OnUserDeclinedToRate;

	// Token: 0x14000007 RID: 7
	// (add) Token: 0x0600050C RID: 1292 RVA: 0x0001E91C File Offset: 0x0001CB1C
	// (remove) Token: 0x0600050D RID: 1293 RVA: 0x0001E954 File Offset: 0x0001CB54
	public event UniRate.OnUserWantReminderToRateDelegate OnUserWantReminderToRate;

	// Token: 0x14000008 RID: 8
	// (add) Token: 0x0600050E RID: 1294 RVA: 0x0001E98C File Offset: 0x0001CB8C
	// (remove) Token: 0x0600050F RID: 1295 RVA: 0x0001E9C4 File Offset: 0x0001CBC4
	public event UniRate.ShouldUniRateOpenRatePageDelegate ShouldUniRateOpenRatePage;

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000510 RID: 1296 RVA: 0x0001E9F9 File Offset: 0x0001CBF9
	public string MessageTitle
	{
		get
		{
			if (!string.IsNullOrEmpty(this.messageTitle))
			{
				return this.messageTitle;
			}
			return this.GetLocalizedMessageTitle();
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000511 RID: 1297 RVA: 0x0001EA15 File Offset: 0x0001CC15
	public string Message
	{
		get
		{
			if (!string.IsNullOrEmpty(this.message))
			{
				return this.message;
			}
			return this.GetLocalizedMessage();
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000512 RID: 1298 RVA: 0x0001EA31 File Offset: 0x0001CC31
	public string CancelButtonLabel
	{
		get
		{
			if (!string.IsNullOrEmpty(this.cancelButtonLabel))
			{
				return this.cancelButtonLabel;
			}
			return this.GetLocalizedCancelButtonLabel();
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000513 RID: 1299 RVA: 0x0001EA4D File Offset: 0x0001CC4D
	public string RemindButtonLabel
	{
		get
		{
			if (!string.IsNullOrEmpty(this.remindButtonLabel))
			{
				return this.remindButtonLabel;
			}
			return this.GetLocalizedRemindButtonLabel();
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000514 RID: 1300 RVA: 0x0001EA69 File Offset: 0x0001CC69
	public string RateButtonLabel
	{
		get
		{
			if (!string.IsNullOrEmpty(this.rateButtonLabel))
			{
				return this.rateButtonLabel;
			}
			return this.GetLocalizedRateButtonLabel();
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000515 RID: 1301 RVA: 0x0001EA88 File Offset: 0x0001CC88
	public string RatingIOSURL
	{
		get
		{
			if (!string.IsNullOrEmpty(this._ratingIOSURL))
			{
				return this._ratingIOSURL;
			}
			if (this.appStoreID == 0)
			{
				Debug.LogWarning("UniRate does not find your App Store ID");
			}
			if (this.iOSVersion < 7f)
			{
				return "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=" + this.appStoreID;
			}
			return "itms-apps://itunes.apple.com/app/id" + this.appStoreID;
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000516 RID: 1302 RVA: 0x0001EAF4 File Offset: 0x0001CCF4
	public string RatingAndroidURL
	{
		get
		{
			if (!string.IsNullOrEmpty(this._ratingAndroidURL))
			{
				return this._ratingAndroidURL;
			}
			string str = "";
			UniRateMarketType uniRateMarketType = this.marketType;
			if (uniRateMarketType != UniRateMarketType.GooglePlay)
			{
				if (uniRateMarketType == UniRateMarketType.AmazonAppstore)
				{
					str = "amzn://apps/android?p=";
				}
			}
			else
			{
				str = "market://details?id=";
			}
			return str + this.marketPackageName;
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000517 RID: 1303 RVA: 0x0001EB45 File Offset: 0x0001CD45
	// (set) Token: 0x06000518 RID: 1304 RVA: 0x0001EB51 File Offset: 0x0001CD51
	public DateTime firstUsed
	{
		get
		{
			return UniRatePlayerPrefs.GetDate("UniRateFirstUsed");
		}
		set
		{
			UniRatePlayerPrefs.SetDate("UniRateFirstUsed", value);
			SuperPrefs.Save();
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000519 RID: 1305 RVA: 0x0001EB63 File Offset: 0x0001CD63
	// (set) Token: 0x0600051A RID: 1306 RVA: 0x0001EB6F File Offset: 0x0001CD6F
	public DateTime lastReminded
	{
		get
		{
			return UniRatePlayerPrefs.GetDate("UniRateLastReminded");
		}
		set
		{
			UniRatePlayerPrefs.SetDate("UniRateLastReminded", value);
			SuperPrefs.Save();
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x0600051B RID: 1307 RVA: 0x0001EB81 File Offset: 0x0001CD81
	// (set) Token: 0x0600051C RID: 1308 RVA: 0x0001EB8D File Offset: 0x0001CD8D
	public int usesCount
	{
		get
		{
			return SuperPrefs.GetInt("UniRateUseCount");
		}
		set
		{
			SuperPrefs.SetInt("UniRateUseCount", value);
			SuperPrefs.Save();
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x0600051D RID: 1309 RVA: 0x0001EB9F File Offset: 0x0001CD9F
	// (set) Token: 0x0600051E RID: 1310 RVA: 0x0001EBAB File Offset: 0x0001CDAB
	public int eventCount
	{
		get
		{
			return SuperPrefs.GetInt("UniRateEventCount");
		}
		set
		{
			SuperPrefs.SetInt("UniRateEventCount", value);
			SuperPrefs.Save();
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x0600051F RID: 1311 RVA: 0x0001EBC0 File Offset: 0x0001CDC0
	public float usesPerWeek
	{
		get
		{
			return (float)((double)this.usesCount / ((DateTime.Now - this.firstUsed).TotalSeconds / 604800.0));
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000520 RID: 1312 RVA: 0x0001EBF8 File Offset: 0x0001CDF8
	// (set) Token: 0x06000521 RID: 1313 RVA: 0x0001EC1E File Offset: 0x0001CE1E
	public bool declinedThisVersion
	{
		get
		{
			return !string.IsNullOrEmpty(this.applicationVersion) && string.Equals(SuperPrefs.GetString("UniRateDeclinedVersion"), this.applicationVersion);
		}
		set
		{
			SuperPrefs.SetString("UniRateDeclinedVersion", value ? this.applicationVersion : "");
			SuperPrefs.Save();
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000522 RID: 1314 RVA: 0x0001EC3F File Offset: 0x0001CE3F
	public bool declinedAnyVersion
	{
		get
		{
			return !string.IsNullOrEmpty(SuperPrefs.GetString("UniRateDeclinedVersion"));
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000523 RID: 1315 RVA: 0x0001EC53 File Offset: 0x0001CE53
	// (set) Token: 0x06000524 RID: 1316 RVA: 0x0001EC62 File Offset: 0x0001CE62
	public bool ratedThisVersion
	{
		get
		{
			return SuperPrefs.GetInt("UniRateRatedVersionChecked") == 1;
		}
		set
		{
			SuperPrefs.SetInt("UniRateRatedVersionChecked", value ? 1 : 0);
			SuperPrefs.Save();
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000525 RID: 1317 RVA: 0x0001EC7A File Offset: 0x0001CE7A
	public bool ratedAnyVersion
	{
		get
		{
			return !string.IsNullOrEmpty(SuperPrefs.GetString("UniRateRatedVersionChecked"));
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000526 RID: 1318 RVA: 0x0001EC90 File Offset: 0x0001CE90
	public float usedDays
	{
		get
		{
			return (float)(DateTime.Now - this.firstUsed).TotalSeconds / 86400f;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000527 RID: 1319 RVA: 0x0001ECBC File Offset: 0x0001CEBC
	public bool waitingByRemindLater
	{
		get
		{
			return this.lastReminded != DateTime.MaxValue;
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000528 RID: 1320 RVA: 0x0001ECD0 File Offset: 0x0001CED0
	public float leftRemindDays
	{
		get
		{
			return (float)((double)this.remindPeriod - (DateTime.Now - this.lastReminded).TotalSeconds / 86400.0);
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000529 RID: 1321 RVA: 0x0001ED08 File Offset: 0x0001CF08
	private Dictionary<string, object> localizationDic
	{
		get
		{
			if (this._localizationDic == null)
			{
				TextAsset textAsset = (TextAsset)Resources.Load("UniRateLocalizationStrings", typeof(TextAsset));
				this._localizationDic = (Json.Deserialize(textAsset.text) as Dictionary<string, object>);
			}
			return this._localizationDic;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x0600052A RID: 1322 RVA: 0x0001ED54 File Offset: 0x0001CF54
	public static UniRate Instance
	{
		get
		{
			if (!UniRate._instance)
			{
				UniRate._instance = (Object.FindObjectOfType(typeof(UniRate)) as UniRate);
				if (!UniRate._instance)
				{
					UniRate._instance = new GameObject("UniRateManager").AddComponent<UniRate>();
				}
				else
				{
					UniRate._instance.gameObject.name = "UniRateManager";
				}
				Object.DontDestroyOnLoad(UniRate._instance.gameObject);
				UniRatePlugin.InitUniRateAndroid();
			}
			return UniRate._instance;
		}
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0001EDD8 File Offset: 0x0001CFD8
	public bool ShouldPromptForRating()
	{
		if (this.previewMode)
		{
			Debug.Log("UniRate is in preview mode. Make sure you set previewMode to false when release.");
			return true;
		}
		if (this.ratedThisVersion)
		{
			UniRateDebug.Log("Not prompt. The user has already rated this version");
			return false;
		}
		if (!this.promptAgainForEachNewVersion && this.ratedAnyVersion)
		{
			UniRateDebug.Log("Not prompt. The user has already rated for some version and promptAgainForEachNewVersion is disabled");
			return false;
		}
		if (this.declinedThisVersion)
		{
			UniRateDebug.Log("Not prompt. The user refused to rate this version");
			return false;
		}
		if ((this.daysUntilPrompt > 0f || this.usesPerWeekForPrompt != 0f) && this.firstUsed == DateTime.MaxValue)
		{
			UniRateDebug.Log("Not prompt. First launch");
			return false;
		}
		if ((DateTime.Now - this.firstUsed).TotalSeconds < (double)(this.daysUntilPrompt * 86400f))
		{
			UniRateDebug.Log("Not prompt. App was used less than " + this.daysUntilPrompt + " days ago");
			return false;
		}
		if (this.usesCount < this.usesUntilPrompt)
		{
			UniRateDebug.Log("Not prompt. App was only used " + this.usesCount + " times");
			return false;
		}
		if (this.eventCount < this.eventsUntilPrompt)
		{
			UniRateDebug.Log("Not prompt. Only " + this.eventCount + " times of events logged");
			return false;
		}
		if (this.usesPerWeek < this.usesPerWeekForPrompt)
		{
			UniRateDebug.Log("Not prompt. Only used " + this.usesPerWeek + " times per week");
			return false;
		}
		if (this.lastReminded != DateTime.MaxValue && (DateTime.Now - this.lastReminded).TotalSeconds < (double)(this.remindPeriod * 86400f))
		{
			UniRateDebug.Log("Not prompt. The user askd to be reminded and it is not the time now");
			return false;
		}
		return true;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0001EF90 File Offset: 0x0001D190
	public void PromptIfNetworkAvailable()
	{
		this.CheckAndReadyToRate(true);
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x0001EF99 File Offset: 0x0001D199
	public void RateIfNetworkAvailable()
	{
		this.CheckAndReadyToRate(false);
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0001EFA4 File Offset: 0x0001D1A4
	public void ShowPrompt()
	{
		UniRateDebug.Log("It's time to show prompt");
		if (this.OnPromptedForRating != null)
		{
			this.OnPromptedForRating();
		}
		if (!this.useCustomizedPromptView)
		{
			UniRatePlugin.ShowPrompt(this.MessageTitle, this.Message, this.RateButtonLabel, this.CancelButtonLabel, this.RemindButtonLabel);
			this._promptShowing = true;
		}
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0001F000 File Offset: 0x0001D200
	public void OpenRatePage()
	{
		this.ratedThisVersion = true;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0001F009 File Offset: 0x0001D209
	public void LogEvent(bool withPrompt)
	{
		this.IncreaseEventCount();
		if (withPrompt && this.ShouldPromptForRating())
		{
			this.PromptIfNetworkAvailable();
		}
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x0001F024 File Offset: 0x0001D224
	public void Reset()
	{
		SuperPrefs.DeleteKey("UniRateRatedVersionChecked");
		SuperPrefs.DeleteKey("UniRateDeclinedVersion");
		SuperPrefs.DeleteKey("UniRateLastReminded");
		SuperPrefs.DeleteKey("UniRateLastVersionUsed");
		SuperPrefs.DeleteKey("UniRateFirstUsed");
		SuperPrefs.DeleteKey("UniRateUseCount");
		SuperPrefs.DeleteKey("UniRateEventCount");
		SuperPrefs.Save();
		UniRate.Instance.Init();
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0001F086 File Offset: 0x0001D286
	private void Start()
	{
		if (UniRate._instance != null)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		UniRate.Instance.Init();
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x0001F0AC File Offset: 0x0001D2AC
	private void Init()
	{
		if (string.IsNullOrEmpty(this.appStoreCountry))
		{
			this.appStoreCountry = UniRatePlugin.GetAppStoreCountry();
			UniRateDebug.Log("Get Country Code: " + this.appStoreCountry);
		}
		if (string.IsNullOrEmpty(this.applicationVersion))
		{
			this.applicationVersion = UniRatePlugin.GetApplicationVersion();
			UniRateDebug.Log("Get App Version: " + this.applicationVersion);
		}
		if (string.IsNullOrEmpty(this.applicationName))
		{
			this.applicationName = UniRatePlugin.GetApplicationName();
			UniRateDebug.Log("Get App Name: " + this.applicationName);
		}
		if (string.IsNullOrEmpty(this.applicationBundleID))
		{
			this.applicationBundleID = UniRatePlugin.GetApplicationBundleID();
			UniRateDebug.Log("Get Bundle ID: " + this.applicationBundleID);
		}
		if (string.IsNullOrEmpty(this.marketPackageName))
		{
			this.marketPackageName = UniRatePlugin.GetPackageName();
			UniRateDebug.Log("Get Android package name: " + this.marketPackageName);
		}
		this._promptShowing = false;
		this.UniRateLauched();
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0001F1A8 File Offset: 0x0001D3A8
	private void UniRateLauched()
	{
		if (!this.IsSameVersion())
		{
			SuperPrefs.SetString("UniRateLastVersionUsed", this.applicationVersion);
			UniRatePlayerPrefs.SetDate("UniRateFirstUsed", DateTime.Now);
			SuperPrefs.SetInt("UniRateUseCount", 0);
			SuperPrefs.SetInt("UniRateEventCount", 0);
			SuperPrefs.DeleteKey("UniRateLastReminded");
			SuperPrefs.Save();
			if (this.OnDetectAppUpdated != null)
			{
				this.OnDetectAppUpdated();
			}
		}
		this.IncreaseUseCount();
		if (this.promptAtLaunch && this.ShouldPromptForRating())
		{
			this.PromptIfNetworkAvailable();
		}
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0001F230 File Offset: 0x0001D430
	private bool IsSameVersion()
	{
		return !string.IsNullOrEmpty(this.applicationVersion) && string.Equals(SuperPrefs.GetString("UniRateLastVersionUsed"), this.applicationVersion);
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0001F256 File Offset: 0x0001D456
	private void OnApplicationPause(bool pauseStatus)
	{
		if (!pauseStatus && UniRate._instance != null && !this.onlyCountUseWhenFreshStartUp)
		{
			this.IncreaseUseCount();
			if (this.promptAtLaunch && !this._promptShowing && this.ShouldPromptForRating())
			{
				this.PromptIfNetworkAvailable();
			}
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0001F294 File Offset: 0x0001D494
	private void IncreaseUseCount()
	{
		int usesCount = this.usesCount;
		this.usesCount = usesCount + 1;
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x0001F2B4 File Offset: 0x0001D4B4
	private void IncreaseEventCount()
	{
		int eventCount = this.eventCount;
		this.eventCount = eventCount + 1;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0001F2D1 File Offset: 0x0001D4D1
	private void CheckAndReadyToRate(bool showPrompt)
	{
		Debug.Log("In CheckAndReadyToRate");
		bool currentChecking = this._currentChecking;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0001F2E4 File Offset: 0x0001D4E4
	private IEnumerator CheckForConnectivityInBackground(bool showPrompt)
	{
		string text;
		if (!string.IsNullOrEmpty(this.appStoreCountry))
		{
			text = string.Format("http://itunes.apple.com/{0}lookup", this.appStoreCountry + "/");
		}
		else
		{
			text = string.Format("http://itunes.apple.com/{0}lookup", "");
		}
		if (this.appStoreID != 0)
		{
			text = text + "?id=" + this.appStoreID;
		}
		else
		{
			text = text + "?bundleId=" + this.applicationBundleID;
		}
		UniRateDebug.Log("Checking app info: " + text);
		bool errorHappened = false;
		WWW www = new WWW(text);
		yield return www;
		if (string.IsNullOrEmpty(www.error))
		{
			UniRateAppInfo uniRateAppInfo = new UniRateAppInfo(www.text);
			if (uniRateAppInfo.validAppInfo)
			{
				if (uniRateAppInfo.bundleId.Equals(this.applicationBundleID))
				{
					if (this.appStoreID == 0)
					{
						this.appStoreID = uniRateAppInfo.appID;
						UniRateDebug.Log("UniRate found the app, app id: " + this.appStoreID);
					}
					if (this.onlyPromptIfLatestVersion && !this.previewMode && !this.applicationVersion.Equals(uniRateAppInfo.version))
					{
						UniRateDebug.Log("No prompt because it is not the version in app store and you set onlyPromptIfLatestVersion.");
						errorHappened = true;
						this.UniRateFailWithError(UniRate.Error.NotTheLatestVersion);
					}
				}
				else
				{
					Debug.LogWarning("The bundle Id is not the same. Appstore: " + uniRateAppInfo.bundleId + " vs AppSetting:" + this.applicationBundleID);
					errorHappened = true;
					this.UniRateFailWithError(UniRate.Error.BundleIdDoesNotMatchAppStore);
				}
			}
			else if (this.appStoreID != 0)
			{
				Debug.LogWarning("No App info found with this app Id " + this.appStoreID);
				errorHappened = true;
				this.UniRateFailWithError(UniRate.Error.AppNotFoundOnAppStore);
			}
			else
			{
				Debug.Log("No App info found with this bundle Id " + this.applicationBundleID);
				Debug.Log("Could not find your app on AppStore. It is normal when your app is not released, don't worry about this message.");
			}
		}
		else
		{
			UniRateDebug.Log("Error happend in loading app information. Maybe due to no internet connection.");
			errorHappened = true;
			this.UniRateFailWithError(UniRate.Error.NetworkError);
		}
		if (!errorHappened)
		{
			this._currentChecking = false;
			if (showPrompt)
			{
				this.ReadyToPrompt();
			}
			else
			{
				this.OpenRatePage();
			}
		}
		yield break;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x0001F2FA File Offset: 0x0001D4FA
	private void ReadyToPrompt()
	{
		if (this.ShouldUniRatePromptForRating != null && !this.ShouldUniRatePromptForRating())
		{
			UniRateDebug.Log("Not display prompt because ShouldUniRatePromptForRating returns false.");
			return;
		}
		this.ShowPrompt();
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0001F322 File Offset: 0x0001D522
	private void UniRateFailWithError(UniRate.Error error)
	{
		if (this.OnUniRateFaild != null)
		{
			this.OnUniRateFaild(error);
		}
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0001F338 File Offset: 0x0001D538
	private void UniRateUserDeclinedPrompt()
	{
		UniRateDebug.Log("User declined the prompt");
		this._promptShowing = false;
		this.declinedThisVersion = true;
		if (this.OnUserDeclinedToRate != null)
		{
			this.OnUserDeclinedToRate();
		}
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x0001F365 File Offset: 0x0001D565
	private void UniRateUserWantRemind()
	{
		UniRateDebug.Log("User wants to be reminded later");
		this._promptShowing = false;
		this.lastReminded = DateTime.Now;
		if (this.OnUserWantReminderToRate != null)
		{
			this.OnUserWantReminderToRate();
		}
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0001F398 File Offset: 0x0001D598
	private void UniRateUserWantToRate()
	{
		UniRateDebug.Log("User wants to rate");
		this._promptShowing = false;
		if (this.OnUserAttemptToRate != null)
		{
			this.OnUserAttemptToRate();
		}
		if (this.ShouldUniRateOpenRatePage != null && !this.ShouldUniRateOpenRatePage())
		{
			UniRateDebug.Log("Not open rate page because ShouldUniRateOpenRatePage() returning false");
			return;
		}
		this.OpenRatePage();
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000540 RID: 1344 RVA: 0x0001F3F0 File Offset: 0x0001D5F0
	private float iOSVersion
	{
		get
		{
			float result = -1f;
			float.TryParse(SystemInfo.operatingSystem.Replace("iPhone OS ", "").Substring(0, 1), out result);
			return result;
		}
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0001F428 File Offset: 0x0001D628
	private string GetLocalizedMessageTitle()
	{
		string text = "Rate {0}";
		if (this.autoLocalization)
		{
			string lang = Application.systemLanguage.ToString();
			text = (this.GetContentForLanguageAndKey(lang, "title") ?? text);
		}
		return string.Format(text, this.applicationName);
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0001F478 File Offset: 0x0001D678
	private string GetLocalizedMessage()
	{
		string text = "If you enjoy {0}, would you mind taking a moment to rate it? It will not take more than a minute. Thanks for your support!";
		if (this.autoLocalization)
		{
			string lang = Application.systemLanguage.ToString();
			text = (this.GetContentForLanguageAndKey(lang, "body") ?? text);
		}
		return string.Format(text, this.applicationName);
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0001F4C8 File Offset: 0x0001D6C8
	private string GetLocalizedCancelButtonLabel()
	{
		string text = "No, thanks";
		if (this.autoLocalization)
		{
			string lang = Application.systemLanguage.ToString();
			text = (this.GetContentForLanguageAndKey(lang, "cancel") ?? text);
		}
		return text;
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0001F50C File Offset: 0x0001D70C
	private string GetLocalizedRemindButtonLabel()
	{
		string text = "Remind me later";
		if (this.autoLocalization)
		{
			string lang = Application.systemLanguage.ToString();
			text = (this.GetContentForLanguageAndKey(lang, "remind") ?? text);
		}
		return text;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0001F550 File Offset: 0x0001D750
	private string GetLocalizedRateButtonLabel()
	{
		string text = "Rate it now";
		if (this.autoLocalization)
		{
			string lang = Application.systemLanguage.ToString();
			text = (this.GetContentForLanguageAndKey(lang, "rate") ?? text);
		}
		return text;
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x0001F594 File Offset: 0x0001D794
	private string GetContentForLanguageAndKey(string lang, string key)
	{
		if (this.localizationDic != null && this.localizationDic.ContainsKey(lang))
		{
			Dictionary<string, object> dictionary = this.localizationDic[lang] as Dictionary<string, object>;
			if (dictionary != null && dictionary.ContainsKey(key))
			{
				return dictionary[key] as string;
			}
		}
		return null;
	}

	// Token: 0x040005C3 RID: 1475
	public int appStoreID;

	// Token: 0x040005C4 RID: 1476
	public string marketPackageName;

	// Token: 0x040005C5 RID: 1477
	public UniRateMarketType marketType;

	// Token: 0x040005C6 RID: 1478
	public string appStoreCountry;

	// Token: 0x040005C7 RID: 1479
	public string applicationName;

	// Token: 0x040005C8 RID: 1480
	public string applicationVersion;

	// Token: 0x040005C9 RID: 1481
	public string applicationBundleID;

	// Token: 0x040005CA RID: 1482
	public int usesUntilPrompt = 10;

	// Token: 0x040005CB RID: 1483
	public bool onlyCountUseWhenFreshStartUp;

	// Token: 0x040005CC RID: 1484
	public int eventsUntilPrompt;

	// Token: 0x040005CD RID: 1485
	public float daysUntilPrompt = 3f;

	// Token: 0x040005CE RID: 1486
	public float usesPerWeekForPrompt;

	// Token: 0x040005CF RID: 1487
	public float remindPeriod = 1f;

	// Token: 0x040005D0 RID: 1488
	public string messageTitle = "";

	// Token: 0x040005D1 RID: 1489
	public string message = "";

	// Token: 0x040005D2 RID: 1490
	public string cancelButtonLabel = "";

	// Token: 0x040005D3 RID: 1491
	public string remindButtonLabel = "";

	// Token: 0x040005D4 RID: 1492
	public string rateButtonLabel = "";

	// Token: 0x040005D5 RID: 1493
	public bool onlyPromptIfLatestVersion = true;

	// Token: 0x040005D6 RID: 1494
	public bool promptAgainForEachNewVersion = true;

	// Token: 0x040005D7 RID: 1495
	public bool promptAtLaunch = true;

	// Token: 0x040005D8 RID: 1496
	public bool useCustomizedPromptView;

	// Token: 0x040005D9 RID: 1497
	public bool autoLocalization = true;

	// Token: 0x040005DA RID: 1498
	public bool previewMode;

	// Token: 0x040005DB RID: 1499
	[SerializeField]
	private string _ratingIOSURL;

	// Token: 0x040005DC RID: 1500
	[SerializeField]
	private string _ratingAndroidURL;

	// Token: 0x040005DD RID: 1501
	private const string kUniRateRatedVersionKey = "UniRateRatedVersionChecked";

	// Token: 0x040005DE RID: 1502
	private const string kUniRateDeclinedVersionKey = "UniRateDeclinedVersion";

	// Token: 0x040005DF RID: 1503
	private const string kUniRateLastRemindedKey = "UniRateLastReminded";

	// Token: 0x040005E0 RID: 1504
	private const string kUniRateLastVersionUsedKey = "UniRateLastVersionUsed";

	// Token: 0x040005E1 RID: 1505
	private const string kUniRateFirstUsedKey = "UniRateFirstUsed";

	// Token: 0x040005E2 RID: 1506
	private const string kUniRateUseCountKey = "UniRateUseCount";

	// Token: 0x040005E3 RID: 1507
	private const string kUniRateEventCountKey = "UniRateEventCount";

	// Token: 0x040005E4 RID: 1508
	private const string kUniRateAppLookupURLFormat = "http://itunes.apple.com/{0}lookup";

	// Token: 0x040005E5 RID: 1509
	private const string kUniRateiOSAppStoreURLFormat = "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=";

	// Token: 0x040005E6 RID: 1510
	private const string kUniRateiOS7AppStoreURLFormat = "itms-apps://itunes.apple.com/app/id";

	// Token: 0x040005E7 RID: 1511
	private const string kUniRateAndroidMarketURLFormat = "market://details?id=";

	// Token: 0x040005E8 RID: 1512
	private const string kUniRateAmazonAppstoreURLFormat = "amzn://apps/android?p=";

	// Token: 0x040005E9 RID: 1513
	private const string kDefaultTitle = "Rate {0}";

	// Token: 0x040005EA RID: 1514
	private const string kDefaultMessage = "If you enjoy {0}, would you mind taking a moment to rate it? It will not take more than a minute. Thanks for your support!";

	// Token: 0x040005EB RID: 1515
	private const string kDefaultCancelBtnTitle = "No, thanks";

	// Token: 0x040005EC RID: 1516
	private const string kDefaultRateBtnTitle = "Rate it now";

	// Token: 0x040005ED RID: 1517
	private const string kDefaultRemindBtnTitle = "Remind me later";

	// Token: 0x040005EE RID: 1518
	private const float SECONDS_IN_A_DAY = 86400f;

	// Token: 0x040005EF RID: 1519
	private const float SECONDS_IN_A_WEEK = 604800f;

	// Token: 0x040005F0 RID: 1520
	private bool _currentChecking;

	// Token: 0x040005F1 RID: 1521
	private bool _promptShowing;

	// Token: 0x040005F2 RID: 1522
	private Dictionary<string, object> _localizationDic;

	// Token: 0x040005F3 RID: 1523
	private static UniRate _instance;

	// Token: 0x0200032D RID: 813
	// (Invoke) Token: 0x06001612 RID: 5650
	public delegate void OnUniRateFaildDelegate(UniRate.Error error);

	// Token: 0x0200032E RID: 814
	// (Invoke) Token: 0x06001616 RID: 5654
	public delegate void OnDetectAppUpdatedDelegate();

	// Token: 0x0200032F RID: 815
	// (Invoke) Token: 0x0600161A RID: 5658
	public delegate bool ShouldUniRatePromptForRatingDelegate();

	// Token: 0x02000330 RID: 816
	// (Invoke) Token: 0x0600161E RID: 5662
	public delegate void OnPromptedForRatingDelegate();

	// Token: 0x02000331 RID: 817
	// (Invoke) Token: 0x06001622 RID: 5666
	public delegate void OnUserAttemptToRateDelegate();

	// Token: 0x02000332 RID: 818
	// (Invoke) Token: 0x06001626 RID: 5670
	public delegate void OnUserDeclinedToRateDelegate();

	// Token: 0x02000333 RID: 819
	// (Invoke) Token: 0x0600162A RID: 5674
	public delegate void OnUserWantReminderToRateDelegate();

	// Token: 0x02000334 RID: 820
	// (Invoke) Token: 0x0600162E RID: 5678
	public delegate bool ShouldUniRateOpenRatePageDelegate();

	// Token: 0x02000335 RID: 821
	public enum Error
	{
		// Token: 0x040011DA RID: 4570
		BundleIdDoesNotMatchAppStore,
		// Token: 0x040011DB RID: 4571
		AppNotFoundOnAppStore,
		// Token: 0x040011DC RID: 4572
		NotTheLatestVersion,
		// Token: 0x040011DD RID: 4573
		NetworkError
	}
}
