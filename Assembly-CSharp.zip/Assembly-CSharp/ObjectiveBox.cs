﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000026 RID: 38
public class ObjectiveBox : ContentBox
{
	// Token: 0x06000121 RID: 289 RVA: 0x000065CB File Offset: 0x000047CB
	public override void Validate()
	{
		base.StartCoroutine("MoveCheck");
		base.Validate();
	}

	// Token: 0x06000122 RID: 290 RVA: 0x000065E0 File Offset: 0x000047E0
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
		this.obj = (Objective)instance;
		this.thisrect = base.GetComponent<RectTransform>();
		if (!stayHidden)
		{
			this.text.text = this.obj.description;
		}
		if (trig)
		{
			this.ShowCheck();
			this.text.color = this.validCol;
			if (this.nick)
			{
				this.nick.color = this.validCol;
			}
		}
		else if (stayHidden)
		{
			this.text.color = this.hiddenCol;
			if (this.nick)
			{
				this.nick.color = this.hiddenCol;
			}
		}
		else
		{
			this.text.color = this.activeCol;
			if (this.nick)
			{
				this.nick.color = this.activeCol;
			}
		}
		if (this.nick)
		{
			this.nick.text = this.obj.title.Get();
		}
	}

	// Token: 0x06000123 RID: 291 RVA: 0x000066E5 File Offset: 0x000048E5
	private IEnumerator MoveCheck()
	{
		yield return new WaitForSeconds(0.5f);
		JukeBox.diff.PlaySound(SFXTypes.ui_achievement_unlock, false, false, 2.5f, -1, 1.5f, 1f);
		WaitForSeconds swait = new WaitForSeconds(0.05f);
		int num2;
		for (int i = 0; i < 8; i = num2 + 1)
		{
			yield return swait;
			if (this.starPrefab != null)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.starPrefab);
				gameObject.transform.SetParent(base.transform.parent.parent.parent, false);
				gameObject.transform.SetAsFirstSibling();
				float num = Util.Rand(0.5f, 1f);
				gameObject.transform.localScale = new Vector3(num, num, 1f);
				gameObject.transform.Rotate(Vector3.forward, Util.Rand(0f, 360f));
			}
			num2 = i;
		}
		float j = 0f;
		while (j < 1f)
		{
			this.checkbox.fillAmount = j;
			j += Time.deltaTime * 2f;
			yield return null;
		}
		yield break;
	}

	// Token: 0x06000124 RID: 292 RVA: 0x000066F4 File Offset: 0x000048F4
	public void ShowCheck()
	{
		this.checkbox.fillAmount = 1f;
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00006706 File Offset: 0x00004906
	public void HideRight()
	{
		base.StartCoroutine("DoHideRight");
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00006714 File Offset: 0x00004914
	private IEnumerator DoHideRight()
	{
		float t = 0f;
		while (t < 1f)
		{
			this.thisrect.anchoredPosition = Vector2.Lerp(this.thisrect.anchoredPosition, this.thisrect.anchoredPosition + Vector2.right * 10f, 0.3f + t);
			t += Time.deltaTime * 4f;
			yield return null;
		}
		Object.Destroy(base.gameObject);
		yield break;
	}

	// Token: 0x06000127 RID: 295 RVA: 0x00006724 File Offset: 0x00004924
	public override void Close()
	{
		if (!this.obj.title.isEmpty)
		{
			CardReader.diff.GetComponent<KingdomAct>().SetCurrentNick(this.obj.title.Get(), this.obj.name);
		}
		base.Close();
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00006773 File Offset: 0x00004973
	private void OnDisable()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x0400010E RID: 270
	public Color validCol;

	// Token: 0x0400010F RID: 271
	public GameObject starPrefab;

	// Token: 0x04000110 RID: 272
	public Color activeCol;

	// Token: 0x04000111 RID: 273
	public Color hiddenCol;

	// Token: 0x04000112 RID: 274
	public Image checkbox;

	// Token: 0x04000113 RID: 275
	public Text text;

	// Token: 0x04000114 RID: 276
	private RectTransform thisrect;

	// Token: 0x04000115 RID: 277
	public Objective obj;

	// Token: 0x04000116 RID: 278
	public Text nick;
}
