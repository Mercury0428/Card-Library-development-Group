﻿using System;
using UnityEngine;

// Token: 0x0200000F RID: 15
public class iOSHapticFeedbackExample : MonoBehaviour
{
	// Token: 0x06000085 RID: 133 RVA: 0x00003E44 File Offset: 0x00002044
	private void OnGUI()
	{
		for (int i = 0; i < 7; i++)
		{
			if (GUI.Button(new Rect(0f, (float)(i * 60), 300f, 50f), "Trigger " + (iOSHapticFeedback.iOSFeedbackType)i))
			{
				iOSHapticFeedback.Instance.Trigger((iOSHapticFeedback.iOSFeedbackType)i);
			}
		}
	}
}
