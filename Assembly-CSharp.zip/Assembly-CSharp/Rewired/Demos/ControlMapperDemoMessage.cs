﻿using System;
using System.Collections;
using Rewired.UI.ControlMapper;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.Demos
{
	// Token: 0x020001AD RID: 429
	[AddComponentMenu("")]
	public class ControlMapperDemoMessage : MonoBehaviour
	{
		// Token: 0x06000F39 RID: 3897 RVA: 0x0005C12E File Offset: 0x0005A32E
		private void Awake()
		{
			if (this.controlMapper != null)
			{
				this.controlMapper.ScreenClosedEvent += this.OnControlMapperClosed;
				this.controlMapper.ScreenOpenedEvent += this.OnControlMapperOpened;
			}
		}

		// Token: 0x06000F3A RID: 3898 RVA: 0x0005C16C File Offset: 0x0005A36C
		private void Start()
		{
			this.SelectDefault();
		}

		// Token: 0x06000F3B RID: 3899 RVA: 0x0005C174 File Offset: 0x0005A374
		private void OnControlMapperClosed()
		{
			base.gameObject.SetActive(true);
			base.StartCoroutine(this.SelectDefaultDeferred());
		}

		// Token: 0x06000F3C RID: 3900 RVA: 0x00003E98 File Offset: 0x00002098
		private void OnControlMapperOpened()
		{
			base.gameObject.SetActive(false);
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0005C18F File Offset: 0x0005A38F
		private void SelectDefault()
		{
			if (EventSystem.current == null)
			{
				return;
			}
			if (this.defaultSelectable != null)
			{
				EventSystem.current.SetSelectedGameObject(this.defaultSelectable.gameObject);
			}
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0005C1C2 File Offset: 0x0005A3C2
		private IEnumerator SelectDefaultDeferred()
		{
			yield return null;
			this.SelectDefault();
			yield break;
		}

		// Token: 0x04000C0A RID: 3082
		public ControlMapper controlMapper;

		// Token: 0x04000C0B RID: 3083
		public Selectable defaultSelectable;
	}
}
