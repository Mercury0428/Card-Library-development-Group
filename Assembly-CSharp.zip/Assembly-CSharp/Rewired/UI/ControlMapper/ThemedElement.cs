﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A1 RID: 417
	[AddComponentMenu("")]
	public class ThemedElement : MonoBehaviour
	{
		// Token: 0x06000EDC RID: 3804 RVA: 0x0005ACF8 File Offset: 0x00058EF8
		private void Start()
		{
			ControlMapper.ApplyTheme(this._elements);
		}

		// Token: 0x04000BD8 RID: 3032
		[SerializeField]
		private ThemedElement.ElementInfo[] _elements;

		// Token: 0x02000382 RID: 898
		[Serializable]
		public class ElementInfo
		{
			// Token: 0x170004B2 RID: 1202
			// (get) Token: 0x060017E4 RID: 6116 RVA: 0x00075B9B File Offset: 0x00073D9B
			public string themeClass
			{
				get
				{
					return this._themeClass;
				}
			}

			// Token: 0x170004B3 RID: 1203
			// (get) Token: 0x060017E5 RID: 6117 RVA: 0x00075BA3 File Offset: 0x00073DA3
			public Component component
			{
				get
				{
					return this._component;
				}
			}

			// Token: 0x0400133F RID: 4927
			[SerializeField]
			private string _themeClass;

			// Token: 0x04001340 RID: 4928
			[SerializeField]
			private Component _component;
		}
	}
}
