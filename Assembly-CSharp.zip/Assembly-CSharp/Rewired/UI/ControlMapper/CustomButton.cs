﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000197 RID: 407
	[AddComponentMenu("")]
	public class CustomButton : Button, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000DFC RID: 3580 RVA: 0x00059043 File Offset: 0x00057243
		// (set) Token: 0x06000DFD RID: 3581 RVA: 0x0005904B File Offset: 0x0005724B
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000DFE RID: 3582 RVA: 0x00059054 File Offset: 0x00057254
		// (set) Token: 0x06000DFF RID: 3583 RVA: 0x0005905C File Offset: 0x0005725C
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000E00 RID: 3584 RVA: 0x00059065 File Offset: 0x00057265
		// (set) Token: 0x06000E01 RID: 3585 RVA: 0x0005906D File Offset: 0x0005726D
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000E02 RID: 3586 RVA: 0x00059076 File Offset: 0x00057276
		// (set) Token: 0x06000E03 RID: 3587 RVA: 0x0005907E File Offset: 0x0005727E
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000E04 RID: 3588 RVA: 0x00059087 File Offset: 0x00057287
		// (set) Token: 0x06000E05 RID: 3589 RVA: 0x0005908F File Offset: 0x0005728F
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000E06 RID: 3590 RVA: 0x00059098 File Offset: 0x00057298
		// (set) Token: 0x06000E07 RID: 3591 RVA: 0x000590A0 File Offset: 0x000572A0
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000E08 RID: 3592 RVA: 0x000590A9 File Offset: 0x000572A9
		// (set) Token: 0x06000E09 RID: 3593 RVA: 0x000590B1 File Offset: 0x000572B1
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000E0A RID: 3594 RVA: 0x000590BA File Offset: 0x000572BA
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000E0B RID: 3595 RVA: 0x000590C8 File Offset: 0x000572C8
		// (remove) Token: 0x06000E0C RID: 3596 RVA: 0x00059100 File Offset: 0x00057300
		private event UnityAction _CancelEvent;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000E0D RID: 3597 RVA: 0x00059135 File Offset: 0x00057335
		// (remove) Token: 0x06000E0E RID: 3598 RVA: 0x0005913E File Offset: 0x0005733E
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000E0F RID: 3599 RVA: 0x00059148 File Offset: 0x00057348
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x0005919C File Offset: 0x0005739C
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000E11 RID: 3601 RVA: 0x000591F0 File Offset: 0x000573F0
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x00059244 File Offset: 0x00057444
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x00059298 File Offset: 0x00057498
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000E14 RID: 3604 RVA: 0x000592CC File Offset: 0x000574CC
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000E15 RID: 3605 RVA: 0x00059354 File Offset: 0x00057554
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x00059396 File Offset: 0x00057596
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000E17 RID: 3607 RVA: 0x000593B4 File Offset: 0x000575B4
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000E18 RID: 3608 RVA: 0x00059422 File Offset: 0x00057622
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000E19 RID: 3609 RVA: 0x00059432 File Offset: 0x00057632
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000E1A RID: 3610 RVA: 0x00059442 File Offset: 0x00057642
		private void Press()
		{
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			base.onClick.Invoke();
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x00059460 File Offset: 0x00057660
		public override void OnPointerClick(PointerEventData eventData)
		{
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.Press();
			if (!this.IsActive() || !this.IsInteractable())
			{
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x000594AC File Offset: 0x000576AC
		public override void OnSubmit(BaseEventData eventData)
		{
			this.Press();
			if (!this.IsActive() || !this.IsInteractable())
			{
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
				return;
			}
			this.DoStateTransition(Selectable.SelectionState.Pressed, false);
			base.StartCoroutine(this.OnFinishSubmit());
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x000594E9 File Offset: 0x000576E9
		private IEnumerator OnFinishSubmit()
		{
			float fadeTime = base.colors.fadeDuration;
			float elapsedTime = 0f;
			while (elapsedTime < fadeTime)
			{
				elapsedTime += Time.unscaledDeltaTime;
				yield return null;
			}
			this.DoStateTransition(base.currentSelectionState, false);
			yield break;
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x000594F8 File Offset: 0x000576F8
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x0005954A File Offset: 0x0005774A
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x04000B66 RID: 2918
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x04000B67 RID: 2919
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x04000B68 RID: 2920
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x04000B69 RID: 2921
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x04000B6A RID: 2922
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x04000B6B RID: 2923
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x04000B6C RID: 2924
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x04000B6D RID: 2925
		private bool isHighlightDisabled;
	}
}
