﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019D RID: 413
	[AddComponentMenu("")]
	public class InputRow : MonoBehaviour
	{
		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000E8F RID: 3727 RVA: 0x0005A445 File Offset: 0x00058645
		// (set) Token: 0x06000E90 RID: 3728 RVA: 0x0005A44D File Offset: 0x0005864D
		public ButtonInfo[] buttons { get; private set; }

		// Token: 0x06000E91 RID: 3729 RVA: 0x0005A456 File Offset: 0x00058656
		public void Initialize(int rowIndex, string label, Action<int, ButtonInfo> inputFieldActivatedCallback)
		{
			this.rowIndex = rowIndex;
			this.label.text = label;
			this.inputFieldActivatedCallback = inputFieldActivatedCallback;
			this.buttons = base.transform.GetComponentsInChildren<ButtonInfo>(true);
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0005A484 File Offset: 0x00058684
		public void OnButtonActivated(ButtonInfo buttonInfo)
		{
			if (this.inputFieldActivatedCallback == null)
			{
				return;
			}
			this.inputFieldActivatedCallback(this.rowIndex, buttonInfo);
		}

		// Token: 0x04000B93 RID: 2963
		public Text label;

		// Token: 0x04000B95 RID: 2965
		private int rowIndex;

		// Token: 0x04000B96 RID: 2966
		private Action<int, ButtonInfo> inputFieldActivatedCallback;
	}
}
