﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001AA RID: 426
	[AddComponentMenu("")]
	public class UISliderControl : UIControl
	{
		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000F01 RID: 3841 RVA: 0x0005B676 File Offset: 0x00059876
		// (set) Token: 0x06000F02 RID: 3842 RVA: 0x0005B67E File Offset: 0x0005987E
		public bool showIcon
		{
			get
			{
				return this._showIcon;
			}
			set
			{
				if (this.iconImage == null)
				{
					return;
				}
				this.iconImage.gameObject.SetActive(value);
				this._showIcon = value;
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000F03 RID: 3843 RVA: 0x0005B6A7 File Offset: 0x000598A7
		// (set) Token: 0x06000F04 RID: 3844 RVA: 0x0005B6AF File Offset: 0x000598AF
		public bool showSlider
		{
			get
			{
				return this._showSlider;
			}
			set
			{
				if (this.slider == null)
				{
					return;
				}
				this.slider.gameObject.SetActive(value);
				this._showSlider = value;
			}
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0005B6D8 File Offset: 0x000598D8
		public override void SetCancelCallback(Action cancelCallback)
		{
			base.SetCancelCallback(cancelCallback);
			if (cancelCallback == null || this.slider == null)
			{
				return;
			}
			if (this.slider is ICustomSelectable)
			{
				(this.slider as ICustomSelectable).CancelEvent += delegate()
				{
					cancelCallback();
				};
				return;
			}
			EventTrigger eventTrigger = this.slider.GetComponent<EventTrigger>();
			if (eventTrigger == null)
			{
				eventTrigger = this.slider.gameObject.AddComponent<EventTrigger>();
			}
			EventTrigger.Entry entry = new EventTrigger.Entry();
			entry.callback = new EventTrigger.TriggerEvent();
			entry.eventID = EventTriggerType.Cancel;
			entry.callback.AddListener(delegate(BaseEventData data)
			{
				cancelCallback();
			});
			if (eventTrigger.triggers == null)
			{
				eventTrigger.triggers = new List<EventTrigger.Entry>();
			}
			eventTrigger.triggers.Add(entry);
		}

		// Token: 0x04000BF7 RID: 3063
		public Image iconImage;

		// Token: 0x04000BF8 RID: 3064
		public Slider slider;

		// Token: 0x04000BF9 RID: 3065
		private bool _showIcon;

		// Token: 0x04000BFA RID: 3066
		private bool _showSlider;
	}
}
