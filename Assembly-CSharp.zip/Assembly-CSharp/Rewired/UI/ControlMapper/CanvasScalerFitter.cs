﻿using System;
using Rewired.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000195 RID: 405
	[RequireComponent(typeof(CanvasScalerExt))]
	public class CanvasScalerFitter : MonoBehaviour
	{
		// Token: 0x06000CF7 RID: 3319 RVA: 0x00053298 File Offset: 0x00051498
		private void OnEnable()
		{
			this.canvasScaler = base.GetComponent<CanvasScalerExt>();
			this.Update();
			this.canvasScaler.ForceRefresh();
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x000532B7 File Offset: 0x000514B7
		private void Update()
		{
			if (Screen.width != this.screenWidth || Screen.height != this.screenHeight)
			{
				this.screenWidth = Screen.width;
				this.screenHeight = Screen.height;
				this.UpdateSize();
			}
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x000532F0 File Offset: 0x000514F0
		private void UpdateSize()
		{
			if (this.canvasScaler.uiScaleMode != CanvasScaler.ScaleMode.ScaleWithScreenSize)
			{
				return;
			}
			if (this.breakPoints == null)
			{
				return;
			}
			float num = (float)Screen.width / (float)Screen.height;
			float num2 = float.PositiveInfinity;
			int num3 = 0;
			for (int i = 0; i < this.breakPoints.Length; i++)
			{
				float num4 = Mathf.Abs(num - this.breakPoints[i].screenAspectRatio);
				if ((num4 <= this.breakPoints[i].screenAspectRatio || MathTools.IsNear(this.breakPoints[i].screenAspectRatio, 0.01f)) && num4 < num2)
				{
					num2 = num4;
					num3 = i;
				}
			}
			this.canvasScaler.referenceResolution = this.breakPoints[num3].referenceResolution;
		}

		// Token: 0x04000B09 RID: 2825
		[SerializeField]
		private CanvasScalerFitter.BreakPoint[] breakPoints;

		// Token: 0x04000B0A RID: 2826
		private CanvasScalerExt canvasScaler;

		// Token: 0x04000B0B RID: 2827
		private int screenWidth;

		// Token: 0x04000B0C RID: 2828
		private int screenHeight;

		// Token: 0x04000B0D RID: 2829
		private Action ScreenSizeChanged;

		// Token: 0x02000362 RID: 866
		[Serializable]
		private class BreakPoint
		{
			// Token: 0x0400128E RID: 4750
			[SerializeField]
			public string name;

			// Token: 0x0400128F RID: 4751
			[SerializeField]
			public float screenAspectRatio;

			// Token: 0x04001290 RID: 4752
			[SerializeField]
			public Vector2 referenceResolution;
		}
	}
}
