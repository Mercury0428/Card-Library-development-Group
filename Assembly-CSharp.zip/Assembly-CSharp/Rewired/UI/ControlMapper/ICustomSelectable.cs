﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019A RID: 410
	public interface ICustomSelectable : ICancelHandler, IEventSystemHandler
	{
		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000E63 RID: 3683
		// (set) Token: 0x06000E64 RID: 3684
		Sprite disabledHighlightedSprite { get; set; }

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000E65 RID: 3685
		// (set) Token: 0x06000E66 RID: 3686
		Color disabledHighlightedColor { get; set; }

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000E67 RID: 3687
		// (set) Token: 0x06000E68 RID: 3688
		string disabledHighlightedTrigger { get; set; }

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000E69 RID: 3689
		// (set) Token: 0x06000E6A RID: 3690
		bool autoNavUp { get; set; }

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000E6B RID: 3691
		// (set) Token: 0x06000E6C RID: 3692
		bool autoNavDown { get; set; }

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000E6D RID: 3693
		// (set) Token: 0x06000E6E RID: 3694
		bool autoNavLeft { get; set; }

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000E6F RID: 3695
		// (set) Token: 0x06000E70 RID: 3696
		bool autoNavRight { get; set; }

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000E71 RID: 3697
		// (remove) Token: 0x06000E72 RID: 3698
		event UnityAction CancelEvent;
	}
}
