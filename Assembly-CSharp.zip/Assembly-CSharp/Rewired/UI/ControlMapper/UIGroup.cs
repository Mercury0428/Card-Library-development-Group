﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A7 RID: 423
	[AddComponentMenu("")]
	public class UIGroup : MonoBehaviour
	{
		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000EF6 RID: 3830 RVA: 0x0005B378 File Offset: 0x00059578
		// (set) Token: 0x06000EF7 RID: 3831 RVA: 0x0005B399 File Offset: 0x00059599
		public string labelText
		{
			get
			{
				if (!(this._label != null))
				{
					return string.Empty;
				}
				return this._label.text;
			}
			set
			{
				if (this._label == null)
				{
					return;
				}
				this._label.text = value;
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000EF8 RID: 3832 RVA: 0x0005B3B6 File Offset: 0x000595B6
		public Transform content
		{
			get
			{
				return this._content;
			}
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x0005B3BE File Offset: 0x000595BE
		public void SetLabelActive(bool state)
		{
			if (this._label == null)
			{
				return;
			}
			this._label.gameObject.SetActive(state);
		}

		// Token: 0x04000BF2 RID: 3058
		[SerializeField]
		private Text _label;

		// Token: 0x04000BF3 RID: 3059
		[SerializeField]
		private Transform _content;
	}
}
