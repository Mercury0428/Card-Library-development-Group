﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001AC RID: 428
	[AddComponentMenu("")]
	[RequireComponent(typeof(CanvasGroup))]
	public class Window : MonoBehaviour
	{
		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000F0D RID: 3853 RVA: 0x0005BAA3 File Offset: 0x00059CA3
		public bool hasFocus
		{
			get
			{
				return this._isFocusedCallback != null && this._isFocusedCallback(this._id);
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000F0E RID: 3854 RVA: 0x0005BAC0 File Offset: 0x00059CC0
		public int id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000F0F RID: 3855 RVA: 0x0005BAC8 File Offset: 0x00059CC8
		public RectTransform rectTransform
		{
			get
			{
				if (this._rectTransform == null)
				{
					this._rectTransform = base.gameObject.GetComponent<RectTransform>();
				}
				return this._rectTransform;
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000F10 RID: 3856 RVA: 0x0005BAEF File Offset: 0x00059CEF
		public Text titleText
		{
			get
			{
				return this._titleText;
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000F11 RID: 3857 RVA: 0x0005BAF7 File Offset: 0x00059CF7
		public List<Text> contentText
		{
			get
			{
				return this._contentText;
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000F12 RID: 3858 RVA: 0x0005BAFF File Offset: 0x00059CFF
		// (set) Token: 0x06000F13 RID: 3859 RVA: 0x0005BB07 File Offset: 0x00059D07
		public GameObject defaultUIElement
		{
			get
			{
				return this._defaultUIElement;
			}
			set
			{
				this._defaultUIElement = value;
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000F14 RID: 3860 RVA: 0x0005BB10 File Offset: 0x00059D10
		// (set) Token: 0x06000F15 RID: 3861 RVA: 0x0005BB18 File Offset: 0x00059D18
		public Action<int> updateCallback
		{
			get
			{
				return this._updateCallback;
			}
			set
			{
				this._updateCallback = value;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000F16 RID: 3862 RVA: 0x0005BB21 File Offset: 0x00059D21
		public Window.Timer timer
		{
			get
			{
				return this._timer;
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06000F17 RID: 3863 RVA: 0x0005BB29 File Offset: 0x00059D29
		// (set) Token: 0x06000F18 RID: 3864 RVA: 0x0005BB3C File Offset: 0x00059D3C
		public int width
		{
			get
			{
				return (int)this.rectTransform.sizeDelta.x;
			}
			set
			{
				Vector2 sizeDelta = this.rectTransform.sizeDelta;
				sizeDelta.x = (float)value;
				this.rectTransform.sizeDelta = sizeDelta;
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000F19 RID: 3865 RVA: 0x0005BB6A File Offset: 0x00059D6A
		// (set) Token: 0x06000F1A RID: 3866 RVA: 0x0005BB80 File Offset: 0x00059D80
		public int height
		{
			get
			{
				return (int)this.rectTransform.sizeDelta.y;
			}
			set
			{
				Vector2 sizeDelta = this.rectTransform.sizeDelta;
				sizeDelta.y = (float)value;
				this.rectTransform.sizeDelta = sizeDelta;
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x06000F1B RID: 3867 RVA: 0x0005BBAE File Offset: 0x00059DAE
		protected bool initialized
		{
			get
			{
				return this._initialized;
			}
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x0005BBB6 File Offset: 0x00059DB6
		private void OnEnable()
		{
			base.StartCoroutine("OnEnableAsync");
		}

		// Token: 0x06000F1D RID: 3869 RVA: 0x0005BBC4 File Offset: 0x00059DC4
		protected virtual void Update()
		{
			if (!this._initialized)
			{
				return;
			}
			if (!this.hasFocus)
			{
				return;
			}
			this.CheckUISelection();
			if (this._updateCallback != null)
			{
				this._updateCallback(this._id);
			}
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x0005BBF8 File Offset: 0x00059DF8
		public virtual void Initialize(int id, Func<int, bool> isFocusedCallback)
		{
			if (this._initialized)
			{
				Debug.LogError("Window is already initialized!");
				return;
			}
			this._id = id;
			this._isFocusedCallback = isFocusedCallback;
			this._timer = new Window.Timer();
			this._contentText = new List<Text>();
			this._canvasGroup = base.GetComponent<CanvasGroup>();
			this._initialized = true;
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x0005BC4F File Offset: 0x00059E4F
		public void SetSize(int width, int height)
		{
			this.rectTransform.sizeDelta = new Vector2((float)width, (float)height);
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x0005BC65 File Offset: 0x00059E65
		public void CreateTitleText(GameObject prefab, Vector2 offset)
		{
			this.CreateText(prefab, ref this._titleText, "Title Text", UIPivot.TopCenter, UIAnchor.TopHStretch, offset);
		}

		// Token: 0x06000F21 RID: 3873 RVA: 0x0005BC84 File Offset: 0x00059E84
		public void CreateTitleText(GameObject prefab, Vector2 offset, string text)
		{
			this.CreateTitleText(prefab, offset);
			this.SetTitleText(text);
		}

		// Token: 0x06000F22 RID: 3874 RVA: 0x0005BC98 File Offset: 0x00059E98
		public void AddContentText(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			Text item = null;
			this.CreateText(prefab, ref item, "Content Text", pivot, anchor, offset);
			this._contentText.Add(item);
		}

		// Token: 0x06000F23 RID: 3875 RVA: 0x0005BCC5 File Offset: 0x00059EC5
		public void AddContentText(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string text)
		{
			this.AddContentText(prefab, pivot, anchor, offset);
			this.SetContentText(text, this._contentText.Count - 1);
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x0005BCE7 File Offset: 0x00059EE7
		public void AddContentImage(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			this.CreateImage(prefab, "Image", pivot, anchor, offset);
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x0005BCF9 File Offset: 0x00059EF9
		public void AddContentImage(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string text)
		{
			this.AddContentImage(prefab, pivot, anchor, offset);
		}

		// Token: 0x06000F26 RID: 3878 RVA: 0x0005BD08 File Offset: 0x00059F08
		public void CreateButton(GameObject prefab, UIPivot pivot, UIAnchor anchor, Vector2 offset, string buttonText, UnityAction confirmCallback, UnityAction cancelCallback, bool setDefault)
		{
			if (prefab == null)
			{
				return;
			}
			ButtonInfo buttonInfo;
			GameObject gameObject = this.CreateButton(prefab, "Button", anchor, pivot, offset, out buttonInfo);
			if (gameObject == null)
			{
				return;
			}
			Button component = gameObject.GetComponent<Button>();
			if (confirmCallback != null)
			{
				component.onClick.AddListener(confirmCallback);
			}
			CustomButton customButton = component as CustomButton;
			if (cancelCallback != null && customButton != null)
			{
				customButton.CancelEvent += cancelCallback;
			}
			if (buttonInfo.text != null)
			{
				buttonInfo.text.text = buttonText;
			}
			if (setDefault)
			{
				this._defaultUIElement = gameObject;
			}
		}

		// Token: 0x06000F27 RID: 3879 RVA: 0x0005BD96 File Offset: 0x00059F96
		public string GetTitleText(string text)
		{
			if (this._titleText == null)
			{
				return string.Empty;
			}
			return this._titleText.text;
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x0005BDB7 File Offset: 0x00059FB7
		public void SetTitleText(string text)
		{
			if (this._titleText == null)
			{
				return;
			}
			this._titleText.text = text;
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x0005BDD4 File Offset: 0x00059FD4
		public string GetContentText(int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return string.Empty;
			}
			return this._contentText[index].text;
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x0005BE24 File Offset: 0x0005A024
		public float GetContentTextHeight(int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return 0f;
			}
			return this._contentText[index].rectTransform.sizeDelta.y;
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x0005BE7C File Offset: 0x0005A07C
		public void SetContentText(string text, int index)
		{
			if (this._contentText == null || this._contentText.Count <= index || this._contentText[index] == null)
			{
				return;
			}
			this._contentText[index].text = text;
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x0005BEBB File Offset: 0x0005A0BB
		public void SetUpdateCallback(Action<int> callback)
		{
			this.updateCallback = callback;
		}

		// Token: 0x06000F2D RID: 3885 RVA: 0x0005BEC4 File Offset: 0x0005A0C4
		public virtual void TakeInputFocus()
		{
			if (EventSystem.current == null)
			{
				return;
			}
			EventSystem.current.SetSelectedGameObject(this._defaultUIElement);
			this.Enable();
		}

		// Token: 0x06000F2E RID: 3886 RVA: 0x0005BEEA File Offset: 0x0005A0EA
		public virtual void Enable()
		{
			this._canvasGroup.interactable = true;
		}

		// Token: 0x06000F2F RID: 3887 RVA: 0x0005BEF8 File Offset: 0x0005A0F8
		public virtual void Disable()
		{
			this._canvasGroup.interactable = false;
		}

		// Token: 0x06000F30 RID: 3888 RVA: 0x0005BF06 File Offset: 0x0005A106
		public virtual void Cancel()
		{
			if (!this.initialized)
			{
				return;
			}
			if (this.cancelCallback != null)
			{
				this.cancelCallback();
			}
		}

		// Token: 0x06000F31 RID: 3889 RVA: 0x0005BF24 File Offset: 0x0005A124
		private void CreateText(GameObject prefab, ref Text textComponent, string name, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			if (prefab == null || this.content == null)
			{
				return;
			}
			if (textComponent != null)
			{
				Debug.LogError("Window already has " + name + "!");
				return;
			}
			GameObject gameObject = UITools.InstantiateGUIObject<Text>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
			if (gameObject == null)
			{
				return;
			}
			textComponent = gameObject.GetComponent<Text>();
		}

		// Token: 0x06000F32 RID: 3890 RVA: 0x0005BFA8 File Offset: 0x0005A1A8
		private void CreateImage(GameObject prefab, string name, UIPivot pivot, UIAnchor anchor, Vector2 offset)
		{
			if (prefab == null || this.content == null)
			{
				return;
			}
			UITools.InstantiateGUIObject<Image>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
		}

		// Token: 0x06000F33 RID: 3891 RVA: 0x0005BFF8 File Offset: 0x0005A1F8
		private GameObject CreateButton(GameObject prefab, string name, UIAnchor anchor, UIPivot pivot, Vector2 offset, out ButtonInfo buttonInfo)
		{
			buttonInfo = null;
			if (prefab == null)
			{
				return null;
			}
			GameObject gameObject = UITools.InstantiateGUIObject<ButtonInfo>(prefab, this.content.transform, name, pivot, anchor.min, anchor.max, offset);
			if (gameObject == null)
			{
				return null;
			}
			buttonInfo = gameObject.GetComponent<ButtonInfo>();
			if (gameObject.GetComponent<Button>() == null)
			{
				Debug.Log("Button prefab is missing Button component!");
				return null;
			}
			if (buttonInfo == null)
			{
				Debug.Log("Button prefab is missing ButtonInfo component!");
				return null;
			}
			return gameObject;
		}

		// Token: 0x06000F34 RID: 3892 RVA: 0x0005C082 File Offset: 0x0005A282
		private IEnumerator OnEnableAsync()
		{
			yield return 1;
			if (EventSystem.current == null)
			{
				yield break;
			}
			if (this.defaultUIElement != null)
			{
				EventSystem.current.SetSelectedGameObject(this.defaultUIElement);
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(null);
			}
			yield break;
		}

		// Token: 0x06000F35 RID: 3893 RVA: 0x0005C094 File Offset: 0x0005A294
		private void CheckUISelection()
		{
			if (!this.hasFocus)
			{
				return;
			}
			if (EventSystem.current == null)
			{
				return;
			}
			if (EventSystem.current.currentSelectedGameObject == null)
			{
				this.RestoreDefaultOrLastUISelection();
			}
			this.lastUISelection = EventSystem.current.currentSelectedGameObject;
		}

		// Token: 0x06000F36 RID: 3894 RVA: 0x0005C0E0 File Offset: 0x0005A2E0
		private void RestoreDefaultOrLastUISelection()
		{
			if (!this.hasFocus)
			{
				return;
			}
			if (this.lastUISelection == null || !this.lastUISelection.activeInHierarchy)
			{
				this.SetUISelection(this._defaultUIElement);
				return;
			}
			this.SetUISelection(this.lastUISelection);
		}

		// Token: 0x06000F37 RID: 3895 RVA: 0x000583F6 File Offset: 0x000565F6
		private void SetUISelection(GameObject selection)
		{
			if (EventSystem.current == null)
			{
				return;
			}
			EventSystem.current.SetSelectedGameObject(selection);
		}

		// Token: 0x04000BFB RID: 3067
		public Image backgroundImage;

		// Token: 0x04000BFC RID: 3068
		public GameObject content;

		// Token: 0x04000BFD RID: 3069
		private bool _initialized;

		// Token: 0x04000BFE RID: 3070
		private int _id = -1;

		// Token: 0x04000BFF RID: 3071
		private RectTransform _rectTransform;

		// Token: 0x04000C00 RID: 3072
		private Text _titleText;

		// Token: 0x04000C01 RID: 3073
		private List<Text> _contentText;

		// Token: 0x04000C02 RID: 3074
		private GameObject _defaultUIElement;

		// Token: 0x04000C03 RID: 3075
		private Action<int> _updateCallback;

		// Token: 0x04000C04 RID: 3076
		private Func<int, bool> _isFocusedCallback;

		// Token: 0x04000C05 RID: 3077
		private Window.Timer _timer;

		// Token: 0x04000C06 RID: 3078
		private CanvasGroup _canvasGroup;

		// Token: 0x04000C07 RID: 3079
		public UnityAction cancelCallback;

		// Token: 0x04000C08 RID: 3080
		private GameObject lastUISelection;

		// Token: 0x04000C09 RID: 3081
		private List<Selectable> selectables;

		// Token: 0x02000390 RID: 912
		public class Timer
		{
			// Token: 0x170004DD RID: 1245
			// (get) Token: 0x06001839 RID: 6201 RVA: 0x0007624B File Offset: 0x0007444B
			public bool started
			{
				get
				{
					return this._started;
				}
			}

			// Token: 0x170004DE RID: 1246
			// (get) Token: 0x0600183A RID: 6202 RVA: 0x00076253 File Offset: 0x00074453
			public bool finished
			{
				get
				{
					if (!this.started)
					{
						return false;
					}
					if (Time.realtimeSinceStartup < this.end)
					{
						return false;
					}
					this._started = false;
					return true;
				}
			}

			// Token: 0x170004DF RID: 1247
			// (get) Token: 0x0600183B RID: 6203 RVA: 0x00076276 File Offset: 0x00074476
			public float remaining
			{
				get
				{
					if (!this._started)
					{
						return 0f;
					}
					return this.end - Time.realtimeSinceStartup;
				}
			}

			// Token: 0x0600183D RID: 6205 RVA: 0x00076292 File Offset: 0x00074492
			public void Start(float length)
			{
				this.end = Time.realtimeSinceStartup + length;
				this._started = true;
			}

			// Token: 0x0600183E RID: 6206 RVA: 0x000762A8 File Offset: 0x000744A8
			public void Stop()
			{
				this._started = false;
			}

			// Token: 0x04001375 RID: 4981
			private bool _started;

			// Token: 0x04001376 RID: 4982
			private float end;
		}
	}
}
