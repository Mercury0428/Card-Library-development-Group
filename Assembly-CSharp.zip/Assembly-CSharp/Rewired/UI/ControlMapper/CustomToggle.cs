﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000199 RID: 409
	[AddComponentMenu("")]
	public class CustomToggle : Toggle, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000E42 RID: 3650 RVA: 0x000599E7 File Offset: 0x00057BE7
		// (set) Token: 0x06000E43 RID: 3651 RVA: 0x000599EF File Offset: 0x00057BEF
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000E44 RID: 3652 RVA: 0x000599F8 File Offset: 0x00057BF8
		// (set) Token: 0x06000E45 RID: 3653 RVA: 0x00059A00 File Offset: 0x00057C00
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000E46 RID: 3654 RVA: 0x00059A09 File Offset: 0x00057C09
		// (set) Token: 0x06000E47 RID: 3655 RVA: 0x00059A11 File Offset: 0x00057C11
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000E48 RID: 3656 RVA: 0x00059A1A File Offset: 0x00057C1A
		// (set) Token: 0x06000E49 RID: 3657 RVA: 0x00059A22 File Offset: 0x00057C22
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000E4A RID: 3658 RVA: 0x00059A2B File Offset: 0x00057C2B
		// (set) Token: 0x06000E4B RID: 3659 RVA: 0x00059A33 File Offset: 0x00057C33
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000E4C RID: 3660 RVA: 0x00059A3C File Offset: 0x00057C3C
		// (set) Token: 0x06000E4D RID: 3661 RVA: 0x00059A44 File Offset: 0x00057C44
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000E4E RID: 3662 RVA: 0x00059A4D File Offset: 0x00057C4D
		// (set) Token: 0x06000E4F RID: 3663 RVA: 0x00059A55 File Offset: 0x00057C55
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000E50 RID: 3664 RVA: 0x000590BA File Offset: 0x000572BA
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000E51 RID: 3665 RVA: 0x00059A60 File Offset: 0x00057C60
		// (remove) Token: 0x06000E52 RID: 3666 RVA: 0x00059A98 File Offset: 0x00057C98
		private event UnityAction _CancelEvent;

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000E53 RID: 3667 RVA: 0x00059ACD File Offset: 0x00057CCD
		// (remove) Token: 0x06000E54 RID: 3668 RVA: 0x00059AD6 File Offset: 0x00057CD6
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x00059AE0 File Offset: 0x00057CE0
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x00059B34 File Offset: 0x00057D34
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000E57 RID: 3671 RVA: 0x00059B88 File Offset: 0x00057D88
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000E58 RID: 3672 RVA: 0x00059BDC File Offset: 0x00057DDC
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000E59 RID: 3673 RVA: 0x00059C30 File Offset: 0x00057E30
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x00059C64 File Offset: 0x00057E64
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x00059CEC File Offset: 0x00057EEC
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x00059396 File Offset: 0x00057596
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x00059D30 File Offset: 0x00057F30
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x00059D9E File Offset: 0x00057F9E
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000E5F RID: 3679 RVA: 0x00059DAE File Offset: 0x00057FAE
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000E60 RID: 3680 RVA: 0x00059DC0 File Offset: 0x00057FC0
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000E61 RID: 3681 RVA: 0x00059E12 File Offset: 0x00058012
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x04000B78 RID: 2936
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x04000B79 RID: 2937
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x04000B7A RID: 2938
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x04000B7B RID: 2939
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x04000B7C RID: 2940
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x04000B7D RID: 2941
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x04000B7E RID: 2942
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x04000B7F RID: 2943
		private bool isHighlightDisabled;
	}
}
