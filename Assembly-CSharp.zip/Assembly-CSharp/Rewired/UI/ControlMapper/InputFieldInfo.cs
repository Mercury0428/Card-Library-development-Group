﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019C RID: 412
	[AddComponentMenu("")]
	public class InputFieldInfo : UIElementInfo
	{
		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000E84 RID: 3716 RVA: 0x0005A3F0 File Offset: 0x000585F0
		// (set) Token: 0x06000E85 RID: 3717 RVA: 0x0005A3F8 File Offset: 0x000585F8
		public int actionId { get; set; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000E86 RID: 3718 RVA: 0x0005A401 File Offset: 0x00058601
		// (set) Token: 0x06000E87 RID: 3719 RVA: 0x0005A409 File Offset: 0x00058609
		public AxisRange axisRange { get; set; }

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000E88 RID: 3720 RVA: 0x0005A412 File Offset: 0x00058612
		// (set) Token: 0x06000E89 RID: 3721 RVA: 0x0005A41A File Offset: 0x0005861A
		public int actionElementMapId { get; set; }

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000E8A RID: 3722 RVA: 0x0005A423 File Offset: 0x00058623
		// (set) Token: 0x06000E8B RID: 3723 RVA: 0x0005A42B File Offset: 0x0005862B
		public ControllerType controllerType { get; set; }

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000E8C RID: 3724 RVA: 0x0005A434 File Offset: 0x00058634
		// (set) Token: 0x06000E8D RID: 3725 RVA: 0x0005A43C File Offset: 0x0005863C
		public int controllerId { get; set; }
	}
}
