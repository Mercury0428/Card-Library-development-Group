﻿using System;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A3 RID: 419
	[AddComponentMenu("")]
	public class ToggleInfo : InputFieldInfo
	{
	}
}
