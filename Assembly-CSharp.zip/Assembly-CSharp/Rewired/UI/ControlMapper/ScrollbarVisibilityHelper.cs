﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019F RID: 415
	[AddComponentMenu("")]
	public class ScrollbarVisibilityHelper : MonoBehaviour
	{
		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000ECD RID: 3789 RVA: 0x0005A990 File Offset: 0x00058B90
		private Scrollbar hScrollBar
		{
			get
			{
				if (!(this.scrollRect != null))
				{
					return null;
				}
				return this.scrollRect.horizontalScrollbar;
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000ECE RID: 3790 RVA: 0x0005A9AD File Offset: 0x00058BAD
		private Scrollbar vScrollBar
		{
			get
			{
				if (!(this.scrollRect != null))
				{
					return null;
				}
				return this.scrollRect.verticalScrollbar;
			}
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0005A9CA File Offset: 0x00058BCA
		private void Awake()
		{
			if (this.scrollRect != null)
			{
				this.target = this.scrollRect.gameObject.AddComponent<ScrollbarVisibilityHelper>();
				this.target.onlySendMessage = true;
				this.target.target = this;
			}
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0005AA08 File Offset: 0x00058C08
		private void OnRectTransformDimensionsChange()
		{
			if (this.onlySendMessage)
			{
				if (this.target != null)
				{
					this.target.ScrollRectTransformDimensionsChanged();
					return;
				}
			}
			else
			{
				this.EvaluateScrollbar();
			}
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x0005AA32 File Offset: 0x00058C32
		private void ScrollRectTransformDimensionsChanged()
		{
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x06000ED2 RID: 3794 RVA: 0x0005AA3C File Offset: 0x00058C3C
		private void EvaluateScrollbar()
		{
			if (this.scrollRect == null)
			{
				return;
			}
			if (this.vScrollBar == null && this.hScrollBar == null)
			{
				return;
			}
			if (!base.gameObject.activeInHierarchy)
			{
				return;
			}
			Rect rect = this.scrollRect.content.rect;
			Rect rect2 = (this.scrollRect.transform as RectTransform).rect;
			if (this.vScrollBar != null)
			{
				bool value = rect.height > rect2.height;
				this.SetActiveDeferred(this.vScrollBar.gameObject, value);
			}
			if (this.hScrollBar != null)
			{
				bool value2 = rect.width > rect2.width;
				this.SetActiveDeferred(this.hScrollBar.gameObject, value2);
			}
		}

		// Token: 0x06000ED3 RID: 3795 RVA: 0x0005AB14 File Offset: 0x00058D14
		private void SetActiveDeferred(GameObject obj, bool value)
		{
			base.StopAllCoroutines();
			base.StartCoroutine(this.SetActiveCoroutine(obj, value));
		}

		// Token: 0x06000ED4 RID: 3796 RVA: 0x0005AB2B File Offset: 0x00058D2B
		private IEnumerator SetActiveCoroutine(GameObject obj, bool value)
		{
			yield return null;
			if (obj != null)
			{
				obj.SetActive(value);
			}
			yield break;
		}

		// Token: 0x04000BD1 RID: 3025
		public ScrollRect scrollRect;

		// Token: 0x04000BD2 RID: 3026
		private bool onlySendMessage;

		// Token: 0x04000BD3 RID: 3027
		private ScrollbarVisibilityHelper target;
	}
}
