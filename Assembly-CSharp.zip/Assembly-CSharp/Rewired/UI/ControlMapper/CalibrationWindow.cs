﻿using System;
using System.Collections.Generic;
using Rewired.Integration.UnityUI;
using Rewired.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000193 RID: 403
	[AddComponentMenu("")]
	public class CalibrationWindow : Window
	{
		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000CD5 RID: 3285 RVA: 0x000525C1 File Offset: 0x000507C1
		private bool axisSelected
		{
			get
			{
				return this.joystick != null && this.selectedAxis >= 0 && this.selectedAxis < this.joystick.calibrationMap.axisCount;
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x06000CD6 RID: 3286 RVA: 0x000525F1 File Offset: 0x000507F1
		private AxisCalibration axisCalibration
		{
			get
			{
				if (!this.axisSelected)
				{
					return null;
				}
				return this.joystick.calibrationMap.GetAxis(this.selectedAxis);
			}
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x00052614 File Offset: 0x00050814
		public override void Initialize(int id, Func<int, bool> isFocusedCallback)
		{
			if (this.rightContentContainer == null || this.valueDisplayGroup == null || this.calibratedValueMarker == null || this.rawValueMarker == null || this.calibratedZeroMarker == null || this.deadzoneArea == null || this.deadzoneSlider == null || this.sensitivitySlider == null || this.zeroSlider == null || this.invertToggle == null || this.axisScrollAreaContent == null || this.doneButton == null || this.calibrateButton == null || this.axisButtonPrefab == null || this.doneButtonLabel == null || this.cancelButtonLabel == null || this.defaultButtonLabel == null || this.deadzoneSliderLabel == null || this.zeroSliderLabel == null || this.sensitivitySliderLabel == null || this.invertToggleLabel == null || this.calibrateButtonLabel == null)
			{
				Debug.LogError("Rewired Control Mapper: All inspector values must be assigned!");
				return;
			}
			this.axisButtons = new List<Button>();
			this.buttonCallbacks = new Dictionary<int, Action<int>>();
			this.doneButtonLabel.text = ControlMapper.GetLanguage().done;
			this.cancelButtonLabel.text = ControlMapper.GetLanguage().cancel;
			this.defaultButtonLabel.text = ControlMapper.GetLanguage().default_;
			this.deadzoneSliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_deadZoneSliderLabel;
			this.zeroSliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_zeroSliderLabel;
			this.sensitivitySliderLabel.text = ControlMapper.GetLanguage().calibrateWindow_sensitivitySliderLabel;
			this.invertToggleLabel.text = ControlMapper.GetLanguage().calibrateWindow_invertToggleLabel;
			this.calibrateButtonLabel.text = ControlMapper.GetLanguage().calibrateWindow_calibrateButtonLabel;
			base.Initialize(id, isFocusedCallback);
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x0005284C File Offset: 0x00050A4C
		public void SetJoystick(int playerId, Joystick joystick)
		{
			if (!base.initialized)
			{
				return;
			}
			this.playerId = playerId;
			this.joystick = joystick;
			if (joystick == null)
			{
				Debug.LogError("Rewired Control Mapper: Joystick cannot be null!");
				return;
			}
			float num = 0f;
			for (int i = 0; i < joystick.axisCount; i++)
			{
				int index = i;
				GameObject gameObject = UITools.InstantiateGUIObject<Button>(this.axisButtonPrefab, this.axisScrollAreaContent, "Axis" + i);
				Button button = gameObject.GetComponent<Button>();
				button.onClick.AddListener(delegate()
				{
					this.OnAxisSelected(index, button);
				});
				Text componentInSelfOrChildren = UnityTools.GetComponentInSelfOrChildren<Text>(gameObject);
				if (componentInSelfOrChildren != null)
				{
					componentInSelfOrChildren.text = joystick.AxisElementIdentifiers[i].name;
				}
				if (num == 0f)
				{
					num = UnityTools.GetComponentInSelfOrChildren<LayoutElement>(gameObject).minHeight;
				}
				this.axisButtons.Add(button);
			}
			float spacing = this.axisScrollAreaContent.GetComponent<VerticalLayoutGroup>().spacing;
			this.axisScrollAreaContent.sizeDelta = new Vector2(this.axisScrollAreaContent.sizeDelta.x, Mathf.Max((float)joystick.axisCount * (num + spacing) - spacing, this.axisScrollAreaContent.sizeDelta.y));
			this.origCalibrationData = joystick.calibrationMap.ToXmlString();
			this.displayAreaWidth = this.rightContentContainer.sizeDelta.x;
			this.rewiredStandaloneInputModule = base.gameObject.transform.root.GetComponentInChildren<RewiredStandaloneInputModule>();
			if (this.rewiredStandaloneInputModule != null)
			{
				this.menuHorizActionId = ReInput.mapping.GetActionId(this.rewiredStandaloneInputModule.horizontalAxis);
				this.menuVertActionId = ReInput.mapping.GetActionId(this.rewiredStandaloneInputModule.verticalAxis);
			}
			if (joystick.axisCount > 0)
			{
				this.SelectAxis(0);
			}
			base.defaultUIElement = this.doneButton.gameObject;
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x00052A52 File Offset: 0x00050C52
		public void SetButtonCallback(CalibrationWindow.ButtonIdentifier buttonIdentifier, Action<int> callback)
		{
			if (!base.initialized)
			{
				return;
			}
			if (callback == null)
			{
				return;
			}
			if (this.buttonCallbacks.ContainsKey((int)buttonIdentifier))
			{
				this.buttonCallbacks[(int)buttonIdentifier] = callback;
				return;
			}
			this.buttonCallbacks.Add((int)buttonIdentifier, callback);
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x00052A8C File Offset: 0x00050C8C
		public override void Cancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick != null)
			{
				this.joystick.ImportCalibrationMapFromXmlString(this.origCalibrationData);
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(1, out action))
			{
				if (this.cancelCallback != null)
				{
					this.cancelCallback();
				}
				return;
			}
			action(base.id);
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x00052AEC File Offset: 0x00050CEC
		protected override void Update()
		{
			if (!base.initialized)
			{
				return;
			}
			base.Update();
			this.UpdateDisplay();
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x00052B04 File Offset: 0x00050D04
		public void OnDone()
		{
			if (!base.initialized)
			{
				return;
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(0, out action))
			{
				return;
			}
			action(base.id);
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x00052B37 File Offset: 0x00050D37
		public void OnCancel()
		{
			this.Cancel();
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x00052B3F File Offset: 0x00050D3F
		public void OnRestoreDefault()
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick == null)
			{
				return;
			}
			this.joystick.calibrationMap.Reset();
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x00052B70 File Offset: 0x00050D70
		public void OnCalibrate()
		{
			if (!base.initialized)
			{
				return;
			}
			Action<int> action;
			if (!this.buttonCallbacks.TryGetValue(3, out action))
			{
				return;
			}
			action(this.selectedAxis);
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x00052BA3 File Offset: 0x00050DA3
		public void OnInvert(bool state)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.invert = state;
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x00052BC3 File Offset: 0x00050DC3
		public void OnZeroValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.calibratedZero = value;
			this.RedrawCalibratedZero();
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x00052BE9 File Offset: 0x00050DE9
		public void OnZeroCancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.calibratedZero = this.origSelectedAxisCalibrationData.zero;
			this.RedrawCalibratedZero();
			this.RefreshControls();
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x00052C20 File Offset: 0x00050E20
		public void OnDeadzoneValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.deadZone = Mathf.Clamp(value, 0f, 0.8f);
			if (value > 0.8f)
			{
				this.deadzoneSlider.value = 0.8f;
			}
			this.RedrawDeadzone();
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x00052C78 File Offset: 0x00050E78
		public void OnDeadzoneCancel()
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.deadZone = this.origSelectedAxisCalibrationData.deadZone;
			this.RedrawDeadzone();
			this.RefreshControls();
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x00052CB0 File Offset: 0x00050EB0
		public void OnSensitivityValueChange(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.sensitivity = Mathf.Clamp(value, this.minSensitivity, float.PositiveInfinity);
			if (value < this.minSensitivity)
			{
				this.sensitivitySlider.value = this.minSensitivity;
			}
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x00052D05 File Offset: 0x00050F05
		public void OnSensitivityCancel(float value)
		{
			if (!base.initialized)
			{
				return;
			}
			if (!this.axisSelected)
			{
				return;
			}
			this.axisCalibration.sensitivity = this.origSelectedAxisCalibrationData.sensitivity;
			this.RefreshControls();
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x00052D35 File Offset: 0x00050F35
		public void OnAxisScrollRectScroll(Vector2 pos)
		{
			bool initialized = base.initialized;
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x00052D3E File Offset: 0x00050F3E
		private void OnAxisSelected(int axisIndex, Button button)
		{
			if (!base.initialized)
			{
				return;
			}
			if (this.joystick == null)
			{
				return;
			}
			this.SelectAxis(axisIndex);
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x00052D65 File Offset: 0x00050F65
		private void UpdateDisplay()
		{
			this.RedrawValueMarkers();
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x00052D6D File Offset: 0x00050F6D
		private void Redraw()
		{
			this.RedrawCalibratedZero();
			this.RedrawValueMarkers();
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x00052D7C File Offset: 0x00050F7C
		private void RefreshControls()
		{
			if (!this.axisSelected)
			{
				this.deadzoneSlider.value = 0f;
				this.zeroSlider.value = 0f;
				this.sensitivitySlider.value = 0f;
				this.invertToggle.isOn = false;
				return;
			}
			this.deadzoneSlider.value = this.axisCalibration.deadZone;
			this.zeroSlider.value = this.axisCalibration.calibratedZero;
			this.sensitivitySlider.value = this.axisCalibration.sensitivity;
			this.invertToggle.isOn = this.axisCalibration.invert;
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x00052E28 File Offset: 0x00051028
		private void RedrawDeadzone()
		{
			if (!this.axisSelected)
			{
				return;
			}
			float x = this.displayAreaWidth * this.axisCalibration.deadZone;
			this.deadzoneArea.sizeDelta = new Vector2(x, this.deadzoneArea.sizeDelta.y);
			this.deadzoneArea.anchoredPosition = new Vector2(this.axisCalibration.calibratedZero * -this.deadzoneArea.parent.localPosition.x, this.deadzoneArea.anchoredPosition.y);
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x00052EB4 File Offset: 0x000510B4
		private void RedrawCalibratedZero()
		{
			if (!this.axisSelected)
			{
				return;
			}
			this.calibratedZeroMarker.anchoredPosition = new Vector2(this.axisCalibration.calibratedZero * -this.deadzoneArea.parent.localPosition.x, this.calibratedZeroMarker.anchoredPosition.y);
			this.RedrawDeadzone();
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x00052F14 File Offset: 0x00051114
		private void RedrawValueMarkers()
		{
			if (!this.axisSelected)
			{
				this.calibratedValueMarker.anchoredPosition = new Vector2(0f, this.calibratedValueMarker.anchoredPosition.y);
				this.rawValueMarker.anchoredPosition = new Vector2(0f, this.rawValueMarker.anchoredPosition.y);
				return;
			}
			float axis = this.joystick.GetAxis(this.selectedAxis);
			float num = Mathf.Clamp(this.joystick.GetAxisRaw(this.selectedAxis), -1f, 1f);
			this.calibratedValueMarker.anchoredPosition = new Vector2(this.displayAreaWidth * 0.5f * axis, this.calibratedValueMarker.anchoredPosition.y);
			this.rawValueMarker.anchoredPosition = new Vector2(this.displayAreaWidth * 0.5f * num, this.rawValueMarker.anchoredPosition.y);
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x00053004 File Offset: 0x00051204
		private void SelectAxis(int index)
		{
			if (index < 0 || index >= this.axisButtons.Count)
			{
				return;
			}
			if (this.axisButtons[index] == null)
			{
				return;
			}
			this.axisButtons[index].interactable = false;
			this.axisButtons[index].Select();
			for (int i = 0; i < this.axisButtons.Count; i++)
			{
				if (i != index)
				{
					this.axisButtons[i].interactable = true;
				}
			}
			this.selectedAxis = index;
			this.origSelectedAxisCalibrationData = this.axisCalibration.GetData();
			this.SetMinSensitivity();
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x000530A6 File Offset: 0x000512A6
		public override void TakeInputFocus()
		{
			base.TakeInputFocus();
			if (this.selectedAxis >= 0)
			{
				this.SelectAxis(this.selectedAxis);
			}
			this.RefreshControls();
			this.Redraw();
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x000530D0 File Offset: 0x000512D0
		private void SetMinSensitivity()
		{
			if (!this.axisSelected)
			{
				return;
			}
			this.minSensitivity = 0.1f;
			if (this.rewiredStandaloneInputModule != null)
			{
				if (this.IsMenuAxis(this.menuHorizActionId, this.selectedAxis))
				{
					this.GetAxisButtonDeadZone(this.playerId, this.menuHorizActionId, ref this.minSensitivity);
					return;
				}
				if (this.IsMenuAxis(this.menuVertActionId, this.selectedAxis))
				{
					this.GetAxisButtonDeadZone(this.playerId, this.menuVertActionId, ref this.minSensitivity);
				}
			}
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x00053158 File Offset: 0x00051358
		private bool IsMenuAxis(int actionId, int axisIndex)
		{
			if (this.rewiredStandaloneInputModule == null)
			{
				return false;
			}
			IList<Player> allPlayers = ReInput.players.AllPlayers;
			int count = allPlayers.Count;
			for (int i = 0; i < count; i++)
			{
				IList<JoystickMap> maps = allPlayers[i].controllers.maps.GetMaps<JoystickMap>(this.joystick.id);
				if (maps != null)
				{
					int count2 = maps.Count;
					for (int j = 0; j < count2; j++)
					{
						IList<ActionElementMap> axisMaps = maps[j].AxisMaps;
						if (axisMaps != null)
						{
							int count3 = axisMaps.Count;
							for (int k = 0; k < count3; k++)
							{
								ActionElementMap actionElementMap = axisMaps[k];
								if (actionElementMap.actionId == actionId && actionElementMap.elementIndex == axisIndex)
								{
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x00053228 File Offset: 0x00051428
		private void GetAxisButtonDeadZone(int playerId, int actionId, ref float value)
		{
			InputAction action = ReInput.mapping.GetAction(actionId);
			if (action == null)
			{
				return;
			}
			int behaviorId = action.behaviorId;
			InputBehavior inputBehavior = ReInput.mapping.GetInputBehavior(playerId, behaviorId);
			if (inputBehavior == null)
			{
				return;
			}
			value = inputBehavior.buttonDeadZone + 0.1f;
		}

		// Token: 0x04000AE5 RID: 2789
		private const float minSensitivityOtherAxes = 0.1f;

		// Token: 0x04000AE6 RID: 2790
		private const float maxDeadzone = 0.8f;

		// Token: 0x04000AE7 RID: 2791
		[SerializeField]
		private RectTransform rightContentContainer;

		// Token: 0x04000AE8 RID: 2792
		[SerializeField]
		private RectTransform valueDisplayGroup;

		// Token: 0x04000AE9 RID: 2793
		[SerializeField]
		private RectTransform calibratedValueMarker;

		// Token: 0x04000AEA RID: 2794
		[SerializeField]
		private RectTransform rawValueMarker;

		// Token: 0x04000AEB RID: 2795
		[SerializeField]
		private RectTransform calibratedZeroMarker;

		// Token: 0x04000AEC RID: 2796
		[SerializeField]
		private RectTransform deadzoneArea;

		// Token: 0x04000AED RID: 2797
		[SerializeField]
		private Slider deadzoneSlider;

		// Token: 0x04000AEE RID: 2798
		[SerializeField]
		private Slider zeroSlider;

		// Token: 0x04000AEF RID: 2799
		[SerializeField]
		private Slider sensitivitySlider;

		// Token: 0x04000AF0 RID: 2800
		[SerializeField]
		private Toggle invertToggle;

		// Token: 0x04000AF1 RID: 2801
		[SerializeField]
		private RectTransform axisScrollAreaContent;

		// Token: 0x04000AF2 RID: 2802
		[SerializeField]
		private Button doneButton;

		// Token: 0x04000AF3 RID: 2803
		[SerializeField]
		private Button calibrateButton;

		// Token: 0x04000AF4 RID: 2804
		[SerializeField]
		private Text doneButtonLabel;

		// Token: 0x04000AF5 RID: 2805
		[SerializeField]
		private Text cancelButtonLabel;

		// Token: 0x04000AF6 RID: 2806
		[SerializeField]
		private Text defaultButtonLabel;

		// Token: 0x04000AF7 RID: 2807
		[SerializeField]
		private Text deadzoneSliderLabel;

		// Token: 0x04000AF8 RID: 2808
		[SerializeField]
		private Text zeroSliderLabel;

		// Token: 0x04000AF9 RID: 2809
		[SerializeField]
		private Text sensitivitySliderLabel;

		// Token: 0x04000AFA RID: 2810
		[SerializeField]
		private Text invertToggleLabel;

		// Token: 0x04000AFB RID: 2811
		[SerializeField]
		private Text calibrateButtonLabel;

		// Token: 0x04000AFC RID: 2812
		[SerializeField]
		private GameObject axisButtonPrefab;

		// Token: 0x04000AFD RID: 2813
		private Joystick joystick;

		// Token: 0x04000AFE RID: 2814
		private string origCalibrationData;

		// Token: 0x04000AFF RID: 2815
		private int selectedAxis = -1;

		// Token: 0x04000B00 RID: 2816
		private AxisCalibrationData origSelectedAxisCalibrationData;

		// Token: 0x04000B01 RID: 2817
		private float displayAreaWidth;

		// Token: 0x04000B02 RID: 2818
		private List<Button> axisButtons;

		// Token: 0x04000B03 RID: 2819
		private Dictionary<int, Action<int>> buttonCallbacks;

		// Token: 0x04000B04 RID: 2820
		private int playerId;

		// Token: 0x04000B05 RID: 2821
		private RewiredStandaloneInputModule rewiredStandaloneInputModule;

		// Token: 0x04000B06 RID: 2822
		private int menuHorizActionId = -1;

		// Token: 0x04000B07 RID: 2823
		private int menuVertActionId = -1;

		// Token: 0x04000B08 RID: 2824
		private float minSensitivity;

		// Token: 0x02000360 RID: 864
		public enum ButtonIdentifier
		{
			// Token: 0x04001287 RID: 4743
			Done,
			// Token: 0x04001288 RID: 4744
			Cancel,
			// Token: 0x04001289 RID: 4745
			Default,
			// Token: 0x0400128A RID: 4746
			Calibrate
		}
	}
}
