﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000194 RID: 404
	[AddComponentMenu("")]
	public class CanvasScalerExt : CanvasScaler
	{
		// Token: 0x06000CF5 RID: 3317 RVA: 0x00053288 File Offset: 0x00051488
		public void ForceRefresh()
		{
			this.Handle();
		}
	}
}
