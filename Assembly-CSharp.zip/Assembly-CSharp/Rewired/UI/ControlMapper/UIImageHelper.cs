﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A8 RID: 424
	[AddComponentMenu("")]
	[RequireComponent(typeof(Image))]
	public class UIImageHelper : MonoBehaviour
	{
		// Token: 0x06000EFB RID: 3835 RVA: 0x0005B3E0 File Offset: 0x000595E0
		public void SetEnabledState(bool newState)
		{
			this.currentState = newState;
			UIImageHelper.State state = newState ? this.enabledState : this.disabledState;
			if (state == null)
			{
				return;
			}
			Image component = base.gameObject.GetComponent<Image>();
			if (component == null)
			{
				Debug.LogError("Image is missing!");
				return;
			}
			state.Set(component);
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0005B431 File Offset: 0x00059631
		public void SetEnabledStateColor(Color color)
		{
			this.enabledState.color = color;
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0005B43F File Offset: 0x0005963F
		public void SetDisabledStateColor(Color color)
		{
			this.disabledState.color = color;
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x0005B450 File Offset: 0x00059650
		public void Refresh()
		{
			UIImageHelper.State state = this.currentState ? this.enabledState : this.disabledState;
			Image component = base.gameObject.GetComponent<Image>();
			if (component == null)
			{
				return;
			}
			state.Set(component);
		}

		// Token: 0x04000BF4 RID: 3060
		[SerializeField]
		private UIImageHelper.State enabledState;

		// Token: 0x04000BF5 RID: 3061
		[SerializeField]
		private UIImageHelper.State disabledState;

		// Token: 0x04000BF6 RID: 3062
		private bool currentState;

		// Token: 0x0200038E RID: 910
		[Serializable]
		private class State
		{
			// Token: 0x06001834 RID: 6196 RVA: 0x00076226 File Offset: 0x00074426
			public void Set(Image image)
			{
				if (image == null)
				{
					return;
				}
				image.color = this.color;
			}

			// Token: 0x04001373 RID: 4979
			[SerializeField]
			public Color color;
		}
	}
}
