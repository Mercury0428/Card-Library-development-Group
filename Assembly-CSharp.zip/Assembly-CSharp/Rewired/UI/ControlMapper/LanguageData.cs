﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x0200019E RID: 414
	public class LanguageData : ScriptableObject
	{
		// Token: 0x06000E94 RID: 3732 RVA: 0x0005A4A1 File Offset: 0x000586A1
		public void Initialize()
		{
			if (this._initialized)
			{
				return;
			}
			this.customDict = LanguageData.CustomEntry.ToDictionary(this._customEntries);
			this._initialized = true;
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x0005A4C4 File Offset: 0x000586C4
		public string GetCustomEntry(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				return string.Empty;
			}
			string result;
			if (!this.customDict.TryGetValue(key, out result))
			{
				return string.Empty;
			}
			return result;
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0005A4F6 File Offset: 0x000586F6
		public bool ContainsCustomEntryKey(string key)
		{
			return !string.IsNullOrEmpty(key) && this.customDict.ContainsKey(key);
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000E97 RID: 3735 RVA: 0x0005A50E File Offset: 0x0005870E
		public string yes
		{
			get
			{
				return this._yes;
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000E98 RID: 3736 RVA: 0x0005A516 File Offset: 0x00058716
		public string no
		{
			get
			{
				return this._no;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000E99 RID: 3737 RVA: 0x0005A51E File Offset: 0x0005871E
		public string add
		{
			get
			{
				return this._add;
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000E9A RID: 3738 RVA: 0x0005A526 File Offset: 0x00058726
		public string replace
		{
			get
			{
				return this._replace;
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000E9B RID: 3739 RVA: 0x0005A52E File Offset: 0x0005872E
		public string remove
		{
			get
			{
				return this._remove;
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000E9C RID: 3740 RVA: 0x0005A536 File Offset: 0x00058736
		public string cancel
		{
			get
			{
				return this._cancel;
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000E9D RID: 3741 RVA: 0x0005A53E File Offset: 0x0005873E
		public string none
		{
			get
			{
				return this._none;
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000E9E RID: 3742 RVA: 0x0005A546 File Offset: 0x00058746
		public string okay
		{
			get
			{
				return this._okay;
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000E9F RID: 3743 RVA: 0x0005A54E File Offset: 0x0005874E
		public string done
		{
			get
			{
				return this._done;
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000EA0 RID: 3744 RVA: 0x0005A556 File Offset: 0x00058756
		public string default_
		{
			get
			{
				return this._default;
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000EA1 RID: 3745 RVA: 0x0005A55E File Offset: 0x0005875E
		public string assignControllerWindowTitle
		{
			get
			{
				return this._assignControllerWindowTitle;
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000EA2 RID: 3746 RVA: 0x0005A566 File Offset: 0x00058766
		public string assignControllerWindowMessage
		{
			get
			{
				return this._assignControllerWindowMessage;
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000EA3 RID: 3747 RVA: 0x0005A56E File Offset: 0x0005876E
		public string controllerAssignmentConflictWindowTitle
		{
			get
			{
				return this._controllerAssignmentConflictWindowTitle;
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000EA4 RID: 3748 RVA: 0x0005A576 File Offset: 0x00058776
		public string elementAssignmentPrePollingWindowMessage
		{
			get
			{
				return this._elementAssignmentPrePollingWindowMessage;
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000EA5 RID: 3749 RVA: 0x0005A57E File Offset: 0x0005877E
		public string elementAssignmentConflictWindowMessage
		{
			get
			{
				return this._elementAssignmentConflictWindowMessage;
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000EA6 RID: 3750 RVA: 0x0005A586 File Offset: 0x00058786
		public string mouseAssignmentConflictWindowTitle
		{
			get
			{
				return this._mouseAssignmentConflictWindowTitle;
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000EA7 RID: 3751 RVA: 0x0005A58E File Offset: 0x0005878E
		public string calibrateControllerWindowTitle
		{
			get
			{
				return this._calibrateControllerWindowTitle;
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x0005A596 File Offset: 0x00058796
		public string calibrateAxisStep1WindowTitle
		{
			get
			{
				return this._calibrateAxisStep1WindowTitle;
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x0005A59E File Offset: 0x0005879E
		public string calibrateAxisStep2WindowTitle
		{
			get
			{
				return this._calibrateAxisStep2WindowTitle;
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000EAA RID: 3754 RVA: 0x0005A5A6 File Offset: 0x000587A6
		public string inputBehaviorSettingsWindowTitle
		{
			get
			{
				return this._inputBehaviorSettingsWindowTitle;
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000EAB RID: 3755 RVA: 0x0005A5AE File Offset: 0x000587AE
		public string restoreDefaultsWindowTitle
		{
			get
			{
				return this._restoreDefaultsWindowTitle;
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000EAC RID: 3756 RVA: 0x0005A5B6 File Offset: 0x000587B6
		public string actionColumnLabel
		{
			get
			{
				return this._actionColumnLabel;
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000EAD RID: 3757 RVA: 0x0005A5BE File Offset: 0x000587BE
		public string keyboardColumnLabel
		{
			get
			{
				return this._keyboardColumnLabel;
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000EAE RID: 3758 RVA: 0x0005A5C6 File Offset: 0x000587C6
		public string mouseColumnLabel
		{
			get
			{
				return this._mouseColumnLabel;
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000EAF RID: 3759 RVA: 0x0005A5CE File Offset: 0x000587CE
		public string controllerColumnLabel
		{
			get
			{
				return this._controllerColumnLabel;
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000EB0 RID: 3760 RVA: 0x0005A5D6 File Offset: 0x000587D6
		public string removeControllerButtonLabel
		{
			get
			{
				return this._removeControllerButtonLabel;
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000EB1 RID: 3761 RVA: 0x0005A5DE File Offset: 0x000587DE
		public string calibrateControllerButtonLabel
		{
			get
			{
				return this._calibrateControllerButtonLabel;
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000EB2 RID: 3762 RVA: 0x0005A5E6 File Offset: 0x000587E6
		public string assignControllerButtonLabel
		{
			get
			{
				return this._assignControllerButtonLabel;
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000EB3 RID: 3763 RVA: 0x0005A5EE File Offset: 0x000587EE
		public string inputBehaviorSettingsButtonLabel
		{
			get
			{
				return this._inputBehaviorSettingsButtonLabel;
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000EB4 RID: 3764 RVA: 0x0005A5F6 File Offset: 0x000587F6
		public string doneButtonLabel
		{
			get
			{
				return this._doneButtonLabel;
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x0005A5FE File Offset: 0x000587FE
		public string restoreDefaultsButtonLabel
		{
			get
			{
				return this._restoreDefaultsButtonLabel;
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000EB6 RID: 3766 RVA: 0x0005A606 File Offset: 0x00058806
		public string controllerSettingsGroupLabel
		{
			get
			{
				return this._controllerSettingsGroupLabel;
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x0005A60E File Offset: 0x0005880E
		public string playersGroupLabel
		{
			get
			{
				return this._playersGroupLabel;
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000EB8 RID: 3768 RVA: 0x0005A616 File Offset: 0x00058816
		public string assignedControllersGroupLabel
		{
			get
			{
				return this._assignedControllersGroupLabel;
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x0005A61E File Offset: 0x0005881E
		public string settingsGroupLabel
		{
			get
			{
				return this._settingsGroupLabel;
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000EBA RID: 3770 RVA: 0x0005A626 File Offset: 0x00058826
		public string mapCategoriesGroupLabel
		{
			get
			{
				return this._mapCategoriesGroupLabel;
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000EBB RID: 3771 RVA: 0x0005A62E File Offset: 0x0005882E
		public string restoreDefaultsWindowMessage
		{
			get
			{
				if (ReInput.players.playerCount > 1)
				{
					return this._restoreDefaultsWindowMessage_multiPlayer;
				}
				return this._restoreDefaultsWindowMessage_onePlayer;
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000EBC RID: 3772 RVA: 0x0005A64A File Offset: 0x0005884A
		public string calibrateWindow_deadZoneSliderLabel
		{
			get
			{
				return this._calibrateWindow_deadZoneSliderLabel;
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000EBD RID: 3773 RVA: 0x0005A652 File Offset: 0x00058852
		public string calibrateWindow_zeroSliderLabel
		{
			get
			{
				return this._calibrateWindow_zeroSliderLabel;
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000EBE RID: 3774 RVA: 0x0005A65A File Offset: 0x0005885A
		public string calibrateWindow_sensitivitySliderLabel
		{
			get
			{
				return this._calibrateWindow_sensitivitySliderLabel;
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000EBF RID: 3775 RVA: 0x0005A662 File Offset: 0x00058862
		public string calibrateWindow_invertToggleLabel
		{
			get
			{
				return this._calibrateWindow_invertToggleLabel;
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000EC0 RID: 3776 RVA: 0x0005A66A File Offset: 0x0005886A
		public string calibrateWindow_calibrateButtonLabel
		{
			get
			{
				return this._calibrateWindow_calibrateButtonLabel;
			}
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x0005A672 File Offset: 0x00058872
		public string GetControllerAssignmentConflictWindowMessage(string joystickName, string otherPlayerName, string currentPlayerName)
		{
			return string.Format(this._controllerAssignmentConflictWindowMessage, joystickName, otherPlayerName, currentPlayerName);
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0005A682 File Offset: 0x00058882
		public string GetJoystickElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._joystickElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0005A690 File Offset: 0x00058890
		public string GetJoystickElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName)
		{
			return string.Format(this._joystickElementAssignmentPollingWindowMessage_fullAxisFieldOnly, actionName);
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0005A69E File Offset: 0x0005889E
		public string GetKeyboardElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._keyboardElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0005A6AC File Offset: 0x000588AC
		public string GetMouseElementAssignmentPollingWindowMessage(string actionName)
		{
			return string.Format(this._mouseElementAssignmentPollingWindowMessage, actionName);
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0005A6BA File Offset: 0x000588BA
		public string GetMouseElementAssignmentPollingWindowMessage_FullAxisFieldOnly(string actionName)
		{
			return string.Format(this._mouseElementAssignmentPollingWindowMessage_fullAxisFieldOnly, actionName);
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0005A6C8 File Offset: 0x000588C8
		public string GetElementAlreadyInUseBlocked(string elementName)
		{
			return string.Format(this._elementAlreadyInUseBlocked, elementName);
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0005A6D6 File Offset: 0x000588D6
		public string GetElementAlreadyInUseCanReplace(string elementName, bool allowConflicts)
		{
			if (!allowConflicts)
			{
				return string.Format(this._elementAlreadyInUseCanReplace, elementName);
			}
			return string.Format(this._elementAlreadyInUseCanReplace_conflictAllowed, elementName);
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0005A6F4 File Offset: 0x000588F4
		public string GetMouseAssignmentConflictWindowMessage(string otherPlayerName, string thisPlayerName)
		{
			return string.Format(this._mouseAssignmentConflictWindowMessage, otherPlayerName, thisPlayerName);
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0005A703 File Offset: 0x00058903
		public string GetCalibrateAxisStep1WindowMessage(string axisName)
		{
			return string.Format(this._calibrateAxisStep1WindowMessage, axisName);
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0005A711 File Offset: 0x00058911
		public string GetCalibrateAxisStep2WindowMessage(string axisName)
		{
			return string.Format(this._calibrateAxisStep2WindowMessage, axisName);
		}

		// Token: 0x04000B97 RID: 2967
		[SerializeField]
		private string _yes = "Yes";

		// Token: 0x04000B98 RID: 2968
		[SerializeField]
		private string _no = "No";

		// Token: 0x04000B99 RID: 2969
		[SerializeField]
		private string _add = "Add";

		// Token: 0x04000B9A RID: 2970
		[SerializeField]
		private string _replace = "Replace";

		// Token: 0x04000B9B RID: 2971
		[SerializeField]
		private string _remove = "Remove";

		// Token: 0x04000B9C RID: 2972
		[SerializeField]
		private string _cancel = "Cancel";

		// Token: 0x04000B9D RID: 2973
		[SerializeField]
		private string _none = "None";

		// Token: 0x04000B9E RID: 2974
		[SerializeField]
		private string _okay = "Okay";

		// Token: 0x04000B9F RID: 2975
		[SerializeField]
		private string _done = "Done";

		// Token: 0x04000BA0 RID: 2976
		[SerializeField]
		private string _default = "Default";

		// Token: 0x04000BA1 RID: 2977
		[SerializeField]
		private string _assignControllerWindowTitle = "Choose Controller";

		// Token: 0x04000BA2 RID: 2978
		[SerializeField]
		private string _assignControllerWindowMessage = "Press any button or move an axis on the controller you would like to use.";

		// Token: 0x04000BA3 RID: 2979
		[SerializeField]
		private string _controllerAssignmentConflictWindowTitle = "Controller Assignment";

		// Token: 0x04000BA4 RID: 2980
		[SerializeField]
		[Tooltip("{0} = Joystick Name\n{1} = Other Player Name\n{2} = This Player Name")]
		private string _controllerAssignmentConflictWindowMessage = "{0} is already assigned to {1}. Do you want to assign this controller to {2} instead?";

		// Token: 0x04000BA5 RID: 2981
		[SerializeField]
		private string _elementAssignmentPrePollingWindowMessage = "First center or zero all sticks and axes and press any button or wait for the timer to finish.";

		// Token: 0x04000BA6 RID: 2982
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _joystickElementAssignmentPollingWindowMessage = "Now press a button or move an axis to assign it to {0}.";

		// Token: 0x04000BA7 RID: 2983
		[SerializeField]
		[Tooltip("This text is only displayed when split-axis fields have been disabled and the user clicks on the full-axis field. Button/key/D-pad input cannot be assigned to a full-axis field.\n{0} = Action Name")]
		private string _joystickElementAssignmentPollingWindowMessage_fullAxisFieldOnly = "Now move an axis to assign it to {0}.";

		// Token: 0x04000BA8 RID: 2984
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _keyboardElementAssignmentPollingWindowMessage = "Press a key to assign it to {0}. Modifier keys may also be used. To assign a modifier key alone, hold it down for 1 second.";

		// Token: 0x04000BA9 RID: 2985
		[SerializeField]
		[Tooltip("{0} = Action Name")]
		private string _mouseElementAssignmentPollingWindowMessage = "Press a mouse button or move an axis to assign it to {0}.";

		// Token: 0x04000BAA RID: 2986
		[SerializeField]
		[Tooltip("This text is only displayed when split-axis fields have been disabled and the user clicks on the full-axis field. Button/key/D-pad input cannot be assigned to a full-axis field.\n{0} = Action Name")]
		private string _mouseElementAssignmentPollingWindowMessage_fullAxisFieldOnly = "Move an axis to assign it to {0}.";

		// Token: 0x04000BAB RID: 2987
		[SerializeField]
		private string _elementAssignmentConflictWindowMessage = "Assignment Conflict";

		// Token: 0x04000BAC RID: 2988
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseBlocked = "{0} is already in use cannot be replaced.";

		// Token: 0x04000BAD RID: 2989
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseCanReplace = "{0} is already in use. Do you want to replace it?";

		// Token: 0x04000BAE RID: 2990
		[SerializeField]
		[Tooltip("{0} = Element Name")]
		private string _elementAlreadyInUseCanReplace_conflictAllowed = "{0} is already in use. Do you want to replace it? You may also choose to add the assignment anyway.";

		// Token: 0x04000BAF RID: 2991
		[SerializeField]
		private string _mouseAssignmentConflictWindowTitle = "Mouse Assignment";

		// Token: 0x04000BB0 RID: 2992
		[SerializeField]
		[Tooltip("{0} = Other Player Name\n{1} = This Player Name")]
		private string _mouseAssignmentConflictWindowMessage = "The mouse is already assigned to {0}. Do you want to assign the mouse to {1} instead?";

		// Token: 0x04000BB1 RID: 2993
		[SerializeField]
		private string _calibrateControllerWindowTitle = "Calibrate Controller";

		// Token: 0x04000BB2 RID: 2994
		[SerializeField]
		private string _calibrateAxisStep1WindowTitle = "Calibrate Zero";

		// Token: 0x04000BB3 RID: 2995
		[SerializeField]
		[Tooltip("{0} = Axis Name")]
		private string _calibrateAxisStep1WindowMessage = "Center or zero {0} and press any button or wait for the timer to finish.";

		// Token: 0x04000BB4 RID: 2996
		[SerializeField]
		private string _calibrateAxisStep2WindowTitle = "Calibrate Range";

		// Token: 0x04000BB5 RID: 2997
		[SerializeField]
		[Tooltip("{0} = Axis Name")]
		private string _calibrateAxisStep2WindowMessage = "Move {0} through its entire range then press any button or wait for the timer to finish.";

		// Token: 0x04000BB6 RID: 2998
		[SerializeField]
		private string _inputBehaviorSettingsWindowTitle = "Sensitivity Settings";

		// Token: 0x04000BB7 RID: 2999
		[SerializeField]
		private string _restoreDefaultsWindowTitle = "Restore Defaults";

		// Token: 0x04000BB8 RID: 3000
		[SerializeField]
		[Tooltip("Message for a single player game.")]
		private string _restoreDefaultsWindowMessage_onePlayer = "This will restore the default input configuration. Are you sure you want to do this?";

		// Token: 0x04000BB9 RID: 3001
		[SerializeField]
		[Tooltip("Message for a multi-player game.")]
		private string _restoreDefaultsWindowMessage_multiPlayer = "This will restore the default input configuration for all players. Are you sure you want to do this?";

		// Token: 0x04000BBA RID: 3002
		[SerializeField]
		private string _actionColumnLabel = "Actions";

		// Token: 0x04000BBB RID: 3003
		[SerializeField]
		private string _keyboardColumnLabel = "Keyboard";

		// Token: 0x04000BBC RID: 3004
		[SerializeField]
		private string _mouseColumnLabel = "Mouse";

		// Token: 0x04000BBD RID: 3005
		[SerializeField]
		private string _controllerColumnLabel = "Controller";

		// Token: 0x04000BBE RID: 3006
		[SerializeField]
		private string _removeControllerButtonLabel = "Remove";

		// Token: 0x04000BBF RID: 3007
		[SerializeField]
		private string _calibrateControllerButtonLabel = "Calibrate";

		// Token: 0x04000BC0 RID: 3008
		[SerializeField]
		private string _assignControllerButtonLabel = "Assign Controller";

		// Token: 0x04000BC1 RID: 3009
		[SerializeField]
		private string _inputBehaviorSettingsButtonLabel = "Sensitivity";

		// Token: 0x04000BC2 RID: 3010
		[SerializeField]
		private string _doneButtonLabel = "Done";

		// Token: 0x04000BC3 RID: 3011
		[SerializeField]
		private string _restoreDefaultsButtonLabel = "Restore Defaults";

		// Token: 0x04000BC4 RID: 3012
		[SerializeField]
		private string _playersGroupLabel = "Players:";

		// Token: 0x04000BC5 RID: 3013
		[SerializeField]
		private string _controllerSettingsGroupLabel = "Controller:";

		// Token: 0x04000BC6 RID: 3014
		[SerializeField]
		private string _assignedControllersGroupLabel = "Assigned Controllers:";

		// Token: 0x04000BC7 RID: 3015
		[SerializeField]
		private string _settingsGroupLabel = "Settings:";

		// Token: 0x04000BC8 RID: 3016
		[SerializeField]
		private string _mapCategoriesGroupLabel = "Categories:";

		// Token: 0x04000BC9 RID: 3017
		[SerializeField]
		private string _calibrateWindow_deadZoneSliderLabel = "Dead Zone:";

		// Token: 0x04000BCA RID: 3018
		[SerializeField]
		private string _calibrateWindow_zeroSliderLabel = "Zero:";

		// Token: 0x04000BCB RID: 3019
		[SerializeField]
		private string _calibrateWindow_sensitivitySliderLabel = "Sensitivity:";

		// Token: 0x04000BCC RID: 3020
		[SerializeField]
		private string _calibrateWindow_invertToggleLabel = "Invert";

		// Token: 0x04000BCD RID: 3021
		[SerializeField]
		private string _calibrateWindow_calibrateButtonLabel = "Calibrate";

		// Token: 0x04000BCE RID: 3022
		[SerializeField]
		private LanguageData.CustomEntry[] _customEntries;

		// Token: 0x04000BCF RID: 3023
		private bool _initialized;

		// Token: 0x04000BD0 RID: 3024
		private Dictionary<string, string> customDict;

		// Token: 0x02000380 RID: 896
		[Serializable]
		private class CustomEntry
		{
			// Token: 0x060017DB RID: 6107 RVA: 0x00002050 File Offset: 0x00000250
			public CustomEntry()
			{
			}

			// Token: 0x060017DC RID: 6108 RVA: 0x00075A7D File Offset: 0x00073C7D
			public CustomEntry(string key, string value)
			{
				this.key = key;
				this.value = value;
			}

			// Token: 0x060017DD RID: 6109 RVA: 0x00075A94 File Offset: 0x00073C94
			public static Dictionary<string, string> ToDictionary(LanguageData.CustomEntry[] array)
			{
				if (array == null)
				{
					return new Dictionary<string, string>();
				}
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i] != null && !string.IsNullOrEmpty(array[i].key) && !string.IsNullOrEmpty(array[i].value))
					{
						if (dictionary.ContainsKey(array[i].key))
						{
							Debug.LogError("Key \"" + array[i].key + "\" is already in dictionary!");
						}
						else
						{
							dictionary.Add(array[i].key, array[i].value);
						}
					}
				}
				return dictionary;
			}

			// Token: 0x04001339 RID: 4921
			public string key;

			// Token: 0x0400133A RID: 4922
			public string value;
		}
	}
}
