﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A2 RID: 418
	[Serializable]
	public class ThemeSettings : ScriptableObject
	{
		// Token: 0x06000EDE RID: 3806 RVA: 0x0005AD08 File Offset: 0x00058F08
		public void Apply(ThemedElement.ElementInfo[] elementInfo)
		{
			if (elementInfo == null)
			{
				return;
			}
			for (int i = 0; i < elementInfo.Length; i++)
			{
				if (elementInfo[i] != null)
				{
					this.Apply(elementInfo[i].themeClass, elementInfo[i].component);
				}
			}
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x0005AD44 File Offset: 0x00058F44
		private void Apply(string themeClass, Component component)
		{
			if (component as Selectable != null)
			{
				this.Apply(themeClass, (Selectable)component);
				return;
			}
			if (component as Image != null)
			{
				this.Apply(themeClass, (Image)component);
				return;
			}
			if (component as Text != null)
			{
				this.Apply(themeClass, (Text)component);
				return;
			}
			if (component as UIImageHelper != null)
			{
				this.Apply(themeClass, (UIImageHelper)component);
				return;
			}
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x0005ADC4 File Offset: 0x00058FC4
		private void Apply(string themeClass, Selectable item)
		{
			if (item == null)
			{
				return;
			}
			ThemeSettings.SelectableSettings_Base selectableSettings_Base;
			if (item as Button != null)
			{
				if (themeClass == "inputGridField")
				{
					selectableSettings_Base = this._inputGridFieldSettings;
				}
				else
				{
					selectableSettings_Base = this._buttonSettings;
				}
			}
			else if (item as Scrollbar != null)
			{
				selectableSettings_Base = this._scrollbarSettings;
			}
			else if (item as Slider != null)
			{
				selectableSettings_Base = this._sliderSettings;
			}
			else if (item as Toggle != null)
			{
				if (themeClass == "button")
				{
					selectableSettings_Base = this._buttonSettings;
				}
				else
				{
					selectableSettings_Base = this._selectableSettings;
				}
			}
			else
			{
				selectableSettings_Base = this._selectableSettings;
			}
			selectableSettings_Base.Apply(item);
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x0005AE74 File Offset: 0x00059074
		private void Apply(string themeClass, Image item)
		{
			if (item == null)
			{
				return;
			}
			uint num = <PrivateImplementationDetails>.ComputeStringHash(themeClass);
			if (num <= 2822822017U)
			{
				if (num <= 283896133U)
				{
					if (num != 106194061U)
					{
						if (num != 283896133U)
						{
							return;
						}
						if (!(themeClass == "popupWindow"))
						{
							return;
						}
						this._popupWindowBackground.CopyTo(item);
						return;
					}
					else
					{
						if (!(themeClass == "invertToggleButtonBackground"))
						{
							return;
						}
						this._buttonSettings.imageSettings.CopyTo(item);
						return;
					}
				}
				else if (num != 2601460036U)
				{
					if (num != 2822822017U)
					{
						return;
					}
					if (!(themeClass == "invertToggle"))
					{
						return;
					}
					this._invertToggle.CopyTo(item);
					return;
				}
				else
				{
					if (!(themeClass == "area"))
					{
						return;
					}
					this._areaBackground.CopyTo(item);
					return;
				}
			}
			else if (num <= 3490313510U)
			{
				if (num != 2998767316U)
				{
					if (num != 3490313510U)
					{
						return;
					}
					if (!(themeClass == "calibrationRawValueMarker"))
					{
						return;
					}
					this._calibrationRawValueMarker.CopyTo(item);
					return;
				}
				else
				{
					if (!(themeClass == "mainWindow"))
					{
						return;
					}
					this._mainWindowBackground.CopyTo(item);
					return;
				}
			}
			else if (num != 3776179782U)
			{
				if (num != 3911450241U)
				{
					return;
				}
				if (!(themeClass == "invertToggleBackground"))
				{
					return;
				}
				this._inputGridFieldSettings.imageSettings.CopyTo(item);
				return;
			}
			else
			{
				if (!(themeClass == "calibrationValueMarker"))
				{
					return;
				}
				this._calibrationValueMarker.CopyTo(item);
				return;
			}
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x0005AFD4 File Offset: 0x000591D4
		private void Apply(string themeClass, Text item)
		{
			if (item == null)
			{
				return;
			}
			ThemeSettings.TextSettings textSettings;
			if (!(themeClass == "button"))
			{
				if (!(themeClass == "inputGridField"))
				{
					textSettings = this._textSettings;
				}
				else
				{
					textSettings = this._inputGridFieldTextSettings;
				}
			}
			else
			{
				textSettings = this._buttonTextSettings;
			}
			if (textSettings.font != null)
			{
				item.font = textSettings.font;
			}
			item.color = textSettings.color;
			item.lineSpacing = textSettings.lineSpacing;
			if (textSettings.sizeMultiplier != 1f)
			{
				item.fontSize = (int)((float)item.fontSize * textSettings.sizeMultiplier);
				item.resizeTextMaxSize = (int)((float)item.resizeTextMaxSize * textSettings.sizeMultiplier);
				item.resizeTextMinSize = (int)((float)item.resizeTextMinSize * textSettings.sizeMultiplier);
			}
			if (textSettings.style != ThemeSettings.FontStyleOverride.Default)
			{
				item.fontStyle = (FontStyle)(textSettings.style - 1);
			}
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0005B0B4 File Offset: 0x000592B4
		private void Apply(string themeClass, UIImageHelper item)
		{
			if (item == null)
			{
				return;
			}
			item.SetEnabledStateColor(this._invertToggle.color);
			item.SetDisabledStateColor(this._invertToggleDisabledColor);
			item.Refresh();
		}

		// Token: 0x04000BD9 RID: 3033
		[SerializeField]
		private ThemeSettings.ImageSettings _mainWindowBackground;

		// Token: 0x04000BDA RID: 3034
		[SerializeField]
		private ThemeSettings.ImageSettings _popupWindowBackground;

		// Token: 0x04000BDB RID: 3035
		[SerializeField]
		private ThemeSettings.ImageSettings _areaBackground;

		// Token: 0x04000BDC RID: 3036
		[SerializeField]
		private ThemeSettings.SelectableSettings _selectableSettings;

		// Token: 0x04000BDD RID: 3037
		[SerializeField]
		private ThemeSettings.SelectableSettings _buttonSettings;

		// Token: 0x04000BDE RID: 3038
		[SerializeField]
		private ThemeSettings.SelectableSettings _inputGridFieldSettings;

		// Token: 0x04000BDF RID: 3039
		[SerializeField]
		private ThemeSettings.ScrollbarSettings _scrollbarSettings;

		// Token: 0x04000BE0 RID: 3040
		[SerializeField]
		private ThemeSettings.SliderSettings _sliderSettings;

		// Token: 0x04000BE1 RID: 3041
		[SerializeField]
		private ThemeSettings.ImageSettings _invertToggle;

		// Token: 0x04000BE2 RID: 3042
		[SerializeField]
		private Color _invertToggleDisabledColor;

		// Token: 0x04000BE3 RID: 3043
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationValueMarker;

		// Token: 0x04000BE4 RID: 3044
		[SerializeField]
		private ThemeSettings.ImageSettings _calibrationRawValueMarker;

		// Token: 0x04000BE5 RID: 3045
		[SerializeField]
		private ThemeSettings.TextSettings _textSettings;

		// Token: 0x04000BE6 RID: 3046
		[SerializeField]
		private ThemeSettings.TextSettings _buttonTextSettings;

		// Token: 0x04000BE7 RID: 3047
		[SerializeField]
		private ThemeSettings.TextSettings _inputGridFieldTextSettings;

		// Token: 0x02000383 RID: 899
		[Serializable]
		private abstract class SelectableSettings_Base
		{
			// Token: 0x170004B4 RID: 1204
			// (get) Token: 0x060017E7 RID: 6119 RVA: 0x00075BAB File Offset: 0x00073DAB
			public Selectable.Transition transition
			{
				get
				{
					return this._transition;
				}
			}

			// Token: 0x170004B5 RID: 1205
			// (get) Token: 0x060017E8 RID: 6120 RVA: 0x00075BB3 File Offset: 0x00073DB3
			public ThemeSettings.CustomColorBlock selectableColors
			{
				get
				{
					return this._colors;
				}
			}

			// Token: 0x170004B6 RID: 1206
			// (get) Token: 0x060017E9 RID: 6121 RVA: 0x00075BBB File Offset: 0x00073DBB
			public ThemeSettings.CustomSpriteState spriteState
			{
				get
				{
					return this._spriteState;
				}
			}

			// Token: 0x170004B7 RID: 1207
			// (get) Token: 0x060017EA RID: 6122 RVA: 0x00075BC3 File Offset: 0x00073DC3
			public ThemeSettings.CustomAnimationTriggers animationTriggers
			{
				get
				{
					return this._animationTriggers;
				}
			}

			// Token: 0x060017EB RID: 6123 RVA: 0x00075BCC File Offset: 0x00073DCC
			public virtual void Apply(Selectable item)
			{
				Selectable.Transition transition = this._transition;
				bool flag = item.transition != transition;
				item.transition = transition;
				ICustomSelectable customSelectable = item as ICustomSelectable;
				if (transition == Selectable.Transition.ColorTint)
				{
					ThemeSettings.CustomColorBlock colors = this._colors;
					colors.fadeDuration = 0f;
					item.colors = colors;
					colors.fadeDuration = this._colors.fadeDuration;
					item.colors = colors;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedColor = colors.disabledHighlightedColor;
					}
				}
				else if (transition == Selectable.Transition.SpriteSwap)
				{
					item.spriteState = this._spriteState;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedSprite = this._spriteState.disabledHighlightedSprite;
					}
				}
				else if (transition == Selectable.Transition.Animation)
				{
					item.animationTriggers.disabledTrigger = this._animationTriggers.disabledTrigger;
					item.animationTriggers.highlightedTrigger = this._animationTriggers.highlightedTrigger;
					item.animationTriggers.normalTrigger = this._animationTriggers.normalTrigger;
					item.animationTriggers.pressedTrigger = this._animationTriggers.pressedTrigger;
					if (customSelectable != null)
					{
						customSelectable.disabledHighlightedTrigger = this._animationTriggers.disabledHighlightedTrigger;
					}
				}
				if (flag)
				{
					item.targetGraphic.CrossFadeColor(item.targetGraphic.color, 0f, true, true);
				}
			}

			// Token: 0x04001341 RID: 4929
			[SerializeField]
			protected Selectable.Transition _transition;

			// Token: 0x04001342 RID: 4930
			[SerializeField]
			protected ThemeSettings.CustomColorBlock _colors;

			// Token: 0x04001343 RID: 4931
			[SerializeField]
			protected ThemeSettings.CustomSpriteState _spriteState;

			// Token: 0x04001344 RID: 4932
			[SerializeField]
			protected ThemeSettings.CustomAnimationTriggers _animationTriggers;
		}

		// Token: 0x02000384 RID: 900
		[Serializable]
		private class SelectableSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x170004B8 RID: 1208
			// (get) Token: 0x060017ED RID: 6125 RVA: 0x00075D10 File Offset: 0x00073F10
			public ThemeSettings.ImageSettings imageSettings
			{
				get
				{
					return this._imageSettings;
				}
			}

			// Token: 0x060017EE RID: 6126 RVA: 0x00075D18 File Offset: 0x00073F18
			public override void Apply(Selectable item)
			{
				if (item == null)
				{
					return;
				}
				base.Apply(item);
				if (this._imageSettings != null)
				{
					this._imageSettings.CopyTo(item.targetGraphic as Image);
				}
			}

			// Token: 0x04001345 RID: 4933
			[SerializeField]
			private ThemeSettings.ImageSettings _imageSettings;
		}

		// Token: 0x02000385 RID: 901
		[Serializable]
		private class SliderSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x170004B9 RID: 1209
			// (get) Token: 0x060017F0 RID: 6128 RVA: 0x00075D51 File Offset: 0x00073F51
			public ThemeSettings.ImageSettings handleImageSettings
			{
				get
				{
					return this._handleImageSettings;
				}
			}

			// Token: 0x170004BA RID: 1210
			// (get) Token: 0x060017F1 RID: 6129 RVA: 0x00075D59 File Offset: 0x00073F59
			public ThemeSettings.ImageSettings fillImageSettings
			{
				get
				{
					return this._fillImageSettings;
				}
			}

			// Token: 0x170004BB RID: 1211
			// (get) Token: 0x060017F2 RID: 6130 RVA: 0x00075D61 File Offset: 0x00073F61
			public ThemeSettings.ImageSettings backgroundImageSettings
			{
				get
				{
					return this._backgroundImageSettings;
				}
			}

			// Token: 0x060017F3 RID: 6131 RVA: 0x00075D6C File Offset: 0x00073F6C
			private void Apply(Slider item)
			{
				if (item == null)
				{
					return;
				}
				if (this._handleImageSettings != null)
				{
					this._handleImageSettings.CopyTo(item.targetGraphic as Image);
				}
				if (this._fillImageSettings != null)
				{
					RectTransform fillRect = item.fillRect;
					if (fillRect != null)
					{
						this._fillImageSettings.CopyTo(fillRect.GetComponent<Image>());
					}
				}
				if (this._backgroundImageSettings != null)
				{
					Transform transform = item.transform.Find("Background");
					if (transform != null)
					{
						this._backgroundImageSettings.CopyTo(transform.GetComponent<Image>());
					}
				}
			}

			// Token: 0x060017F4 RID: 6132 RVA: 0x00075DFD File Offset: 0x00073FFD
			public override void Apply(Selectable item)
			{
				base.Apply(item);
				this.Apply(item as Slider);
			}

			// Token: 0x04001346 RID: 4934
			[SerializeField]
			private ThemeSettings.ImageSettings _handleImageSettings;

			// Token: 0x04001347 RID: 4935
			[SerializeField]
			private ThemeSettings.ImageSettings _fillImageSettings;

			// Token: 0x04001348 RID: 4936
			[SerializeField]
			private ThemeSettings.ImageSettings _backgroundImageSettings;
		}

		// Token: 0x02000386 RID: 902
		[Serializable]
		private class ScrollbarSettings : ThemeSettings.SelectableSettings_Base
		{
			// Token: 0x170004BC RID: 1212
			// (get) Token: 0x060017F6 RID: 6134 RVA: 0x00075E12 File Offset: 0x00074012
			public ThemeSettings.ImageSettings handle
			{
				get
				{
					return this._handleImageSettings;
				}
			}

			// Token: 0x170004BD RID: 1213
			// (get) Token: 0x060017F7 RID: 6135 RVA: 0x00075E1A File Offset: 0x0007401A
			public ThemeSettings.ImageSettings background
			{
				get
				{
					return this._backgroundImageSettings;
				}
			}

			// Token: 0x060017F8 RID: 6136 RVA: 0x00075E24 File Offset: 0x00074024
			private void Apply(Scrollbar item)
			{
				if (item == null)
				{
					return;
				}
				if (this._handleImageSettings != null)
				{
					this._handleImageSettings.CopyTo(item.targetGraphic as Image);
				}
				if (this._backgroundImageSettings != null)
				{
					this._backgroundImageSettings.CopyTo(item.GetComponent<Image>());
				}
			}

			// Token: 0x060017F9 RID: 6137 RVA: 0x00075E72 File Offset: 0x00074072
			public override void Apply(Selectable item)
			{
				base.Apply(item);
				this.Apply(item as Scrollbar);
			}

			// Token: 0x04001349 RID: 4937
			[SerializeField]
			private ThemeSettings.ImageSettings _handleImageSettings;

			// Token: 0x0400134A RID: 4938
			[SerializeField]
			private ThemeSettings.ImageSettings _backgroundImageSettings;
		}

		// Token: 0x02000387 RID: 903
		[Serializable]
		private class ImageSettings
		{
			// Token: 0x170004BE RID: 1214
			// (get) Token: 0x060017FB RID: 6139 RVA: 0x00075E87 File Offset: 0x00074087
			public Color color
			{
				get
				{
					return this._color;
				}
			}

			// Token: 0x170004BF RID: 1215
			// (get) Token: 0x060017FC RID: 6140 RVA: 0x00075E8F File Offset: 0x0007408F
			public Sprite sprite
			{
				get
				{
					return this._sprite;
				}
			}

			// Token: 0x170004C0 RID: 1216
			// (get) Token: 0x060017FD RID: 6141 RVA: 0x00075E97 File Offset: 0x00074097
			public Material materal
			{
				get
				{
					return this._materal;
				}
			}

			// Token: 0x170004C1 RID: 1217
			// (get) Token: 0x060017FE RID: 6142 RVA: 0x00075E9F File Offset: 0x0007409F
			public Image.Type type
			{
				get
				{
					return this._type;
				}
			}

			// Token: 0x170004C2 RID: 1218
			// (get) Token: 0x060017FF RID: 6143 RVA: 0x00075EA7 File Offset: 0x000740A7
			public bool preserveAspect
			{
				get
				{
					return this._preserveAspect;
				}
			}

			// Token: 0x170004C3 RID: 1219
			// (get) Token: 0x06001800 RID: 6144 RVA: 0x00075EAF File Offset: 0x000740AF
			public bool fillCenter
			{
				get
				{
					return this._fillCenter;
				}
			}

			// Token: 0x170004C4 RID: 1220
			// (get) Token: 0x06001801 RID: 6145 RVA: 0x00075EB7 File Offset: 0x000740B7
			public Image.FillMethod fillMethod
			{
				get
				{
					return this._fillMethod;
				}
			}

			// Token: 0x170004C5 RID: 1221
			// (get) Token: 0x06001802 RID: 6146 RVA: 0x00075EBF File Offset: 0x000740BF
			public float fillAmout
			{
				get
				{
					return this._fillAmout;
				}
			}

			// Token: 0x170004C6 RID: 1222
			// (get) Token: 0x06001803 RID: 6147 RVA: 0x00075EC7 File Offset: 0x000740C7
			public bool fillClockwise
			{
				get
				{
					return this._fillClockwise;
				}
			}

			// Token: 0x170004C7 RID: 1223
			// (get) Token: 0x06001804 RID: 6148 RVA: 0x00075ECF File Offset: 0x000740CF
			public int fillOrigin
			{
				get
				{
					return this._fillOrigin;
				}
			}

			// Token: 0x06001805 RID: 6149 RVA: 0x00075ED8 File Offset: 0x000740D8
			public virtual void CopyTo(Image image)
			{
				if (image == null)
				{
					return;
				}
				image.color = this._color;
				image.sprite = this._sprite;
				image.material = this._materal;
				image.type = this._type;
				image.preserveAspect = this._preserveAspect;
				image.fillCenter = this._fillCenter;
				image.fillMethod = this._fillMethod;
				image.fillAmount = this._fillAmout;
				image.fillClockwise = this._fillClockwise;
				image.fillOrigin = this._fillOrigin;
			}

			// Token: 0x0400134B RID: 4939
			[SerializeField]
			private Color _color = Color.white;

			// Token: 0x0400134C RID: 4940
			[SerializeField]
			private Sprite _sprite;

			// Token: 0x0400134D RID: 4941
			[SerializeField]
			private Material _materal;

			// Token: 0x0400134E RID: 4942
			[SerializeField]
			private Image.Type _type;

			// Token: 0x0400134F RID: 4943
			[SerializeField]
			private bool _preserveAspect;

			// Token: 0x04001350 RID: 4944
			[SerializeField]
			private bool _fillCenter;

			// Token: 0x04001351 RID: 4945
			[SerializeField]
			private Image.FillMethod _fillMethod;

			// Token: 0x04001352 RID: 4946
			[SerializeField]
			private float _fillAmout;

			// Token: 0x04001353 RID: 4947
			[SerializeField]
			private bool _fillClockwise;

			// Token: 0x04001354 RID: 4948
			[SerializeField]
			private int _fillOrigin;
		}

		// Token: 0x02000388 RID: 904
		[Serializable]
		private struct CustomColorBlock
		{
			// Token: 0x170004C8 RID: 1224
			// (get) Token: 0x06001807 RID: 6151 RVA: 0x00075F7A File Offset: 0x0007417A
			// (set) Token: 0x06001808 RID: 6152 RVA: 0x00075F82 File Offset: 0x00074182
			public float colorMultiplier
			{
				get
				{
					return this.m_ColorMultiplier;
				}
				set
				{
					this.m_ColorMultiplier = value;
				}
			}

			// Token: 0x170004C9 RID: 1225
			// (get) Token: 0x06001809 RID: 6153 RVA: 0x00075F8B File Offset: 0x0007418B
			// (set) Token: 0x0600180A RID: 6154 RVA: 0x00075F93 File Offset: 0x00074193
			public Color disabledColor
			{
				get
				{
					return this.m_DisabledColor;
				}
				set
				{
					this.m_DisabledColor = value;
				}
			}

			// Token: 0x170004CA RID: 1226
			// (get) Token: 0x0600180B RID: 6155 RVA: 0x00075F9C File Offset: 0x0007419C
			// (set) Token: 0x0600180C RID: 6156 RVA: 0x00075FA4 File Offset: 0x000741A4
			public float fadeDuration
			{
				get
				{
					return this.m_FadeDuration;
				}
				set
				{
					this.m_FadeDuration = value;
				}
			}

			// Token: 0x170004CB RID: 1227
			// (get) Token: 0x0600180D RID: 6157 RVA: 0x00075FAD File Offset: 0x000741AD
			// (set) Token: 0x0600180E RID: 6158 RVA: 0x00075FB5 File Offset: 0x000741B5
			public Color highlightedColor
			{
				get
				{
					return this.m_HighlightedColor;
				}
				set
				{
					this.m_HighlightedColor = value;
				}
			}

			// Token: 0x170004CC RID: 1228
			// (get) Token: 0x0600180F RID: 6159 RVA: 0x00075FBE File Offset: 0x000741BE
			// (set) Token: 0x06001810 RID: 6160 RVA: 0x00075FC6 File Offset: 0x000741C6
			public Color normalColor
			{
				get
				{
					return this.m_NormalColor;
				}
				set
				{
					this.m_NormalColor = value;
				}
			}

			// Token: 0x170004CD RID: 1229
			// (get) Token: 0x06001811 RID: 6161 RVA: 0x00075FCF File Offset: 0x000741CF
			// (set) Token: 0x06001812 RID: 6162 RVA: 0x00075FD7 File Offset: 0x000741D7
			public Color pressedColor
			{
				get
				{
					return this.m_PressedColor;
				}
				set
				{
					this.m_PressedColor = value;
				}
			}

			// Token: 0x170004CE RID: 1230
			// (get) Token: 0x06001813 RID: 6163 RVA: 0x00075FE0 File Offset: 0x000741E0
			// (set) Token: 0x06001814 RID: 6164 RVA: 0x00075FE8 File Offset: 0x000741E8
			public Color disabledHighlightedColor
			{
				get
				{
					return this.m_DisabledHighlightedColor;
				}
				set
				{
					this.m_DisabledHighlightedColor = value;
				}
			}

			// Token: 0x06001815 RID: 6165 RVA: 0x00075FF4 File Offset: 0x000741F4
			public static implicit operator ColorBlock(ThemeSettings.CustomColorBlock item)
			{
				return new ColorBlock
				{
					colorMultiplier = item.m_ColorMultiplier,
					disabledColor = item.m_DisabledColor,
					fadeDuration = item.m_FadeDuration,
					highlightedColor = item.m_HighlightedColor,
					normalColor = item.m_NormalColor,
					pressedColor = item.m_PressedColor
				};
			}

			// Token: 0x04001355 RID: 4949
			[SerializeField]
			private float m_ColorMultiplier;

			// Token: 0x04001356 RID: 4950
			[SerializeField]
			private Color m_DisabledColor;

			// Token: 0x04001357 RID: 4951
			[SerializeField]
			private float m_FadeDuration;

			// Token: 0x04001358 RID: 4952
			[SerializeField]
			private Color m_HighlightedColor;

			// Token: 0x04001359 RID: 4953
			[SerializeField]
			private Color m_NormalColor;

			// Token: 0x0400135A RID: 4954
			[SerializeField]
			private Color m_PressedColor;

			// Token: 0x0400135B RID: 4955
			[SerializeField]
			private Color m_DisabledHighlightedColor;
		}

		// Token: 0x02000389 RID: 905
		[Serializable]
		private struct CustomSpriteState
		{
			// Token: 0x170004CF RID: 1231
			// (get) Token: 0x06001816 RID: 6166 RVA: 0x00076058 File Offset: 0x00074258
			// (set) Token: 0x06001817 RID: 6167 RVA: 0x00076060 File Offset: 0x00074260
			public Sprite disabledSprite
			{
				get
				{
					return this.m_DisabledSprite;
				}
				set
				{
					this.m_DisabledSprite = value;
				}
			}

			// Token: 0x170004D0 RID: 1232
			// (get) Token: 0x06001818 RID: 6168 RVA: 0x00076069 File Offset: 0x00074269
			// (set) Token: 0x06001819 RID: 6169 RVA: 0x00076071 File Offset: 0x00074271
			public Sprite highlightedSprite
			{
				get
				{
					return this.m_HighlightedSprite;
				}
				set
				{
					this.m_HighlightedSprite = value;
				}
			}

			// Token: 0x170004D1 RID: 1233
			// (get) Token: 0x0600181A RID: 6170 RVA: 0x0007607A File Offset: 0x0007427A
			// (set) Token: 0x0600181B RID: 6171 RVA: 0x00076082 File Offset: 0x00074282
			public Sprite pressedSprite
			{
				get
				{
					return this.m_PressedSprite;
				}
				set
				{
					this.m_PressedSprite = value;
				}
			}

			// Token: 0x170004D2 RID: 1234
			// (get) Token: 0x0600181C RID: 6172 RVA: 0x0007608B File Offset: 0x0007428B
			// (set) Token: 0x0600181D RID: 6173 RVA: 0x00076093 File Offset: 0x00074293
			public Sprite disabledHighlightedSprite
			{
				get
				{
					return this.m_DisabledHighlightedSprite;
				}
				set
				{
					this.m_DisabledHighlightedSprite = value;
				}
			}

			// Token: 0x0600181E RID: 6174 RVA: 0x0007609C File Offset: 0x0007429C
			public static implicit operator SpriteState(ThemeSettings.CustomSpriteState item)
			{
				return new SpriteState
				{
					disabledSprite = item.m_DisabledSprite,
					highlightedSprite = item.m_HighlightedSprite,
					pressedSprite = item.m_PressedSprite
				};
			}

			// Token: 0x0400135C RID: 4956
			[SerializeField]
			private Sprite m_DisabledSprite;

			// Token: 0x0400135D RID: 4957
			[SerializeField]
			private Sprite m_HighlightedSprite;

			// Token: 0x0400135E RID: 4958
			[SerializeField]
			private Sprite m_PressedSprite;

			// Token: 0x0400135F RID: 4959
			[SerializeField]
			private Sprite m_DisabledHighlightedSprite;
		}

		// Token: 0x0200038A RID: 906
		[Serializable]
		private class CustomAnimationTriggers
		{
			// Token: 0x0600181F RID: 6175 RVA: 0x000760D9 File Offset: 0x000742D9
			public CustomAnimationTriggers()
			{
				this.m_DisabledTrigger = string.Empty;
				this.m_HighlightedTrigger = string.Empty;
				this.m_NormalTrigger = string.Empty;
				this.m_PressedTrigger = string.Empty;
				this.m_DisabledHighlightedTrigger = string.Empty;
			}

			// Token: 0x170004D3 RID: 1235
			// (get) Token: 0x06001820 RID: 6176 RVA: 0x00076118 File Offset: 0x00074318
			// (set) Token: 0x06001821 RID: 6177 RVA: 0x00076120 File Offset: 0x00074320
			public string disabledTrigger
			{
				get
				{
					return this.m_DisabledTrigger;
				}
				set
				{
					this.m_DisabledTrigger = value;
				}
			}

			// Token: 0x170004D4 RID: 1236
			// (get) Token: 0x06001822 RID: 6178 RVA: 0x00076129 File Offset: 0x00074329
			// (set) Token: 0x06001823 RID: 6179 RVA: 0x00076131 File Offset: 0x00074331
			public string highlightedTrigger
			{
				get
				{
					return this.m_HighlightedTrigger;
				}
				set
				{
					this.m_HighlightedTrigger = value;
				}
			}

			// Token: 0x170004D5 RID: 1237
			// (get) Token: 0x06001824 RID: 6180 RVA: 0x0007613A File Offset: 0x0007433A
			// (set) Token: 0x06001825 RID: 6181 RVA: 0x00076142 File Offset: 0x00074342
			public string normalTrigger
			{
				get
				{
					return this.m_NormalTrigger;
				}
				set
				{
					this.m_NormalTrigger = value;
				}
			}

			// Token: 0x170004D6 RID: 1238
			// (get) Token: 0x06001826 RID: 6182 RVA: 0x0007614B File Offset: 0x0007434B
			// (set) Token: 0x06001827 RID: 6183 RVA: 0x00076153 File Offset: 0x00074353
			public string pressedTrigger
			{
				get
				{
					return this.m_PressedTrigger;
				}
				set
				{
					this.m_PressedTrigger = value;
				}
			}

			// Token: 0x170004D7 RID: 1239
			// (get) Token: 0x06001828 RID: 6184 RVA: 0x0007615C File Offset: 0x0007435C
			// (set) Token: 0x06001829 RID: 6185 RVA: 0x00076164 File Offset: 0x00074364
			public string disabledHighlightedTrigger
			{
				get
				{
					return this.m_DisabledHighlightedTrigger;
				}
				set
				{
					this.m_DisabledHighlightedTrigger = value;
				}
			}

			// Token: 0x0600182A RID: 6186 RVA: 0x0007616D File Offset: 0x0007436D
			public static implicit operator AnimationTriggers(ThemeSettings.CustomAnimationTriggers item)
			{
				return new AnimationTriggers
				{
					disabledTrigger = item.m_DisabledTrigger,
					highlightedTrigger = item.m_HighlightedTrigger,
					normalTrigger = item.m_NormalTrigger,
					pressedTrigger = item.m_PressedTrigger
				};
			}

			// Token: 0x04001360 RID: 4960
			[SerializeField]
			private string m_DisabledTrigger;

			// Token: 0x04001361 RID: 4961
			[SerializeField]
			private string m_HighlightedTrigger;

			// Token: 0x04001362 RID: 4962
			[SerializeField]
			private string m_NormalTrigger;

			// Token: 0x04001363 RID: 4963
			[SerializeField]
			private string m_PressedTrigger;

			// Token: 0x04001364 RID: 4964
			[SerializeField]
			private string m_DisabledHighlightedTrigger;
		}

		// Token: 0x0200038B RID: 907
		[Serializable]
		private class TextSettings
		{
			// Token: 0x170004D8 RID: 1240
			// (get) Token: 0x0600182B RID: 6187 RVA: 0x000761A4 File Offset: 0x000743A4
			public Color color
			{
				get
				{
					return this._color;
				}
			}

			// Token: 0x170004D9 RID: 1241
			// (get) Token: 0x0600182C RID: 6188 RVA: 0x000761AC File Offset: 0x000743AC
			public Font font
			{
				get
				{
					return this._font;
				}
			}

			// Token: 0x170004DA RID: 1242
			// (get) Token: 0x0600182D RID: 6189 RVA: 0x000761B4 File Offset: 0x000743B4
			public ThemeSettings.FontStyleOverride style
			{
				get
				{
					return this._style;
				}
			}

			// Token: 0x170004DB RID: 1243
			// (get) Token: 0x0600182E RID: 6190 RVA: 0x000761BC File Offset: 0x000743BC
			public float lineSpacing
			{
				get
				{
					return this._lineSpacing;
				}
			}

			// Token: 0x170004DC RID: 1244
			// (get) Token: 0x0600182F RID: 6191 RVA: 0x000761C4 File Offset: 0x000743C4
			public float sizeMultiplier
			{
				get
				{
					return this._sizeMultiplier;
				}
			}

			// Token: 0x04001365 RID: 4965
			[SerializeField]
			private Color _color = Color.white;

			// Token: 0x04001366 RID: 4966
			[SerializeField]
			private Font _font;

			// Token: 0x04001367 RID: 4967
			[SerializeField]
			private ThemeSettings.FontStyleOverride _style;

			// Token: 0x04001368 RID: 4968
			[SerializeField]
			private float _lineSpacing = 1f;

			// Token: 0x04001369 RID: 4969
			[SerializeField]
			private float _sizeMultiplier = 1f;
		}

		// Token: 0x0200038C RID: 908
		private enum FontStyleOverride
		{
			// Token: 0x0400136B RID: 4971
			Default,
			// Token: 0x0400136C RID: 4972
			Normal,
			// Token: 0x0400136D RID: 4973
			Bold,
			// Token: 0x0400136E RID: 4974
			Italic,
			// Token: 0x0400136F RID: 4975
			BoldAndItalic
		}
	}
}
