﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x02000198 RID: 408
	[AddComponentMenu("")]
	public class CustomSlider : Slider, ICustomSelectable, ICancelHandler, IEventSystemHandler
	{
		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000E21 RID: 3617 RVA: 0x00059583 File Offset: 0x00057783
		// (set) Token: 0x06000E22 RID: 3618 RVA: 0x0005958B File Offset: 0x0005778B
		public Sprite disabledHighlightedSprite
		{
			get
			{
				return this._disabledHighlightedSprite;
			}
			set
			{
				this._disabledHighlightedSprite = value;
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000E23 RID: 3619 RVA: 0x00059594 File Offset: 0x00057794
		// (set) Token: 0x06000E24 RID: 3620 RVA: 0x0005959C File Offset: 0x0005779C
		public Color disabledHighlightedColor
		{
			get
			{
				return this._disabledHighlightedColor;
			}
			set
			{
				this._disabledHighlightedColor = value;
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000E25 RID: 3621 RVA: 0x000595A5 File Offset: 0x000577A5
		// (set) Token: 0x06000E26 RID: 3622 RVA: 0x000595AD File Offset: 0x000577AD
		public string disabledHighlightedTrigger
		{
			get
			{
				return this._disabledHighlightedTrigger;
			}
			set
			{
				this._disabledHighlightedTrigger = value;
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000E27 RID: 3623 RVA: 0x000595B6 File Offset: 0x000577B6
		// (set) Token: 0x06000E28 RID: 3624 RVA: 0x000595BE File Offset: 0x000577BE
		public bool autoNavUp
		{
			get
			{
				return this._autoNavUp;
			}
			set
			{
				this._autoNavUp = value;
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000E29 RID: 3625 RVA: 0x000595C7 File Offset: 0x000577C7
		// (set) Token: 0x06000E2A RID: 3626 RVA: 0x000595CF File Offset: 0x000577CF
		public bool autoNavDown
		{
			get
			{
				return this._autoNavDown;
			}
			set
			{
				this._autoNavDown = value;
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000E2B RID: 3627 RVA: 0x000595D8 File Offset: 0x000577D8
		// (set) Token: 0x06000E2C RID: 3628 RVA: 0x000595E0 File Offset: 0x000577E0
		public bool autoNavLeft
		{
			get
			{
				return this._autoNavLeft;
			}
			set
			{
				this._autoNavLeft = value;
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000E2D RID: 3629 RVA: 0x000595E9 File Offset: 0x000577E9
		// (set) Token: 0x06000E2E RID: 3630 RVA: 0x000595F1 File Offset: 0x000577F1
		public bool autoNavRight
		{
			get
			{
				return this._autoNavRight;
			}
			set
			{
				this._autoNavRight = value;
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000E2F RID: 3631 RVA: 0x000590BA File Offset: 0x000572BA
		private bool isDisabled
		{
			get
			{
				return !this.IsInteractable();
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000E30 RID: 3632 RVA: 0x000595FC File Offset: 0x000577FC
		// (remove) Token: 0x06000E31 RID: 3633 RVA: 0x00059634 File Offset: 0x00057834
		private event UnityAction _CancelEvent;

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000E32 RID: 3634 RVA: 0x00059669 File Offset: 0x00057869
		// (remove) Token: 0x06000E33 RID: 3635 RVA: 0x00059672 File Offset: 0x00057872
		public event UnityAction CancelEvent
		{
			add
			{
				this._CancelEvent += value;
			}
			remove
			{
				this._CancelEvent -= value;
			}
		}

		// Token: 0x06000E34 RID: 3636 RVA: 0x0005967C File Offset: 0x0005787C
		public override Selectable FindSelectableOnLeft()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavLeft)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.left);
			}
			return base.FindSelectableOnLeft();
		}

		// Token: 0x06000E35 RID: 3637 RVA: 0x000596D0 File Offset: 0x000578D0
		public override Selectable FindSelectableOnRight()
		{
			if ((base.navigation.mode & Navigation.Mode.Horizontal) != Navigation.Mode.None || this._autoNavRight)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.right);
			}
			return base.FindSelectableOnRight();
		}

		// Token: 0x06000E36 RID: 3638 RVA: 0x00059724 File Offset: 0x00057924
		public override Selectable FindSelectableOnUp()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavUp)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.up);
			}
			return base.FindSelectableOnUp();
		}

		// Token: 0x06000E37 RID: 3639 RVA: 0x00059778 File Offset: 0x00057978
		public override Selectable FindSelectableOnDown()
		{
			if ((base.navigation.mode & Navigation.Mode.Vertical) != Navigation.Mode.None || this._autoNavDown)
			{
				return UISelectionUtility.FindNextSelectable(this, base.transform, Selectable.allSelectables, base.transform.rotation * Vector3.down);
			}
			return base.FindSelectableOnDown();
		}

		// Token: 0x06000E38 RID: 3640 RVA: 0x000597CC File Offset: 0x000579CC
		protected override void OnCanvasGroupChanged()
		{
			base.OnCanvasGroupChanged();
			if (EventSystem.current == null)
			{
				return;
			}
			this.EvaluateHightlightDisabled(EventSystem.current.currentSelectedGameObject == base.gameObject);
		}

		// Token: 0x06000E39 RID: 3641 RVA: 0x00059800 File Offset: 0x00057A00
		protected override void DoStateTransition(Selectable.SelectionState state, bool instant)
		{
			if (this.isHighlightDisabled)
			{
				Color disabledHighlightedColor = this._disabledHighlightedColor;
				Sprite disabledHighlightedSprite = this._disabledHighlightedSprite;
				string disabledHighlightedTrigger = this._disabledHighlightedTrigger;
				if (base.gameObject.activeInHierarchy)
				{
					switch (base.transition)
					{
					case Selectable.Transition.ColorTint:
						this.StartColorTween(disabledHighlightedColor * base.colors.colorMultiplier, instant);
						return;
					case Selectable.Transition.SpriteSwap:
						this.DoSpriteSwap(disabledHighlightedSprite);
						return;
					case Selectable.Transition.Animation:
						this.TriggerAnimation(disabledHighlightedTrigger);
						return;
					default:
						return;
					}
				}
			}
			else
			{
				base.DoStateTransition(state, instant);
			}
		}

		// Token: 0x06000E3A RID: 3642 RVA: 0x00059888 File Offset: 0x00057A88
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (base.targetGraphic == null)
			{
				return;
			}
			base.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : base.colors.fadeDuration, true, true);
		}

		// Token: 0x06000E3B RID: 3643 RVA: 0x00059396 File Offset: 0x00057596
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (base.image == null)
			{
				return;
			}
			base.image.overrideSprite = newSprite;
		}

		// Token: 0x06000E3C RID: 3644 RVA: 0x000598CC File Offset: 0x00057ACC
		private void TriggerAnimation(string triggername)
		{
			if (base.animator == null || !base.animator.enabled || !base.animator.isActiveAndEnabled || base.animator.runtimeAnimatorController == null || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			base.animator.ResetTrigger(this._disabledHighlightedTrigger);
			base.animator.SetTrigger(triggername);
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x0005993A File Offset: 0x00057B3A
		public override void OnSelect(BaseEventData eventData)
		{
			base.OnSelect(eventData);
			this.EvaluateHightlightDisabled(true);
		}

		// Token: 0x06000E3E RID: 3646 RVA: 0x0005994A File Offset: 0x00057B4A
		public override void OnDeselect(BaseEventData eventData)
		{
			base.OnDeselect(eventData);
			this.EvaluateHightlightDisabled(false);
		}

		// Token: 0x06000E3F RID: 3647 RVA: 0x0005995C File Offset: 0x00057B5C
		private void EvaluateHightlightDisabled(bool isSelected)
		{
			if (!isSelected)
			{
				if (this.isHighlightDisabled)
				{
					this.isHighlightDisabled = false;
					Selectable.SelectionState state = this.isDisabled ? Selectable.SelectionState.Disabled : base.currentSelectionState;
					this.DoStateTransition(state, false);
					return;
				}
			}
			else
			{
				if (!this.isDisabled)
				{
					return;
				}
				this.isHighlightDisabled = true;
				this.DoStateTransition(Selectable.SelectionState.Disabled, false);
			}
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x000599AE File Offset: 0x00057BAE
		public void OnCancel(BaseEventData eventData)
		{
			if (this._CancelEvent != null)
			{
				this._CancelEvent();
			}
		}

		// Token: 0x04000B6F RID: 2927
		[SerializeField]
		private Sprite _disabledHighlightedSprite;

		// Token: 0x04000B70 RID: 2928
		[SerializeField]
		private Color _disabledHighlightedColor;

		// Token: 0x04000B71 RID: 2929
		[SerializeField]
		private string _disabledHighlightedTrigger;

		// Token: 0x04000B72 RID: 2930
		[SerializeField]
		private bool _autoNavUp = true;

		// Token: 0x04000B73 RID: 2931
		[SerializeField]
		private bool _autoNavDown = true;

		// Token: 0x04000B74 RID: 2932
		[SerializeField]
		private bool _autoNavLeft = true;

		// Token: 0x04000B75 RID: 2933
		[SerializeField]
		private bool _autoNavRight = true;

		// Token: 0x04000B76 RID: 2934
		private bool isHighlightDisabled;
	}
}
