﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper
{
	// Token: 0x020001A6 RID: 422
	[AddComponentMenu("")]
	public abstract class UIElementInfo : MonoBehaviour, ISelectHandler, IEventSystemHandler
	{
		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000EF2 RID: 3826 RVA: 0x0005B2F0 File Offset: 0x000594F0
		// (remove) Token: 0x06000EF3 RID: 3827 RVA: 0x0005B328 File Offset: 0x00059528
		public event Action<GameObject> OnSelectedEvent;

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0005B35D File Offset: 0x0005955D
		public void OnSelect(BaseEventData eventData)
		{
			if (this.OnSelectedEvent != null)
			{
				this.OnSelectedEvent(base.gameObject);
			}
		}

		// Token: 0x04000BEE RID: 3054
		public string identifier;

		// Token: 0x04000BEF RID: 3055
		public int intData;

		// Token: 0x04000BF0 RID: 3056
		public Text text;
	}
}
