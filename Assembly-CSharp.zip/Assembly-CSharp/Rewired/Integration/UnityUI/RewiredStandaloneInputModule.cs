﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

namespace Rewired.Integration.UnityUI
{
	// Token: 0x02000191 RID: 401
	[AddComponentMenu("Event/Rewired Standalone Input Module")]
	public class RewiredStandaloneInputModule : PointerInputModule
	{
		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000C9E RID: 3230 RVA: 0x000515A4 File Offset: 0x0004F7A4
		// (set) Token: 0x06000C9F RID: 3231 RVA: 0x000515AC File Offset: 0x0004F7AC
		public bool UseAllRewiredGamePlayers
		{
			get
			{
				return this.useAllRewiredGamePlayers;
			}
			set
			{
				bool flag = value != this.useAllRewiredGamePlayers;
				this.useAllRewiredGamePlayers = value;
				if (flag)
				{
					this.SetupRewiredVars();
				}
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000CA0 RID: 3232 RVA: 0x000515C9 File Offset: 0x0004F7C9
		// (set) Token: 0x06000CA1 RID: 3233 RVA: 0x000515D1 File Offset: 0x0004F7D1
		public bool UseRewiredSystemPlayer
		{
			get
			{
				return this.useRewiredSystemPlayer;
			}
			set
			{
				bool flag = value != this.useRewiredSystemPlayer;
				this.useRewiredSystemPlayer = value;
				if (flag)
				{
					this.SetupRewiredVars();
				}
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000CA2 RID: 3234 RVA: 0x000515EE File Offset: 0x0004F7EE
		// (set) Token: 0x06000CA3 RID: 3235 RVA: 0x00051600 File Offset: 0x0004F800
		public int[] RewiredPlayerIds
		{
			get
			{
				return (int[])this.rewiredPlayerIds.Clone();
			}
			set
			{
				this.rewiredPlayerIds = ((value != null) ? ((int[])value.Clone()) : new int[0]);
				this.SetupRewiredVars();
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000CA4 RID: 3236 RVA: 0x00051624 File Offset: 0x0004F824
		// (set) Token: 0x06000CA5 RID: 3237 RVA: 0x0005162C File Offset: 0x0004F82C
		public bool UsePlayingPlayersOnly
		{
			get
			{
				return this.usePlayingPlayersOnly;
			}
			set
			{
				this.usePlayingPlayersOnly = value;
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000CA6 RID: 3238 RVA: 0x00051635 File Offset: 0x0004F835
		// (set) Token: 0x06000CA7 RID: 3239 RVA: 0x0005163D File Offset: 0x0004F83D
		public bool MoveOneElementPerAxisPress
		{
			get
			{
				return this.moveOneElementPerAxisPress;
			}
			set
			{
				this.moveOneElementPerAxisPress = value;
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000CA8 RID: 3240 RVA: 0x00051646 File Offset: 0x0004F846
		// (set) Token: 0x06000CA9 RID: 3241 RVA: 0x0005164E File Offset: 0x0004F84E
		public bool allowMouseInput
		{
			get
			{
				return this.m_allowMouseInput;
			}
			set
			{
				this.m_allowMouseInput = value;
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000CAA RID: 3242 RVA: 0x00051657 File Offset: 0x0004F857
		// (set) Token: 0x06000CAB RID: 3243 RVA: 0x0005165F File Offset: 0x0004F85F
		public bool allowMouseInputIfTouchSupported
		{
			get
			{
				return this.m_allowMouseInputIfTouchSupported;
			}
			set
			{
				this.m_allowMouseInputIfTouchSupported = value;
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000CAC RID: 3244 RVA: 0x00051668 File Offset: 0x0004F868
		private bool isMouseSupported
		{
			get
			{
				return this.m_allowMouseInput && (!this.isTouchSupported || this.m_allowMouseInputIfTouchSupported);
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000CAD RID: 3245 RVA: 0x00051684 File Offset: 0x0004F884
		// (set) Token: 0x06000CAE RID: 3246 RVA: 0x0005168C File Offset: 0x0004F88C
		[Obsolete("allowActivationOnMobileDevice has been deprecated. Use forceModuleActive instead")]
		public bool allowActivationOnMobileDevice
		{
			get
			{
				return this.m_ForceModuleActive;
			}
			set
			{
				this.m_ForceModuleActive = value;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x06000CAF RID: 3247 RVA: 0x00051684 File Offset: 0x0004F884
		// (set) Token: 0x06000CB0 RID: 3248 RVA: 0x0005168C File Offset: 0x0004F88C
		public bool forceModuleActive
		{
			get
			{
				return this.m_ForceModuleActive;
			}
			set
			{
				this.m_ForceModuleActive = value;
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x06000CB1 RID: 3249 RVA: 0x00051695 File Offset: 0x0004F895
		// (set) Token: 0x06000CB2 RID: 3250 RVA: 0x0005169D File Offset: 0x0004F89D
		public float inputActionsPerSecond
		{
			get
			{
				return this.m_InputActionsPerSecond;
			}
			set
			{
				this.m_InputActionsPerSecond = value;
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000CB3 RID: 3251 RVA: 0x000516A6 File Offset: 0x0004F8A6
		// (set) Token: 0x06000CB4 RID: 3252 RVA: 0x000516AE File Offset: 0x0004F8AE
		public float repeatDelay
		{
			get
			{
				return this.m_RepeatDelay;
			}
			set
			{
				this.m_RepeatDelay = value;
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000CB5 RID: 3253 RVA: 0x000516B7 File Offset: 0x0004F8B7
		// (set) Token: 0x06000CB6 RID: 3254 RVA: 0x000516BF File Offset: 0x0004F8BF
		public string horizontalAxis
		{
			get
			{
				return this.m_HorizontalAxis;
			}
			set
			{
				this.m_HorizontalAxis = value;
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000CB7 RID: 3255 RVA: 0x000516C8 File Offset: 0x0004F8C8
		// (set) Token: 0x06000CB8 RID: 3256 RVA: 0x000516D0 File Offset: 0x0004F8D0
		public string verticalAxis
		{
			get
			{
				return this.m_VerticalAxis;
			}
			set
			{
				this.m_VerticalAxis = value;
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000CB9 RID: 3257 RVA: 0x000516D9 File Offset: 0x0004F8D9
		// (set) Token: 0x06000CBA RID: 3258 RVA: 0x000516E1 File Offset: 0x0004F8E1
		public string submitButton
		{
			get
			{
				return this.m_SubmitButton;
			}
			set
			{
				this.m_SubmitButton = value;
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000CBB RID: 3259 RVA: 0x000516EA File Offset: 0x0004F8EA
		// (set) Token: 0x06000CBC RID: 3260 RVA: 0x000516F2 File Offset: 0x0004F8F2
		public string cancelButton
		{
			get
			{
				return this.m_CancelButton;
			}
			set
			{
				this.m_CancelButton = value;
			}
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x000516FC File Offset: 0x0004F8FC
		protected RewiredStandaloneInputModule()
		{
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x00051760 File Offset: 0x0004F960
		protected override void Awake()
		{
			base.Awake();
			this.isTouchSupported = global::Input.touchSupported;
			TouchInputModule component = base.GetComponent<TouchInputModule>();
			if (component != null)
			{
				component.enabled = false;
			}
			this.InitializeRewired();
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x0005179B File Offset: 0x0004F99B
		public override void UpdateModule()
		{
			this.CheckEditorRecompile();
			if (this.recompiling)
			{
				return;
			}
			if (!ReInput.isReady)
			{
				return;
			}
			if (this.isMouseSupported)
			{
				this.m_LastMousePosition = this.m_MousePosition;
				this.m_MousePosition = UnityEngine.Input.mousePosition;
			}
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x0000E36F File Offset: 0x0000C56F
		public override bool IsModuleSupported()
		{
			return true;
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x000517D8 File Offset: 0x0004F9D8
		public override bool ShouldActivateModule()
		{
			if (!base.ShouldActivateModule())
			{
				return false;
			}
			if (this.recompiling)
			{
				return false;
			}
			if (!ReInput.isReady)
			{
				return false;
			}
			bool flag = this.m_ForceModuleActive;
			for (int i = 0; i < this.playerIds.Length; i++)
			{
				Player player = ReInput.players.GetPlayer(this.playerIds[i]);
				if (player != null && (!this.usePlayingPlayersOnly || player.isPlaying))
				{
					flag |= player.GetButtonDown(this.m_SubmitButton);
					flag |= player.GetButtonDown(this.m_CancelButton);
					if (this.moveOneElementPerAxisPress)
					{
						flag |= (player.GetButtonDown(this.m_HorizontalAxis) || player.GetNegativeButtonDown(this.m_HorizontalAxis));
						flag |= (player.GetButtonDown(this.m_VerticalAxis) || player.GetNegativeButtonDown(this.m_VerticalAxis));
					}
					else
					{
						flag |= !Mathf.Approximately(player.GetAxisRaw(this.m_HorizontalAxis), 0f);
						flag |= !Mathf.Approximately(player.GetAxisRaw(this.m_VerticalAxis), 0f);
					}
				}
			}
			if (this.isMouseSupported)
			{
				flag |= ((this.m_MousePosition - this.m_LastMousePosition).sqrMagnitude > 0f);
				flag |= UnityEngine.Input.GetMouseButtonDown(0);
			}
			if (this.isTouchSupported)
			{
				for (int j = 0; j < global::Input.touchCount; j++)
				{
					Touch touch = global::Input.GetTouch(j);
					flag |= (touch.phase == TouchPhase.Began || touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary);
				}
			}
			return flag;
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x0005196C File Offset: 0x0004FB6C
		public override void ActivateModule()
		{
			base.ActivateModule();
			if (this.isMouseSupported)
			{
				Vector2 vector = UnityEngine.Input.mousePosition;
				this.m_MousePosition = vector;
				this.m_LastMousePosition = vector;
			}
			GameObject gameObject = base.eventSystem.currentSelectedGameObject;
			if (gameObject == null)
			{
				gameObject = base.eventSystem.firstSelectedGameObject;
			}
			base.eventSystem.SetSelectedGameObject(gameObject, this.GetBaseEventData());
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x000519D3 File Offset: 0x0004FBD3
		public override void DeactivateModule()
		{
			base.DeactivateModule();
			base.ClearSelection();
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x000519E4 File Offset: 0x0004FBE4
		public override void Process()
		{
			if (!ReInput.isReady)
			{
				return;
			}
			bool flag = this.SendUpdateEventToSelectedObject();
			if (base.eventSystem.sendNavigationEvents)
			{
				if (!flag)
				{
					flag |= this.SendMoveEventToSelectedObject();
				}
				if (!flag)
				{
					this.SendSubmitEventToSelectedObject();
				}
			}
			if (!this.ProcessTouchEvents() && this.isMouseSupported)
			{
				this.ProcessMouseEvent();
			}
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x00051A3C File Offset: 0x0004FC3C
		private bool ProcessTouchEvents()
		{
			if (!this.isTouchSupported)
			{
				return false;
			}
			for (int i = 0; i < global::Input.touchCount; i++)
			{
				Touch touch = global::Input.GetTouch(i);
				if (touch.type != TouchType.Indirect)
				{
					bool pressed;
					bool flag;
					PointerEventData touchPointerEventData = base.GetTouchPointerEventData(touch, out pressed, out flag);
					this.ProcessTouchPress(touchPointerEventData, pressed, flag);
					if (!flag)
					{
						this.ProcessMove(touchPointerEventData);
						this.ProcessDrag(touchPointerEventData);
					}
					else
					{
						base.RemovePointerData(touchPointerEventData);
					}
				}
			}
			return global::Input.touchCount > 0;
		}

		// Token: 0x06000CC6 RID: 3270 RVA: 0x00051AB0 File Offset: 0x0004FCB0
		private void ProcessTouchPress(PointerEventData pointerEvent, bool pressed, bool released)
		{
			GameObject gameObject = pointerEvent.pointerCurrentRaycast.gameObject;
			if (pressed)
			{
				pointerEvent.eligibleForClick = true;
				pointerEvent.delta = Vector2.zero;
				pointerEvent.dragging = false;
				pointerEvent.useDragThreshold = true;
				pointerEvent.pressPosition = pointerEvent.position;
				pointerEvent.pointerPressRaycast = pointerEvent.pointerCurrentRaycast;
				base.DeselectIfSelectionChanged(gameObject, pointerEvent);
				if (pointerEvent.pointerEnter != gameObject)
				{
					base.HandlePointerExitAndEnter(pointerEvent, gameObject);
					pointerEvent.pointerEnter = gameObject;
				}
				GameObject gameObject2 = ExecuteEvents.ExecuteHierarchy<IPointerDownHandler>(gameObject, pointerEvent, ExecuteEvents.pointerDownHandler);
				if (gameObject2 == null)
				{
					gameObject2 = ExecuteEvents.GetEventHandler<IPointerClickHandler>(gameObject);
				}
				float unscaledTime = Time.unscaledTime;
				if (gameObject2 == pointerEvent.lastPress)
				{
					if (unscaledTime - pointerEvent.clickTime < 0.3f)
					{
						int clickCount = pointerEvent.clickCount + 1;
						pointerEvent.clickCount = clickCount;
					}
					else
					{
						pointerEvent.clickCount = 1;
					}
					pointerEvent.clickTime = unscaledTime;
				}
				else
				{
					pointerEvent.clickCount = 1;
				}
				pointerEvent.pointerPress = gameObject2;
				pointerEvent.rawPointerPress = gameObject;
				pointerEvent.clickTime = unscaledTime;
				pointerEvent.pointerDrag = ExecuteEvents.GetEventHandler<IDragHandler>(gameObject);
				if (pointerEvent.pointerDrag != null)
				{
					ExecuteEvents.Execute<IInitializePotentialDragHandler>(pointerEvent.pointerDrag, pointerEvent, ExecuteEvents.initializePotentialDrag);
				}
			}
			if (released)
			{
				ExecuteEvents.Execute<IPointerUpHandler>(pointerEvent.pointerPress, pointerEvent, ExecuteEvents.pointerUpHandler);
				GameObject eventHandler = ExecuteEvents.GetEventHandler<IPointerClickHandler>(gameObject);
				if (pointerEvent.pointerPress == eventHandler && pointerEvent.eligibleForClick)
				{
					ExecuteEvents.Execute<IPointerClickHandler>(pointerEvent.pointerPress, pointerEvent, ExecuteEvents.pointerClickHandler);
				}
				else if (pointerEvent.pointerDrag != null && pointerEvent.dragging)
				{
					ExecuteEvents.ExecuteHierarchy<IDropHandler>(gameObject, pointerEvent, ExecuteEvents.dropHandler);
				}
				pointerEvent.eligibleForClick = false;
				pointerEvent.pointerPress = null;
				pointerEvent.rawPointerPress = null;
				if (pointerEvent.pointerDrag != null && pointerEvent.dragging)
				{
					ExecuteEvents.Execute<IEndDragHandler>(pointerEvent.pointerDrag, pointerEvent, ExecuteEvents.endDragHandler);
				}
				pointerEvent.dragging = false;
				pointerEvent.pointerDrag = null;
				if (pointerEvent.pointerDrag != null)
				{
					ExecuteEvents.Execute<IEndDragHandler>(pointerEvent.pointerDrag, pointerEvent, ExecuteEvents.endDragHandler);
				}
				pointerEvent.pointerDrag = null;
				ExecuteEvents.ExecuteHierarchy<IPointerExitHandler>(pointerEvent.pointerEnter, pointerEvent, ExecuteEvents.pointerExitHandler);
				pointerEvent.pointerEnter = null;
			}
		}

		// Token: 0x06000CC7 RID: 3271 RVA: 0x00051CD4 File Offset: 0x0004FED4
		protected bool SendSubmitEventToSelectedObject()
		{
			if (base.eventSystem.currentSelectedGameObject == null)
			{
				return false;
			}
			if (this.recompiling)
			{
				return false;
			}
			BaseEventData baseEventData = this.GetBaseEventData();
			for (int i = 0; i < this.playerIds.Length; i++)
			{
				Player player = ReInput.players.GetPlayer(this.playerIds[i]);
				if (player != null && (!this.usePlayingPlayersOnly || player.isPlaying))
				{
					if (player.GetButtonDown(this.m_SubmitButton))
					{
						ExecuteEvents.Execute<ISubmitHandler>(base.eventSystem.currentSelectedGameObject, baseEventData, ExecuteEvents.submitHandler);
						break;
					}
					if (player.GetButtonDown(this.m_CancelButton))
					{
						ExecuteEvents.Execute<ICancelHandler>(base.eventSystem.currentSelectedGameObject, baseEventData, ExecuteEvents.cancelHandler);
						break;
					}
				}
			}
			return baseEventData.used;
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x00051D98 File Offset: 0x0004FF98
		private Vector2 GetRawMoveVector()
		{
			if (this.recompiling)
			{
				return Vector2.zero;
			}
			Vector2 zero = Vector2.zero;
			bool flag = false;
			bool flag2 = false;
			for (int i = 0; i < this.playerIds.Length; i++)
			{
				Player player = ReInput.players.GetPlayer(this.playerIds[i]);
				if (player != null && (!this.usePlayingPlayersOnly || player.isPlaying))
				{
					if (this.moveOneElementPerAxisPress)
					{
						float num = 0f;
						if (player.GetButtonDown(this.m_HorizontalAxis))
						{
							num = 1f;
						}
						else if (player.GetNegativeButtonDown(this.m_HorizontalAxis))
						{
							num = -1f;
						}
						float num2 = 0f;
						if (player.GetButtonDown(this.m_VerticalAxis))
						{
							num2 = 1f;
						}
						else if (player.GetNegativeButtonDown(this.m_VerticalAxis))
						{
							num2 = -1f;
						}
						zero.x += num;
						zero.y += num2;
					}
					else
					{
						zero.x += player.GetAxisRaw(this.m_HorizontalAxis);
						zero.y += player.GetAxisRaw(this.m_VerticalAxis);
					}
					flag |= (player.GetButtonDown(this.m_HorizontalAxis) || player.GetNegativeButtonDown(this.m_HorizontalAxis));
					flag2 |= (player.GetButtonDown(this.m_VerticalAxis) || player.GetNegativeButtonDown(this.m_VerticalAxis));
				}
			}
			if (flag)
			{
				if (zero.x < 0f)
				{
					zero.x = -1f;
				}
				if (zero.x > 0f)
				{
					zero.x = 1f;
				}
			}
			if (flag2)
			{
				if (zero.y < 0f)
				{
					zero.y = -1f;
				}
				if (zero.y > 0f)
				{
					zero.y = 1f;
				}
			}
			return zero;
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00051F78 File Offset: 0x00050178
		protected bool SendMoveEventToSelectedObject()
		{
			if (this.recompiling)
			{
				return false;
			}
			float unscaledTime = Time.unscaledTime;
			Vector2 rawMoveVector = this.GetRawMoveVector();
			if (Mathf.Approximately(rawMoveVector.x, 0f) && Mathf.Approximately(rawMoveVector.y, 0f))
			{
				this.m_ConsecutiveMoveCount = 0;
				return false;
			}
			bool flag = Vector2.Dot(rawMoveVector, this.m_LastMoveVector) > 0f;
			bool flag2 = this.CheckButtonOrKeyMovement(unscaledTime);
			if (!flag2)
			{
				if (this.m_RepeatDelay > 0f)
				{
					if (flag && this.m_ConsecutiveMoveCount == 1)
					{
						flag2 = (unscaledTime > this.m_PrevActionTime + this.m_RepeatDelay);
					}
					else
					{
						flag2 = (unscaledTime > this.m_PrevActionTime + 1f / this.m_InputActionsPerSecond);
					}
				}
				else
				{
					flag2 = (unscaledTime > this.m_PrevActionTime + 1f / this.m_InputActionsPerSecond);
				}
			}
			if (!flag2)
			{
				return false;
			}
			AxisEventData axisEventData = this.GetAxisEventData(rawMoveVector.x, rawMoveVector.y, 0.6f);
			if (axisEventData.moveDir == MoveDirection.None)
			{
				return false;
			}
			ExecuteEvents.Execute<IMoveHandler>(base.eventSystem.currentSelectedGameObject, axisEventData, ExecuteEvents.moveHandler);
			if (!flag)
			{
				this.m_ConsecutiveMoveCount = 0;
			}
			this.m_ConsecutiveMoveCount++;
			this.m_PrevActionTime = unscaledTime;
			this.m_LastMoveVector = rawMoveVector;
			return axisEventData.used;
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x000520B4 File Offset: 0x000502B4
		private bool CheckButtonOrKeyMovement(float time)
		{
			bool flag = false;
			for (int i = 0; i < this.playerIds.Length; i++)
			{
				Player player = ReInput.players.GetPlayer(this.playerIds[i]);
				if (player != null && (!this.usePlayingPlayersOnly || player.isPlaying))
				{
					flag |= (player.GetButtonDown(this.m_HorizontalAxis) || player.GetNegativeButtonDown(this.m_HorizontalAxis));
					flag |= (player.GetButtonDown(this.m_VerticalAxis) || player.GetNegativeButtonDown(this.m_VerticalAxis));
				}
			}
			return flag;
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x0005213D File Offset: 0x0005033D
		protected void ProcessMouseEvent()
		{
			this.ProcessMouseEvent(0);
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x00052148 File Offset: 0x00050348
		protected void ProcessMouseEvent(int id)
		{
			PointerInputModule.MouseState mousePointerEventData = this.GetMousePointerEventData();
			PointerInputModule.MouseButtonEventData eventData = mousePointerEventData.GetButtonState(PointerEventData.InputButton.Left).eventData;
			this.ProcessMousePress(eventData);
			this.ProcessMove(eventData.buttonData);
			this.ProcessDrag(eventData.buttonData);
			this.ProcessMousePress(mousePointerEventData.GetButtonState(PointerEventData.InputButton.Right).eventData);
			this.ProcessDrag(mousePointerEventData.GetButtonState(PointerEventData.InputButton.Right).eventData.buttonData);
			this.ProcessMousePress(mousePointerEventData.GetButtonState(PointerEventData.InputButton.Middle).eventData);
			this.ProcessDrag(mousePointerEventData.GetButtonState(PointerEventData.InputButton.Middle).eventData.buttonData);
			if (!Mathf.Approximately(eventData.buttonData.scrollDelta.sqrMagnitude, 0f))
			{
				ExecuteEvents.ExecuteHierarchy<IScrollHandler>(ExecuteEvents.GetEventHandler<IScrollHandler>(eventData.buttonData.pointerCurrentRaycast.gameObject), eventData.buttonData, ExecuteEvents.scrollHandler);
			}
		}

		// Token: 0x06000CCD RID: 3277 RVA: 0x00052224 File Offset: 0x00050424
		protected bool SendUpdateEventToSelectedObject()
		{
			if (base.eventSystem.currentSelectedGameObject == null)
			{
				return false;
			}
			BaseEventData baseEventData = this.GetBaseEventData();
			ExecuteEvents.Execute<IUpdateSelectedHandler>(base.eventSystem.currentSelectedGameObject, baseEventData, ExecuteEvents.updateSelectedHandler);
			return baseEventData.used;
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x0005226C File Offset: 0x0005046C
		protected void ProcessMousePress(PointerInputModule.MouseButtonEventData data)
		{
			PointerEventData buttonData = data.buttonData;
			GameObject gameObject = buttonData.pointerCurrentRaycast.gameObject;
			if (data.PressedThisFrame())
			{
				buttonData.eligibleForClick = true;
				buttonData.delta = Vector2.zero;
				buttonData.dragging = false;
				buttonData.useDragThreshold = true;
				buttonData.pressPosition = buttonData.position;
				buttonData.pointerPressRaycast = buttonData.pointerCurrentRaycast;
				base.DeselectIfSelectionChanged(gameObject, buttonData);
				GameObject gameObject2 = ExecuteEvents.ExecuteHierarchy<IPointerDownHandler>(gameObject, buttonData, ExecuteEvents.pointerDownHandler);
				if (gameObject2 == null)
				{
					gameObject2 = ExecuteEvents.GetEventHandler<IPointerClickHandler>(gameObject);
				}
				float unscaledTime = Time.unscaledTime;
				if (gameObject2 == buttonData.lastPress)
				{
					if (unscaledTime - buttonData.clickTime < 0.3f)
					{
						PointerEventData pointerEventData = buttonData;
						int clickCount = pointerEventData.clickCount + 1;
						pointerEventData.clickCount = clickCount;
					}
					else
					{
						buttonData.clickCount = 1;
					}
					buttonData.clickTime = unscaledTime;
				}
				else
				{
					buttonData.clickCount = 1;
				}
				buttonData.pointerPress = gameObject2;
				buttonData.rawPointerPress = gameObject;
				buttonData.clickTime = unscaledTime;
				buttonData.pointerDrag = ExecuteEvents.GetEventHandler<IDragHandler>(gameObject);
				if (buttonData.pointerDrag != null)
				{
					ExecuteEvents.Execute<IInitializePotentialDragHandler>(buttonData.pointerDrag, buttonData, ExecuteEvents.initializePotentialDrag);
				}
			}
			if (data.ReleasedThisFrame())
			{
				ExecuteEvents.Execute<IPointerUpHandler>(buttonData.pointerPress, buttonData, ExecuteEvents.pointerUpHandler);
				GameObject eventHandler = ExecuteEvents.GetEventHandler<IPointerClickHandler>(gameObject);
				if (buttonData.pointerPress == eventHandler && buttonData.eligibleForClick)
				{
					ExecuteEvents.Execute<IPointerClickHandler>(buttonData.pointerPress, buttonData, ExecuteEvents.pointerClickHandler);
				}
				else if (buttonData.pointerDrag != null && buttonData.dragging)
				{
					ExecuteEvents.ExecuteHierarchy<IDropHandler>(gameObject, buttonData, ExecuteEvents.dropHandler);
				}
				buttonData.eligibleForClick = false;
				buttonData.pointerPress = null;
				buttonData.rawPointerPress = null;
				if (buttonData.pointerDrag != null && buttonData.dragging)
				{
					ExecuteEvents.Execute<IEndDragHandler>(buttonData.pointerDrag, buttonData, ExecuteEvents.endDragHandler);
				}
				buttonData.dragging = false;
				buttonData.pointerDrag = null;
				if (gameObject != buttonData.pointerEnter)
				{
					base.HandlePointerExitAndEnter(buttonData, null);
					base.HandlePointerExitAndEnter(buttonData, gameObject);
				}
			}
		}

		// Token: 0x06000CCF RID: 3279 RVA: 0x00052466 File Offset: 0x00050666
		private void InitializeRewired()
		{
			if (!ReInput.isReady)
			{
				Debug.LogError("Rewired is not initialized! Are you missing a Rewired Input Manager in your scene?");
				return;
			}
			ReInput.EditorRecompileEvent += this.OnEditorRecompile;
			this.SetupRewiredVars();
		}

		// Token: 0x06000CD0 RID: 3280 RVA: 0x00052494 File Offset: 0x00050694
		private void SetupRewiredVars()
		{
			if (this.useAllRewiredGamePlayers)
			{
				IList<Player> list = this.useRewiredSystemPlayer ? ReInput.players.AllPlayers : ReInput.players.Players;
				this.playerIds = new int[list.Count];
				for (int i = 0; i < list.Count; i++)
				{
					this.playerIds[i] = list[i].id;
				}
				return;
			}
			int num = this.rewiredPlayerIds.Length + (this.useRewiredSystemPlayer ? 1 : 0);
			this.playerIds = new int[num];
			for (int j = 0; j < this.rewiredPlayerIds.Length; j++)
			{
				this.playerIds[j] = ReInput.players.GetPlayer(this.rewiredPlayerIds[j]).id;
			}
			if (this.useRewiredSystemPlayer)
			{
				this.playerIds[num - 1] = ReInput.players.GetSystemPlayer().id;
			}
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x00052574 File Offset: 0x00050774
		private void CheckEditorRecompile()
		{
			if (!this.recompiling)
			{
				return;
			}
			if (!ReInput.isReady)
			{
				return;
			}
			this.recompiling = false;
			this.InitializeRewired();
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x00052594 File Offset: 0x00050794
		private void OnEditorRecompile()
		{
			this.recompiling = true;
			this.ClearRewiredVars();
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x000525A3 File Offset: 0x000507A3
		private void ClearRewiredVars()
		{
			Array.Clear(this.playerIds, 0, this.playerIds.Length);
		}

		// Token: 0x04000ACB RID: 2763
		private const string DEFAULT_ACTION_MOVE_HORIZONTAL = "UIHorizontal";

		// Token: 0x04000ACC RID: 2764
		private const string DEFAULT_ACTION_MOVE_VERTICAL = "UIVertical";

		// Token: 0x04000ACD RID: 2765
		private const string DEFAULT_ACTION_SUBMIT = "UISubmit";

		// Token: 0x04000ACE RID: 2766
		private const string DEFAULT_ACTION_CANCEL = "UICancel";

		// Token: 0x04000ACF RID: 2767
		private int[] playerIds;

		// Token: 0x04000AD0 RID: 2768
		private bool recompiling;

		// Token: 0x04000AD1 RID: 2769
		private bool isTouchSupported;

		// Token: 0x04000AD2 RID: 2770
		[SerializeField]
		[Tooltip("Use all Rewired game Players to control the UI. This does not include the System Player. If enabled, this setting overrides individual Player Ids set in Rewired Player Ids.")]
		private bool useAllRewiredGamePlayers;

		// Token: 0x04000AD3 RID: 2771
		[SerializeField]
		[Tooltip("Allow the Rewired System Player to control the UI.")]
		private bool useRewiredSystemPlayer;

		// Token: 0x04000AD4 RID: 2772
		[SerializeField]
		[Tooltip("A list of Player Ids that are allowed to control the UI. If Use All Rewired Game Players = True, this list will be ignored.")]
		private int[] rewiredPlayerIds = new int[1];

		// Token: 0x04000AD5 RID: 2773
		[SerializeField]
		[Tooltip("Allow only Players with Player.isPlaying = true to control the UI.")]
		private bool usePlayingPlayersOnly;

		// Token: 0x04000AD6 RID: 2774
		[SerializeField]
		[Tooltip("Makes an axis press always move only one UI selection. Enable if you do not want to allow scrolling through UI elements by holding an axis direction.")]
		private bool moveOneElementPerAxisPress;

		// Token: 0x04000AD7 RID: 2775
		private float m_PrevActionTime;

		// Token: 0x04000AD8 RID: 2776
		private Vector2 m_LastMoveVector;

		// Token: 0x04000AD9 RID: 2777
		private int m_ConsecutiveMoveCount;

		// Token: 0x04000ADA RID: 2778
		private Vector2 m_LastMousePosition;

		// Token: 0x04000ADB RID: 2779
		private Vector2 m_MousePosition;

		// Token: 0x04000ADC RID: 2780
		[SerializeField]
		private string m_HorizontalAxis = "UIHorizontal";

		// Token: 0x04000ADD RID: 2781
		[SerializeField]
		[Tooltip("Name of the vertical axis for movement (if axis events are used).")]
		private string m_VerticalAxis = "UIVertical";

		// Token: 0x04000ADE RID: 2782
		[SerializeField]
		[Tooltip("Name of the action used to submit.")]
		private string m_SubmitButton = "UISubmit";

		// Token: 0x04000ADF RID: 2783
		[SerializeField]
		[Tooltip("Name of the action used to cancel.")]
		private string m_CancelButton = "UICancel";

		// Token: 0x04000AE0 RID: 2784
		[SerializeField]
		[Tooltip("Number of selection changes allowed per second when a movement button/axis is held in a direction.")]
		private float m_InputActionsPerSecond = 10f;

		// Token: 0x04000AE1 RID: 2785
		[SerializeField]
		[Tooltip("Delay in seconds before vertical/horizontal movement starts repeating continouously when a movement direction is held.")]
		private float m_RepeatDelay;

		// Token: 0x04000AE2 RID: 2786
		[SerializeField]
		[Tooltip("Allows the mouse to be used to select elements.")]
		private bool m_allowMouseInput = true;

		// Token: 0x04000AE3 RID: 2787
		[SerializeField]
		[Tooltip("Allows the mouse to be used to select elements if the device also supports touch control.")]
		private bool m_allowMouseInputIfTouchSupported = true;

		// Token: 0x04000AE4 RID: 2788
		[SerializeField]
		[FormerlySerializedAs("m_AllowActivationOnMobileDevice")]
		[Tooltip("Forces the module to always be active.")]
		private bool m_ForceModuleActive;
	}
}
