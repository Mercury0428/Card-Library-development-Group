﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Rewired.Utils.Interfaces;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.Utils
{
	// Token: 0x0200018F RID: 399
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class ExternalTools : IExternalTools
	{
		// Token: 0x06000C40 RID: 3136 RVA: 0x0000821B File Offset: 0x0000641B
		public bool LinuxInput_IsJoystickPreconfigured(string name)
		{
			return false;
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000C41 RID: 3137 RVA: 0x00050680 File Offset: 0x0004E880
		// (remove) Token: 0x06000C42 RID: 3138 RVA: 0x000506B8 File Offset: 0x0004E8B8
		public event Action<uint, bool> XboxOneInput_OnGamepadStateChange;

		// Token: 0x06000C43 RID: 3139 RVA: 0x0000821B File Offset: 0x0000641B
		public int XboxOneInput_GetUserIdForGamepad(uint id)
		{
			return 0;
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x000506ED File Offset: 0x0004E8ED
		public ulong XboxOneInput_GetControllerId(uint unityJoystickId)
		{
			return 0UL;
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x0000821B File Offset: 0x0000641B
		public bool XboxOneInput_IsGamepadActive(uint unityJoystickId)
		{
			return false;
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x00050652 File Offset: 0x0004E852
		public string XboxOneInput_GetControllerType(ulong xboxControllerId)
		{
			return string.Empty;
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x0000821B File Offset: 0x0000641B
		public uint XboxOneInput_GetJoystickId(ulong xboxControllerId)
		{
			return 0U;
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x00003D07 File Offset: 0x00001F07
		public void XboxOne_Gamepad_UpdatePlugin()
		{
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x0000821B File Offset: 0x0000641B
		public bool XboxOne_Gamepad_SetGamepadVibration(ulong xboxOneJoystickId, float leftMotor, float rightMotor, float leftTriggerLevel, float rightTriggerLevel)
		{
			return false;
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x00003D07 File Offset: 0x00001F07
		public void XboxOne_Gamepad_PulseVibrateMotor(ulong xboxOneJoystickId, int motorInt, float startLevel, float endLevel, ulong durationMS)
		{
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x000506F1 File Offset: 0x0004E8F1
		public Vector3 PS4Input_GetLastAcceleration(int id)
		{
			return Vector3.zero;
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x000506F1 File Offset: 0x0004E8F1
		public Vector3 PS4Input_GetLastGyro(int id)
		{
			return Vector3.zero;
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x000506F8 File Offset: 0x0004E8F8
		public Vector4 PS4Input_GetLastOrientation(int id)
		{
			return Vector4.zero;
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x000506FF File Offset: 0x0004E8FF
		public void PS4Input_GetLastTouchData(int id, out int touchNum, out int touch0x, out int touch0y, out int touch0id, out int touch1x, out int touch1y, out int touch1id)
		{
			touchNum = 0;
			touch0x = 0;
			touch0y = 0;
			touch0id = 0;
			touch1x = 0;
			touch1y = 0;
			touch1id = 0;
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x0005071B File Offset: 0x0004E91B
		public void PS4Input_GetPadControllerInformation(int id, out float touchpixelDensity, out int touchResolutionX, out int touchResolutionY, out int analogDeadZoneLeft, out int analogDeadZoneright, out int connectionType)
		{
			touchpixelDensity = 0f;
			touchResolutionX = 0;
			touchResolutionY = 0;
			analogDeadZoneLeft = 0;
			analogDeadZoneright = 0;
			connectionType = 0;
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadSetMotionSensorState(int id, bool bEnable)
		{
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadSetTiltCorrectionState(int id, bool bEnable)
		{
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadSetAngularVelocityDeadbandState(int id, bool bEnable)
		{
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadSetLightBar(int id, int red, int green, int blue)
		{
		}

		// Token: 0x06000C54 RID: 3156 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadResetLightBar(int id)
		{
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadSetVibration(int id, int largeMotor, int smallMotor)
		{
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x00003D07 File Offset: 0x00001F07
		public void PS4Input_PadResetOrientation(int id)
		{
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x0000821B File Offset: 0x0000641B
		public bool PS4Input_PadIsConnected(int id)
		{
			return false;
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x000393B1 File Offset: 0x000375B1
		public object PS4Input_PadGetUsersDetails(int slot)
		{
			return null;
		}

		// Token: 0x06000C59 RID: 3161 RVA: 0x000506F1 File Offset: 0x0004E8F1
		public Vector3 PS4Input_GetLastMoveAcceleration(int id, int index)
		{
			return Vector3.zero;
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x000506F1 File Offset: 0x0004E8F1
		public Vector3 PS4Input_GetLastMoveGyro(int id, int index)
		{
			return Vector3.zero;
		}

		// Token: 0x06000C5B RID: 3163 RVA: 0x0000821B File Offset: 0x0000641B
		public int PS4Input_MoveGetButtons(int id, int index)
		{
			return 0;
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x0000821B File Offset: 0x0000641B
		public int PS4Input_MoveGetAnalogButton(int id, int index)
		{
			return 0;
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x0000821B File Offset: 0x0000641B
		public bool PS4Input_MoveIsConnected(int id, int index)
		{
			return false;
		}

		// Token: 0x06000C5E RID: 3166 RVA: 0x0000821B File Offset: 0x0000641B
		public int PS4Input_MoveGetUsersMoveHandles(int maxNumberControllers, int[] primaryHandles, int[] secondaryHandles)
		{
			return 0;
		}

		// Token: 0x06000C5F RID: 3167 RVA: 0x0000821B File Offset: 0x0000641B
		public int PS4Input_MoveGetUsersMoveHandles(int maxNumberControllers, int[] primaryHandles)
		{
			return 0;
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x0000821B File Offset: 0x0000641B
		public int PS4Input_MoveGetUsersMoveHandles(int maxNumberControllers)
		{
			return 0;
		}

		// Token: 0x06000C61 RID: 3169 RVA: 0x00050737 File Offset: 0x0004E937
		public IntPtr PS4Input_MoveGetControllerInputForTracking()
		{
			return IntPtr.Zero;
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x0005073E File Offset: 0x0004E93E
		public void GetDeviceVIDPIDs(out List<int> vids, out List<int> pids)
		{
			vids = new List<int>();
			pids = new List<int>();
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x0005074E File Offset: 0x0004E94E
		public bool UnityUI_Graphic_GetRaycastTarget(object graphic)
		{
			return !(graphic as Graphic == null) && (graphic as Graphic).raycastTarget;
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x0005076B File Offset: 0x0004E96B
		public void UnityUI_Graphic_SetRaycastTarget(object graphic, bool value)
		{
			if (graphic as Graphic == null)
			{
				return;
			}
			(graphic as Graphic).raycastTarget = value;
		}
	}
}
