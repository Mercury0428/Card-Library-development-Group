﻿using System;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Rewired.Platforms;
using Rewired.Utils;
using Rewired.Utils.Interfaces;
using UnityEngine;

namespace Rewired
{
	// Token: 0x0200018E RID: 398
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class InputManager : InputManager_Base
	{
		// Token: 0x06000C3A RID: 3130 RVA: 0x00050613 File Offset: 0x0004E813
		protected override void DetectPlatform()
		{
			this.editorPlatform = EditorPlatform.None;
			this.platform = Platform.Unknown;
			this.webplayerPlatform = WebplayerPlatform.None;
			this.isEditor = false;
			if (SystemInfo.deviceName == null)
			{
				string empty = string.Empty;
			}
			if (SystemInfo.deviceModel == null)
			{
				string empty2 = string.Empty;
			}
			this.platform = Platform.Windows;
		}

		// Token: 0x06000C3B RID: 3131 RVA: 0x00003D07 File Offset: 0x00001F07
		protected override void CheckRecompile()
		{
		}

		// Token: 0x06000C3C RID: 3132 RVA: 0x00050652 File Offset: 0x0004E852
		protected override string GetFocusedEditorWindowTitle()
		{
			return string.Empty;
		}

		// Token: 0x06000C3D RID: 3133 RVA: 0x00050659 File Offset: 0x0004E859
		protected override IExternalTools GetExternalTools()
		{
			return new ExternalTools();
		}

		// Token: 0x06000C3E RID: 3134 RVA: 0x00050660 File Offset: 0x0004E860
		private bool CheckDeviceName(string searchPattern, string deviceName, string deviceModel)
		{
			return Regex.IsMatch(deviceName, searchPattern, RegexOptions.IgnoreCase) || Regex.IsMatch(deviceModel, searchPattern, RegexOptions.IgnoreCase);
		}
	}
}
