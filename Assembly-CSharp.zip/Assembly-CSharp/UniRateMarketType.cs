﻿using System;

// Token: 0x020000A7 RID: 167
public enum UniRateMarketType
{
	// Token: 0x040005F5 RID: 1525
	GooglePlay,
	// Token: 0x040005F6 RID: 1526
	AmazonAppstore
}
