﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace SVGImporter
{
	// Token: 0x020000AF RID: 175
	[RequireComponent(typeof(SVGRenderer))]
	public class SVGLegacyAnimator : MonoBehaviour
	{
		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000575 RID: 1397 RVA: 0x0001FFED File Offset: 0x0001E1ED
		// (set) Token: 0x06000576 RID: 1398 RVA: 0x0001FFF5 File Offset: 0x0001E1F5
		public SVGLegacyAnimator.OnCompleteEvent onComplete
		{
			get
			{
				return this.m_onComplete;
			}
			set
			{
				this.m_onComplete = value;
			}
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x0001FFFE File Offset: 0x0001E1FE
		public void Play()
		{
			this._isPlaying = true;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00020007 File Offset: 0x0001E207
		public void Stop()
		{
			this.currentLoop = 0;
			this.progress = 0f;
			this._isPlaying = false;
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00020022 File Offset: 0x0001E222
		public void Pause()
		{
			this._isPlaying = false;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0002002B File Offset: 0x0001E22B
		public void Restart()
		{
			this.Stop();
			this.Play();
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x0600057B RID: 1403 RVA: 0x00020039 File Offset: 0x0001E239
		public bool isPlaying
		{
			get
			{
				return this._isPlaying;
			}
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00020041 File Offset: 0x0001E241
		protected virtual void Awake()
		{
			this.svgRenderer = base.GetComponent<SVGRenderer>();
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0002004F File Offset: 0x0001E24F
		protected virtual void Start()
		{
			if (this.playOnAwake)
			{
				this.Play();
			}
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00020060 File Offset: 0x0001E260
		protected virtual void LateUpdate()
		{
			if (!this._isPlaying)
			{
				return;
			}
			if (this.progress >= 0f && this.direction)
			{
				this.progress += Time.deltaTime * this.timeScale;
				if (this.progress >= this.duration)
				{
					this.AnimationEnded();
				}
			}
			else if (this.progress <= this.duration && !this.direction)
			{
				this.progress -= Time.deltaTime * this.timeScale;
				if (this.progress <= 0f)
				{
					this.AnimationEnded();
				}
			}
			switch (this.wrapMode)
			{
			case SVGLegacyAnimator.WrapMode.ONCE:
				this.progress = Mathf.Clamp(this.progress, 0f, this.duration);
				break;
			case SVGLegacyAnimator.WrapMode.LOOP:
				this.progress = Mathf.Repeat(this.progress, this.duration);
				break;
			case SVGLegacyAnimator.WrapMode.PING_PONG:
				this.progress = Mathf.Clamp(this.progress, 0f, this.duration);
				break;
			}
			this.UpdateMesh();
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00020170 File Offset: 0x0001E370
		public void UpdateMesh()
		{
			int num = Mathf.Clamp(Mathf.RoundToInt(this.normalizedProgress * (float)this.frames.Length - 0.5f), 0, this.frames.Length - 1);
			if (this.svgRenderer.vectorGraphics != this.frames[num])
			{
				this.svgRenderer.vectorGraphics = this.frames[num];
			}
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x000201D8 File Offset: 0x0001E3D8
		private void AnimationEnded()
		{
			switch (this.wrapMode)
			{
			case SVGLegacyAnimator.WrapMode.ONCE:
				if (this.rewind)
				{
					this.Stop();
				}
				else
				{
					this._isPlaying = false;
				}
				this.m_onComplete.Invoke(this);
				return;
			case SVGLegacyAnimator.WrapMode.LOOP:
				if (this.loops >= 0 && this.currentLoop >= this.loops)
				{
					if (this.rewind)
					{
						this.Stop();
					}
					else
					{
						this.currentLoop = this.loops;
						this._isPlaying = false;
					}
					this.m_onComplete.Invoke(this);
					return;
				}
				this.currentLoop++;
				return;
			case SVGLegacyAnimator.WrapMode.PING_PONG:
				if (this.loops >= 0 && this.currentLoop >= this.loops)
				{
					if (this.rewind)
					{
						this.Stop();
					}
					else
					{
						this.currentLoop = this.loops;
						this._isPlaying = false;
					}
					this.m_onComplete.Invoke(this);
					return;
				}
				this.direction = !this.direction;
				this.currentLoop++;
				return;
			default:
				return;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000581 RID: 1409 RVA: 0x000202DD File Offset: 0x0001E4DD
		public float normalizedProgress
		{
			get
			{
				if (this.duration == 0f)
				{
					return 0f;
				}
				return Mathf.Clamp01(this.progress / this.duration);
			}
		}

		// Token: 0x0400061E RID: 1566
		public SVGAsset[] frames;

		// Token: 0x0400061F RID: 1567
		public SVGLegacyAnimator.WrapMode wrapMode;

		// Token: 0x04000620 RID: 1568
		public bool playOnAwake = true;

		// Token: 0x04000621 RID: 1569
		public float duration = 1f;

		// Token: 0x04000622 RID: 1570
		public float timeScale = 1f;

		// Token: 0x04000623 RID: 1571
		public bool direction = true;

		// Token: 0x04000624 RID: 1572
		public int loops = -1;

		// Token: 0x04000625 RID: 1573
		public int currentLoop;

		// Token: 0x04000626 RID: 1574
		public bool rewind;

		// Token: 0x04000627 RID: 1575
		public float progress;

		// Token: 0x04000628 RID: 1576
		[FormerlySerializedAs("onComplete")]
		[SerializeField]
		protected SVGLegacyAnimator.OnCompleteEvent m_onComplete = new SVGLegacyAnimator.OnCompleteEvent();

		// Token: 0x04000629 RID: 1577
		protected bool _isPlaying;

		// Token: 0x0400062A RID: 1578
		protected SVGRenderer svgRenderer;

		// Token: 0x0200033D RID: 829
		[Serializable]
		public class OnCompleteEvent : UnityEvent<SVGLegacyAnimator>
		{
		}

		// Token: 0x0200033E RID: 830
		public enum WrapMode
		{
			// Token: 0x040011F8 RID: 4600
			ONCE,
			// Token: 0x040011F9 RID: 4601
			LOOP,
			// Token: 0x040011FA RID: 4602
			PING_PONG
		}
	}
}
