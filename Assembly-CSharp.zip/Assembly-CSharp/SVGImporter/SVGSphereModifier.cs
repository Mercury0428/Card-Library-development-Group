﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B9 RID: 185
	[ExecuteInEditMode]
	[RequireComponent(typeof(ISVGRenderer))]
	[AddComponentMenu("Rendering/SVG Modifiers/Sphere Modifier", 22)]
	public class SVGSphereModifier : SVGModifier
	{
		// Token: 0x060005AA RID: 1450 RVA: 0x00020D88 File Offset: 0x0001EF88
		protected override void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force)
		{
			if (this.center == null)
			{
				return;
			}
			Vector2 a = this.center.position;
			if (layers == null)
			{
				return;
			}
			int num = layers.Length;
			if (!this.useSelection)
			{
				for (int i = 0; i < num; i++)
				{
					if (layers[i].shapes != null)
					{
						int num2 = layers[i].shapes.Length;
						for (int j = 0; j < num2; j++)
						{
							int vertexCount = layers[i].shapes[j].vertexCount;
							for (int k = 0; k < vertexCount; k++)
							{
								Vector2 vector = a - layers[i].shapes[j].vertices[k];
								float num3 = Mathf.Sqrt(vector.x * vector.x + vector.y * vector.y);
								Vector2 zero = Vector2.zero;
								if (num3 > 0f)
								{
									zero.x = vector.x / num3;
									zero.y = vector.y / num3;
								}
								layers[i].shapes[j].vertices[k] += zero * (1f - Mathf.Clamp01(num3 / this.radius)) * this.intensity;
							}
						}
					}
				}
				return;
			}
			for (int l = 0; l < num; l++)
			{
				if (layers[l].shapes != null && this.layerSelection.Contains(l))
				{
					int num4 = layers[l].shapes.Length;
					for (int m = 0; m < num4; m++)
					{
						int vertexCount2 = layers[l].shapes[m].vertexCount;
						for (int n = 0; n < vertexCount2; n++)
						{
							Vector2 vector = a - layers[l].shapes[m].vertices[n];
							float num3 = Mathf.Sqrt(vector.x * vector.x + vector.y * vector.y);
							Vector2 zero = Vector2.zero;
							if (num3 > 0f)
							{
								zero.x = vector.x / num3;
								zero.y = vector.y / num3;
							}
							layers[l].shapes[m].vertices[n] += zero * (1f - Mathf.Clamp01(num3 / this.radius)) * this.intensity;
						}
					}
				}
			}
		}

		// Token: 0x04000650 RID: 1616
		public Transform center;

		// Token: 0x04000651 RID: 1617
		public float radius;

		// Token: 0x04000652 RID: 1618
		public float intensity;
	}
}
