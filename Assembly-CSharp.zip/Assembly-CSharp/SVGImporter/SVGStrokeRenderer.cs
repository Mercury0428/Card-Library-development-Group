﻿using System;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000CE RID: 206
	[ExecuteInEditMode]
	[RequireComponent(typeof(ISVGShape), typeof(ISVGRenderer))]
	[AddComponentMenu("Rendering/SVG Stroke Renderer", 21)]
	public class SVGStrokeRenderer : MonoBehaviour, ISVGModify
	{
		// Token: 0x060006C9 RID: 1737 RVA: 0x00027F08 File Offset: 0x00026108
		private void OnWillRenderObject()
		{
			if (this.svgRenderer == null || this.svgRenderer.lastFrameChanged == Time.frameCount)
			{
				return;
			}
			this.svgRenderer.UpdateRenderer();
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00003D07 File Offset: 0x00001F07
		protected virtual void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force)
		{
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00027F30 File Offset: 0x00026130
		private void Init()
		{
			this.svgShape = (base.GetComponent(typeof(ISVGShape)) as ISVGShape);
			this.svgRenderer = (base.GetComponent(typeof(ISVGRenderer)) as ISVGRenderer);
			if (this.svgRenderer != null)
			{
				this.svgRenderer.AddModifier(this);
				ISVGRenderer isvgrenderer = this.svgRenderer;
				isvgrenderer.OnPrepareForRendering = (Action<SVGLayer[], SVGAsset, bool>)Delegate.Combine(isvgrenderer.OnPrepareForRendering, new Action<SVGLayer[], SVGAsset, bool>(this.PrepareForRendering));
			}
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00027FB0 File Offset: 0x000261B0
		private void Clear()
		{
			if (this.svgRenderer != null)
			{
				ISVGRenderer isvgrenderer = this.svgRenderer;
				isvgrenderer.OnPrepareForRendering = (Action<SVGLayer[], SVGAsset, bool>)Delegate.Remove(isvgrenderer.OnPrepareForRendering, new Action<SVGLayer[], SVGAsset, bool>(this.PrepareForRendering));
				this.svgRenderer.RemoveModifier(this);
				this.svgRenderer = null;
			}
			this.svgShape = null;
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x00028007 File Offset: 0x00026207
		private void OnEnable()
		{
			this.Init();
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0002800F File Offset: 0x0002620F
		private void OnDisable()
		{
			this.Clear();
		}

		// Token: 0x04000728 RID: 1832
		public StrokeLineJoin lineJoin;

		// Token: 0x04000729 RID: 1833
		public StrokeLineCap lineCap;

		// Token: 0x0400072A RID: 1834
		public Color32 color = Color.white;

		// Token: 0x0400072B RID: 1835
		public float width = 1f;

		// Token: 0x0400072C RID: 1836
		public float mitterLimit = 4f;

		// Token: 0x0400072D RID: 1837
		public float roundQuality = 10f;

		// Token: 0x0400072E RID: 1838
		public float[] dashArray;

		// Token: 0x0400072F RID: 1839
		public float dashOffset;

		// Token: 0x04000730 RID: 1840
		public ClosePathRule closeLine;

		// Token: 0x04000731 RID: 1841
		protected ISVGShape svgShape;

		// Token: 0x04000732 RID: 1842
		protected ISVGRenderer svgRenderer;
	}
}
