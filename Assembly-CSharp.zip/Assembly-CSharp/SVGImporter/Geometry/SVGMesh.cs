﻿using System;
using System.Collections.Generic;
using SVGImporter.Data;
using SVGImporter.Rendering;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Geometry
{
	// Token: 0x020000DD RID: 221
	public class SVGMesh
	{
		// Token: 0x0600074A RID: 1866 RVA: 0x0002C060 File Offset: 0x0002A260
		public static bool CombineMeshes(SVGLayer[] layers, Mesh mesh, out Shader[] shaders, SVGUseGradients useGradients = SVGUseGradients.Always, SVGAssetFormat format = SVGAssetFormat.Transparent, bool compressDepth = true, bool antialiased = false)
		{
			shaders = new Shader[0];
			bool flag = false;
			bool flag2 = false;
			bool flag3 = useGradients == SVGUseGradients.Always;
			if (layers == null)
			{
				return false;
			}
			int num = layers.Length;
			int num2 = 0;
			int num3 = 0;
			FILL_BLEND fill_BLEND = FILL_BLEND.ALPHA_BLENDED;
			if (format == SVGAssetFormat.Opaque)
			{
				if (compressDepth)
				{
					SVGBounds infiniteInverse = SVGBounds.InfiniteInverse;
					for (int i = 0; i < num; i++)
					{
						int num4 = layers[i].shapes.Length;
						for (int j = 0; j < num4; j++)
						{
							SVGShape svgshape = layers[i].shapes[j];
							if (svgshape.bounds.size.sqrMagnitude != 0f)
							{
								infiniteInverse.Encapsulate(svgshape.bounds.center, svgshape.bounds.size);
							}
						}
					}
					infiniteInverse.size *= 1.2f;
					if (!infiniteInverse.isInfiniteInverse)
					{
						SVGDepthTree svgdepthTree = new SVGDepthTree(infiniteInverse);
						for (int k = 0; k < num; k++)
						{
							int num5 = layers[k].shapes.Length;
							for (int l = 0; l < num5; l++)
							{
								SVGShape svgshape = layers[k].shapes[l];
								int[] array = svgdepthTree.TestDepthAdd(l, new SVGBounds(svgshape.bounds.center, svgshape.bounds.size));
								if (array == null || array.Length == 0)
								{
									svgshape.depth = 0f;
								}
								else
								{
									int num6 = array.Length;
									int num7 = 0;
									int num8 = -1;
									for (int m = 0; m < num6; m++)
									{
										if ((int)layers[k].shapes[array[m]].depth > num7)
										{
											num7 = (int)layers[k].shapes[array[m]].depth;
											num8 = array[m];
										}
									}
									if (layers[k].shapes[l].fill.blend == FILL_BLEND.OPAQUE)
									{
										svgshape.depth = (float)(num7 + 1);
									}
									else if (num8 != -1 && layers[k].shapes[num8].fill.blend == FILL_BLEND.OPAQUE)
									{
										svgshape.depth = (float)(num7 + 1);
									}
									else
									{
										svgshape.depth = (float)num7;
									}
								}
								layers[k].shapes[l] = svgshape;
							}
						}
					}
				}
				else
				{
					int num9 = 0;
					for (int n = 0; n < num; n++)
					{
						int num10 = layers[n].shapes.Length;
						for (int num11 = 0; num11 < num10; num11++)
						{
							SVGShape svgshape = layers[n].shapes[num11];
							SVGFill fill = svgshape.fill;
							if (fill.blend == FILL_BLEND.OPAQUE || fill_BLEND == FILL_BLEND.OPAQUE)
							{
								svgshape.depth = (float)(++num9);
							}
							else
							{
								svgshape.depth = (float)num9;
							}
							fill_BLEND = fill.blend;
							layers[n].shapes[num11] = svgshape;
						}
					}
				}
			}
			int num12 = 0;
			int num13 = 0;
			for (int num14 = 0; num14 < num; num14++)
			{
				int num15 = layers[num14].shapes.Length;
				for (int num16 = 0; num16 < num15; num16++)
				{
					SVGFill fill = layers[num14].shapes[num16].fill;
					if (fill.blend == FILL_BLEND.OPAQUE)
					{
						num2 += layers[num14].shapes[num16].triangles.Length;
						flag = true;
					}
					else if (fill.blend == FILL_BLEND.ALPHA_BLENDED)
					{
						num3 += layers[num14].shapes[num16].triangles.Length;
						flag2 = true;
					}
					if (fill.fillType == FILL_TYPE.GRADIENT)
					{
						flag3 = true;
					}
					int num17 = layers[num14].shapes[num16].vertices.Length;
					num12 += num17;
				}
			}
			int num18 = num2 + num3;
			if (useGradients == SVGUseGradients.Never)
			{
				flag3 = false;
			}
			if (format != SVGAssetFormat.Opaque)
			{
				flag = false;
				flag2 = true;
			}
			Vector3[] array2 = new Vector3[num12];
			Color32[] array3 = new Color32[num12];
			Vector2[] array4 = null;
			Vector2[] array5 = null;
			Vector3[] array6 = null;
			List<Shader> list = new List<Shader>();
			if (antialiased)
			{
				array6 = new Vector3[num12];
			}
			if (flag3)
			{
				array4 = new Vector2[num12];
				array5 = new Vector2[num12];
				if (flag)
				{
					list.Add(SVGShader.GradientColorOpaque);
				}
				if (flag2)
				{
					if (antialiased)
					{
						list.Add(SVGShader.GradientColorAlphaBlendedAntialiased);
					}
					else
					{
						list.Add(SVGShader.GradientColorAlphaBlended);
					}
				}
			}
			else
			{
				if (flag)
				{
					list.Add(SVGShader.SolidColorOpaque);
				}
				if (flag2)
				{
					if (antialiased)
					{
						list.Add(SVGShader.SolidColorAlphaBlendedAntialiased);
					}
					else
					{
						list.Add(SVGShader.SolidColorAlphaBlended);
					}
				}
			}
			for (int num19 = 0; num19 < num; num19++)
			{
				int num20 = layers[num19].shapes.Length;
				for (int num21 = 0; num21 < num20; num21++)
				{
					int num17 = layers[num19].shapes[num21].vertices.Length;
					if (layers[num19].shapes[num21].colors != null && layers[num19].shapes[num21].colors.Length == num17)
					{
						Color32 finalColor = layers[num19].shapes[num21].fill.finalColor;
						for (int num22 = 0; num22 < num17; num22++)
						{
							int num23 = num13 + num22;
							array2[num23] = layers[num19].shapes[num21].vertices[num22];
							if (flag)
							{
								array2[num23].z = layers[num19].shapes[num21].depth * -SVGAssetImport.minDepthOffset;
							}
							else
							{
								array2[num23].z = layers[num19].shapes[num21].depth;
							}
							array3[num23].r = finalColor.r * layers[num19].shapes[num21].colors[num22].r / byte.MaxValue;
							array3[num23].g = finalColor.g * layers[num19].shapes[num21].colors[num22].g / byte.MaxValue;
							array3[num23].b = finalColor.b * layers[num19].shapes[num21].colors[num22].b / byte.MaxValue;
							array3[num23].a = finalColor.a * layers[num19].shapes[num21].colors[num22].a / byte.MaxValue;
						}
					}
					else
					{
						Color32 finalColor2 = layers[num19].shapes[num21].fill.finalColor;
						for (int num24 = 0; num24 < num17; num24++)
						{
							int num23 = num13 + num24;
							array2[num23] = layers[num19].shapes[num21].vertices[num24];
							if (flag)
							{
								array2[num23].z = layers[num19].shapes[num21].depth * -SVGAssetImport.minDepthOffset;
							}
							else
							{
								array2[num23].z = layers[num19].shapes[num21].depth;
							}
							array3[num23] = finalColor2;
						}
					}
					if (flag3)
					{
						if (layers[num19].shapes[num21].fill.fillType == FILL_TYPE.GRADIENT && layers[num19].shapes[num21].fill.gradientColors != null)
						{
							SVGMatrix transform = layers[num19].shapes[num21].fill.transform;
							Rect viewport = layers[num19].shapes[num21].fill.viewport;
							Vector2 vector = Vector2.zero;
							Vector2 vector2 = new Vector2((float)layers[num19].shapes[num21].fill.gradientColors.index, (float)layers[num19].shapes[num21].fill.gradientType);
							if (layers[num19].shapes[num21].angles != null && layers[num19].shapes[num21].angles.Length == num17)
							{
								for (int num25 = 0; num25 < num17; num25++)
								{
									int num23 = num13 + num25;
									vector.x = array2[num23].x;
									vector.y = array2[num23].y;
									vector = transform.Transform(vector);
									array4[num23].x = (vector.x - viewport.x) / viewport.width;
									array4[num23].y = (vector.y - viewport.y) / viewport.height;
									array5[num23] = vector2;
									array6[num23].x = layers[num19].shapes[num21].angles[num25].x;
									array6[num23].y = layers[num19].shapes[num21].angles[num25].y;
								}
							}
							else
							{
								for (int num26 = 0; num26 < num17; num26++)
								{
									int num23 = num13 + num26;
									vector.x = array2[num23].x;
									vector.y = array2[num23].y;
									vector = transform.Transform(vector);
									array4[num23].x = (vector.x - viewport.x) / viewport.width;
									array4[num23].y = (vector.y - viewport.y) / viewport.height;
									array5[num23] = vector2;
								}
							}
						}
						else if (layers[num19].shapes[num21].fill.fillType == FILL_TYPE.TEXTURE)
						{
							SVGMatrix transform2 = layers[num19].shapes[num21].fill.transform;
							Vector2 zero = Vector2.zero;
							if (layers[num19].shapes[num21].angles != null && layers[num19].shapes[num21].angles.Length == num17)
							{
								for (int num27 = 0; num27 < num17; num27++)
								{
									int num23 = num13 + num27;
									zero.x = array2[num23].x;
									zero.y = array2[num23].y;
									array4[num23] = transform2.Transform(zero);
									array6[num23].x = layers[num19].shapes[num21].angles[num27].x;
									array6[num23].y = layers[num19].shapes[num21].angles[num27].y;
								}
							}
							else
							{
								for (int num28 = 0; num28 < num17; num28++)
								{
									int num23 = num13 + num28;
									zero.x = array2[num23].x;
									zero.y = array2[num23].y;
									array4[num23] = transform2.Transform(zero);
								}
							}
						}
						else if (layers[num19].shapes[num21].angles != null && layers[num19].shapes[num21].angles.Length == num17)
						{
							for (int num29 = 0; num29 < num17; num29++)
							{
								int num23 = num13 + num29;
								array6[num23].x = layers[num19].shapes[num21].angles[num29].x;
								array6[num23].y = layers[num19].shapes[num21].angles[num29].y;
							}
						}
					}
					else if (antialiased && layers[num19].shapes[num21].angles != null && layers[num19].shapes[num21].angles.Length == num17)
					{
						for (int num30 = 0; num30 < num17; num30++)
						{
							int num23 = num13 + num30;
							array6[num23] = layers[num19].shapes[num21].angles[num30];
						}
					}
					num13 += num17;
				}
			}
			int[][] array7;
			if (flag && flag2)
			{
				array7 = new int[][]
				{
					new int[num2],
					new int[num3]
				};
				int num31 = 0;
				int num32 = 0;
				int num33 = 0;
				for (int num34 = 0; num34 < num; num34++)
				{
					int num35 = layers[num34].shapes.Length;
					for (int num36 = 0; num36 < num35; num36++)
					{
						int num37 = layers[num34].shapes[num36].triangles.Length;
						if (layers[num34].shapes[num36].fill.blend == FILL_BLEND.OPAQUE)
						{
							for (int num38 = 0; num38 < num37; num38++)
							{
								array7[0][num32++] = num31 + layers[num34].shapes[num36].triangles[num38];
							}
						}
						else
						{
							for (int num39 = 0; num39 < num37; num39++)
							{
								array7[1][num33++] = num31 + layers[num34].shapes[num36].triangles[num39];
							}
						}
						num31 += layers[num34].shapes[num36].vertices.Length;
					}
				}
			}
			else
			{
				array7 = new int[][]
				{
					new int[num18]
				};
				int num40 = 0;
				int num41 = 0;
				for (int num42 = 0; num42 < num; num42++)
				{
					int num43 = layers[num42].shapes.Length;
					for (int num44 = 0; num44 < num43; num44++)
					{
						int num45 = layers[num42].shapes[num44].triangles.Length;
						for (int num46 = 0; num46 < num45; num46++)
						{
							array7[0][num41++] = num40 + layers[num42].shapes[num44].triangles[num46];
						}
						num40 += layers[num42].shapes[num44].vertices.Length;
					}
				}
			}
			if (list.Count != 0)
			{
				shaders = list.ToArray();
			}
			mesh.Clear();
			mesh.MarkDynamic();
			if (array2 == null)
			{
				return false;
			}
			if (array2.Length > 65000)
			{
				Debug.LogError("A mesh may not have more than 65000 vertices. Please try to reduce quality or split SVG file.");
				return false;
			}
			mesh.vertices = array2;
			mesh.colors32 = array3;
			if (array4 != null)
			{
				mesh.uv = array4;
			}
			if (array5 != null)
			{
				mesh.uv2 = array5;
			}
			if (array6 != null)
			{
				mesh.normals = array6;
			}
			if (array7.Length == 1)
			{
				mesh.triangles = array7[0];
			}
			else
			{
				mesh.subMeshCount = array7.Length;
				for (int num47 = 0; num47 < array7.Length; num47++)
				{
					mesh.SetTriangles(array7[num47], num47);
				}
			}
			return true;
		}
	}
}
