﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Geometry
{
	// Token: 0x020000DE RID: 222
	public class SVGMeshCutter
	{
		// Token: 0x0200034D RID: 845
		private struct MeshBuilder
		{
			// Token: 0x0600168C RID: 5772 RVA: 0x00072C5C File Offset: 0x00070E5C
			public MeshBuilder(Mesh m, Vector3[] vertices)
			{
				this.pos = new List<Vector3>();
				this.col = new List<Color32>();
				this.uv = new List<Vector2>();
				this.uv2 = new List<Vector2>();
				this.tri = new List<int>();
				this.map = new Dictionary<SVGMeshCutter.MeshBuilder.IntPair, int>();
				this.mesh = m;
				this.origVertices = vertices;
			}

			// Token: 0x0600168D RID: 5773 RVA: 0x00072CBC File Offset: 0x00070EBC
			private int MergeVertex(int i)
			{
				SVGMeshCutter.MeshBuilder.IntPair key = new SVGMeshCutter.MeshBuilder.IntPair(i, i);
				int count;
				if (!this.map.TryGetValue(key, out count))
				{
					this.map.Add(key, count = this.pos.Count);
					this.pos.Add(this.origVertices[i]);
					this.col.Add(this.mesh.colors32[i]);
					this.uv.Add(this.mesh.uv[i]);
					this.uv2.Add(this.mesh.uv2[i]);
				}
				return count;
			}

			// Token: 0x0600168E RID: 5774 RVA: 0x00072D6C File Offset: 0x00070F6C
			private static void MergeCutVertex(SVGMeshCutter.MeshBuilder leftSide, SVGMeshCutter.MeshBuilder rightSide, int i1, int i2, Vector2 origin, Vector2 direction, out int jl, out int jr)
			{
				SVGMeshCutter.MeshBuilder.IntPair key = new SVGMeshCutter.MeshBuilder.IntPair(i1, i2);
				if (!leftSide.map.TryGetValue(key, out jl))
				{
					jl = leftSide.pos.Count;
					jr = rightSide.pos.Count;
					leftSide.map.Add(key, jl);
					rightSide.map.Add(key, jr);
					float num = SVGMeshCutter.MeshBuilder.CutEdge(leftSide.origVertices[i1], leftSide.origVertices[i2], origin, direction);
					Vector3 item = leftSide.origVertices[i1] + (leftSide.origVertices[i2] - leftSide.origVertices[i1]) * num;
					leftSide.pos.Add(item);
					rightSide.pos.Add(item);
					Color32 item2 = Color32.Lerp(leftSide.mesh.colors32[i1], leftSide.mesh.colors32[i2], num);
					leftSide.col.Add(item2);
					rightSide.col.Add(item2);
					Vector2 item3 = leftSide.mesh.uv[i1] + (leftSide.mesh.uv[i2] - leftSide.mesh.uv[i1]) * num;
					leftSide.uv.Add(item3);
					rightSide.uv.Add(item3);
					Vector2 item4 = leftSide.mesh.uv2[i1] + (leftSide.mesh.uv2[i2] - leftSide.mesh.uv2[i1]) * num;
					leftSide.uv2.Add(item4);
					rightSide.uv2.Add(item4);
					return;
				}
				jr = rightSide.map[key];
			}

			// Token: 0x0600168F RID: 5775 RVA: 0x00072F4D File Offset: 0x0007114D
			public void AddTri(int i1, int i2, int i3)
			{
				this.tri.Add(this.MergeVertex(i1));
				this.tri.Add(this.MergeVertex(i2));
				this.tri.Add(this.MergeVertex(i3));
			}

			// Token: 0x06001690 RID: 5776 RVA: 0x00072F88 File Offset: 0x00071188
			public static void AddCutTri(SVGMeshCutter.MeshBuilder leftSide, SVGMeshCutter.MeshBuilder rightSide, int i1, int i2, int i3, Vector2 origin, Vector2 direction)
			{
				int item = leftSide.MergeVertex(i1);
				int item2 = rightSide.MergeVertex(i2);
				int item3 = rightSide.MergeVertex(i3);
				int item4;
				int item5;
				SVGMeshCutter.MeshBuilder.MergeCutVertex(leftSide, rightSide, i1, i2, origin, direction, out item4, out item5);
				int item6;
				int item7;
				SVGMeshCutter.MeshBuilder.MergeCutVertex(leftSide, rightSide, i1, i3, origin, direction, out item6, out item7);
				leftSide.tri.Add(item);
				leftSide.tri.Add(item4);
				leftSide.tri.Add(item6);
				rightSide.tri.Add(item5);
				rightSide.tri.Add(item2);
				rightSide.tri.Add(item3);
				rightSide.tri.Add(item5);
				rightSide.tri.Add(item3);
				rightSide.tri.Add(item7);
			}

			// Token: 0x06001691 RID: 5777 RVA: 0x00073044 File Offset: 0x00071244
			public Mesh ToMesh()
			{
				Mesh mesh = new Mesh();
				mesh.vertices = this.pos.ToArray();
				mesh.colors32 = this.col.ToArray();
				mesh.uv = this.uv.ToArray();
				mesh.uv2 = this.uv2.ToArray();
				mesh.triangles = this.tri.ToArray();
				mesh.RecalculateBounds();
				return mesh;
			}

			// Token: 0x06001692 RID: 5778 RVA: 0x000730B4 File Offset: 0x000712B4
			private static float CutEdge(Vector3 v1, Vector3 v2, Vector2 origin, Vector2 direction)
			{
				return Mathf.Clamp01((direction.y * v1.x - direction.x * v1.y + direction.x * origin.y - direction.y * origin.x) / (direction.x * (v2.y - v1.y) - direction.y * (v2.x - v1.x)));
			}

			// Token: 0x06001693 RID: 5779 RVA: 0x00073128 File Offset: 0x00071328
			public bool IsDegenerate(Vector2 origin, Vector2 direction)
			{
				float num = (float)this.pos.Count * (-direction.x * origin.y + direction.y * origin.x);
				for (int i = 0; i < this.pos.Count; i++)
				{
					num += direction.x * this.pos[i].y - direction.y * this.pos[i].x;
				}
				return (double)Mathf.Abs(num) < 0.01 * (double)direction.magnitude;
			}

			// Token: 0x04001233 RID: 4659
			public List<Vector3> pos;

			// Token: 0x04001234 RID: 4660
			public List<Color32> col;

			// Token: 0x04001235 RID: 4661
			public List<Vector2> uv;

			// Token: 0x04001236 RID: 4662
			public List<Vector2> uv2;

			// Token: 0x04001237 RID: 4663
			public List<int> tri;

			// Token: 0x04001238 RID: 4664
			private Dictionary<SVGMeshCutter.MeshBuilder.IntPair, int> map;

			// Token: 0x04001239 RID: 4665
			private Mesh mesh;

			// Token: 0x0400123A RID: 4666
			private Vector3[] origVertices;

			// Token: 0x020003F2 RID: 1010
			private struct IntPair
			{
				// Token: 0x060018AB RID: 6315 RVA: 0x00078B50 File Offset: 0x00076D50
				public IntPair(int first, int second)
				{
					if (first < second)
					{
						this.first = first;
						this.second = second;
						return;
					}
					this.first = second;
					this.second = first;
				}

				// Token: 0x04001520 RID: 5408
				public int first;

				// Token: 0x04001521 RID: 5409
				public int second;
			}
		}
	}
}
