﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000C6 RID: 198
	[ExecuteInEditMode]
	public class SVGAtlas : MonoBehaviour
	{
		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000601 RID: 1537 RVA: 0x00023C5B File Offset: 0x00021E5B
		public bool atlasHasChanged
		{
			get
			{
				return this._atlasHasChanged;
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x00023C63 File Offset: 0x00021E63
		public static bool beingDestroyed
		{
			get
			{
				return SVGAtlas._beingDestroyed;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000603 RID: 1539 RVA: 0x00023C6A File Offset: 0x00021E6A
		public static Texture2D whiteTexture
		{
			get
			{
				if (SVGAtlas._whiteTexture == null)
				{
					SVGAtlas._whiteTexture = SVGAtlas.GenerateWhiteTexture();
				}
				return SVGAtlas._whiteTexture;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x00023C88 File Offset: 0x00021E88
		public static Texture2D gradientShapeTexture
		{
			get
			{
				if (SVGAtlas._gradientShapeTexture == null)
				{
					SVGAtlas._gradientShapeTexture = SVGAtlas.GenerateGradientShapeTexture(SVGAtlas._gradientShapeTextureSize);
				}
				return SVGAtlas._gradientShapeTexture;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000605 RID: 1541 RVA: 0x00023CAB File Offset: 0x00021EAB
		// (set) Token: 0x06000606 RID: 1542 RVA: 0x00023CB2 File Offset: 0x00021EB2
		public static int gradientShapeTextureSize
		{
			get
			{
				return SVGAtlas._gradientShapeTextureSize;
			}
			set
			{
				if (SVGAtlas._gradientShapeTextureSize == value)
				{
					return;
				}
				if (SVGAtlas._gradientShapeTexture != null)
				{
					Object.DestroyImmediate(SVGAtlas._gradientShapeTexture);
				}
				SVGAtlas._gradientShapeTexture = SVGAtlas.GenerateGradientShapeTexture(SVGAtlas._gradientShapeTextureSize);
			}
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00023CE3 File Offset: 0x00021EE3
		public static void ClearGradientShapeTexture()
		{
			if (SVGAtlas.gradientShapeTexture == null)
			{
				return;
			}
			Object.DestroyImmediate(SVGAtlas._gradientShapeTexture);
			SVGAtlas._gradientShapeTexture = null;
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x00023D03 File Offset: 0x00021F03
		public SVGAtlasData atlasData
		{
			get
			{
				return this._atlasData;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000609 RID: 1545 RVA: 0x00023D0B File Offset: 0x00021F0B
		public Material ui
		{
			get
			{
				if (this._ui == null)
				{
					this._ui = new Material(SVGShader.UI);
					this._ui.hideFlags = HideFlags.DontSave;
					this.UpdateMaterialProperties(this._ui);
				}
				return this._ui;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600060A RID: 1546 RVA: 0x00023D4A File Offset: 0x00021F4A
		public Material uiAntialiased
		{
			get
			{
				if (this._uiAntialiased == null)
				{
					this._uiAntialiased = new Material(SVGShader.UIAntialiased);
					this._uiAntialiased.hideFlags = HideFlags.DontSave;
					this.UpdateMaterialProperties(this._uiAntialiased);
				}
				return this._uiAntialiased;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600060B RID: 1547 RVA: 0x00023D89 File Offset: 0x00021F89
		public Material opaqueSolid
		{
			get
			{
				if (this._opaqueSolid == null)
				{
					this._opaqueSolid = new Material(SVGShader.SolidColorOpaque);
					this._opaqueSolid.hideFlags = HideFlags.DontSave;
				}
				return this._opaqueSolid;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600060C RID: 1548 RVA: 0x00023DBC File Offset: 0x00021FBC
		public Material transparentSolid
		{
			get
			{
				if (this._transparentSolid == null)
				{
					this._transparentSolid = new Material(SVGShader.SolidColorAlphaBlended);
					this._transparentSolid.hideFlags = HideFlags.DontSave;
				}
				return this._transparentSolid;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600060D RID: 1549 RVA: 0x00023DEF File Offset: 0x00021FEF
		public Material transparentSolidAntialiased
		{
			get
			{
				if (this._transparentSolidAntialiased == null)
				{
					this._transparentSolidAntialiased = new Material(SVGShader.SolidColorAlphaBlendedAntialiased);
					this._transparentSolidAntialiased.hideFlags = HideFlags.DontSave;
				}
				return this._transparentSolidAntialiased;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600060E RID: 1550 RVA: 0x00023E22 File Offset: 0x00022022
		public Material opaqueGradient
		{
			get
			{
				if (this._opaqueGradient == null)
				{
					this._opaqueGradient = new Material(SVGShader.GradientColorOpaque);
					this._opaqueGradient.hideFlags = HideFlags.DontSave;
					this.UpdateMaterialProperties(this._opaqueGradient);
				}
				return this._opaqueGradient;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600060F RID: 1551 RVA: 0x00023E61 File Offset: 0x00022061
		public Material transparentGradient
		{
			get
			{
				if (this._transparentGradient == null)
				{
					this._transparentGradient = new Material(SVGShader.GradientColorAlphaBlended);
					this._transparentGradient.hideFlags = HideFlags.DontSave;
					this.UpdateMaterialProperties(this._transparentGradient);
				}
				return this._transparentGradient;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00023EA0 File Offset: 0x000220A0
		public Material transparentGradientAntialiased
		{
			get
			{
				if (this._transparentGradientAntialiased == null)
				{
					this._transparentGradientAntialiased = new Material(SVGShader.GradientColorAlphaBlendedAntialiased);
					this._transparentGradientAntialiased.hideFlags = HideFlags.DontSave;
					this.UpdateMaterialProperties(this._transparentGradientAntialiased);
				}
				return this._transparentGradientAntialiased;
			}
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x00023EE0 File Offset: 0x000220E0
		public void UpdateMaterialProperties(Material material)
		{
			if (material == null)
			{
				return;
			}
			if (this.atlasTextures != null && this.atlasTextures.Count > 0 && material.HasProperty("_GradientColor"))
			{
				material.SetTexture("_GradientColor", this.atlasTextures[0]);
			}
			if (material.HasProperty("_GradientShape"))
			{
				material.SetTexture("_GradientShape", SVGAtlas.gradientShapeTexture);
			}
			if (material.HasProperty("_Params"))
			{
				material.SetVector("_Params", new Vector4((float)this.atlasTextureWidth, (float)this.atlasTextureHeight, (float)this.gradientWidth, (float)this.gradientHeight));
			}
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00023F88 File Offset: 0x00022188
		protected void Awake()
		{
			if (Application.isPlaying)
			{
				Object.DontDestroyOnLoad(base.gameObject);
			}
			this._atlasHasChanged = false;
			SVGAtlas._beingDestroyed = false;
			this.AddFakeCamera();
			Camera.onPreRender = (Camera.CameraCallback)Delegate.Combine(Camera.onPreRender, new Camera.CameraCallback(this.OnAtlasPreRender));
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x00023FDA File Offset: 0x000221DA
		public void OnPreRender()
		{
			this.OnAtlasPreRender(null);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00023FE3 File Offset: 0x000221E3
		protected void OnDestroy()
		{
			SVGAtlas._beingDestroyed = true;
			Camera.onPreRender = (Camera.CameraCallback)Delegate.Remove(Camera.onPreRender, new Camera.CameraCallback(this.OnAtlasPreRender));
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0002400B File Offset: 0x0002220B
		protected void AddFakeCamera()
		{
			Camera camera = base.gameObject.AddComponent<Camera>();
			camera.hideFlags = HideFlags.DontSave;
			camera.clearFlags = CameraClearFlags.Nothing;
			camera.orthographic = true;
			camera.depth = float.MinValue;
			camera.cullingMask = 0;
			camera.useOcclusionCulling = false;
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x00024046 File Offset: 0x00022246
		public void OnAtlasPreRender(Camera camera = null)
		{
			SVGImporterSettings.UpdateAntialiasing();
			if (this._atlasHasChanged)
			{
				this.RebuildAtlas();
				this._atlasHasChanged = false;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000617 RID: 1559 RVA: 0x00024064 File Offset: 0x00022264
		public static SVGAtlas Instance
		{
			get
			{
				if (SVGAtlas._Instance == null)
				{
					SVGAtlas[] array = Resources.FindObjectsOfTypeAll<SVGAtlas>();
					if (array != null && array.Length != 0)
					{
						SVGAtlas._Instance = array[0];
					}
				}
				if (SVGAtlas._Instance == null)
				{
					SVGAtlas._Instance = new GameObject("SVGAtlas", new Type[]
					{
						typeof(SVGAtlas)
					})
					{
						hideFlags = HideFlags.HideAndDontSave
					}.GetComponent<SVGAtlas>();
					SVGAtlas._Instance.hideFlags = HideFlags.DontSave;
					SVGAtlas._Instance.Init();
				}
				return SVGAtlas._Instance;
			}
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x000240EC File Offset: 0x000222EC
		public bool ContainsMaterial(Material material)
		{
			return material == this._ui || material == this._uiAntialiased || material == this._opaqueSolid || material == this._transparentSolid || material == this._transparentSolidAntialiased || material == this._opaqueGradient || material == this._transparentGradient || material == this._transparentGradientAntialiased || (this.materials != null && this.materials.Contains(material));
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00024194 File Offset: 0x00022394
		public void UpdateMaterialList()
		{
			if (this.materials == null)
			{
				this.materials = new List<Material>();
			}
			this.materials.Clear();
			if (this._ui != null)
			{
				this.materials.Add(this._ui);
			}
			if (this._uiAntialiased != null)
			{
				this.materials.Add(this._uiAntialiased);
			}
			if (this._opaqueSolid != null)
			{
				this.materials.Add(this._opaqueSolid);
			}
			if (this._transparentSolid != null)
			{
				this.materials.Add(this._transparentSolid);
			}
			if (this._opaqueGradient != null)
			{
				this.materials.Add(this._opaqueGradient);
			}
			if (this._transparentGradient != null)
			{
				this.materials.Add(this._transparentGradient);
			}
			if (this._transparentGradientAntialiased != null)
			{
				this.materials.Add(this._transparentGradientAntialiased);
			}
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x00003D07 File Offset: 0x00001F07
		public void UpdateGradientList()
		{
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x00024298 File Offset: 0x00022498
		public void ClearAll()
		{
			Debug.Log(string.Concat(new object[]
			{
				"Cleared SVG Atlas: ",
				Time.frameCount,
				", playmode: ",
				Application.isPlaying.ToString()
			}));
			if (this._ui != null)
			{
				SVGAtlas.DestroyObjectInternal(this._ui);
				this._ui = null;
			}
			if (this._uiAntialiased != null)
			{
				SVGAtlas.DestroyObjectInternal(this._uiAntialiased);
				this._uiAntialiased = null;
			}
			if (this._opaqueSolid != null)
			{
				SVGAtlas.DestroyObjectInternal(this._opaqueSolid);
				this._opaqueSolid = null;
			}
			if (this._transparentSolid != null)
			{
				SVGAtlas.DestroyObjectInternal(this._transparentSolid);
				this._transparentSolid = null;
			}
			if (this._transparentSolidAntialiased != null)
			{
				SVGAtlas.DestroyObjectInternal(this._transparentSolidAntialiased);
				this._transparentSolidAntialiased = null;
			}
			if (this._opaqueGradient != null)
			{
				SVGAtlas.DestroyObjectInternal(this._opaqueGradient);
				this._opaqueGradient = null;
			}
			if (this._transparentGradient != null)
			{
				SVGAtlas.DestroyObjectInternal(this._transparentGradient);
				this._transparentGradient = null;
			}
			if (this._transparentGradientAntialiased != null)
			{
				SVGAtlas.DestroyObjectInternal(this._transparentGradientAntialiased);
				this._transparentGradientAntialiased = null;
			}
			this.ClearAllData();
			this.ClearMaterials();
			this.ClearAtlasTextures();
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x000243F4 File Offset: 0x000225F4
		protected void Init()
		{
			if (this.materials == null)
			{
				this.materials = new List<Material>();
			}
			if (this._atlasData == null)
			{
				this._atlasData = new SVGAtlasData();
				this._atlasData.Init(this.atlasTextureWidth * this.atlasTextureHeight);
				this.AddGradient(SVGAtlasData.GetDefaultGradient());
			}
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x0002444C File Offset: 0x0002264C
		public static void RenderGradient(Texture2D texture, CCGradient gradient, int x, int y, int gradientWidth, int gradientHeight)
		{
			if (texture == null || gradient == null || !gradient.initialised)
			{
				return;
			}
			float num = (float)(gradientWidth - 1 - 2);
			Color[] array = new Color[gradientWidth * gradientHeight];
			for (int i = 0; i < gradientWidth; i++)
			{
				Color color = gradient.Evaluate((float)(i - 1) / num);
				for (int j = 0; j < gradientHeight; j++)
				{
					array[gradientWidth * j + i] = color;
				}
			}
			texture.SetPixels(x, y, gradientWidth, gradientHeight, array);
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x000244CC File Offset: 0x000226CC
		public int imagePerRow
		{
			get
			{
				return this.atlasTextureWidth / this.gradientWidth;
			}
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x000244DB File Offset: 0x000226DB
		public bool GetCoords(out int x, out int y, int imageIndex)
		{
			bool result = this.atlasTextures == null || this.atlasTextures.Count == 0;
			SVGAtlas.GetCoords(out x, out y, imageIndex, this.gradientWidth, this.gradientHeight, this.atlasTextureWidth, this.atlasTextureHeight);
			return result;
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x00024518 File Offset: 0x00022718
		public static void GetCoords(out int x, out int y, int imageIndex, int gradientWidth, int gradientHeight, int atlasTextureWidth, int atlasTextureHeight)
		{
			int num = imageIndex * gradientWidth;
			x = num % atlasTextureWidth;
			y = Mathf.FloorToInt((float)(num / atlasTextureWidth)) * gradientHeight;
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x00024540 File Offset: 0x00022740
		public Texture CreateAtlasTexture(int index, int width, int height)
		{
			if (this.atlasTextures == null)
			{
				this.atlasTextures = new List<Texture2D>();
			}
			Texture2D texture2D = SVGAtlas.CreateTexture(width, height);
			texture2D.hideFlags = HideFlags.DontSave;
			texture2D.name = "Atlas " + index.ToString();
			SVGAtlas.AssignMaterialGradients(this._opaqueGradient, texture2D, SVGAtlas.gradientShapeTexture, this.gradientWidth, this.gradientHeight);
			SVGAtlas.AssignMaterialGradients(this._transparentGradient, texture2D, SVGAtlas.gradientShapeTexture, this.gradientWidth, this.gradientHeight);
			SVGAtlas.AssignMaterialGradients(this._transparentGradientAntialiased, texture2D, SVGAtlas.gradientShapeTexture, this.gradientWidth, this.gradientHeight);
			SVGAtlas.AssignMaterialGradients(this._ui, texture2D, SVGAtlas.gradientShapeTexture, this.gradientWidth, this.gradientHeight);
			SVGAtlas.AssignMaterialGradients(this._uiAntialiased, texture2D, SVGAtlas.gradientShapeTexture, this.gradientWidth, this.gradientHeight);
			if (index >= this.atlasTextures.Count - 1)
			{
				this.atlasTextures.Add(texture2D);
			}
			else if (index >= 0)
			{
				this.atlasTextures[index] = texture2D;
			}
			return texture2D;
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00024648 File Offset: 0x00022848
		public static Texture2D CreateTexture(int width, int height)
		{
			return new Texture2D(width, height, TextureFormat.ARGB32, false)
			{
				filterMode = FilterMode.Bilinear,
				wrapMode = TextureWrapMode.Clamp,
				anisoLevel = 0
			};
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00024668 File Offset: 0x00022868
		public CCGradient AddGradient(CCGradient gradient)
		{
			if (gradient == null || !gradient.initialised)
			{
				return null;
			}
			if (this._atlasData == null)
			{
				this._atlasData = new SVGAtlasData();
				this._atlasData.Init(this.atlasTextureWidth * this.atlasTextureHeight);
			}
			bool flag;
			gradient = this._atlasData.AddGradient(gradient, out flag);
			if (flag)
			{
				return gradient;
			}
			int num = 0;
			int num2 = 0;
			this.GetCoords(out num, out num2, gradient.index);
			gradient.atlasIndex = 0;
			this._atlasHasChanged = true;
			return gradient;
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x000246E6 File Offset: 0x000228E6
		public bool RemoveGradient(CCGradient gradient)
		{
			return gradient != null && gradient.initialised && this._atlasData != null && this._atlasData.RemoveGradient(gradient);
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00024710 File Offset: 0x00022910
		public CCGradient GetGradient(CCGradient gradient)
		{
			if (gradient == null || !gradient.initialised)
			{
				return null;
			}
			if (this._atlasData == null)
			{
				return null;
			}
			return this._atlasData.GetGradient(gradient);
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x00024735 File Offset: 0x00022935
		public bool HasGradient(CCGradient gradient)
		{
			return gradient != null && gradient.initialised && this._atlasData != null && this._atlasData.HasGradient(gradient);
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002475C File Offset: 0x0002295C
		public void RebuildAtlas()
		{
			int index = 0;
			if (this._atlasData == null)
			{
				Debug.LogWarning("atlasData is null! " + base.GetInstanceID());
				return;
			}
			CCGradient[] gradients = this._atlasData.gradients;
			if (gradients == null)
			{
				return;
			}
			int num = gradients.Length;
			for (int i = 0; i < num; i++)
			{
				if (gradients[i] != null)
				{
					int x;
					int y;
					if (this.GetCoords(out x, out y, gradients[i].index))
					{
						this.CreateAtlasTexture(index, this.atlasTextureWidth, this.atlasTextureHeight);
					}
					SVGAtlas.RenderGradient(this.atlasTextures[index], gradients[i], x, y, this.gradientWidth, this.gradientHeight);
				}
			}
			for (int j = 0; j < this.atlasTextures.Count; j++)
			{
				this.atlasTextures[j].Apply(false);
			}
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00024834 File Offset: 0x00022A34
		public static Texture2D GenerateGradientAtlasTexture(CCGradient[] gradients, int gradientWidth, int gradientHeight)
		{
			if (gradients == null || gradients.Length == 0)
			{
				return null;
			}
			float num = (float)gradients.Length;
			int num2 = gradientWidth * 2;
			int height = Mathf.CeilToInt(num * (float)gradientWidth / (float)num2) * gradientHeight + gradientHeight;
			Texture2D texture2D = SVGAtlas.CreateTexture(num2, height);
			for (int i = 0; i < gradients.Length; i++)
			{
				int x;
				int y;
				SVGAtlas.GetCoords(out x, out y, i, gradientWidth, gradientHeight, num2, height);
				SVGAtlas.RenderGradient(texture2D, gradients[i], x, y, gradientWidth, gradientHeight);
			}
			texture2D.Apply(false);
			return texture2D;
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x000248A0 File Offset: 0x00022AA0
		public static Texture2D GenerateGradientShapeTexture(int textureSize)
		{
			Texture2D texture2D = new Texture2D(textureSize, textureSize, TextureFormat.ARGB32, false);
			texture2D.hideFlags = HideFlags.DontSave;
			texture2D.name = "Gradient Shape Texture";
			texture2D.anisoLevel = 0;
			texture2D.filterMode = FilterMode.Trilinear;
			texture2D.wrapMode = TextureWrapMode.Clamp;
			int num = SVGAtlas.gradientShapeTextureSize * SVGAtlas.gradientShapeTextureSize;
			Color32[] array = new Color32[num];
			float num2 = (float)SVGAtlas.gradientShapeTextureSize * 0.5f;
			float num3 = (float)(SVGAtlas.gradientShapeTextureSize - 1);
			for (int i = 0; i < num; i++)
			{
				float num4 = (float)(i % SVGAtlas.gradientShapeTextureSize);
				float num5 = Mathf.Floor((float)i / (float)SVGAtlas.gradientShapeTextureSize);
				array[i].r = (byte)Mathf.RoundToInt(num4 / num3 * 255f);
				array[i].g = (byte)Mathf.RoundToInt(Mathf.Clamp01(Mathf.Sqrt(Mathf.Pow(num2 - num4, 2f) + Mathf.Pow(num2 - num5, 2f)) / (num2 - 1f)) * 255f);
				float num6 = Mathf.Atan2(-num2 + num5, -num2 + num4);
				if (num6 < 0f)
				{
					num6 = 6.2831855f + num6;
				}
				array[i].b = (byte)Mathf.RoundToInt(Mathf.Clamp01(num6 / 6.2831855f) * 255f);
				array[i].a = byte.MaxValue;
			}
			texture2D.SetPixels32(array);
			texture2D.Apply(true);
			return texture2D;
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x00024A1C File Offset: 0x00022C1C
		public static Texture2D GenerateWhiteTexture()
		{
			Texture2D texture2D = new Texture2D(1, 1, TextureFormat.ARGB32, false);
			texture2D.hideFlags = HideFlags.DontSave;
			texture2D.name = "White Texture";
			texture2D.anisoLevel = 0;
			texture2D.filterMode = FilterMode.Bilinear;
			texture2D.wrapMode = TextureWrapMode.Clamp;
			texture2D.SetPixel(0, 0, Color.white);
			texture2D.Apply(false);
			return texture2D;
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x00024A70 File Offset: 0x00022C70
		public Material GetMaterial(SVGFill fill)
		{
			Material result = null;
			switch (fill.fillType)
			{
			case FILL_TYPE.SOLID:
				result = this.GetColorMaterial(fill);
				break;
			case FILL_TYPE.GRADIENT:
				result = this.GetGradientMaterial(fill);
				break;
			}
			return result;
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00024AB0 File Offset: 0x00022CB0
		protected Material GetGradientMaterial(SVGFill fill)
		{
			Material material = null;
			FILL_BLEND blend = fill.blend;
			Shader shader;
			if (blend != FILL_BLEND.OPAQUE)
			{
				if (blend != FILL_BLEND.ALPHA_BLENDED)
				{
					shader = SVGShader.GradientColorOpaque;
				}
				else
				{
					shader = SVGShader.GradientColorAlphaBlended;
				}
			}
			else
			{
				shader = SVGShader.GradientColorOpaque;
			}
			for (int i = 0; i < this.materials.Count; i++)
			{
				if (!(this.materials[i] == null) && !(this.materials[i].shader != shader))
				{
					if (fill.gradientColors.atlasIndex < 0 || fill.gradientColors.atlasIndex >= this.atlasTextures.Count)
					{
						throw new IndexOutOfRangeException();
					}
					Texture texture = this.atlasTextures[fill.gradientColors.atlasIndex];
					if (!(texture == null) && !(this.materials[i].GetTexture("_GradientColor") != texture))
					{
						material = this.materials[i];
						material.SetTexture("_GradientShape", SVGAtlas.gradientShapeTexture);
						material.SetVector("_Params", new Vector4((float)this.atlasTextureWidth, (float)this.atlasTextureHeight, (float)this.gradientWidth, (float)this.gradientHeight));
					}
				}
			}
			if (material == null)
			{
				material = new Material(shader);
				Texture2D value = this.atlasTextures[fill.gradientColors.atlasIndex];
				material.SetTexture("_GradientColor", value);
				material.SetTexture("_GradientShape", SVGAtlas.gradientShapeTexture);
				material.SetVector("_Params", new Vector4((float)this.atlasTextureWidth, (float)this.atlasTextureHeight, (float)this.gradientWidth, (float)this.gradientHeight));
				this.materials.Add(material);
			}
			return material;
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00024C6C File Offset: 0x00022E6C
		protected Material GetColorMaterial(SVGFill fill)
		{
			Material material = null;
			FILL_BLEND blend = fill.blend;
			Shader shader;
			if (blend != FILL_BLEND.OPAQUE)
			{
				if (blend != FILL_BLEND.ALPHA_BLENDED)
				{
					shader = SVGShader.SolidColorOpaque;
				}
				else
				{
					shader = SVGShader.SolidColorAlphaBlended;
				}
			}
			else
			{
				shader = SVGShader.SolidColorOpaque;
			}
			for (int i = 0; i < this.materials.Count; i++)
			{
				if (!(this.materials[i] == null) && !(this.materials[i].shader != shader))
				{
					material = this.materials[i];
				}
			}
			if (material == null)
			{
				material = new Material(shader);
				this.materials.Add(material);
			}
			return material;
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x0600062E RID: 1582 RVA: 0x00024D10 File Offset: 0x00022F10
		public Vector4 textureParams
		{
			get
			{
				return new Vector4((float)this.atlasTextureWidth, (float)this.atlasTextureHeight, (float)this.gradientWidth, (float)this.gradientHeight);
			}
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x00024D34 File Offset: 0x00022F34
		protected string GetMegaBytes(int bits)
		{
			float num = (float)(bits / 1024 / 1024 / 8);
			if (num < 1f)
			{
				return Mathf.FloorToInt((float)(bits / 1024 / 8)).ToString() + " KB";
			}
			return num.ToString(".0") + " MB";
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x00024D92 File Offset: 0x00022F92
		public void ClearAllData()
		{
			Debug.Log("Clear Atlas Data");
			if (this._atlasData != null)
			{
				this._atlasData.Clear();
			}
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x00024DB4 File Offset: 0x00022FB4
		public void ClearMaterials()
		{
			if (this.materials == null)
			{
				return;
			}
			for (int i = 0; i < this.materials.Count; i++)
			{
				if (!(this.materials[i] == null))
				{
					SVGAtlas.DestroyObjectInternal(this.materials[i]);
				}
			}
			this.materials.Clear();
			this.materials = null;
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x00024E18 File Offset: 0x00023018
		public void ClearAtlasTextures()
		{
			if (this.atlasTextures == null || this.atlasTextures.Count == 0)
			{
				return;
			}
			for (int i = 0; i < this.atlasTextures.Count; i++)
			{
				if (!(this.atlasTextures[i] == null))
				{
					SVGAtlas.DestroyObjectInternal(this.atlasTextures[i]);
					this.atlasTextures[i] = null;
				}
			}
			this.atlasTextures.Clear();
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x00024E8E File Offset: 0x0002308E
		private static void DestroyObjectInternal(Object target)
		{
			if (Application.isPlaying)
			{
				Object.Destroy(target);
				return;
			}
			Object.DestroyImmediate(target, true);
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x00024EA5 File Offset: 0x000230A5
		internal static Camera[] GetAllCameras()
		{
			return Camera.allCameras;
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x00024EAC File Offset: 0x000230AC
		internal static void AddComponent<T>(Component component) where T : MonoBehaviour
		{
			if (component == null)
			{
				return;
			}
			GameObject gameObject = component.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (gameObject.GetComponent<T>() != null)
			{
				return;
			}
			gameObject.AddComponent<T>();
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x00024EF0 File Offset: 0x000230F0
		public static void AssignMaterialGradients(Material material, Texture2D gradientAtlas, Texture2D gradientShape, int gradientWidth, int gradientHeight)
		{
			if (material == null)
			{
				return;
			}
			if (material.HasProperty("_GradientColor"))
			{
				material.SetTexture("_GradientColor", gradientAtlas);
			}
			if (material.HasProperty("_GradientShape"))
			{
				material.SetTexture("_GradientShape", gradientShape);
			}
			if (material.HasProperty("_Params") && gradientAtlas != null)
			{
				Vector4 value = new Vector4((float)gradientAtlas.width, (float)gradientAtlas.height, (float)gradientWidth, (float)gradientHeight);
				material.SetVector("_Params", value);
			}
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x00024F78 File Offset: 0x00023178
		public static void AssignMaterialGradients(Material[] materials, Texture2D gradientAtlas, Texture2D gradientShape, int gradientWidth, int gradientHeight)
		{
			if (materials == null || materials.Length == 0)
			{
				return;
			}
			for (int i = 0; i < materials.Length; i++)
			{
				SVGAtlas.AssignMaterialGradients(materials[i], gradientAtlas, gradientShape, gradientWidth, gradientHeight);
			}
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x00024FA8 File Offset: 0x000231A8
		public Material GetTransparentMaterial(bool antialiasing, bool hasGradients)
		{
			if (antialiasing)
			{
				if (hasGradients)
				{
					return this.transparentGradientAntialiased;
				}
				return this.transparentSolidAntialiased;
			}
			else
			{
				if (hasGradients)
				{
					return this.transparentGradient;
				}
				return this.transparentSolid;
			}
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x00024FCE File Offset: 0x000231CE
		public Material GetOpaqueMaterial(bool hasGradients)
		{
			if (hasGradients)
			{
				return this.opaqueGradient;
			}
			return this.opaqueSolid;
		}

		// Token: 0x040006B6 RID: 1718
		protected bool _atlasHasChanged;

		// Token: 0x040006B7 RID: 1719
		protected static bool _beingDestroyed;

		// Token: 0x040006B8 RID: 1720
		protected static Texture2D _whiteTexture;

		// Token: 0x040006B9 RID: 1721
		protected static Texture2D _gradientShapeTexture;

		// Token: 0x040006BA RID: 1722
		protected static int _gradientShapeTextureSize = 512;

		// Token: 0x040006BB RID: 1723
		protected SVGAtlasData _atlasData;

		// Token: 0x040006BC RID: 1724
		protected Material _ui;

		// Token: 0x040006BD RID: 1725
		protected Material _uiAntialiased;

		// Token: 0x040006BE RID: 1726
		protected Material _opaqueSolid;

		// Token: 0x040006BF RID: 1727
		protected Material _transparentSolid;

		// Token: 0x040006C0 RID: 1728
		protected Material _transparentSolidAntialiased;

		// Token: 0x040006C1 RID: 1729
		protected Material _opaqueGradient;

		// Token: 0x040006C2 RID: 1730
		protected Material _transparentGradient;

		// Token: 0x040006C3 RID: 1731
		protected Material _transparentGradientAntialiased;

		// Token: 0x040006C4 RID: 1732
		public List<Texture2D> atlasTextures;

		// Token: 0x040006C5 RID: 1733
		public List<Material> materials;

		// Token: 0x040006C6 RID: 1734
		public const int defaultGradientWidth = 128;

		// Token: 0x040006C7 RID: 1735
		public const int defaultGradientHeight = 4;

		// Token: 0x040006C8 RID: 1736
		public const int defaultAtlasTextureWidth = 512;

		// Token: 0x040006C9 RID: 1737
		public const int defaultAtlasTextureHeight = 512;

		// Token: 0x040006CA RID: 1738
		private const int atlasIndex = 0;

		// Token: 0x040006CB RID: 1739
		public int gradientWidth = 128;

		// Token: 0x040006CC RID: 1740
		public int gradientHeight = 4;

		// Token: 0x040006CD RID: 1741
		public int atlasTextureWidth = 512;

		// Token: 0x040006CE RID: 1742
		public int atlasTextureHeight = 512;

		// Token: 0x040006CF RID: 1743
		protected static SVGAtlas _Instance;

		// Token: 0x040006D0 RID: 1744
		private const int pixelOffset = 1;

		// Token: 0x040006D1 RID: 1745
		private const float PI2 = 6.2831855f;

		// Token: 0x040006D2 RID: 1746
		public const string _GradientColorKey = "_GradientColor";

		// Token: 0x040006D3 RID: 1747
		public const string _GradientShapeKey = "_GradientShape";

		// Token: 0x040006D4 RID: 1748
		public const string _ParamsKey = "_Params";
	}
}
