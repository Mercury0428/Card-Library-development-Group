﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000165 RID: 357
	internal enum EdgeSide
	{
		// Token: 0x04000998 RID: 2456
		esLeft,
		// Token: 0x04000999 RID: 2457
		esRight
	}
}
