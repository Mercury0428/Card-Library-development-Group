﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000161 RID: 353
	public enum PolyType
	{
		// Token: 0x04000986 RID: 2438
		ptSubject,
		// Token: 0x04000987 RID: 2439
		ptClip
	}
}
