﻿using System;
using System.Collections.Generic;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200015C RID: 348
	public class PolyNode
	{
		// Token: 0x06000A92 RID: 2706 RVA: 0x000448CC File Offset: 0x00042ACC
		private bool IsHoleNode()
		{
			bool flag = true;
			for (PolyNode parent = this.m_Parent; parent != null; parent = parent.m_Parent)
			{
				flag = !flag;
			}
			return flag;
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000A93 RID: 2707 RVA: 0x000448F4 File Offset: 0x00042AF4
		public int ChildCount
		{
			get
			{
				return this.m_Childs.Count;
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000A94 RID: 2708 RVA: 0x00044901 File Offset: 0x00042B01
		public List<IntPoint> Contour
		{
			get
			{
				return this.m_polygon;
			}
		}

		// Token: 0x06000A95 RID: 2709 RVA: 0x0004490C File Offset: 0x00042B0C
		internal void AddChild(PolyNode Child)
		{
			int count = this.m_Childs.Count;
			this.m_Childs.Add(Child);
			Child.m_Parent = this;
			Child.m_Index = count;
		}

		// Token: 0x06000A96 RID: 2710 RVA: 0x0004493F File Offset: 0x00042B3F
		public PolyNode GetNext()
		{
			if (this.m_Childs.Count > 0)
			{
				return this.m_Childs[0];
			}
			return this.GetNextSiblingUp();
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x00044964 File Offset: 0x00042B64
		internal PolyNode GetNextSiblingUp()
		{
			if (this.m_Parent == null)
			{
				return null;
			}
			if (this.m_Index == this.m_Parent.m_Childs.Count - 1)
			{
				return this.m_Parent.GetNextSiblingUp();
			}
			return this.m_Parent.m_Childs[this.m_Index + 1];
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000A98 RID: 2712 RVA: 0x000449B9 File Offset: 0x00042BB9
		public List<PolyNode> Childs
		{
			get
			{
				return this.m_Childs;
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000A99 RID: 2713 RVA: 0x000449C1 File Offset: 0x00042BC1
		public PolyNode Parent
		{
			get
			{
				return this.m_Parent;
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000A9A RID: 2714 RVA: 0x000449C9 File Offset: 0x00042BC9
		public bool IsHole
		{
			get
			{
				return this.IsHoleNode();
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000A9B RID: 2715 RVA: 0x000449D1 File Offset: 0x00042BD1
		// (set) Token: 0x06000A9C RID: 2716 RVA: 0x000449D9 File Offset: 0x00042BD9
		public bool IsOpen { get; set; }

		// Token: 0x04000971 RID: 2417
		internal PolyNode m_Parent;

		// Token: 0x04000972 RID: 2418
		internal List<IntPoint> m_polygon = new List<IntPoint>();

		// Token: 0x04000973 RID: 2419
		internal int m_Index;

		// Token: 0x04000974 RID: 2420
		internal JoinType m_jointype;

		// Token: 0x04000975 RID: 2421
		internal EndType m_endtype;

		// Token: 0x04000976 RID: 2422
		internal List<PolyNode> m_Childs = new List<PolyNode>();
	}
}
