﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000168 RID: 360
	public class IntersectNode
	{
		// Token: 0x040009AF RID: 2479
		internal TEdge Edge1;

		// Token: 0x040009B0 RID: 2480
		internal TEdge Edge2;

		// Token: 0x040009B1 RID: 2481
		internal IntPoint Pt;
	}
}
