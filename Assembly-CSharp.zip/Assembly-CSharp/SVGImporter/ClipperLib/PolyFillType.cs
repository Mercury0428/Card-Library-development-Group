﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000162 RID: 354
	public enum PolyFillType
	{
		// Token: 0x04000989 RID: 2441
		pftEvenOdd,
		// Token: 0x0400098A RID: 2442
		pftNonZero,
		// Token: 0x0400098B RID: 2443
		pftPositive,
		// Token: 0x0400098C RID: 2444
		pftNegative
	}
}
