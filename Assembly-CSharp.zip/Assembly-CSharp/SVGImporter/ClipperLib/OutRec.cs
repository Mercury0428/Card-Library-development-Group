﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016C RID: 364
	internal class OutRec
	{
		// Token: 0x040009B8 RID: 2488
		internal int Idx;

		// Token: 0x040009B9 RID: 2489
		internal bool IsHole;

		// Token: 0x040009BA RID: 2490
		internal bool IsOpen;

		// Token: 0x040009BB RID: 2491
		internal OutRec FirstLeft;

		// Token: 0x040009BC RID: 2492
		internal OutPt Pts;

		// Token: 0x040009BD RID: 2493
		internal OutPt BottomPt;

		// Token: 0x040009BE RID: 2494
		internal PolyNode PolyNode;
	}
}
