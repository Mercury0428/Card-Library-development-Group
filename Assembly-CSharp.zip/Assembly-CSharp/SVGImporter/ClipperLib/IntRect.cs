﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200015F RID: 351
	public struct IntRect
	{
		// Token: 0x06000AB5 RID: 2741 RVA: 0x00045007 File Offset: 0x00043207
		public IntRect(long l, long t, long r, long b)
		{
			this.left = l;
			this.top = t;
			this.right = r;
			this.bottom = b;
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x00045026 File Offset: 0x00043226
		public IntRect(IntRect ir)
		{
			this.left = ir.left;
			this.top = ir.top;
			this.right = ir.right;
			this.bottom = ir.bottom;
		}

		// Token: 0x0400097C RID: 2428
		public long left;

		// Token: 0x0400097D RID: 2429
		public long top;

		// Token: 0x0400097E RID: 2430
		public long right;

		// Token: 0x0400097F RID: 2431
		public long bottom;
	}
}
