﻿using System;
using System.Collections.Generic;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000169 RID: 361
	public class MyIntersectNodeSort : IComparer<IntersectNode>
	{
		// Token: 0x06000AB9 RID: 2745 RVA: 0x00045058 File Offset: 0x00043258
		public int Compare(IntersectNode node1, IntersectNode node2)
		{
			return (int)(node2.Pt.Y - node1.Pt.Y);
		}
	}
}
