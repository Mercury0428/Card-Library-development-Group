﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016A RID: 362
	internal class LocalMinima
	{
		// Token: 0x040009B2 RID: 2482
		internal long Y;

		// Token: 0x040009B3 RID: 2483
		internal TEdge LeftBound;

		// Token: 0x040009B4 RID: 2484
		internal TEdge RightBound;

		// Token: 0x040009B5 RID: 2485
		internal LocalMinima Next;
	}
}
