﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000164 RID: 356
	public enum EndType
	{
		// Token: 0x04000992 RID: 2450
		etClosedPolygon,
		// Token: 0x04000993 RID: 2451
		etClosedLine,
		// Token: 0x04000994 RID: 2452
		etOpenButt,
		// Token: 0x04000995 RID: 2453
		etOpenSquare,
		// Token: 0x04000996 RID: 2454
		etOpenRound
	}
}
