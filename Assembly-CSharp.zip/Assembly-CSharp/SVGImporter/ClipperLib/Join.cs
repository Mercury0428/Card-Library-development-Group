﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016E RID: 366
	internal class Join
	{
		// Token: 0x040009C3 RID: 2499
		internal OutPt OutPt1;

		// Token: 0x040009C4 RID: 2500
		internal OutPt OutPt2;

		// Token: 0x040009C5 RID: 2501
		internal IntPoint OffPt;
	}
}
