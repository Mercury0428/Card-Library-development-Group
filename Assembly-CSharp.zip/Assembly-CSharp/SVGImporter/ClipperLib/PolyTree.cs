﻿using System;
using System.Collections.Generic;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200015B RID: 347
	public class PolyTree : PolyNode
	{
		// Token: 0x06000A8D RID: 2701 RVA: 0x0004481C File Offset: 0x00042A1C
		~PolyTree()
		{
			this.Clear();
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x00044848 File Offset: 0x00042A48
		public void Clear()
		{
			for (int i = 0; i < this.m_AllPolys.Count; i++)
			{
				this.m_AllPolys[i] = null;
			}
			this.m_AllPolys.Clear();
			this.m_Childs.Clear();
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x0004488E File Offset: 0x00042A8E
		public PolyNode GetFirst()
		{
			if (this.m_Childs.Count > 0)
			{
				return this.m_Childs[0];
			}
			return null;
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000A90 RID: 2704 RVA: 0x000448AC File Offset: 0x00042AAC
		public int Total
		{
			get
			{
				return this.m_AllPolys.Count;
			}
		}

		// Token: 0x04000970 RID: 2416
		internal List<PolyNode> m_AllPolys = new List<PolyNode>();
	}
}
