﻿using System;
using System.Collections.Generic;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016F RID: 367
	public class ClipperBase
	{
		// Token: 0x06000AC0 RID: 2752 RVA: 0x00045072 File Offset: 0x00043272
		internal static bool near_zero(double val)
		{
			return val > -1E-20 && val < 1E-20;
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000AC1 RID: 2753 RVA: 0x0004508E File Offset: 0x0004328E
		// (set) Token: 0x06000AC2 RID: 2754 RVA: 0x00045096 File Offset: 0x00043296
		public bool PreserveCollinear { get; set; }

		// Token: 0x06000AC3 RID: 2755 RVA: 0x0004509F File Offset: 0x0004329F
		internal static bool IsHorizontal(TEdge e)
		{
			return e.Delta.Y == 0L;
		}

		// Token: 0x06000AC4 RID: 2756 RVA: 0x000450B0 File Offset: 0x000432B0
		internal bool PointIsVertex(IntPoint pt, OutPt pp)
		{
			OutPt outPt = pp;
			while (!(outPt.Pt == pt))
			{
				outPt = outPt.Next;
				if (outPt == pp)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x000450DC File Offset: 0x000432DC
		internal bool PointOnLineSegment(IntPoint pt, IntPoint linePt1, IntPoint linePt2, bool UseFullRange)
		{
			if (UseFullRange)
			{
				return (pt.X == linePt1.X && pt.Y == linePt1.Y) || (pt.X == linePt2.X && pt.Y == linePt2.Y) || (pt.X > linePt1.X == pt.X < linePt2.X && pt.Y > linePt1.Y == pt.Y < linePt2.Y && Int128.Int128Mul(pt.X - linePt1.X, linePt2.Y - linePt1.Y) == Int128.Int128Mul(linePt2.X - linePt1.X, pt.Y - linePt1.Y));
			}
			return (pt.X == linePt1.X && pt.Y == linePt1.Y) || (pt.X == linePt2.X && pt.Y == linePt2.Y) || (pt.X > linePt1.X == pt.X < linePt2.X && pt.Y > linePt1.Y == pt.Y < linePt2.Y && (pt.X - linePt1.X) * (linePt2.Y - linePt1.Y) == (linePt2.X - linePt1.X) * (pt.Y - linePt1.Y));
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x00045268 File Offset: 0x00043468
		internal bool PointOnPolygon(IntPoint pt, OutPt pp, bool UseFullRange)
		{
			OutPt outPt = pp;
			while (!this.PointOnLineSegment(pt, outPt.Pt, outPt.Next.Pt, UseFullRange))
			{
				outPt = outPt.Next;
				if (outPt == pp)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x000452A0 File Offset: 0x000434A0
		internal static bool SlopesEqual(TEdge e1, TEdge e2, bool UseFullRange)
		{
			if (UseFullRange)
			{
				return Int128.Int128Mul(e1.Delta.Y, e2.Delta.X) == Int128.Int128Mul(e1.Delta.X, e2.Delta.Y);
			}
			return e1.Delta.Y * e2.Delta.X == e1.Delta.X * e2.Delta.Y;
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0004531C File Offset: 0x0004351C
		protected static bool SlopesEqual(IntPoint pt1, IntPoint pt2, IntPoint pt3, bool UseFullRange)
		{
			if (UseFullRange)
			{
				return Int128.Int128Mul(pt1.Y - pt2.Y, pt2.X - pt3.X) == Int128.Int128Mul(pt1.X - pt2.X, pt2.Y - pt3.Y);
			}
			return (pt1.Y - pt2.Y) * (pt2.X - pt3.X) - (pt1.X - pt2.X) * (pt2.Y - pt3.Y) == 0L;
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x000453AC File Offset: 0x000435AC
		protected static bool SlopesEqual(IntPoint pt1, IntPoint pt2, IntPoint pt3, IntPoint pt4, bool UseFullRange)
		{
			if (UseFullRange)
			{
				return Int128.Int128Mul(pt1.Y - pt2.Y, pt3.X - pt4.X) == Int128.Int128Mul(pt1.X - pt2.X, pt3.Y - pt4.Y);
			}
			return (pt1.Y - pt2.Y) * (pt3.X - pt4.X) - (pt1.X - pt2.X) * (pt3.Y - pt4.Y) == 0L;
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0004543C File Offset: 0x0004363C
		internal ClipperBase()
		{
			this.m_MinimaList = null;
			this.m_CurrentLM = null;
			this.m_UseFullRange = false;
			this.m_HasOpenPaths = false;
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x0004546C File Offset: 0x0004366C
		public virtual void Clear()
		{
			this.DisposeLocalMinimaList();
			for (int i = 0; i < this.m_edges.Count; i++)
			{
				for (int j = 0; j < this.m_edges[i].Count; j++)
				{
					this.m_edges[i][j] = null;
				}
				this.m_edges[i].Clear();
			}
			this.m_edges.Clear();
			this.m_UseFullRange = false;
			this.m_HasOpenPaths = false;
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x000454F0 File Offset: 0x000436F0
		private void DisposeLocalMinimaList()
		{
			while (this.m_MinimaList != null)
			{
				LocalMinima next = this.m_MinimaList.Next;
				this.m_MinimaList = null;
				this.m_MinimaList = next;
			}
			this.m_CurrentLM = null;
		}

		// Token: 0x06000ACD RID: 2765 RVA: 0x00045528 File Offset: 0x00043728
		private void RangeTest(IntPoint Pt, ref bool useFullRange)
		{
			if (useFullRange)
			{
				if (Pt.X > 4611686018427387903L || Pt.Y > 4611686018427387903L || -Pt.X > 4611686018427387903L || -Pt.Y > 4611686018427387903L)
				{
					throw new ClipperException("Coordinate outside allowed range");
				}
			}
			else if (Pt.X > 1073741823L || Pt.Y > 1073741823L || -Pt.X > 1073741823L || -Pt.Y > 1073741823L)
			{
				useFullRange = true;
				this.RangeTest(Pt, ref useFullRange);
			}
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x000455CF File Offset: 0x000437CF
		private void InitEdge(TEdge e, TEdge eNext, TEdge ePrev, IntPoint pt)
		{
			e.Next = eNext;
			e.Prev = ePrev;
			e.Curr = pt;
			e.OutIdx = -1;
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x000455F0 File Offset: 0x000437F0
		private void InitEdge2(TEdge e, PolyType polyType)
		{
			if (e.Curr.Y >= e.Next.Curr.Y)
			{
				e.Bot = e.Curr;
				e.Top = e.Next.Curr;
			}
			else
			{
				e.Top = e.Curr;
				e.Bot = e.Next.Curr;
			}
			this.SetDx(e);
			e.PolyTyp = polyType;
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x00045664 File Offset: 0x00043864
		private TEdge FindNextLocMin(TEdge E)
		{
			TEdge tedge;
			for (;;)
			{
				if (!(E.Bot != E.Prev.Bot) && !(E.Curr == E.Top))
				{
					if (E.Dx != -3.4E+38 && E.Prev.Dx != -3.4E+38)
					{
						break;
					}
					while (E.Prev.Dx == -3.4E+38)
					{
						E = E.Prev;
					}
					tedge = E;
					while (E.Dx == -3.4E+38)
					{
						E = E.Next;
					}
					if (E.Top.Y != E.Prev.Bot.Y)
					{
						goto Block_7;
					}
				}
				else
				{
					E = E.Next;
				}
			}
			return E;
			Block_7:
			if (tedge.Prev.Bot.X < E.Bot.X)
			{
				E = tedge;
			}
			return E;
		}

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0004574C File Offset: 0x0004394C
		private TEdge ProcessBound(TEdge E, bool IsClockwise)
		{
			TEdge tedge = E;
			TEdge tedge2 = E;
			if (E.Dx == -3.4E+38)
			{
				long x;
				if (IsClockwise)
				{
					x = E.Prev.Bot.X;
				}
				else
				{
					x = E.Next.Bot.X;
				}
				if (E.Bot.X != x)
				{
					this.ReverseHorizontal(E);
				}
			}
			if (tedge2.OutIdx != -2)
			{
				if (IsClockwise)
				{
					while (tedge2.Top.Y == tedge2.Next.Bot.Y && tedge2.Next.OutIdx != -2)
					{
						tedge2 = tedge2.Next;
					}
					if (tedge2.Dx == -3.4E+38 && tedge2.Next.OutIdx != -2)
					{
						TEdge tedge3 = tedge2;
						while (tedge3.Prev.Dx == -3.4E+38)
						{
							tedge3 = tedge3.Prev;
						}
						if (tedge3.Prev.Top.X == tedge2.Next.Top.X)
						{
							if (!IsClockwise)
							{
								tedge2 = tedge3.Prev;
							}
						}
						else if (tedge3.Prev.Top.X > tedge2.Next.Top.X)
						{
							tedge2 = tedge3.Prev;
						}
					}
					while (E != tedge2)
					{
						E.NextInLML = E.Next;
						if (E.Dx == -3.4E+38 && E != tedge && E.Bot.X != E.Prev.Top.X)
						{
							this.ReverseHorizontal(E);
						}
						E = E.Next;
					}
					if (E.Dx == -3.4E+38 && E != tedge && E.Bot.X != E.Prev.Top.X)
					{
						this.ReverseHorizontal(E);
					}
					tedge2 = tedge2.Next;
				}
				else
				{
					while (tedge2.Top.Y == tedge2.Prev.Bot.Y && tedge2.Prev.OutIdx != -2)
					{
						tedge2 = tedge2.Prev;
					}
					if (tedge2.Dx == -3.4E+38 && tedge2.Prev.OutIdx != -2)
					{
						TEdge tedge3 = tedge2;
						while (tedge3.Next.Dx == -3.4E+38)
						{
							tedge3 = tedge3.Next;
						}
						if (tedge3.Next.Top.X == tedge2.Prev.Top.X)
						{
							if (!IsClockwise)
							{
								tedge2 = tedge3.Next;
							}
						}
						else if (tedge3.Next.Top.X > tedge2.Prev.Top.X)
						{
							tedge2 = tedge3.Next;
						}
					}
					while (E != tedge2)
					{
						E.NextInLML = E.Prev;
						if (E.Dx == -3.4E+38 && E != tedge && E.Bot.X != E.Next.Top.X)
						{
							this.ReverseHorizontal(E);
						}
						E = E.Prev;
					}
					if (E.Dx == -3.4E+38 && E != tedge && E.Bot.X != E.Next.Top.X)
					{
						this.ReverseHorizontal(E);
					}
					tedge2 = tedge2.Prev;
				}
			}
			if (tedge2.OutIdx == -2)
			{
				E = tedge2;
				if (IsClockwise)
				{
					while (E.Top.Y == E.Next.Bot.Y)
					{
						E = E.Next;
					}
					while (E != tedge2)
					{
						if (E.Dx != -3.4E+38)
						{
							break;
						}
						E = E.Prev;
					}
				}
				else
				{
					while (E.Top.Y == E.Prev.Bot.Y)
					{
						E = E.Prev;
					}
					while (E != tedge2 && E.Dx == -3.4E+38)
					{
						E = E.Next;
					}
				}
				if (E == tedge2)
				{
					if (IsClockwise)
					{
						tedge2 = E.Next;
					}
					else
					{
						tedge2 = E.Prev;
					}
				}
				else
				{
					if (IsClockwise)
					{
						E = tedge2.Next;
					}
					else
					{
						E = tedge2.Prev;
					}
					LocalMinima localMinima = new LocalMinima();
					localMinima.Next = null;
					localMinima.Y = E.Bot.Y;
					localMinima.LeftBound = null;
					localMinima.RightBound = E;
					localMinima.RightBound.WindDelta = 0;
					tedge2 = this.ProcessBound(localMinima.RightBound, IsClockwise);
					this.InsertLocalMinima(localMinima);
				}
			}
			return tedge2;
		}

		// Token: 0x06000AD2 RID: 2770 RVA: 0x00045BB8 File Offset: 0x00043DB8
		public bool AddPath(List<IntPoint> pg, PolyType polyType, bool Closed)
		{
			if (!Closed)
			{
				throw new ClipperException("AddPath: Open paths have been disabled.");
			}
			int i = pg.Count - 1;
			if (Closed)
			{
				while (i > 0)
				{
					if (!(pg[i] == pg[0]))
					{
						break;
					}
					i--;
				}
			}
			while (i > 0 && pg[i] == pg[i - 1])
			{
				i--;
			}
			if ((Closed && i < 2) || (!Closed && i < 1))
			{
				return false;
			}
			List<TEdge> list = new List<TEdge>(i + 1);
			for (int j = 0; j <= i; j++)
			{
				list.Add(new TEdge());
			}
			bool flag = true;
			list[1].Curr = pg[1];
			this.RangeTest(pg[0], ref this.m_UseFullRange);
			this.RangeTest(pg[i], ref this.m_UseFullRange);
			this.InitEdge(list[0], list[1], list[i], pg[0]);
			this.InitEdge(list[i], list[0], list[i - 1], pg[i]);
			for (int k = i - 1; k >= 1; k--)
			{
				this.RangeTest(pg[k], ref this.m_UseFullRange);
				this.InitEdge(list[k], list[k + 1], list[k - 1], pg[k]);
			}
			TEdge tedge = list[0];
			TEdge tedge2 = tedge;
			TEdge tedge3 = tedge;
			for (;;)
			{
				if (tedge2.Curr == tedge2.Next.Curr)
				{
					if (tedge2 == tedge2.Next)
					{
						break;
					}
					if (tedge2 == tedge)
					{
						tedge = tedge2.Next;
					}
					tedge2 = this.RemoveEdge(tedge2);
					tedge3 = tedge2;
				}
				else
				{
					if (tedge2.Prev == tedge2.Next)
					{
						break;
					}
					if (Closed && ClipperBase.SlopesEqual(tedge2.Prev.Curr, tedge2.Curr, tedge2.Next.Curr, this.m_UseFullRange) && (!this.PreserveCollinear || !this.Pt2IsBetweenPt1AndPt3(tedge2.Prev.Curr, tedge2.Curr, tedge2.Next.Curr)))
					{
						if (tedge2 == tedge)
						{
							tedge = tedge2.Next;
						}
						tedge2 = this.RemoveEdge(tedge2);
						tedge2 = tedge2.Prev;
						tedge3 = tedge2;
					}
					else
					{
						tedge2 = tedge2.Next;
						if (tedge2 == tedge3)
						{
							break;
						}
					}
				}
			}
			if ((!Closed && tedge2 == tedge2.Next) || (Closed && tedge2.Prev == tedge2.Next))
			{
				return false;
			}
			if (!Closed)
			{
				this.m_HasOpenPaths = true;
				tedge.Prev.OutIdx = -2;
			}
			tedge2 = tedge;
			do
			{
				this.InitEdge2(tedge2, polyType);
				tedge2 = tedge2.Next;
				if (flag && tedge2.Curr.Y != tedge.Curr.Y)
				{
					flag = false;
				}
			}
			while (tedge2 != tedge);
			if (!flag)
			{
				this.m_edges.Add(list);
				TEdge tedge4 = null;
				for (;;)
				{
					tedge2 = this.FindNextLocMin(tedge2);
					if (tedge2 == tedge4)
					{
						break;
					}
					if (tedge4 == null)
					{
						tedge4 = tedge2;
					}
					LocalMinima localMinima = new LocalMinima();
					localMinima.Next = null;
					localMinima.Y = tedge2.Bot.Y;
					bool flag2;
					if (tedge2.Dx < tedge2.Prev.Dx)
					{
						localMinima.LeftBound = tedge2.Prev;
						localMinima.RightBound = tedge2;
						flag2 = false;
					}
					else
					{
						localMinima.LeftBound = tedge2;
						localMinima.RightBound = tedge2.Prev;
						flag2 = true;
					}
					localMinima.LeftBound.Side = EdgeSide.esLeft;
					localMinima.RightBound.Side = EdgeSide.esRight;
					if (!Closed)
					{
						localMinima.LeftBound.WindDelta = 0;
					}
					else if (localMinima.LeftBound.Next == localMinima.RightBound)
					{
						localMinima.LeftBound.WindDelta = -1;
					}
					else
					{
						localMinima.LeftBound.WindDelta = 1;
					}
					localMinima.RightBound.WindDelta = -localMinima.LeftBound.WindDelta;
					tedge2 = this.ProcessBound(localMinima.LeftBound, flag2);
					TEdge tedge5 = this.ProcessBound(localMinima.RightBound, !flag2);
					if (localMinima.LeftBound.OutIdx == -2)
					{
						localMinima.LeftBound = null;
					}
					else if (localMinima.RightBound.OutIdx == -2)
					{
						localMinima.RightBound = null;
					}
					this.InsertLocalMinima(localMinima);
					if (!flag2)
					{
						tedge2 = tedge5;
					}
				}
				return true;
			}
			if (Closed)
			{
				return false;
			}
			tedge2.Prev.OutIdx = -2;
			if (tedge2.Prev.Bot.X < tedge2.Prev.Top.X)
			{
				this.ReverseHorizontal(tedge2.Prev);
			}
			LocalMinima localMinima2 = new LocalMinima();
			localMinima2.Next = null;
			localMinima2.Y = tedge2.Bot.Y;
			localMinima2.LeftBound = null;
			localMinima2.RightBound = tedge2;
			localMinima2.RightBound.Side = EdgeSide.esRight;
			localMinima2.RightBound.WindDelta = 0;
			while (tedge2.Next.OutIdx != -2)
			{
				tedge2.NextInLML = tedge2.Next;
				if (tedge2.Bot.X != tedge2.Prev.Top.X)
				{
					this.ReverseHorizontal(tedge2);
				}
				tedge2 = tedge2.Next;
			}
			this.InsertLocalMinima(localMinima2);
			this.m_edges.Add(list);
			return true;
		}

		// Token: 0x06000AD3 RID: 2771 RVA: 0x00046114 File Offset: 0x00044314
		public bool AddPaths(List<List<IntPoint>> ppg, PolyType polyType, bool closed)
		{
			bool result = false;
			for (int i = 0; i < ppg.Count; i++)
			{
				if (this.AddPath(ppg[i], polyType, closed))
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06000AD4 RID: 2772 RVA: 0x00046148 File Offset: 0x00044348
		internal bool Pt2IsBetweenPt1AndPt3(IntPoint pt1, IntPoint pt2, IntPoint pt3)
		{
			if (pt1 == pt3 || pt1 == pt2 || pt3 == pt2)
			{
				return false;
			}
			if (pt1.X != pt3.X)
			{
				return pt2.X > pt1.X == pt2.X < pt3.X;
			}
			return pt2.Y > pt1.Y == pt2.Y < pt3.Y;
		}

		// Token: 0x06000AD5 RID: 2773 RVA: 0x000461BD File Offset: 0x000443BD
		private TEdge RemoveEdge(TEdge e)
		{
			e.Prev.Next = e.Next;
			e.Next.Prev = e.Prev;
			TEdge next = e.Next;
			e.Prev = null;
			return next;
		}

		// Token: 0x06000AD6 RID: 2774 RVA: 0x000461F0 File Offset: 0x000443F0
		private void SetDx(TEdge e)
		{
			e.Delta.X = e.Top.X - e.Bot.X;
			e.Delta.Y = e.Top.Y - e.Bot.Y;
			if (e.Delta.Y == 0L)
			{
				e.Dx = -3.4E+38;
				return;
			}
			e.Dx = (double)e.Delta.X / (double)e.Delta.Y;
		}

		// Token: 0x06000AD7 RID: 2775 RVA: 0x00046280 File Offset: 0x00044480
		private void InsertLocalMinima(LocalMinima newLm)
		{
			if (this.m_MinimaList == null)
			{
				this.m_MinimaList = newLm;
				return;
			}
			if (newLm.Y >= this.m_MinimaList.Y)
			{
				newLm.Next = this.m_MinimaList;
				this.m_MinimaList = newLm;
				return;
			}
			LocalMinima localMinima = this.m_MinimaList;
			while (localMinima.Next != null && newLm.Y < localMinima.Next.Y)
			{
				localMinima = localMinima.Next;
			}
			newLm.Next = localMinima.Next;
			localMinima.Next = newLm;
		}

		// Token: 0x06000AD8 RID: 2776 RVA: 0x00046302 File Offset: 0x00044502
		protected void PopLocalMinima()
		{
			if (this.m_CurrentLM == null)
			{
				return;
			}
			this.m_CurrentLM = this.m_CurrentLM.Next;
		}

		// Token: 0x06000AD9 RID: 2777 RVA: 0x00046320 File Offset: 0x00044520
		private void ReverseHorizontal(TEdge e)
		{
			long x = e.Top.X;
			e.Top.X = e.Bot.X;
			e.Bot.X = x;
		}

		// Token: 0x06000ADA RID: 2778 RVA: 0x0004635C File Offset: 0x0004455C
		protected virtual void Reset()
		{
			this.m_CurrentLM = this.m_MinimaList;
			if (this.m_CurrentLM == null)
			{
				return;
			}
			for (LocalMinima localMinima = this.m_MinimaList; localMinima != null; localMinima = localMinima.Next)
			{
				TEdge tedge = localMinima.LeftBound;
				if (tedge != null)
				{
					tedge.Curr = tedge.Bot;
					tedge.Side = EdgeSide.esLeft;
					tedge.OutIdx = -1;
				}
				tedge = localMinima.RightBound;
				if (tedge != null)
				{
					tedge.Curr = tedge.Bot;
					tedge.Side = EdgeSide.esRight;
					tedge.OutIdx = -1;
				}
			}
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x000463DC File Offset: 0x000445DC
		public static IntRect GetBounds(List<List<IntPoint>> paths)
		{
			int i = 0;
			int count = paths.Count;
			while (i < count && paths[i].Count == 0)
			{
				i++;
			}
			if (i == count)
			{
				return new IntRect(0L, 0L, 0L, 0L);
			}
			IntRect intRect = default(IntRect);
			intRect.left = paths[i][0].X;
			intRect.right = intRect.left;
			intRect.top = paths[i][0].Y;
			intRect.bottom = intRect.top;
			while (i < count)
			{
				for (int j = 0; j < paths[i].Count; j++)
				{
					if (paths[i][j].X < intRect.left)
					{
						intRect.left = paths[i][j].X;
					}
					else if (paths[i][j].X > intRect.right)
					{
						intRect.right = paths[i][j].X;
					}
					if (paths[i][j].Y < intRect.top)
					{
						intRect.top = paths[i][j].Y;
					}
					else if (paths[i][j].Y > intRect.bottom)
					{
						intRect.bottom = paths[i][j].Y;
					}
				}
				i++;
			}
			return intRect;
		}

		// Token: 0x040009C6 RID: 2502
		protected const double horizontal = -3.4E+38;

		// Token: 0x040009C7 RID: 2503
		protected const int Skip = -2;

		// Token: 0x040009C8 RID: 2504
		protected const int Unassigned = -1;

		// Token: 0x040009C9 RID: 2505
		protected const double tolerance = 1E-20;

		// Token: 0x040009CA RID: 2506
		internal const long loRange = 1073741823L;

		// Token: 0x040009CB RID: 2507
		internal const long hiRange = 4611686018427387903L;

		// Token: 0x040009CC RID: 2508
		internal LocalMinima m_MinimaList;

		// Token: 0x040009CD RID: 2509
		internal LocalMinima m_CurrentLM;

		// Token: 0x040009CE RID: 2510
		internal List<List<TEdge>> m_edges = new List<List<TEdge>>();

		// Token: 0x040009CF RID: 2511
		internal bool m_UseFullRange;

		// Token: 0x040009D0 RID: 2512
		internal bool m_HasOpenPaths;
	}
}
