﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200015A RID: 346
	public struct DoublePoint
	{
		// Token: 0x06000A8A RID: 2698 RVA: 0x000447D6 File Offset: 0x000429D6
		public DoublePoint(double x = 0.0, double y = 0.0)
		{
			this.X = x;
			this.Y = y;
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x000447E6 File Offset: 0x000429E6
		public DoublePoint(DoublePoint dp)
		{
			this.X = dp.X;
			this.Y = dp.Y;
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x00044800 File Offset: 0x00042A00
		public DoublePoint(IntPoint ip)
		{
			this.X = (double)ip.X;
			this.Y = (double)ip.Y;
		}

		// Token: 0x0400096E RID: 2414
		public double X;

		// Token: 0x0400096F RID: 2415
		public double Y;
	}
}
