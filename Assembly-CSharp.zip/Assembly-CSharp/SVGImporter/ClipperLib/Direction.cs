﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000166 RID: 358
	internal enum Direction
	{
		// Token: 0x0400099B RID: 2459
		dRightToLeft,
		// Token: 0x0400099C RID: 2460
		dLeftToRight
	}
}
