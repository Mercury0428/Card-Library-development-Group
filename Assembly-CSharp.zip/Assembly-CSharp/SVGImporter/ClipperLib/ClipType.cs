﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000160 RID: 352
	public enum ClipType
	{
		// Token: 0x04000981 RID: 2433
		ctIntersection,
		// Token: 0x04000982 RID: 2434
		ctUnion,
		// Token: 0x04000983 RID: 2435
		ctDifference,
		// Token: 0x04000984 RID: 2436
		ctXor
	}
}
