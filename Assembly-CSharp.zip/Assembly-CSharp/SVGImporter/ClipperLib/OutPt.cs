﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016D RID: 365
	internal class OutPt
	{
		// Token: 0x040009BF RID: 2495
		internal int Idx;

		// Token: 0x040009C0 RID: 2496
		internal IntPoint Pt;

		// Token: 0x040009C1 RID: 2497
		internal OutPt Next;

		// Token: 0x040009C2 RID: 2498
		internal OutPt Prev;
	}
}
