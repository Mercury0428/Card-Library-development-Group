﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000163 RID: 355
	public enum JoinType
	{
		// Token: 0x0400098E RID: 2446
		jtSquare,
		// Token: 0x0400098F RID: 2447
		jtRound,
		// Token: 0x04000990 RID: 2448
		jtMiter
	}
}
