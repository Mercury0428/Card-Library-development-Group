﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200016B RID: 363
	internal class Scanbeam
	{
		// Token: 0x040009B6 RID: 2486
		internal long Y;

		// Token: 0x040009B7 RID: 2487
		internal Scanbeam Next;
	}
}
