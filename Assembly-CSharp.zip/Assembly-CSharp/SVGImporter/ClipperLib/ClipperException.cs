﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000172 RID: 370
	internal class ClipperException : Exception
	{
		// Token: 0x06000B5D RID: 2909 RVA: 0x0004CDBC File Offset: 0x0004AFBC
		public ClipperException(string description) : base(description)
		{
		}
	}
}
