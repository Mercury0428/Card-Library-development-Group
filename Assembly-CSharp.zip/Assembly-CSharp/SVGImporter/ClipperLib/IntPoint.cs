﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x0200015E RID: 350
	public struct IntPoint
	{
		// Token: 0x06000AAE RID: 2734 RVA: 0x00044F33 File Offset: 0x00043133
		public IntPoint(long X, long Y)
		{
			this.X = X;
			this.Y = Y;
		}

		// Token: 0x06000AAF RID: 2735 RVA: 0x00044F43 File Offset: 0x00043143
		public IntPoint(double x, double y)
		{
			this.X = (long)x;
			this.Y = (long)y;
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x00044F55 File Offset: 0x00043155
		public IntPoint(IntPoint pt)
		{
			this.X = pt.X;
			this.Y = pt.Y;
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x00044F6F File Offset: 0x0004316F
		public static bool operator ==(IntPoint a, IntPoint b)
		{
			return a.X == b.X && a.Y == b.Y;
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x00044F8F File Offset: 0x0004318F
		public static bool operator !=(IntPoint a, IntPoint b)
		{
			return a.X != b.X || a.Y != b.Y;
		}

		// Token: 0x06000AB3 RID: 2739 RVA: 0x00044FB4 File Offset: 0x000431B4
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			if (obj is IntPoint)
			{
				IntPoint intPoint = (IntPoint)obj;
				return this.X == intPoint.X && this.Y == intPoint.Y;
			}
			return false;
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x00044FF5 File Offset: 0x000431F5
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x0400097A RID: 2426
		public long X;

		// Token: 0x0400097B RID: 2427
		public long Y;
	}
}
