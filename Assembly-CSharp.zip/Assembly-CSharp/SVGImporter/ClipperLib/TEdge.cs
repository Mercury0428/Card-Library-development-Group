﻿using System;

namespace SVGImporter.ClipperLib
{
	// Token: 0x02000167 RID: 359
	internal class TEdge
	{
		// Token: 0x0400099D RID: 2461
		internal IntPoint Bot;

		// Token: 0x0400099E RID: 2462
		internal IntPoint Curr;

		// Token: 0x0400099F RID: 2463
		internal IntPoint Top;

		// Token: 0x040009A0 RID: 2464
		internal IntPoint Delta;

		// Token: 0x040009A1 RID: 2465
		internal double Dx;

		// Token: 0x040009A2 RID: 2466
		internal PolyType PolyTyp;

		// Token: 0x040009A3 RID: 2467
		internal EdgeSide Side;

		// Token: 0x040009A4 RID: 2468
		internal int WindDelta;

		// Token: 0x040009A5 RID: 2469
		internal int WindCnt;

		// Token: 0x040009A6 RID: 2470
		internal int WindCnt2;

		// Token: 0x040009A7 RID: 2471
		internal int OutIdx;

		// Token: 0x040009A8 RID: 2472
		internal TEdge Next;

		// Token: 0x040009A9 RID: 2473
		internal TEdge Prev;

		// Token: 0x040009AA RID: 2474
		internal TEdge NextInLML;

		// Token: 0x040009AB RID: 2475
		internal TEdge NextInAEL;

		// Token: 0x040009AC RID: 2476
		internal TEdge PrevInAEL;

		// Token: 0x040009AD RID: 2477
		internal TEdge NextInSEL;

		// Token: 0x040009AE RID: 2478
		internal TEdge PrevInSEL;
	}
}
