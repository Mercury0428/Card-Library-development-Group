﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Geometry;
using SVGImporter.Rendering;
using SVGImporter.Utils;
using UnityEngine;
using UnityEngine.Serialization;

namespace SVGImporter
{
	// Token: 0x020000C3 RID: 195
	[Serializable]
	public class SVGAsset : ScriptableObject
	{
		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060005BD RID: 1469 RVA: 0x00022451 File Offset: 0x00020651
		public Mesh sharedMesh
		{
			get
			{
				return this.runtimeMesh;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060005BE RID: 1470 RVA: 0x0002245C File Offset: 0x0002065C
		public bool isOpaque
		{
			get
			{
				if (this._format == SVGAssetFormat.Transparent || this._format == SVGAssetFormat.uGUI)
				{
					return false;
				}
				if (this._sharedShaders == null || this._sharedShaders.Length == 0)
				{
					return true;
				}
				for (int i = 0; i < this._sharedShaders.Length; i++)
				{
					if (!string.IsNullOrEmpty(this._sharedShaders[i]) && this._sharedShaders[i].ToLower().Contains("opaque"))
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x060005BF RID: 1471 RVA: 0x000224D0 File Offset: 0x000206D0
		public Mesh mesh
		{
			get
			{
				Mesh sharedMesh = this.sharedMesh;
				if (sharedMesh == null)
				{
					return null;
				}
				Mesh mesh = SVGMeshUtils.Clone(sharedMesh);
				if (mesh != null)
				{
					Mesh mesh2 = mesh;
					mesh2.name = mesh2.name + " Instance " + mesh.GetInstanceID();
				}
				return mesh;
			}
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00022524 File Offset: 0x00020724
		public void AddReference(ISVGReference reference)
		{
			if (this.hasGradients)
			{
				if (SVGAtlas.beingDestroyed)
				{
					return;
				}
				for (int i = 0; i < this._sharedGradients.Length; i++)
				{
					if (this._sharedGradients[i] != null)
					{
						CCGradient ccgradient = SVGAtlas.Instance.GetGradient(this._sharedGradients[i]);
						if (ccgradient != null)
						{
							ccgradient.AddReference(reference);
						}
						else
						{
							ccgradient = SVGAtlas.Instance.AddGradient(this._sharedGradients[i].Clone());
							ccgradient.AddReference(reference);
						}
					}
				}
			}
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x000225A0 File Offset: 0x000207A0
		public void RemoveReference(ISVGReference reference)
		{
			if (this.hasGradients)
			{
				int num = 0;
				if (SVGAtlas.beingDestroyed)
				{
					return;
				}
				for (int i = 0; i < this._sharedGradients.Length; i++)
				{
					if (this._sharedGradients[i] != null)
					{
						CCGradient gradient = SVGAtlas.Instance.GetGradient(this._sharedGradients[i]);
						if (gradient != null)
						{
							gradient.RemoveReference(reference);
							if (gradient.referenceCount == 0)
							{
								SVGAtlas.Instance.RemoveGradient(gradient);
							}
							num += gradient.CountReferences(reference);
						}
					}
				}
				if (num == 0)
				{
					if (this._runtimeMesh != null)
					{
						this._runtimeMesh.Clear();
						this._runtimeMesh = null;
					}
					if (this._runtimeMaterials != null)
					{
						this._runtimeMaterials = null;
					}
				}
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x060005C2 RID: 1474 RVA: 0x00022650 File Offset: 0x00020850
		protected Mesh runtimeMesh
		{
			get
			{
				if (!this.hasGradients)
				{
					return this._sharedMesh;
				}
				if (this._runtimeMesh == null && this._sharedMesh != null)
				{
					Dictionary<int, int> dictionary = new Dictionary<int, int>();
					CCGradient[] array = new CCGradient[this._sharedGradients.Length];
					for (int i = 0; i < this._sharedGradients.Length; i++)
					{
						if (this._sharedGradients[i] != null)
						{
							CCGradient gradient = SVGAtlas.Instance.GetGradient(this._sharedGradients[i]);
							if (gradient != null)
							{
								array[i] = gradient;
							}
							else
							{
								array[i] = SVGAtlas.Instance.AddGradient(this._sharedGradients[i].Clone());
							}
							dictionary.Add(this._sharedGradients[i].index, array[i].index);
						}
					}
					this._runtimeMesh = SVGMeshUtils.Clone(this._sharedMesh);
					this._runtimeMesh.hideFlags = HideFlags.DontSave;
					if (this._runtimeMesh.uv2 != null && this._runtimeMesh.uv2.Length != 0)
					{
						Vector2[] uv = this._runtimeMesh.uv2;
						for (int j = 0; j < uv.Length; j++)
						{
							int key = Mathf.FloorToInt(Mathf.Abs(uv[j].x));
							try
							{
								uv[j].x = (float)dictionary[key];
							}
							catch
							{
							}
						}
						this._runtimeMesh.uv2 = uv;
					}
				}
				return this._runtimeMesh;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060005C3 RID: 1475 RVA: 0x000227C4 File Offset: 0x000209C4
		protected Mesh runtimeLegacyUIMesh
		{
			get
			{
				if (this._runtimeLegacyUIMesh == null)
				{
					this._runtimeLegacyUIMesh = SVGAsset.CreateLegacyUIMesh(this.sharedMesh);
				}
				return this._runtimeLegacyUIMesh;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x060005C4 RID: 1476 RVA: 0x000227EB File Offset: 0x000209EB
		public Mesh sharedLegacyUIMesh
		{
			get
			{
				return this.runtimeLegacyUIMesh;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x060005C5 RID: 1477 RVA: 0x000227F3 File Offset: 0x000209F3
		public Material sharedUIMaterial
		{
			get
			{
				if (this._antialiasing)
				{
					return SVGAtlas.Instance.uiAntialiased;
				}
				return SVGAtlas.Instance.ui;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x060005C6 RID: 1478 RVA: 0x00022812 File Offset: 0x00020A12
		public Material uiMaterial
		{
			get
			{
				if (this._antialiasing)
				{
					return this.CloneMaterial(SVGAtlas.Instance.uiAntialiased);
				}
				return this.CloneMaterial(SVGAtlas.Instance.ui);
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x060005C7 RID: 1479 RVA: 0x0002283D File Offset: 0x00020A3D
		public Material[] sharedMaterials
		{
			get
			{
				return this.runtimeMaterials;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x00022848 File Offset: 0x00020A48
		public Material[] materials
		{
			get
			{
				if (this.sharedMaterials == null)
				{
					return null;
				}
				int num = this.sharedMaterials.Length;
				Material[] array = new Material[num];
				for (int i = 0; i < num; i++)
				{
					array[i] = this.CloneMaterial(this.sharedMaterials[i]);
				}
				return array;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060005C9 RID: 1481 RVA: 0x00022890 File Offset: 0x00020A90
		public Material[] runtimeMaterials
		{
			get
			{
				bool flag = false;
				if (this._runtimeMaterials != null && this._runtimeMaterials.Length != 0)
				{
					for (int i = 0; i < this._runtimeMaterials.Length; i++)
					{
						if (!(this._runtimeMaterials[i] != null))
						{
							flag = true;
							break;
						}
					}
				}
				else
				{
					flag = true;
				}
				if (flag)
				{
					if (this._sharedShaders != null && this._sharedShaders.Length != 0)
					{
						this._runtimeMaterials = new Material[this._sharedShaders.Length];
						for (int j = 0; j < this._sharedShaders.Length; j++)
						{
							if (this._sharedShaders[j] != null)
							{
								string a = this._sharedShaders[j];
								if (a == SVGShader.SolidColorOpaque.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.opaqueSolid;
								}
								else if (a == SVGShader.SolidColorAlphaBlended.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.transparentSolid;
								}
								else if (a == SVGShader.SolidColorAlphaBlendedAntialiased.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.transparentSolidAntialiased;
								}
								else if (a == SVGShader.GradientColorOpaque.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.opaqueGradient;
								}
								else if (a == SVGShader.GradientColorAlphaBlended.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.transparentGradient;
								}
								else if (a == SVGShader.GradientColorAlphaBlendedAntialiased.name)
								{
									this._runtimeMaterials[j] = SVGAtlas.Instance.transparentGradientAntialiased;
								}
							}
						}
					}
					else
					{
						this._runtimeMaterials = new Material[0];
					}
				}
				return this._runtimeMaterials;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060005CA RID: 1482 RVA: 0x00022A36 File Offset: 0x00020C36
		public bool antialiasing
		{
			get
			{
				return this._antialiasing;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060005CB RID: 1483 RVA: 0x00022A3E File Offset: 0x00020C3E
		public bool generateCollider
		{
			get
			{
				return this._generateCollider;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x00022A46 File Offset: 0x00020C46
		public bool keepSVGFile
		{
			get
			{
				return this._keepSVGFile;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060005CD RID: 1485 RVA: 0x00022A4E File Offset: 0x00020C4E
		public bool ignoreSVGCanvas
		{
			get
			{
				return this._ignoreSVGCanvas;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x00022A56 File Offset: 0x00020C56
		public SVGPath[] colliderShape
		{
			get
			{
				return this._colliderShape;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060005CF RID: 1487 RVA: 0x00022A5E File Offset: 0x00020C5E
		public SVGAssetFormat format
		{
			get
			{
				return this._format;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060005D0 RID: 1488 RVA: 0x00022A66 File Offset: 0x00020C66
		public SVGUseGradients useGradients
		{
			get
			{
				return this._useGradients;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060005D1 RID: 1489 RVA: 0x00022A6E File Offset: 0x00020C6E
		public SVGMeshCompression meshCompression
		{
			get
			{
				return this._meshCompression;
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00022A76 File Offset: 0x00020C76
		public bool optimizeMesh
		{
			get
			{
				return this._optimizeMesh;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060005D3 RID: 1491 RVA: 0x00022A7E File Offset: 0x00020C7E
		public bool generateNormals
		{
			get
			{
				return this._generateNormals;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x00022A86 File Offset: 0x00020C86
		public bool generateTangents
		{
			get
			{
				return this._generateTangents;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060005D5 RID: 1493 RVA: 0x00022A8E File Offset: 0x00020C8E
		public float scale
		{
			get
			{
				return this._scale;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x00022A96 File Offset: 0x00020C96
		public float vpm
		{
			get
			{
				return this._vpm;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x00022A9E File Offset: 0x00020C9E
		public float depthOffset
		{
			get
			{
				return this._depthOffset;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060005D8 RID: 1496 RVA: 0x00022AA6 File Offset: 0x00020CA6
		public bool compressDepth
		{
			get
			{
				return this._compressDepth;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060005D9 RID: 1497 RVA: 0x00022AAE File Offset: 0x00020CAE
		public Vector2 pivotPoint
		{
			get
			{
				return this._pivotPoint;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x00022AB6 File Offset: 0x00020CB6
		public bool customPivotPoint
		{
			get
			{
				return this._customPivotPoint;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060005DB RID: 1499 RVA: 0x00022ABE File Offset: 0x00020CBE
		public Vector4 border
		{
			get
			{
				return this._border;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060005DC RID: 1500 RVA: 0x00022AC6 File Offset: 0x00020CC6
		public bool sliceMesh
		{
			get
			{
				return this._sliceMesh;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060005DD RID: 1501 RVA: 0x00022ACE File Offset: 0x00020CCE
		public string svgFile
		{
			get
			{
				if (!string.IsNullOrEmpty(this._svgFile))
				{
					return this._svgFile;
				}
				if (this._documentAsset != null)
				{
					return this._documentAsset.svgFile;
				}
				return null;
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x00022AFF File Offset: 0x00020CFF
		public CCGradient[] sharedGradients
		{
			get
			{
				return this._sharedGradients;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060005DF RID: 1503 RVA: 0x00022B07 File Offset: 0x00020D07
		public string[] sharedShaders
		{
			get
			{
				return this._sharedShaders;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00022B10 File Offset: 0x00020D10
		public Bounds bounds
		{
			get
			{
				if (this._sharedMesh == null)
				{
					return default(Bounds);
				}
				return this._sharedMesh.bounds;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060005E1 RID: 1505 RVA: 0x00022B40 File Offset: 0x00020D40
		public Rect canvasRectangle
		{
			get
			{
				return this._canvasRectangle;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x00022B48 File Offset: 0x00020D48
		public bool useLayers
		{
			get
			{
				return this._useLayers;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060005E3 RID: 1507 RVA: 0x00022B50 File Offset: 0x00020D50
		public SVGLayer[] layers
		{
			get
			{
				return this._layers;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x00022B58 File Offset: 0x00020D58
		public SVGLayer[] layersClone
		{
			get
			{
				if (this._layers == null)
				{
					return null;
				}
				int num = this._layers.Length;
				SVGLayer[] array = new SVGLayer[num];
				for (int i = 0; i < num; i++)
				{
					array[i] = this._layers[i].Clone();
				}
				return array;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060005E5 RID: 1509 RVA: 0x00022BA4 File Offset: 0x00020DA4
		public bool hasGradients
		{
			get
			{
				return this._sharedGradients != null && this._sharedGradients.Length != 0 && (this._sharedGradients.Length != 1 || !(this._sharedGradients[0].hash == "GC999FFFFFFC000FFFFFFA999999A000999"));
			}
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x00022BE0 File Offset: 0x00020DE0
		protected Material CloneMaterial(Material original)
		{
			if (original == null)
			{
				return null;
			}
			Material material = new Material(original.shader);
			material.CopyPropertiesFromMaterial(original);
			return material;
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060005E7 RID: 1511 RVA: 0x00022BFF File Offset: 0x00020DFF
		public int uiVertexCount
		{
			get
			{
				if (this._sharedMesh == null || this._sharedMesh.triangles == null)
				{
					return 0;
				}
				int num = this._sharedMesh.triangles.Length;
				return num + num / 3;
			}
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x00022C30 File Offset: 0x00020E30
		protected static Mesh CreateLegacyUIMesh(Mesh inputMesh)
		{
			if (inputMesh == null)
			{
				return null;
			}
			Mesh mesh = new Mesh();
			Vector3[] vertices = inputMesh.vertices;
			Color32[] colors = inputMesh.colors32;
			Vector2[] uv = inputMesh.uv;
			Vector2[] uv2 = inputMesh.uv2;
			Vector3[] normals = inputMesh.normals;
			Vector4[] tangents = inputMesh.tangents;
			int[] triangles = inputMesh.triangles;
			int num = triangles.Length;
			int num2 = num + num / 3;
			Vector3[] array = new Vector3[num2];
			Color32[] array2 = new Color32[num2];
			int num3 = 0;
			for (int i = 0; i < num; i += 3)
			{
				int num4 = triangles[i];
				array[num3] = vertices[num4];
				array2[num3] = colors[num4];
				num3++;
				num4 = triangles[i + 1];
				array[num3] = vertices[num4];
				array2[num3] = colors[num4];
				num3++;
				num4 = triangles[i + 2];
				array[num3] = vertices[num4];
				array2[num3] = colors[num4];
				num3++;
			}
			mesh.vertices = array;
			mesh.colors32 = array2;
			if (uv != null && uv.Length != 0 && uv2 != null && uv2.Length != 0)
			{
				num3 = 0;
				Vector2[] array3 = new Vector2[num2];
				Vector2[] array4 = new Vector2[num2];
				for (int j = 0; j < num; j += 3)
				{
					int num4 = triangles[j];
					array3[num3] = uv[num4];
					array4[num3] = uv2[num4];
					num3++;
					num4 = triangles[j + 1];
					array3[num3] = uv[num4];
					array4[num3] = uv2[num4];
					num3++;
					num4 = triangles[j + 2];
					array3[num3] = uv[num4];
					array4[num3] = uv2[num4];
					num3++;
				}
				mesh.uv = array3;
				mesh.uv2 = array4;
			}
			if (normals != null && normals.Length != 0)
			{
				num3 = 0;
				Vector3[] array5 = new Vector3[num2];
				for (int k = 0; k < num; k += 3)
				{
					int num4 = triangles[k];
					array5[num3] = normals[num4];
					num3++;
					num4 = triangles[k + 1];
					array5[num3] = normals[num4];
					num3++;
					num4 = triangles[k + 2];
					array5[num3] = normals[num4];
					num3++;
				}
				mesh.normals = array5;
			}
			if (tangents != null && tangents.Length != 0)
			{
				num3 = 0;
				Vector4[] array6 = new Vector4[num2];
				for (int l = 0; l < num; l += 3)
				{
					int num4 = triangles[l];
					array6[num3] = tangents[num4];
					num3++;
					num4 = triangles[l + 1];
					array6[num3] = tangents[num4];
					num3++;
					num4 = triangles[l + 2];
					array6[num3] = tangents[num4];
					num3++;
				}
				mesh.tangents = array6;
			}
			return mesh;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x00022F84 File Offset: 0x00021184
		public static SVGAsset Load(string svgText, SVGImporterSettings settings = null)
		{
			if (string.IsNullOrEmpty(svgText))
			{
				return null;
			}
			if (settings == null)
			{
				SVGAssetImport.format = SVGAssetFormat.Transparent;
				SVGAssetImport.pivotPoint = new Vector2(0.5f, 0.5f);
				SVGAssetImport.meshScale = 0.01f;
				SVGAssetImport.border = new Vector4(0f, 0f, 0f, 0f);
				SVGAssetImport.sliceMesh = false;
				SVGAssetImport.minDepthOffset = 0.01f;
				SVGAssetImport.compressDepth = true;
				SVGAssetImport.ignoreSVGCanvas = true;
				SVGAssetImport.useGradients = SVGUseGradients.Always;
			}
			else
			{
				SVGAssetImport.format = settings.defaultSVGFormat;
				SVGAssetImport.pivotPoint = settings.defaultPivotPoint;
				SVGAssetImport.meshScale = settings.defaultScale;
				SVGAssetImport.border = new Vector4(0f, 0f, 0f, 0f);
				SVGAssetImport.sliceMesh = false;
				SVGAssetImport.minDepthOffset = settings.defaultDepthOffset;
				SVGAssetImport.compressDepth = settings.defaultCompressDepth;
				SVGAssetImport.ignoreSVGCanvas = settings.defaultIgnoreSVGCanvas;
				SVGAssetImport.useGradients = settings.defaultUseGradients;
				SVGAssetImport.antialiasing = settings.defaultAntialiasing;
			}
			SVGGraphics r = new SVGGraphics(1000f, SVGAssetImport.antialiasing);
			SVGDocument svgdocument = null;
			SVGAssetImport.Clear();
			SVGAssetImport.atlasData = new SVGAtlasData();
			SVGAssetImport.atlasData.Init(262144);
			SVGAssetImport.atlasData.AddGradient(SVGAtlasData.GetDefaultGradient());
			SVGParser.Init();
			SVGGraphics.Init();
			List<SVGError> list = new List<SVGError>();
			svgdocument = new SVGDocument(svgText, r);
			SVGElement rootElement = svgdocument.rootElement;
			if (rootElement == null)
			{
				Debug.LogError("SVG Document is corrupted!");
				return null;
			}
			SVGAsset svgasset = ScriptableObject.CreateInstance<SVGAsset>();
			svgasset._antialiasing = SVGAssetImport.antialiasing;
			svgasset._border = SVGAssetImport.border;
			svgasset._compressDepth = SVGAssetImport.compressDepth;
			svgasset._depthOffset = SVGAssetImport.minDepthOffset;
			svgasset._ignoreSVGCanvas = SVGAssetImport.ignoreSVGCanvas;
			svgasset._meshCompression = SVGMeshCompression.Off;
			svgasset._scale = SVGAssetImport.meshScale;
			svgasset._format = SVGAssetImport.format;
			svgasset._useGradients = SVGAssetImport.useGradients;
			svgasset._pivotPoint = SVGAssetImport.pivotPoint;
			svgasset._vpm = SVGAssetImport.vpm;
			svgasset._sharedGradients = null;
			if (settings != null)
			{
				svgasset._generateCollider = settings.defaultGenerateCollider;
				svgasset._generateNormals = settings.defaultGenerateNormals;
				svgasset._generateTangents = settings.defaultGenerateTangents;
				svgasset._sliceMesh = false;
				svgasset._optimizeMesh = settings.defaultOptimizeMesh;
				svgasset._keepSVGFile = settings.defaultKeepSVGFile;
			}
			else
			{
				svgasset._generateCollider = false;
				svgasset._generateNormals = false;
				svgasset._generateTangents = false;
				svgasset._sliceMesh = false;
				svgasset._optimizeMesh = true;
				svgasset._keepSVGFile = false;
			}
			try
			{
				rootElement.Render();
				Rect viewport = rootElement.paintable.viewport;
				viewport.x *= SVGAssetImport.meshScale;
				viewport.y *= SVGAssetImport.meshScale;
				viewport.size *= SVGAssetImport.meshScale;
				Vector2 vector;
				SVGGraphics.CorrectSVGLayers(SVGGraphics.layers, viewport, svgasset, out vector);
				bool flag = svgasset.useGradients == SVGUseGradients.Always;
				Mesh mesh = new Mesh();
				Shader[] array;
				SVGMesh.CombineMeshes(SVGGraphics.layers.ToArray(), mesh, out array, svgasset._useGradients, svgasset._format, svgasset._compressDepth, svgasset._antialiasing);
				if (mesh == null)
				{
					return null;
				}
				if (svgasset._useGradients == SVGUseGradients.Always)
				{
					if (array != null)
					{
						for (int i = 0; i < array.Length; i++)
						{
							if (!(array[i] == null))
							{
								if (array[i].name == SVGShader.SolidColorOpaque.name)
								{
									array[i] = SVGShader.GradientColorOpaque;
								}
								else if (array[i].name == SVGShader.SolidColorAlphaBlended.name)
								{
									array[i] = SVGShader.GradientColorAlphaBlended;
								}
								else if (array[i].name == SVGShader.SolidColorAlphaBlendedAntialiased.name)
								{
									array[i] = SVGShader.GradientColorAlphaBlendedAntialiased;
								}
							}
						}
					}
					flag = true;
				}
				else if (array != null)
				{
					for (int j = 0; j < array.Length; j++)
					{
						if (!(array[j] == null) && (array[j].name == SVGShader.GradientColorOpaque.name || array[j].name == SVGShader.GradientColorAlphaBlended.name || array[j].name == SVGShader.GradientColorAlphaBlendedAntialiased.name))
						{
							flag = true;
							break;
						}
					}
				}
				if (!svgasset.useLayers)
				{
					svgasset._sharedMesh = mesh;
				}
				if (array != null && array.Length != 0)
				{
					svgasset._sharedShaders = new string[array.Length];
					if (flag)
					{
						for (int k = 0; k < array.Length; k++)
						{
							svgasset._sharedShaders[k] = array[k].name;
						}
					}
					else
					{
						for (int l = 0; l < array.Length; l++)
						{
							if (array[l].name == SVGShader.GradientColorAlphaBlended.name)
							{
								array[l] = SVGShader.SolidColorAlphaBlended;
							}
							else if (array[l].name == SVGShader.GradientColorAlphaBlendedAntialiased.name)
							{
								array[l] = SVGShader.SolidColorAlphaBlendedAntialiased;
							}
							else if (array[l].name == SVGShader.GradientColorOpaque.name)
							{
								array[l] = SVGShader.SolidColorOpaque;
							}
							svgasset._sharedShaders[l] = array[l].name;
						}
					}
				}
				svgasset._canvasRectangle = new Rect(viewport.x, viewport.y, viewport.size.x, viewport.size.y);
				if (svgasset.generateCollider && SVGGraphics.paths != null && SVGGraphics.paths.Count > 0)
				{
					List<List<Vector2>> list2 = new List<List<Vector2>>();
					for (int m = 0; m < SVGGraphics.paths.Count; m++)
					{
						Vector2[] points = SVGGraphics.paths[m].points;
						for (int n = 0; n < points.Length; n++)
						{
							points[n].x = points[n].x * SVGAssetImport.meshScale - vector.x;
							points[n].y = (points[n].y * SVGAssetImport.meshScale + vector.y) * -1f;
						}
						list2.Add(new List<Vector2>(points));
					}
					list2 = SVGGeom.MergePolygon(list2);
					SVGPath[] array2 = new SVGPath[list2.Count];
					for (int num = 0; num < list2.Count; num++)
					{
						array2[num] = new SVGPath(list2[num].ToArray());
					}
					if (array2 != null && array2.Length != 0)
					{
						svgasset._colliderShape = array2;
					}
				}
				if (flag && SVGAssetImport.atlasData.gradientCache != null && SVGAssetImport.atlasData.gradientCache.Count > 0)
				{
					CCGradient[] array3 = new CCGradient[SVGAssetImport.atlasData.gradientCache.Count];
					int num2 = 0;
					foreach (KeyValuePair<string, CCGradient> keyValuePair in SVGAssetImport.atlasData.gradientCache)
					{
						array3[num2++] = keyValuePair.Value;
					}
					svgasset._sharedGradients = array3;
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("Asset Failed to import\n" + ex.Message);
				list.Add(SVGError.CorruptedFile);
			}
			svgasset._documentAsset = SVGDocumentAsset.CreateInstance(svgText, list.ToArray(), null, null);
			if (svgdocument != null)
			{
				svgdocument.Clear();
			}
			SVGAssetImport.Clear();
			return svgasset;
		}

		// Token: 0x04000683 RID: 1667
		[FormerlySerializedAs("lastTimeModified")]
		[SerializeField]
		protected long _lastTimeModified;

		// Token: 0x04000684 RID: 1668
		[FormerlySerializedAs("documentAsset")]
		[SerializeField]
		protected SVGDocumentAsset _documentAsset;

		// Token: 0x04000685 RID: 1669
		[FormerlySerializedAs("sharedMesh")]
		[SerializeField]
		protected Mesh _sharedMesh;

		// Token: 0x04000686 RID: 1670
		protected Mesh _runtimeMesh;

		// Token: 0x04000687 RID: 1671
		protected Mesh _runtimeLegacyUIMesh;

		// Token: 0x04000688 RID: 1672
		protected Material[] _runtimeMaterials;

		// Token: 0x04000689 RID: 1673
		[FormerlySerializedAs("antialiasing")]
		[SerializeField]
		protected bool _antialiasing;

		// Token: 0x0400068A RID: 1674
		[FormerlySerializedAs("generateCollider")]
		[SerializeField]
		protected bool _generateCollider;

		// Token: 0x0400068B RID: 1675
		[FormerlySerializedAs("keepSVGFile")]
		[SerializeField]
		protected bool _keepSVGFile = true;

		// Token: 0x0400068C RID: 1676
		[FormerlySerializedAs("ignoreSVGCanvas")]
		[SerializeField]
		protected bool _ignoreSVGCanvas = true;

		// Token: 0x0400068D RID: 1677
		[FormerlySerializedAs("colliderShape")]
		[SerializeField]
		protected SVGPath[] _colliderShape;

		// Token: 0x0400068E RID: 1678
		[FormerlySerializedAs("format")]
		[SerializeField]
		protected SVGAssetFormat _format = SVGAssetFormat.Transparent;

		// Token: 0x0400068F RID: 1679
		[FormerlySerializedAs("useGradients")]
		[SerializeField]
		protected SVGUseGradients _useGradients;

		// Token: 0x04000690 RID: 1680
		[FormerlySerializedAs("meshCompression")]
		[SerializeField]
		protected SVGMeshCompression _meshCompression;

		// Token: 0x04000691 RID: 1681
		[FormerlySerializedAs("optimizeMesh")]
		[SerializeField]
		protected bool _optimizeMesh = true;

		// Token: 0x04000692 RID: 1682
		[FormerlySerializedAs("generateNormals")]
		[SerializeField]
		protected bool _generateNormals;

		// Token: 0x04000693 RID: 1683
		[FormerlySerializedAs("generateTangents")]
		[SerializeField]
		protected bool _generateTangents;

		// Token: 0x04000694 RID: 1684
		[FormerlySerializedAs("scale")]
		[SerializeField]
		protected float _scale = 0.01f;

		// Token: 0x04000695 RID: 1685
		[FormerlySerializedAs("vpm")]
		[SerializeField]
		protected float _vpm = 1000f;

		// Token: 0x04000696 RID: 1686
		[FormerlySerializedAs("depthOffset")]
		[SerializeField]
		protected float _depthOffset = 0.01f;

		// Token: 0x04000697 RID: 1687
		[FormerlySerializedAs("compressDepth")]
		[SerializeField]
		protected bool _compressDepth = true;

		// Token: 0x04000698 RID: 1688
		[FormerlySerializedAs("pivotPoint")]
		[SerializeField]
		protected Vector2 _pivotPoint = new Vector2(0.5f, 0.5f);

		// Token: 0x04000699 RID: 1689
		[FormerlySerializedAs("customPivotPoint")]
		[SerializeField]
		protected bool _customPivotPoint;

		// Token: 0x0400069A RID: 1690
		[FormerlySerializedAs("border")]
		[SerializeField]
		protected Vector4 _border = new Vector4(0f, 0f, 0f, 0f);

		// Token: 0x0400069B RID: 1691
		[FormerlySerializedAs("sliceMesh")]
		[SerializeField]
		protected bool _sliceMesh;

		// Token: 0x0400069C RID: 1692
		protected string _svgFile;

		// Token: 0x0400069D RID: 1693
		[FormerlySerializedAs("sharedGradients")]
		[SerializeField]
		protected CCGradient[] _sharedGradients;

		// Token: 0x0400069E RID: 1694
		[FormerlySerializedAs("sharedShaders")]
		[SerializeField]
		protected string[] _sharedShaders;

		// Token: 0x0400069F RID: 1695
		[FormerlySerializedAs("canvasRectangle")]
		[SerializeField]
		protected Rect _canvasRectangle;

		// Token: 0x040006A0 RID: 1696
		[FormerlySerializedAs("useLayers")]
		[SerializeField]
		protected bool _useLayers;

		// Token: 0x040006A1 RID: 1697
		[FormerlySerializedAs("layers")]
		[SerializeField]
		protected SVGLayer[] _layers;
	}
}
