﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000F0 RID: 240
	public enum SVGColorType : ushort
	{
		// Token: 0x040007CD RID: 1997
		Unknown,
		// Token: 0x040007CE RID: 1998
		RGB,
		// Token: 0x040007CF RID: 1999
		Current,
		// Token: 0x040007D0 RID: 2000
		None
	}
}
