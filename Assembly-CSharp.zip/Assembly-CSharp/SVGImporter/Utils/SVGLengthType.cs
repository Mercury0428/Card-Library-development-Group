﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000F2 RID: 242
	public enum SVGLengthType : ushort
	{
		// Token: 0x040007D4 RID: 2004
		Unknown,
		// Token: 0x040007D5 RID: 2005
		Number,
		// Token: 0x040007D6 RID: 2006
		Percentage,
		// Token: 0x040007D7 RID: 2007
		EMs,
		// Token: 0x040007D8 RID: 2008
		EXs,
		// Token: 0x040007D9 RID: 2009
		PX,
		// Token: 0x040007DA RID: 2010
		CM,
		// Token: 0x040007DB RID: 2011
		MM,
		// Token: 0x040007DC RID: 2012
		IN,
		// Token: 0x040007DD RID: 2013
		PT,
		// Token: 0x040007DE RID: 2014
		PC
	}
}
