﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000FF RID: 255
	public enum ClosePathRule
	{
		// Token: 0x04000802 RID: 2050
		ALWAYS,
		// Token: 0x04000803 RID: 2051
		NEVER,
		// Token: 0x04000804 RID: 2052
		AUTO
	}
}
