﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000FA RID: 250
	[Serializable]
	public struct SVGBounds
	{
		// Token: 0x060007D3 RID: 2003 RVA: 0x000313BC File Offset: 0x0002F5BC
		public SVGBounds(float minX, float minY, float maxX, float maxY)
		{
			this._minX = minX;
			this._minY = minY;
			this._maxX = maxX;
			this._maxY = maxY;
			this._center = Vector2.zero;
			this._size = Vector2.one;
			this._extents = this._size * 0.5f;
			this.UpdateSizeExtentsCenter();
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x00031418 File Offset: 0x0002F618
		public SVGBounds(Vector2 center, Vector2 size)
		{
			this._minX = 0f;
			this._minY = 0f;
			this._maxX = 0f;
			this._maxY = 0f;
			this._center = center;
			this._size = size;
			this._extents = this._size * 0.5f;
			this.UpdateMinMax();
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x0003147C File Offset: 0x0002F67C
		public SVGBounds(Bounds bounds)
		{
			this._minX = 0f;
			this._minY = 0f;
			this._maxX = 0f;
			this._maxY = 0f;
			this._center = bounds.center;
			this._size = bounds.size;
			this._extents = this._size * 0.5f;
			this.UpdateMinMax();
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x000314F5 File Offset: 0x0002F6F5
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x000314FD File Offset: 0x0002F6FD
		public float minX
		{
			get
			{
				return this._minX;
			}
			set
			{
				if (this._minX == value)
				{
					return;
				}
				this._minX = value;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x00031516 File Offset: 0x0002F716
		// (set) Token: 0x060007D9 RID: 2009 RVA: 0x0003151E File Offset: 0x0002F71E
		public float maxX
		{
			get
			{
				return this._maxX;
			}
			set
			{
				if (this._maxX == value)
				{
					return;
				}
				this._maxX = value;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x00031537 File Offset: 0x0002F737
		// (set) Token: 0x060007DB RID: 2011 RVA: 0x0003153F File Offset: 0x0002F73F
		public float minY
		{
			get
			{
				return this._minY;
			}
			set
			{
				if (this._minY == value)
				{
					return;
				}
				this._minY = value;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x00031558 File Offset: 0x0002F758
		// (set) Token: 0x060007DD RID: 2013 RVA: 0x00031560 File Offset: 0x0002F760
		public float maxY
		{
			get
			{
				return this._maxY;
			}
			set
			{
				if (this._maxY == value)
				{
					return;
				}
				this._maxY = value;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x00031579 File Offset: 0x0002F779
		// (set) Token: 0x060007DF RID: 2015 RVA: 0x0003158C File Offset: 0x0002F78C
		public Vector2 min
		{
			get
			{
				return new Vector2(this._minX, this._minY);
			}
			set
			{
				if (this._minX == value.x && this._minY == value.y)
				{
					return;
				}
				this._minX = value.x;
				this._minY = value.y;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060007E0 RID: 2016 RVA: 0x000315C9 File Offset: 0x0002F7C9
		// (set) Token: 0x060007E1 RID: 2017 RVA: 0x000315DC File Offset: 0x0002F7DC
		public Vector2 max
		{
			get
			{
				return new Vector2(this._maxX, this._maxY);
			}
			set
			{
				if (this._maxX == value.x && this._maxY == value.y)
				{
					return;
				}
				this._maxX = value.x;
				this._maxY = value.y;
				this.UpdateSizeExtentsCenter();
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060007E2 RID: 2018 RVA: 0x00031619 File Offset: 0x0002F819
		// (set) Token: 0x060007E3 RID: 2019 RVA: 0x00031621 File Offset: 0x0002F821
		public Vector2 size
		{
			get
			{
				return this._size;
			}
			set
			{
				if (this._size == value)
				{
					return;
				}
				this._size = value;
				this._extents = value * 0.5f;
				this.UpdateMinMax();
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060007E4 RID: 2020 RVA: 0x00031650 File Offset: 0x0002F850
		// (set) Token: 0x060007E5 RID: 2021 RVA: 0x00031658 File Offset: 0x0002F858
		public Vector2 extents
		{
			get
			{
				return this._extents;
			}
			set
			{
				if (this._extents == value)
				{
					return;
				}
				this._size = value * 2f;
				this._extents = value;
				this.UpdateMinMax();
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060007E6 RID: 2022 RVA: 0x00031687 File Offset: 0x0002F887
		// (set) Token: 0x060007E7 RID: 2023 RVA: 0x0003168F File Offset: 0x0002F88F
		public Vector2 center
		{
			get
			{
				return this._center;
			}
			set
			{
				if (this._center == value)
				{
					return;
				}
				this._center = value;
				this.UpdateMinMax();
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060007E8 RID: 2024 RVA: 0x000316AD File Offset: 0x0002F8AD
		public Rect rect
		{
			get
			{
				return new Rect(this._minX, this._minY, this._size.x, this._size.y);
			}
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x000316D6 File Offset: 0x0002F8D6
		public bool Contains(Vector2 point)
		{
			return point.x >= this._minX && point.x <= this._maxX && point.y >= this._minY && point.y <= this._maxY;
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00031715 File Offset: 0x0002F915
		public bool Contains(SVGBounds bounds)
		{
			return bounds._minX >= this._minX && bounds._minY >= this._minY && bounds._maxX <= this._maxX && bounds._maxY <= this._maxY;
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00031754 File Offset: 0x0002F954
		public bool Contains(Vector2 center, Vector2 size)
		{
			size *= 0.5f;
			return center.x - size.x >= this._minX && center.y - size.y >= this._minY && center.x + size.x <= this._maxX && center.y + size.y <= this._maxY;
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x000317C8 File Offset: 0x0002F9C8
		public SVGBounds Encapsulate(Vector2 point)
		{
			bool flag = false;
			if (point.x < this._minX)
			{
				this._minX = point.x;
				flag = true;
			}
			if (point.x > this._maxX)
			{
				this._maxX = point.x;
				flag = true;
			}
			if (point.y < this._minY)
			{
				this._minY = point.y;
				flag = true;
			}
			if (point.y > this._maxY)
			{
				this._maxY = point.y;
				flag = true;
			}
			if (flag)
			{
				this.UpdateSizeExtentsCenter();
			}
			return this;
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00031858 File Offset: 0x0002FA58
		public SVGBounds Encapsulate(float minX, float minY, float maxX, float maxY)
		{
			bool flag = false;
			if (minX < this._minX)
			{
				this._minX = minX;
				flag = true;
			}
			if (maxX > this._maxX)
			{
				this._maxX = maxX;
				flag = true;
			}
			if (minY < this._minY)
			{
				this._minY = minY;
				flag = true;
			}
			if (maxY > this._maxY)
			{
				this._maxY = maxY;
				flag = true;
			}
			if (flag)
			{
				this.UpdateSizeExtentsCenter();
			}
			return this;
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x000318C0 File Offset: 0x0002FAC0
		public SVGBounds Encapsulate(Vector2 center, Vector2 size)
		{
			size *= 0.5f;
			return this.Encapsulate(center.x - size.x, center.y - size.y, center.x + size.x, center.y + size.y);
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x00031914 File Offset: 0x0002FB14
		public SVGBounds Encapsulate(SVGBounds bounds)
		{
			return this.Encapsulate(bounds._minX, bounds._minY, bounds._maxX, bounds._maxY);
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00031934 File Offset: 0x0002FB34
		public SVGBounds Encapsulate(Bounds bounds)
		{
			return this.Encapsulate(bounds.min.x, bounds.min.y, bounds.max.x, bounds.max.y);
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x0003196C File Offset: 0x0002FB6C
		public SVGBounds Expand(float amount)
		{
			if (amount == 1f)
			{
				return this;
			}
			this._size *= amount;
			this._extents = this._size * 0.5f;
			this.UpdateMinMax();
			return this;
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x000319BC File Offset: 0x0002FBBC
		public SVGBounds Expand(Vector2 amount)
		{
			if (amount.x == 1f && amount.y == 1f)
			{
				return this;
			}
			this._size.x = this._size.x * amount.x;
			this._size.y = this._size.y * amount.y;
			this._extents = this._size * 0.5f;
			this.UpdateMinMax();
			return this;
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x00031A36 File Offset: 0x0002FC36
		public bool Intersects(SVGBounds bounds)
		{
			return this._minX <= bounds._maxX && this._maxX >= bounds._minX && this._minY <= bounds._maxY && this._maxY >= bounds._minY;
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00031A75 File Offset: 0x0002FC75
		public SVGBounds SetMinMax(float minX, float minY, float maxX, float maxY)
		{
			this._minX = minX;
			this._minY = minY;
			this._maxX = maxX;
			this._maxY = maxY;
			this.UpdateSizeExtentsCenter();
			return this;
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00031AA0 File Offset: 0x0002FCA0
		public void ApplyBounds(SVGBounds bounds)
		{
			this.SetMinMax(bounds._minX, bounds._minY, bounds._maxX, bounds._maxY);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00031AC4 File Offset: 0x0002FCC4
		public SVGBounds Reset()
		{
			this._minX = (this._maxX = (this._minY = (this._maxY = 0f)));
			this._center = Vector2.zero;
			this._size = Vector2.zero;
			this._extents = Vector2.zero;
			return this;
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x00031B1E File Offset: 0x0002FD1E
		public bool Compare(SVGBounds bounds)
		{
			return this._minX == bounds._minX && this._minY == bounds._minY && this._maxX == bounds._maxX && this._maxY == bounds._maxY;
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x00031B5A File Offset: 0x0002FD5A
		public SVGBounds ResetToInfiniteInverse()
		{
			this.SetMinMax(float.MaxValue, float.MaxValue, float.MinValue, float.MinValue);
			return this;
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00031B80 File Offset: 0x0002FD80
		public override string ToString()
		{
			return string.Format("[SVGBounds: minX={0}, maxX={1}, minY={2}, maxY={3}, size={4}, extents={5}, center={6}, rect={7}]", new object[]
			{
				this.minX,
				this.maxX,
				this.minY,
				this.maxY,
				this.size,
				this.extents,
				this.center,
				this.rect
			});
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x00031C0D File Offset: 0x0002FE0D
		public Bounds ToBounds()
		{
			return new Bounds(this._center, this._size);
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x00031C2C File Offset: 0x0002FE2C
		private void UpdateMinMax()
		{
			this._minX = this._center.x - this._extents.x;
			this._minY = this._center.y - this._extents.y;
			this._maxX = this._center.x + this._extents.x;
			this._maxY = this._center.y + this._extents.y;
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x00031CB0 File Offset: 0x0002FEB0
		private void UpdateSizeExtentsCenter()
		{
			this._size.x = Mathf.Abs(this._maxX - this._minX);
			this._size.y = Mathf.Abs(this._maxY - this._minY);
			this._extents.x = this._size.x * 0.5f;
			this._extents.y = this._size.y * 0.5f;
			this._center.x = this._minX + this._extents.x;
			this._center.y = this._minY + this._extents.y;
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060007FD RID: 2045 RVA: 0x00031D69 File Offset: 0x0002FF69
		public static SVGBounds InfiniteInverse
		{
			get
			{
				return new SVGBounds(float.MaxValue, float.MaxValue, float.MinValue, float.MinValue);
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060007FE RID: 2046 RVA: 0x00031D84 File Offset: 0x0002FF84
		public bool isInfiniteInverse
		{
			get
			{
				return this._minX == float.MaxValue && this._minY == float.MaxValue && this._maxX == float.MinValue && this._maxY == float.MinValue;
			}
		}

		// Token: 0x040007F6 RID: 2038
		[HideInInspector]
		[SerializeField]
		private float _minX;

		// Token: 0x040007F7 RID: 2039
		[HideInInspector]
		[SerializeField]
		private float _minY;

		// Token: 0x040007F8 RID: 2040
		[HideInInspector]
		[SerializeField]
		private float _maxX;

		// Token: 0x040007F9 RID: 2041
		[HideInInspector]
		[SerializeField]
		private float _maxY;

		// Token: 0x040007FA RID: 2042
		[SerializeField]
		private Vector2 _center;

		// Token: 0x040007FB RID: 2043
		[SerializeField]
		private Vector2 _size;

		// Token: 0x040007FC RID: 2044
		[HideInInspector]
		[SerializeField]
		private Vector2 _extents;
	}
}
