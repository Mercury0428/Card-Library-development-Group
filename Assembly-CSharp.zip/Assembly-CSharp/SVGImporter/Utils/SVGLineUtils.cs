﻿using System;
using System.Collections.Generic;
using SVGImporter.ClipperLib;
using SVGImporter.LibTessDotNet;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000103 RID: 259
	public class SVGLineUtils
	{
		// Token: 0x0600084F RID: 2127 RVA: 0x000343D8 File Offset: 0x000325D8
		public static List<Vector2> Stroke(StrokeSegment[] segments, float thickness, Color32 color, StrokeLineJoin lineJoin, StrokeLineCap lineCap, float miterLimit = 4f, ClosePathRule closeLine = ClosePathRule.NEVER, float roundQuality = 10f)
		{
			if (segments == null || segments.Length == 0)
			{
				return null;
			}
			if (segments.Length == 1)
			{
				closeLine = ClosePathRule.NEVER;
			}
			else if (closeLine == ClosePathRule.AUTO)
			{
				if (segments[0].startPoint == segments[segments.Length - 1].endPoint)
				{
					closeLine = ClosePathRule.ALWAYS;
				}
				else
				{
					closeLine = ClosePathRule.NEVER;
				}
			}
			if (segments[0].startPoint == segments[segments.Length - 1].endPoint)
			{
				List<StrokeSegment> list = new List<StrokeSegment>(segments);
				list.RemoveAt(list.Count - 1);
				segments = list.ToArray();
			}
			List<Vector2> list2 = new List<Vector2>();
			List<Vector2> list3 = new List<Vector2>();
			if (closeLine == ClosePathRule.ALWAYS)
			{
				segments = new List<StrokeSegment>(segments)
				{
					new StrokeSegment(segments[segments.Length - 1].endPoint, segments[0].startPoint),
					new StrokeSegment(segments[0].startPoint, segments[0].endPoint)
				}.ToArray();
			}
			miterLimit = (miterLimit - 1f) * thickness * 2f;
			if (miterLimit < 1f)
			{
				miterLimit = 1f;
			}
			int num = segments.Length;
			float num2 = thickness * 0.5f;
			float num3 = miterLimit * 0.5f;
			float num4 = num3 * num3;
			Vector2 vector = Vector2.zero;
			Vector2 vector2 = Vector2.zero;
			Matrix4x4 matrix4x = Matrix4x4.TRS(Vector2.zero, Quaternion.Euler(0f, 0f, 90f), Vector2.one);
			if (lineCap == StrokeLineCap.butt || closeLine == ClosePathRule.ALWAYS)
			{
				list2.AddRange(new Vector2[]
				{
					segments[0].startPoint - segments[0].directionNormalizedRotated * num2,
					segments[0].startPoint + segments[0].directionNormalizedRotated * num2
				});
			}
			else if (lineCap == StrokeLineCap.round)
			{
				Vector2 a = Vector2.Lerp(segments[0].startPoint - segments[0].directionNormalizedRotated * num2, segments[0].startPoint + segments[0].directionNormalizedRotated * num2, 0.5f);
				float num5 = Mathf.Atan2(segments[0].directionNormalizedRotated.y, segments[0].directionNormalizedRotated.x);
				float num6 = roundQuality * thickness;
				float num7 = num6 - 1f;
				if (num7 > 0f)
				{
					int num8 = 0;
					while ((float)num8 <= num6)
					{
						float num9 = 1f - Mathf.Clamp01((float)num8 / num7);
						list2.Add(a + new Vector2(Mathf.Cos(num5 + num9 * 3.1415927f) * num2, Mathf.Sin(num5 + num9 * 3.1415927f) * num2));
						num8++;
					}
				}
				list2.AddRange(new Vector2[]
				{
					segments[0].startPoint + segments[0].directionNormalizedRotated * num2
				});
				list3.AddRange(new Vector2[]
				{
					segments[0].startPoint - segments[0].directionNormalizedRotated * num2
				});
			}
			else if (lineCap == StrokeLineCap.square)
			{
				list2.AddRange(new Vector2[]
				{
					segments[0].startPoint - segments[0].directionNormalized * num2 - segments[0].directionNormalizedRotated * num2,
					segments[0].startPoint - segments[0].directionNormalized * num2 + segments[0].directionNormalizedRotated * num2
				});
			}
			Vector2 vector3;
			Vector2 vector4;
			if (num > 1)
			{
				for (int i = 1; i < num; i++)
				{
					int num10 = i - 1;
					float num11 = Vector2.Dot(segments[i].directionNormalized, segments[num10].directionNormalized);
					float num12 = Vector2.Dot(segments[i].directionNormalized, segments[num10].directionNormalizedRotated);
					float num13 = 1f / Mathf.Sin((3.1415927f - Mathf.Acos(num11)) * 0.5f) * thickness;
					float d = num13 * 0.5f;
					Vector2 normalized = Vector2.Lerp(segments[num10].directionNormalizedRotated, segments[i].directionNormalizedRotated, 0.5f).normalized;
					Vector2 b = normalized * d;
					Vector2 b2 = matrix4x.MultiplyVector(normalized);
					vector3 = segments[i].startPoint - segments[i].directionNormalizedRotated * num2;
					vector = segments[i].endPoint - segments[i].directionNormalizedRotated * num2;
					vector4 = segments[i].startPoint + segments[i].directionNormalizedRotated * num2;
					vector2 = segments[i].endPoint + segments[i].directionNormalizedRotated * num2;
					Vector2 vector5 = segments[num10].endPoint - segments[num10].directionNormalizedRotated * num2;
					Vector2 vector6 = segments[num10].endPoint + segments[num10].directionNormalizedRotated * num2;
					if (lineJoin == StrokeLineJoin.miter && miterLimit < num13)
					{
						lineJoin = StrokeLineJoin.bevel;
					}
					if (lineJoin == StrokeLineJoin.miter || lineJoin == StrokeLineJoin.miterClip)
					{
						if (num11 == 1f || num11 == -1f)
						{
							list2.AddRange(new Vector2[]
							{
								vector6,
								vector4
							});
							list3.AddRange(new Vector2[]
							{
								vector5,
								vector3
							});
						}
						else if (num12 < 0f)
						{
							if (miterLimit <= num13)
							{
								Vector2 vector7 = segments[num10].endPoint + normalized * num3;
								Vector2 line1Start = segments[num10].endPoint + b;
								Vector2 line2End = vector7 + b2;
								Vector2 vector8;
								SVGMath.LineLineIntersection(out vector8, line1Start, vector6, vector7, line2End);
								Vector2 vector9;
								SVGMath.LineLineIntersection(out vector9, line1Start, vector4, vector7, line2End);
								if (num4 <= (Vector2.Lerp(vector6, vector4, 0.5f) - segments[num10].endPoint).sqrMagnitude)
								{
									vector8 = vector6;
									vector9 = vector4;
								}
								list2.AddRange(new Vector2[]
								{
									vector8,
									vector9
								});
								list3.AddRange(new Vector2[]
								{
									vector5,
									vector3
								});
							}
							else
							{
								Vector2 vector9 = segments[num10].endPoint + b;
								list2.AddRange(new Vector2[]
								{
									vector9
								});
								list3.AddRange(new Vector2[]
								{
									vector5,
									vector3
								});
							}
						}
						else if (miterLimit <= num13)
						{
							Vector2 vector10 = segments[num10].endPoint - normalized * num3;
							Vector2 line1Start2 = segments[num10].endPoint - b;
							Vector2 line2End2 = vector10 + b2;
							Vector2 vector8;
							SVGMath.LineLineIntersection(out vector8, line1Start2, vector3, vector10, line2End2);
							Vector2 vector9;
							SVGMath.LineLineIntersection(out vector9, line1Start2, vector5, vector10, line2End2);
							if (num4 <= (Vector2.Lerp(vector3, vector5, 0.5f) - segments[num10].endPoint).sqrMagnitude)
							{
								vector8 = vector3;
								vector9 = vector5;
							}
							list3.AddRange(new Vector2[]
							{
								vector9,
								vector8
							});
							list2.AddRange(new Vector2[]
							{
								vector6,
								vector4
							});
						}
						else
						{
							Vector2 vector8 = segments[num10].endPoint - b;
							list3.AddRange(new Vector2[]
							{
								vector8
							});
							list2.AddRange(new Vector2[]
							{
								vector6,
								vector4
							});
						}
					}
					else if (lineJoin == StrokeLineJoin.bevel)
					{
						list2.AddRange(new Vector2[]
						{
							vector6,
							vector4
						});
						list3.AddRange(new Vector2[]
						{
							vector5,
							vector3
						});
					}
					else if (lineJoin == StrokeLineJoin.round)
					{
						if (num11 == 1f)
						{
							list2.AddRange(new Vector2[]
							{
								vector6,
								vector4
							});
							list3.AddRange(new Vector2[]
							{
								vector5,
								vector3
							});
						}
						else if (num12 < 0f)
						{
							list2.AddRange(new Vector2[]
							{
								vector6
							});
							list3.AddRange(new Vector2[]
							{
								vector5,
								vector3
							});
							Vector2 a = segments[i].startPoint;
							Vector2 directionNormalizedRotated = segments[num10].directionNormalizedRotated;
							float num14 = Mathf.Acos(Vector2.Dot(segments[num10].directionNormalized, segments[i].directionNormalized));
							float num5 = Mathf.Atan2(directionNormalizedRotated.y, directionNormalizedRotated.x);
							float num15 = roundQuality * thickness * (Mathf.Acos(num11) / 3.1415927f);
							if (num15 < 1f)
							{
								num15 = 1f;
							}
							float num16 = num15;
							if (num16 > 0f)
							{
								int num8 = 0;
								while ((float)num8 < num15)
								{
									float num9 = Mathf.Clamp01((float)num8 / num16);
									list2.Add(a + new Vector2(Mathf.Cos(num5 - num9 * num14) * num2, Mathf.Sin(num5 - num9 * num14) * num2));
									num8++;
								}
							}
							list2.AddRange(new Vector2[]
							{
								vector4
							});
						}
						else
						{
							list2.AddRange(new Vector2[]
							{
								vector6,
								vector4
							});
							list3.AddRange(new Vector2[]
							{
								vector5
							});
							Vector2 a = segments[i].startPoint;
							Vector2 vector11 = -segments[i].directionNormalizedRotated;
							float num17 = Mathf.Acos(Vector2.Dot(segments[num10].directionNormalized, segments[i].directionNormalized));
							float num5 = Mathf.Atan2(vector11.y, vector11.x);
							float num18 = roundQuality * thickness * (Mathf.Acos(num11) / 3.1415927f);
							if (num18 < 1f)
							{
								num18 = 1f;
							}
							float num19 = num18;
							if (num19 > 0f)
							{
								int num8 = 0;
								while ((float)num8 < num18)
								{
									float num9 = Mathf.Clamp01(1f - (float)num8 / num19);
									list3.Add(a + new Vector2(Mathf.Cos(num5 - num9 * num17) * num2, Mathf.Sin(num5 - num9 * num17) * num2));
									num8++;
								}
							}
							list3.AddRange(new Vector2[]
							{
								vector3
							});
						}
					}
				}
			}
			int num20 = segments.Length - 1;
			vector3 = segments[num20].startPoint - segments[num20].directionNormalizedRotated * num2;
			vector = segments[num20].endPoint - segments[num20].directionNormalizedRotated * num2;
			vector4 = segments[num20].startPoint + segments[num20].directionNormalizedRotated * num2;
			vector2 = segments[num20].endPoint + segments[num20].directionNormalizedRotated * num2;
			if (closeLine == ClosePathRule.NEVER)
			{
				if (lineCap == StrokeLineCap.butt)
				{
					list2.AddRange(new Vector2[]
					{
						vector2,
						vector
					});
				}
				else if (lineCap == StrokeLineCap.round)
				{
					list2.AddRange(new Vector2[]
					{
						vector2
					});
					list3.AddRange(new Vector2[]
					{
						vector
					});
					Vector2 a = Vector2.Lerp(vector, vector2, 0.5f);
					float num5 = Mathf.Atan2(-segments[num20].directionNormalizedRotated.y, -segments[num20].directionNormalizedRotated.x);
					float num21 = roundQuality * thickness;
					float num22 = num21 - 1f;
					if (num22 > 0f)
					{
						int num8 = 0;
						while ((float)num8 <= num21)
						{
							float num9 = 1f - Mathf.Clamp01((float)num8 / num22);
							list2.Add(a + new Vector2(Mathf.Cos(num5 + num9 * 3.1415927f) * num2, Mathf.Sin(num5 + num9 * 3.1415927f) * num2));
							num8++;
						}
					}
				}
				else if (lineCap == StrokeLineCap.square)
				{
					Vector2 b3 = segments[num20].directionNormalized * num2;
					list2.AddRange(new Vector2[]
					{
						vector2 + b3,
						vector + b3
					});
				}
			}
			if ((closeLine == ClosePathRule.ALWAYS && lineJoin == StrokeLineJoin.miter) || lineJoin == StrokeLineJoin.miterClip)
			{
				list2.AddRange(new Vector2[]
				{
					vector2,
					vector
				});
			}
			list3.Reverse();
			list2.AddRange(list3);
			return list2;
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00035178 File Offset: 0x00033378
		public static UnityEngine.Mesh StrokeMesh(StrokeSegment[] segments, float thickness, Color32 color, StrokeLineJoin lineJoin, StrokeLineCap lineCap, float miterLimit = 4f, float[] dashArray = null, float dashOffset = 0f, ClosePathRule closeLine = ClosePathRule.NEVER, float roundQuality = 10f)
		{
			if (segments == null || segments.Length == 0)
			{
				return null;
			}
			return SVGLineUtils.TessellateStroke(SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
			{
				segments
			}, thickness, color, lineJoin, lineCap, miterLimit, dashArray, dashOffset, closeLine, roundQuality), color);
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x000351B4 File Offset: 0x000333B4
		public static List<List<Vector2>> StrokeShape(List<StrokeSegment[]> segments, float thickness, Color32 color, StrokeLineJoin lineJoin, StrokeLineCap lineCap, float miterLimit = 4f, float[] dashArray = null, float dashOffset = 0f, ClosePathRule closeLine = ClosePathRule.NEVER, float roundQuality = 10f)
		{
			if (segments == null || segments.Count == 0)
			{
				return null;
			}
			float num = 0f;
			for (int i = 0; i < segments.Count; i++)
			{
				if (segments[i] != null)
				{
					for (int j = 0; j < segments[i].Length; j++)
					{
						num += segments[i][j].length;
					}
				}
			}
			if (num == 0f)
			{
				return null;
			}
			bool flag;
			SVGLineUtils.ProcessDashArray(ref dashArray, out flag);
			ClosePathRule closeLine2 = closeLine;
			List<StrokeSegment[]> list = new List<StrokeSegment[]>();
			for (int i = 0; i < segments.Count; i++)
			{
				if (segments[i] != null && segments[i].Length != 0)
				{
					if (!flag)
					{
						list.Add(segments[i]);
					}
					else
					{
						list.AddRange(SVGLineUtils.CreateDashedStroke(segments[i], dashArray, dashOffset, ref closeLine2));
					}
				}
			}
			if (list.Count > 0)
			{
				List<List<Vector2>> list2 = new List<List<Vector2>>();
				for (int i = 0; i < list.Count; i++)
				{
					List<Vector2> list3 = SVGLineUtils.Stroke(list[i], thickness, color, lineJoin, lineCap, miterLimit, closeLine2, roundQuality);
					if (list3 != null && list3.Count >= 2)
					{
						List<List<Vector2>> list4 = SVGGeom.SimplifyPolygon(list3, PolyFillType.pftNonZero);
						for (int j = 0; j < list4.Count; j++)
						{
							if (list4[j] != null && list4[j].Count != 0)
							{
								list2.Add(list4[j]);
							}
						}
					}
				}
				return list2;
			}
			return null;
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x0003531C File Offset: 0x0003351C
		protected static List<StrokeSegment[]> CreateDashedStroke(StrokeSegment[] segments, float[] dashArray, float dashOffset, ref ClosePathRule closeLine)
		{
			if (segments == null || segments.Length == 0)
			{
				return null;
			}
			if (closeLine == ClosePathRule.ALWAYS || closeLine == ClosePathRule.AUTO)
			{
				Array.Resize<StrokeSegment>(ref segments, segments.Length + 1);
				segments[segments.Length - 1] = new StrokeSegment(segments[segments.Length - 2].endPoint, segments[0].startPoint);
				closeLine = ClosePathRule.NEVER;
			}
			List<StrokeSegment[]> list = new List<StrokeSegment[]>();
			int num = dashArray.Length;
			int num2 = 0;
			int num3 = segments.Length;
			float num4 = dashOffset;
			List<StrokeSegment> list2 = new List<StrokeSegment>();
			int i = 0;
			while (i < num3)
			{
				if (num2 % 2 == 0)
				{
					float num5 = Mathf.Clamp(num4, 0f, segments[i].length);
					float num6 = Mathf.Clamp(num4 + dashArray[num2], 0f, segments[i].length);
					if (num6 - num5 > 0f)
					{
						list2.Add(new StrokeSegment(segments[i].startPoint + segments[i].directionNormalized * num5, segments[i].startPoint + segments[i].directionNormalized * num6));
					}
				}
				else if (list2.Count > 0)
				{
					list.Add(list2.ToArray());
					list2.Clear();
				}
				if (num4 + dashArray[num2] < segments[i].length)
				{
					num4 += dashArray[num2];
					num2 = (num2 + 1) % num;
				}
				else
				{
					num4 -= segments[i].length;
					i++;
				}
			}
			if (list2.Count > 0)
			{
				list.Add(list2.ToArray());
				list2.Clear();
			}
			return list;
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x000354C4 File Offset: 0x000336C4
		protected static void ProcessDashArray(ref float[] dashArray, out bool useDash)
		{
			useDash = (dashArray != null && dashArray.Length != 0);
			float num = 0f;
			if (useDash)
			{
				int num2 = dashArray.Length;
				if (num2 % 2 == 1)
				{
					Array.Resize<float>(ref dashArray, num2 * 2);
					int num3 = 0;
					for (int i = num2; i < dashArray.Length; i++)
					{
						dashArray[i] = dashArray[num3++];
					}
					num2 = dashArray.Length;
				}
				for (int i = 0; i < dashArray.Length; i++)
				{
					if (dashArray[i] < 0f)
					{
						dashArray[i] = 0f;
					}
					num += dashArray[i];
				}
			}
			if (num == 0f)
			{
				useDash = false;
			}
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x00035558 File Offset: 0x00033758
		public static void TesselateStroke(List<List<Vector2>> inputShapes, Color32 color, out List<List<Vector2>> simplifiedShapes, out Vector3[] vertices, out int[] triangles, out Color32[] colors32)
		{
			simplifiedShapes = null;
			vertices = null;
			triangles = null;
			colors32 = null;
			if (inputShapes == null || inputShapes.Count == 0)
			{
				return;
			}
			simplifiedShapes = new List<List<Vector2>>();
			PolyFillType polyFillType = PolyFillType.pftNonZero;
			for (int i = 0; i < inputShapes.Count; i++)
			{
				if (inputShapes[i] != null && inputShapes.Count != 0)
				{
					List<List<Vector2>> list = SVGGeom.SimplifyPolygon(inputShapes[i], polyFillType);
					if (list == null || list.Count == 0)
					{
						simplifiedShapes.Add(inputShapes[i]);
					}
					else
					{
						simplifiedShapes.AddRange(list);
					}
				}
			}
			Tess tess = new Tess();
			for (int i = 0; i < simplifiedShapes.Count; i++)
			{
				if (simplifiedShapes[i] != null && simplifiedShapes[i].Count >= 2)
				{
					ContourVertex[] array = new ContourVertex[simplifiedShapes[i].Count];
					for (int j = 0; j < simplifiedShapes[i].Count; j++)
					{
						array[j].Position = new Vec3
						{
							X = simplifiedShapes[i][j].x,
							Y = simplifiedShapes[i][j].y,
							Z = 0f
						};
					}
					tess.AddContour(array);
				}
			}
			tess.Tessellate(WindingRule.Positive, ElementType.Polygons, 3);
			if (tess.Vertices == null || tess.Vertices.Length == 0)
			{
				return;
			}
			int num = tess.Vertices.Length;
			int num2 = tess.ElementCount * 3;
			triangles = new int[num2];
			vertices = new Vector3[num];
			colors32 = new Color32[num];
			for (int i = 0; i < num; i++)
			{
				vertices[i] = new Vector3(tess.Vertices[i].Position.X, tess.Vertices[i].Position.Y, 0f);
				colors32[i] = color;
			}
			for (int i = 0; i < num2; i += 3)
			{
				triangles[i] = tess.Elements[i];
				triangles[i + 1] = tess.Elements[i + 1];
				triangles[i + 2] = tess.Elements[i + 2];
			}
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x00035788 File Offset: 0x00033988
		public static UnityEngine.Mesh TessellateStroke(List<List<Vector2>> inputShapes, Color32 color)
		{
			List<List<Vector2>> list;
			Vector3[] array;
			int[] triangles;
			Color32[] colors;
			SVGLineUtils.TesselateStroke(inputShapes, color, out list, out array, out triangles, out colors);
			if (array == null)
			{
				return null;
			}
			return new UnityEngine.Mesh
			{
				vertices = array,
				triangles = triangles,
				colors32 = colors
			};
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x000357C4 File Offset: 0x000339C4
		public static float DeltaAngleRad(float current, float target)
		{
			float num = Mathf.Repeat(target - current, 6.2831855f);
			if (num > 3.1415927f)
			{
				num -= 6.2831855f;
			}
			return num;
		}
	}
}
