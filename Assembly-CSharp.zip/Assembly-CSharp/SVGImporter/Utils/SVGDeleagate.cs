﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x0200010C RID: 268
	public static class SVGDeleagate
	{
		// Token: 0x0600089A RID: 2202 RVA: 0x00038994 File Offset: 0x00036B94
		public static bool IsRegistered(Delegate source, Action compare)
		{
			if (source == null || compare == null)
			{
				return false;
			}
			Delegate[] invocationList = source.GetInvocationList();
			if (invocationList == null || invocationList.Length == 0)
			{
				return false;
			}
			for (int i = 0; i < invocationList.Length; i++)
			{
				if (invocationList[i].Equals(compare))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x000389D8 File Offset: 0x00036BD8
		public static bool IsRegistered<T>(Delegate source, Action<T> compare)
		{
			if (source == null || compare == null)
			{
				return false;
			}
			Delegate[] invocationList = source.GetInvocationList();
			if (invocationList == null || invocationList.Length == 0)
			{
				return false;
			}
			for (int i = 0; i < invocationList.Length; i++)
			{
				if (invocationList[i].Equals(compare))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600089C RID: 2204 RVA: 0x00038A1C File Offset: 0x00036C1C
		public static bool IsRegistered<T1, T2>(Delegate source, Action<T1, T2> compare)
		{
			if (source == null || compare == null)
			{
				return false;
			}
			Delegate[] invocationList = source.GetInvocationList();
			if (invocationList == null || invocationList.Length == 0)
			{
				return false;
			}
			for (int i = 0; i < invocationList.Length; i++)
			{
				if (invocationList[i].Equals(compare))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600089D RID: 2205 RVA: 0x00038A60 File Offset: 0x00036C60
		public static bool IsRegistered<T1, T2, T3>(Delegate source, Action<T1, T2, T3> compare)
		{
			if (source == null || compare == null)
			{
				return false;
			}
			Delegate[] invocationList = source.GetInvocationList();
			if (invocationList == null || invocationList.Length == 0)
			{
				return false;
			}
			for (int i = 0; i < invocationList.Length; i++)
			{
				if (invocationList[i].Equals(compare))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600089E RID: 2206 RVA: 0x00038AA4 File Offset: 0x00036CA4
		public static bool IsRegistered<T1, T2, T3, T4>(Delegate source, Action<T1, T2, T3, T4> compare)
		{
			if (source == null || compare == null)
			{
				return false;
			}
			Delegate[] invocationList = source.GetInvocationList();
			if (invocationList == null || invocationList.Length == 0)
			{
				return false;
			}
			for (int i = 0; i < invocationList.Length; i++)
			{
				if (invocationList[i].Equals(compare))
				{
					return true;
				}
			}
			return false;
		}
	}
}
