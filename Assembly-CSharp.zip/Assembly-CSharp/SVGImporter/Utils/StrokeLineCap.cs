﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x02000101 RID: 257
	public enum StrokeLineCap
	{
		// Token: 0x0400080B RID: 2059
		butt,
		// Token: 0x0400080C RID: 2060
		round,
		// Token: 0x0400080D RID: 2061
		square
	}
}
