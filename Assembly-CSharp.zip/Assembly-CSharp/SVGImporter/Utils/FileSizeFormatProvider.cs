﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x02000109 RID: 265
	public class FileSizeFormatProvider : IFormatProvider, ICustomFormatter
	{
		// Token: 0x06000890 RID: 2192 RVA: 0x0003871D File Offset: 0x0003691D
		public object GetFormat(Type formatType)
		{
			if (formatType == typeof(ICustomFormatter))
			{
				return this;
			}
			return null;
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00038734 File Offset: 0x00036934
		public string Format(string format, object arg, IFormatProvider formatProvider)
		{
			if (format == null || !format.StartsWith("fs"))
			{
				return FileSizeFormatProvider.defaultFormat(format, arg, formatProvider);
			}
			if (arg is string)
			{
				return FileSizeFormatProvider.defaultFormat(format, arg, formatProvider);
			}
			decimal num;
			try
			{
				num = Convert.ToDecimal(arg);
			}
			catch (InvalidCastException)
			{
				return FileSizeFormatProvider.defaultFormat(format, arg, formatProvider);
			}
			string arg2;
			if (num > 1073741824m)
			{
				num /= 1073741824m;
				arg2 = "GB";
			}
			else if (num > 1048576m)
			{
				num /= 1048576m;
				arg2 = "MB";
			}
			else if (num > 1024m)
			{
				num /= 1024m;
				arg2 = "kB";
			}
			else
			{
				arg2 = " B";
			}
			string text = format.Substring(2);
			if (string.IsNullOrEmpty(text))
			{
				text = "2";
			}
			return string.Format("{0:N" + text + "}{1}", num, arg2);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x00038850 File Offset: 0x00036A50
		private static string defaultFormat(string format, object arg, IFormatProvider formatProvider)
		{
			IFormattable formattable = arg as IFormattable;
			if (formattable != null)
			{
				return formattable.ToString(format, formatProvider);
			}
			return arg.ToString();
		}

		// Token: 0x04000819 RID: 2073
		private const string fileSizeFormat = "fs";

		// Token: 0x0400081A RID: 2074
		private const decimal OneKiloByte = 1024m;

		// Token: 0x0400081B RID: 2075
		private const decimal OneMegaByte = 1048576m;

		// Token: 0x0400081C RID: 2076
		private const decimal OneGigaByte = 1073741824m;
	}
}
