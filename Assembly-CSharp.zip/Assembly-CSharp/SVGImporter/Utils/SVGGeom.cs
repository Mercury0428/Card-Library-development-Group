﻿using System;
using System.Collections.Generic;
using SVGImporter.ClipperLib;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000FB RID: 251
	public class SVGGeom
	{
		// Token: 0x060007FF RID: 2047 RVA: 0x00031DBC File Offset: 0x0002FFBC
		public static List<IntPoint> ConvertFloatToInt(List<Vector2> polygon)
		{
			int num = polygon.Count;
			if (num > 1 && polygon[0] == polygon[polygon.Count - 1])
			{
				num--;
			}
			List<IntPoint> list = new List<IntPoint>(num);
			for (int i = 0; i < num; i++)
			{
				list.Add(new IntPoint((long)((int)(polygon[i].x * 1000f)), (long)((int)(polygon[i].y * 1000f))));
			}
			return list;
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x00031E3C File Offset: 0x0003003C
		public static List<Vector2> ConvertIntToFloat(List<IntPoint> polygonInt)
		{
			int num = polygonInt.Count;
			if (num > 1 && polygonInt[0] == polygonInt[polygonInt.Count - 1])
			{
				num--;
			}
			List<Vector2> list = new List<Vector2>(num);
			for (int i = 0; i < num; i++)
			{
				list.Add(new Vector2((float)polygonInt[i].X * 0.001f, (float)polygonInt[i].Y * 0.001f));
			}
			return list;
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x00031EBC File Offset: 0x000300BC
		public static List<List<Vector2>> SimplifyPolygon(List<Vector2> polygon, PolyFillType polyFillType = PolyFillType.pftNonZero)
		{
			if (polygon == null || polygon.Count == 0)
			{
				return null;
			}
			List<List<IntPoint>> list = Clipper.SimplifyPolygon(SVGGeom.ConvertFloatToInt(polygon), polyFillType);
			int count = list.Count;
			List<List<Vector2>> list2 = new List<List<Vector2>>(count);
			for (int i = 0; i < count; i++)
			{
				list2.Add(SVGGeom.ConvertIntToFloat(list[i]));
			}
			if (list2 == null || list2.Count == 0)
			{
				return null;
			}
			return list2;
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x00031F20 File Offset: 0x00030120
		public static List<List<Vector2>> SimplifyPolygons(List<List<Vector2>> polygon, PolyFillType polyFillType = PolyFillType.pftNonZero)
		{
			if (polygon == null || polygon.Count == 0)
			{
				return null;
			}
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			for (int i = 0; i < polygon.Count; i++)
			{
				list.Add(SVGGeom.ConvertFloatToInt(polygon[i]));
			}
			list = Clipper.SimplifyPolygons(list, polyFillType);
			int count = list.Count;
			List<List<Vector2>> list2 = new List<List<Vector2>>(count);
			for (int i = 0; i < count; i++)
			{
				list2.Add(SVGGeom.ConvertIntToFloat(list[i]));
			}
			if (list2 == null || list2.Count == 0)
			{
				return null;
			}
			return list2;
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x00031FA8 File Offset: 0x000301A8
		public static List<List<Vector2>> MergePolygon(List<List<Vector2>> polygon)
		{
			if (polygon == null || polygon.Count == 0)
			{
				return null;
			}
			List<List<IntPoint>> list = new List<List<IntPoint>>
			{
				SVGGeom.ConvertFloatToInt(polygon[0])
			};
			for (int i = 1; i < polygon.Count; i++)
			{
				list = SVGGeom.MergePolygon(list, SVGGeom.ConvertFloatToInt(polygon[i]));
			}
			List<List<Vector2>> list2 = new List<List<Vector2>>();
			for (int j = 0; j < list.Count; j++)
			{
				list2.Add(SVGGeom.ConvertIntToFloat(list[j]));
			}
			return list2;
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x00032028 File Offset: 0x00030228
		public static List<List<IntPoint>> MergePolygon(List<List<IntPoint>> polygonA, List<IntPoint> polygonB)
		{
			Clipper clipper = new Clipper(0);
			clipper.AddPaths(polygonA, PolyType.ptSubject, true);
			clipper.AddPath(polygonB, PolyType.ptClip, true);
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			clipper.Execute(ClipType.ctUnion, list);
			return list;
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x00032060 File Offset: 0x00030260
		public static List<List<Vector2>> ClipPolygon(List<List<Vector2>> polygon, List<List<Vector2>> clipPath)
		{
			if (polygon == null || polygon.Count == 0)
			{
				return null;
			}
			if (clipPath == null || clipPath.Count == 0)
			{
				return polygon;
			}
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			List<List<IntPoint>> list2 = new List<List<IntPoint>>();
			for (int i = 0; i < polygon.Count; i++)
			{
				list.Add(SVGGeom.ConvertFloatToInt(polygon[i]));
			}
			for (int i = 0; i < clipPath.Count; i++)
			{
				list2.Add(SVGGeom.ConvertFloatToInt(clipPath[i]));
			}
			list = SVGGeom.ClipPolygon(list, list2);
			int count = list.Count;
			List<List<Vector2>> list3 = new List<List<Vector2>>(count);
			for (int i = 0; i < count; i++)
			{
				list3.Add(SVGGeom.ConvertIntToFloat(list[i]));
			}
			if (list3 == null || list3.Count == 0)
			{
				return null;
			}
			return list3;
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x00032120 File Offset: 0x00030320
		public static List<List<IntPoint>> ClipPolygon(List<IntPoint> polygon, List<IntPoint> clipPath)
		{
			Clipper clipper = new Clipper(0);
			clipper.AddPath(polygon, PolyType.ptSubject, true);
			clipper.AddPath(clipPath, PolyType.ptClip, true);
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			clipper.Execute(ClipType.ctIntersection, list);
			return list;
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x00032158 File Offset: 0x00030358
		public static List<List<IntPoint>> ClipPolygon(List<List<IntPoint>> polygons, List<IntPoint> clipPath)
		{
			Clipper clipper = new Clipper(0);
			clipper.AddPaths(polygons, PolyType.ptSubject, true);
			clipper.AddPath(clipPath, PolyType.ptClip, true);
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			clipper.Execute(ClipType.ctIntersection, list);
			return list;
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00032190 File Offset: 0x00030390
		public static List<List<IntPoint>> ClipPolygon(List<List<IntPoint>> polygons, List<List<IntPoint>> clipPaths)
		{
			Clipper clipper = new Clipper(0);
			clipper.AddPaths(polygons, PolyType.ptSubject, true);
			clipper.AddPaths(clipPaths, PolyType.ptClip, true);
			List<List<IntPoint>> list = new List<List<IntPoint>>();
			clipper.Execute(ClipType.ctIntersection, list);
			return list;
		}

		// Token: 0x040007FD RID: 2045
		private const int decimalPointInt = 1000;

		// Token: 0x040007FE RID: 2046
		private const float decimalPointFloat = 0.001f;
	}
}
