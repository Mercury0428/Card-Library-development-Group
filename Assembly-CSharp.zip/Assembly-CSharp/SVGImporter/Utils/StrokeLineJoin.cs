﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x02000100 RID: 256
	public enum StrokeLineJoin
	{
		// Token: 0x04000806 RID: 2054
		miter,
		// Token: 0x04000807 RID: 2055
		miterClip,
		// Token: 0x04000808 RID: 2056
		round,
		// Token: 0x04000809 RID: 2057
		bevel
	}
}
