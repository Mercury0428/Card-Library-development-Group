﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x0200010B RID: 267
	public static class SVGPropertyUtility
	{
		// Token: 0x06000897 RID: 2199 RVA: 0x000388D4 File Offset: 0x00036AD4
		public static bool SetColor(ref Color currentValue, Color newValue)
		{
			if (currentValue.r == newValue.r && currentValue.g == newValue.g && currentValue.b == newValue.b && currentValue.a == newValue.a)
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x00038923 File Offset: 0x00036B23
		public static bool SetStruct<T>(ref T currentValue, T newValue) where T : struct
		{
			if (currentValue.Equals(newValue))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00038944 File Offset: 0x00036B44
		public static bool SetClass<T>(ref T currentValue, T newValue) where T : class
		{
			if ((currentValue == null && newValue == null) || (currentValue != null && currentValue.Equals(newValue)))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}
	}
}
