﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x02000104 RID: 260
	public class Edge
	{
		// Token: 0x04000814 RID: 2068
		public int[] vertexIndex = new int[2];

		// Token: 0x04000815 RID: 2069
		public int[] faceIndex = new int[2];
	}
}
