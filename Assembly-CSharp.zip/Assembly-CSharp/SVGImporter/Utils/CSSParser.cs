﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SVGImporter.Utils
{
	// Token: 0x020000EF RID: 239
	public class CSSParser
	{
		// Token: 0x060007A1 RID: 1953 RVA: 0x0002EE9E File Offset: 0x0002D09E
		public static CSSSelector GetSelector(string value)
		{
			if (string.IsNullOrEmpty(value))
			{
				return CSSSelector.None;
			}
			if (value[0] == '.')
			{
				return CSSSelector.Class;
			}
			if (value[0] == '#')
			{
				return CSSSelector.Id;
			}
			return CSSSelector.Element;
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x0002EEC5 File Offset: 0x0002D0C5
		public static string CleanCSS(string cssString)
		{
			cssString = Regex.Replace(cssString, "/\\*.+?\\*/", string.Empty, RegexOptions.Singleline);
			cssString = Regex.Replace(cssString, "\\s+", "");
			return cssString;
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x0002EEF0 File Offset: 0x0002D0F0
		public static Dictionary<string, Dictionary<string, string>> Parse(string value)
		{
			if (string.IsNullOrEmpty(value))
			{
				return null;
			}
			string[] array = value.Split(new char[]
			{
				'}'
			});
			Dictionary<string, Dictionary<string, string>> dictionary = new Dictionary<string, Dictionary<string, string>>();
			for (int i = 0; i < array.Length; i++)
			{
				if (!string.IsNullOrEmpty(array[i]))
				{
					string[] array2 = array[i].Split(new char[]
					{
						'{'
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array2 != null && array2.Length == 2)
					{
						Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
						string[] array3 = array2[1].Split(new char[]
						{
							';'
						}, StringSplitOptions.RemoveEmptyEntries);
						int num = array3.Length;
						for (int j = 0; j < num; j++)
						{
							if (!string.IsNullOrEmpty(array3[j]))
							{
								string[] array4 = array3[j].Split(new char[]
								{
									':'
								}, StringSplitOptions.RemoveEmptyEntries);
								if (array4 != null && array4.Length == 2)
								{
									if (dictionary2.ContainsKey(array4[0]))
									{
										dictionary2[array4[0]] = array4[1];
									}
									else
									{
										dictionary2.Add(array4[0], array4[1]);
									}
								}
							}
						}
						if (dictionary2.Count != 0)
						{
							string[] array5 = array2[0].Split(new char[]
							{
								','
							});
							for (int j = 0; j < array5.Length; j++)
							{
								if (!string.IsNullOrEmpty(array5[j]))
								{
									if (dictionary.ContainsKey(array5[j]))
									{
										dictionary[array5[j]] = dictionary2;
									}
									else
									{
										dictionary.Add(array5[j], dictionary2);
									}
								}
							}
						}
					}
				}
			}
			if (dictionary.Count == 0)
			{
				return null;
			}
			return dictionary;
		}

		// Token: 0x040007C7 RID: 1991
		private const char elementStartChar = '{';

		// Token: 0x040007C8 RID: 1992
		private const char elementEndChar = '}';

		// Token: 0x040007C9 RID: 1993
		private const char elementSplitChar = ',';

		// Token: 0x040007CA RID: 1994
		private const char attributeStartChar = ':';

		// Token: 0x040007CB RID: 1995
		private const char attributeEndChar = ';';
	}
}
