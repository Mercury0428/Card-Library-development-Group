﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;

namespace SVGImporter.Utils
{
	// Token: 0x020000F8 RID: 248
	public static class SVGStringExtractor
	{
		// Token: 0x060007C2 RID: 1986 RVA: 0x000308D0 File Offset: 0x0002EAD0
		public static List<SVGTransform> ExtractTransformList(string inputText)
		{
			List<SVGTransform> list = new List<SVGTransform>();
			string[] array = inputText.Split(SVGStringExtractor.splitPipe, StringSplitOptions.RemoveEmptyEntries);
			int num = array.Length;
			for (int i = 0; i < num; i++)
			{
				if (!string.IsNullOrEmpty(array[i]))
				{
					int num2 = array[i].IndexOf('(');
					if (num2 > 0)
					{
						string text = array[i].Substring(0, num2).Trim();
						string strValue = array[i].Substring(num2 + 1).Trim();
						if (!string.IsNullOrEmpty(text))
						{
							list.Add(new SVGTransform(text, strValue));
						}
					}
				}
			}
			return list;
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x0003095C File Offset: 0x0002EB5C
		public static float[] ExtractTransformValueAsPX(string inputText)
		{
			string[] array = SVGStringExtractor.ExtractTransformValue(inputText);
			float[] array2 = new float[array.Length];
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i] = SVGLength.GetPXLength(array[i]);
			}
			return array2;
		}

		// Token: 0x060007C4 RID: 1988 RVA: 0x00030994 File Offset: 0x0002EB94
		public static string[] ExtractTransformValue(string inputText)
		{
			if (inputText.Length > 1)
			{
				for (int i = 1; i < inputText.Length; i++)
				{
					if (inputText[i] == '-' && inputText[i - 1] != 'e')
					{
						inputText = inputText.Insert(i++, " ");
					}
				}
			}
			char[] array = new char[]
			{
				'.'
			};
			List<string> list = new List<string>(inputText.Split(SVGStringExtractor.splitSpaceComma, StringSplitOptions.RemoveEmptyEntries));
			for (int j = 0; j < list.Count; j++)
			{
				if (list[j][0] == array[0])
				{
					list[j] = list[j].Insert(0, "0");
				}
				string[] array2 = list[j].Split(array, StringSplitOptions.RemoveEmptyEntries);
				int num = array2.Length;
				if (num > 2)
				{
					list[j] = array2[0] + "." + array2[1];
					for (int k = 2; k < num; k++)
					{
						list.Insert(++j, "0." + array2[k]);
					}
				}
			}
			return list.ToArray();
		}

		// Token: 0x060007C5 RID: 1989 RVA: 0x00030AAC File Offset: 0x0002ECAC
		public static void ExtractPathSegList(string inputText, ref List<char> charList, ref List<string> valueList)
		{
			SVGStringExtractor._break.Clear();
			for (int i = 0; i < inputText.Length; i++)
			{
				if (SVGStringExtractor.pathCommands.IndexOf(inputText[i]) >= 0)
				{
					SVGStringExtractor._break.Add(i);
				}
			}
			SVGStringExtractor._break.Add(inputText.Length);
			charList.Capacity = SVGStringExtractor._break.Count - 1;
			valueList.Capacity = SVGStringExtractor._break.Count - 1;
			for (int j = 0; j < SVGStringExtractor._break.Count - 1; j++)
			{
				int num = SVGStringExtractor._break[j];
				int num2 = SVGStringExtractor._break[j + 1];
				string item = inputText.Substring(num + 1, num2 - num - 1);
				charList.Add(inputText[num]);
				valueList.Add(item);
			}
		}

		// Token: 0x060007C6 RID: 1990 RVA: 0x00030B81 File Offset: 0x0002ED81
		public static string[] ExtractStringArray(string inputText)
		{
			return inputText.Split(SVGStringExtractor.splitSpaceComma, StringSplitOptions.RemoveEmptyEntries);
		}

		// Token: 0x060007C7 RID: 1991 RVA: 0x00030B90 File Offset: 0x0002ED90
		public static void ExtractStyleValue(string inputText, ref Dictionary<string, string> dic)
		{
			string[] array = inputText.Split(SVGStringExtractor.splitColonSemicolon, StringSplitOptions.RemoveEmptyEntries);
			int num = array.Length - 1;
			for (int i = 0; i < num; i += 2)
			{
				dic.Add(array[i], array[i + 1]);
			}
		}

		// Token: 0x060007C8 RID: 1992 RVA: 0x00030BCC File Offset: 0x0002EDCC
		public static string ExtractUrl(string inputText)
		{
			inputText = inputText.Replace('\n', ' ').Replace('\t', ' ').Replace('\r', ' ').Replace(" ", "");
			int num = inputText.IndexOf("url(#");
			int num2 = inputText.IndexOf(")");
			if (num2 < 0)
			{
				num2 = inputText.Length;
			}
			return inputText.Substring(num + 5, num2 - num - 5);
		}

		// Token: 0x040007E5 RID: 2021
		public static string pathCommands = "ZzMmLlCcSsQqTtAaHhVv";

		// Token: 0x040007E6 RID: 2022
		private static char[] splitPipe = new char[]
		{
			')'
		};

		// Token: 0x040007E7 RID: 2023
		public static char[] splitSpaceComma = new char[]
		{
			' ',
			',',
			'\n',
			'\t',
			'\r'
		};

		// Token: 0x040007E8 RID: 2024
		private static List<int> _break = new List<int>();

		// Token: 0x040007E9 RID: 2025
		private static char[] splitColonSemicolon = new char[]
		{
			':',
			';',
			' ',
			'\n',
			'\t',
			'\r'
		};
	}
}
