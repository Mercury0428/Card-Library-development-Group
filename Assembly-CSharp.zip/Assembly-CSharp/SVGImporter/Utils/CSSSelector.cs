﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000EE RID: 238
	public enum CSSSelector
	{
		// Token: 0x040007C3 RID: 1987
		None,
		// Token: 0x040007C4 RID: 1988
		Element,
		// Token: 0x040007C5 RID: 1989
		Id,
		// Token: 0x040007C6 RID: 1990
		Class
	}
}
