﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000105 RID: 261
	public class SVGMeshUtils
	{
		// Token: 0x06000859 RID: 2137 RVA: 0x00035810 File Offset: 0x00033A10
		public static Mesh Quad()
		{
			return SVGMeshUtils.Quad(new Vector2(1f, 1f));
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x00035826 File Offset: 0x00033A26
		public static Mesh Quad(float size)
		{
			return SVGMeshUtils.Quad(new Vector2(size, size));
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x00035834 File Offset: 0x00033A34
		public static Mesh Quad(Vector2 size)
		{
			Mesh mesh = new Mesh();
			Vector3[] array = new Vector3[4];
			int[] array2 = new int[6];
			Vector2[] array3 = new Vector2[4];
			Color32[] array4 = new Color32[4];
			array[0] = new Vector3(-size.x, size.y, 0f);
			array[1] = new Vector3(size.x, size.y, 0f);
			array[2] = new Vector3(-size.x, -size.y, 0f);
			array[3] = new Vector3(size.x, -size.y, 0f);
			array2[0] = 0;
			array2[1] = 1;
			array2[2] = 2;
			array2[3] = 1;
			array2[4] = 3;
			array2[5] = 2;
			array3[0] = new Vector2(0f, 1f);
			array3[1] = new Vector2(1f, 1f);
			array3[2] = new Vector2(0f, 0f);
			array3[3] = new Vector2(1f, 0f);
			array4[0] = Color.black;
			array4[1] = Color.black;
			array4[2] = Color.black;
			array4[3] = Color.black;
			mesh.vertices = array;
			mesh.triangles = array2;
			mesh.uv = array3;
			mesh.colors32 = array4;
			mesh.RecalculateNormals();
			mesh.RecalculateBounds();
			return mesh;
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x000359B6 File Offset: 0x00033BB6
		public static Mesh Quad(Vector2 size, int hSegments, int vSegments)
		{
			return SVGMeshUtils.Quad(size, hSegments, vSegments, Vector3.zero);
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x000359C8 File Offset: 0x00033BC8
		public static Mesh Quad(Vector2 size, int hSegments, int vSegments, Vector3 anchorOffset, Color32 color)
		{
			Mesh mesh = new Mesh();
			if (hSegments < 1)
			{
				hSegments = 1;
			}
			if (vSegments < 1)
			{
				vSegments = 1;
			}
			int num = hSegments;
			int num2 = vSegments;
			int num3 = num + 1;
			int num4 = num2 + 1;
			int num5 = num * num2 * 6;
			int num6 = num3 * num4;
			Vector3[] array = new Vector3[num6];
			Vector2[] array2 = new Vector2[num6];
			Color32[] array3 = new Color32[num6];
			int[] array4 = new int[num5];
			int num7 = 0;
			float num8 = 1f / (float)num;
			float num9 = 1f / (float)num2;
			float num10 = size.x / (float)num;
			float num11 = size.y / (float)num2;
			for (float num12 = 0f; num12 < (float)num4; num12 += 1f)
			{
				for (float num13 = 0f; num13 < (float)num3; num13 += 1f)
				{
					array[num7] = new Vector3(num13 * num10 - size.x / 2f + anchorOffset.x, num12 * num11 - size.y / 2f + anchorOffset.y, anchorOffset.z);
					array3[num7] = color;
					array2[num7++] = new Vector2(num13 * num8, num12 * num9);
				}
			}
			num7 = 0;
			for (int i = 0; i < num2; i++)
			{
				for (int j = 0; j < num; j++)
				{
					array4[num7] = i * num3 + j;
					array4[num7 + 1] = (i + 1) * num3 + j;
					array4[num7 + 2] = i * num3 + j + 1;
					array4[num7 + 3] = (i + 1) * num3 + j;
					array4[num7 + 4] = (i + 1) * num3 + j + 1;
					array4[num7 + 5] = i * num3 + j + 1;
					num7 += 6;
				}
			}
			mesh.vertices = array;
			mesh.uv = array2;
			mesh.colors32 = array3;
			mesh.triangles = array4;
			mesh.RecalculateNormals();
			mesh.RecalculateBounds();
			return mesh;
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00035BA5 File Offset: 0x00033DA5
		public static Mesh Quad(Vector2 size, int hSegments, int vSegments, Vector3 anchorOffset)
		{
			return SVGMeshUtils.Quad(size, hSegments, vSegments, anchorOffset, Color.white);
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00035BBC File Offset: 0x00033DBC
		public static Mesh Circle(int circuitSegments, Matrix4x4 meshTransform, Matrix4x4 uvTransform)
		{
			circuitSegments = Mathf.Clamp(circuitSegments, 4, int.MaxValue) + 1;
			int num = circuitSegments - 1;
			Mesh mesh = new Mesh();
			int num2 = circuitSegments + 1;
			int num3 = circuitSegments * 3;
			Vector3[] array = new Vector3[num2];
			Vector2[] array2 = new Vector2[num2];
			int[] array3 = new int[num3];
			Vector2 vector;
			for (int i = 0; i < circuitSegments; i++)
			{
				float num4 = (float)i / (float)num;
				float x = Mathf.Cos(num4 * 6.2831855f) * 0.5f;
				float y = Mathf.Sin(num4 * 6.2831855f) * 0.5f;
				array[i].x = x;
				array[i].y = y;
				array[i] = meshTransform.MultiplyPoint(array[i]);
				array[i].z = 0f;
				vector.x = x;
				vector.y = y;
				vector = uvTransform.MultiplyPoint(vector);
				array2[i].x = vector.x + 0.5f;
				array2[i].y = vector.y + 0.5f;
			}
			array[circuitSegments] = meshTransform.MultiplyPoint(array[circuitSegments]);
			vector.x = (vector.y = 0f);
			vector = uvTransform.MultiplyPoint(vector);
			array2[circuitSegments].x = vector.x + 0.5f;
			array2[circuitSegments].y = vector.y + 0.5f;
			int num5 = 0;
			for (int j = 0; j < num3; j += 3)
			{
				array3[j] = num5;
				array3[j + 2] = num5 + 1;
				array3[j + 1] = circuitSegments;
				num5++;
			}
			mesh.vertices = array;
			mesh.uv = array2;
			mesh.triangles = array3;
			mesh.RecalculateBounds();
			return mesh;
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00035DB0 File Offset: 0x00033FB0
		public static Mesh Rectangle(Matrix4x4 meshTransform, Matrix4x4 uvTransform)
		{
			Mesh mesh = new Mesh();
			Vector3[] array = new Vector3[4];
			int[] array2 = new int[6];
			Vector2[] array3 = new Vector2[4];
			array[0].x = -0.5f;
			array[0].y = 0.5f;
			array[0] = meshTransform.MultiplyPoint(array[0]);
			array[0].z = 0f;
			array[1].x = 0.5f;
			array[1].y = 0.5f;
			array[1] = meshTransform.MultiplyPoint(array[1]);
			array[1].z = 0f;
			array[2].x = -0.5f;
			array[2].y = -0.5f;
			array[2] = meshTransform.MultiplyPoint(array[2]);
			array[2].z = 0f;
			array[3].x = 0.5f;
			array[3].y = -0.5f;
			array[3] = meshTransform.MultiplyPoint(array[3]);
			array[3].z = 0f;
			array2[0] = 0;
			array2[1] = 1;
			array2[2] = 2;
			array2[3] = 1;
			array2[4] = 3;
			array2[5] = 2;
			array3[0].x = -0.5f;
			array3[0].y = 0.5f;
			Vector2 vector = uvTransform.MultiplyPoint(new Vector3(array3[0].x, array3[0].y, 0f));
			array3[0].x = vector.x + 0.5f;
			array3[0].y = vector.y + 0.5f;
			array3[1].x = 0.5f;
			array3[1].y = 0.5f;
			vector = uvTransform.MultiplyPoint(new Vector3(array3[1].x, array3[1].y, 0f));
			array3[1].x = vector.x + 0.5f;
			array3[1].y = vector.y + 0.5f;
			array3[2].x = -0.5f;
			array3[2].y = -0.5f;
			vector = uvTransform.MultiplyPoint(new Vector3(array3[2].x, array3[2].y, 0f));
			array3[2].x = vector.x + 0.5f;
			array3[2].y = vector.y + 0.5f;
			array3[3].x = 0.5f;
			array3[3].y = -0.5f;
			vector = uvTransform.MultiplyPoint(new Vector3(array3[3].x, array3[3].y, 0f));
			array3[3].x = vector.x + 0.5f;
			array3[3].y = vector.y + 0.5f;
			mesh.vertices = array;
			mesh.triangles = array2;
			mesh.uv = array3;
			mesh.RecalculateBounds();
			return mesh;
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x0003612E File Offset: 0x0003432E
		public static Mesh Rectangle()
		{
			return SVGMeshUtils.Rectangle(Matrix4x4.identity, Matrix4x4.identity);
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x0003613F File Offset: 0x0003433F
		public static Mesh Line(int tessellation, Vector3[] positions, Color32 color, float size = 1f, bool closeLine = false)
		{
			return SVGMeshUtils.Line(tessellation, positions, SVGArrayUtils.CreatePreinitializedArray<Color32>(color, positions.Length), SVGArrayUtils.CreatePreinitializedArray<float>(size, positions.Length), null, closeLine);
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00036160 File Offset: 0x00034360
		public static Mesh Line(int tessellation, Vector2[] positions, Color32 color, float size = 1f, bool closeLine = false)
		{
			Vector3[] array = new Vector3[positions.Length];
			for (int i = 0; i < positions.Length; i++)
			{
				array[i].x = positions[i].x;
				array[i].y = positions[i].y;
			}
			return SVGMeshUtils.Line(tessellation, array, SVGArrayUtils.CreatePreinitializedArray<Color32>(color, positions.Length), SVGArrayUtils.CreatePreinitializedArray<float>(size, positions.Length), null, closeLine);
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x000361D0 File Offset: 0x000343D0
		public static Mesh Line(int tessellation, Vector2[] positions, Color32[] colors = null, float[] sizes = null, Vector3[] rotations = null, bool closeLine = false)
		{
			Vector3[] array = new Vector3[positions.Length];
			for (int i = 0; i < positions.Length; i++)
			{
				array[i].x = positions[i].x;
				array[i].y = positions[i].y;
			}
			return SVGMeshUtils.Line(tessellation, array, colors, sizes, rotations, closeLine);
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00036231 File Offset: 0x00034431
		public static void ResetLineSettings()
		{
			SVGMeshUtils.lineUVScale = Vector2.one;
			SVGMeshUtils.lineUVOffset = Vector2.zero;
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x00036248 File Offset: 0x00034448
		public static Mesh Line(int tessellation, Vector3[] positions, Color32[] colors = null, float[] sizes = null, Vector3[] rotations = null, bool closeLine = false)
		{
			if (positions == null)
			{
				SVGMeshUtils.ResetLineSettings();
				return null;
			}
			if (positions.Length < 2)
			{
				SVGMeshUtils.ResetLineSettings();
				return null;
			}
			if (tessellation < 1)
			{
				tessellation = 1;
			}
			int num = tessellation * 2;
			int num2 = positions.Length * num;
			int num3 = positions.Length;
			int num4 = (num3 - 1) * (num - 1) * 6;
			bool flag = colors != null && colors.Length == num3;
			bool flag2 = rotations != null && rotations.Length == num3;
			Vector3[] array = new Vector3[num2];
			int[] array2 = new int[num4];
			Color32[] array3 = null;
			if (flag)
			{
				array3 = new Color32[num2];
			}
			if (sizes == null)
			{
				sizes = SVGArrayUtils.CreatePreinitializedArray<float>(1f, num2);
			}
			Vector2[] array4 = new Vector2[num2];
			Vector3[] array5 = new Vector3[num3];
			float[] array6 = new float[num3];
			Vector3 vector = positions[0];
			Vector3 a = positions[0];
			float num5 = 0f;
			float num6 = 0f;
			Color32 color = Color.white;
			for (int i = 0; i < num3; i++)
			{
				array5[i].x = positions[i].x - vector.x;
				array5[i].y = positions[i].y - vector.y;
				array5[i].z = positions[i].z - vector.z;
				array6[i] = Mathf.Sqrt(array5[i].x * array5[i].x + array5[i].y * array5[i].y + array5[i].z * array5[i].z);
				if (array6[i] != 0f)
				{
					Vector3[] array7 = array5;
					int num7 = i;
					array7[num7].x = array7[num7].x / array6[i];
					Vector3[] array8 = array5;
					int num8 = i;
					array8[num8].y = array8[num8].y / array6[i];
					Vector3[] array9 = array5;
					int num9 = i;
					array9[num9].z = array9[num9].z / array6[i];
				}
				if (flag2)
				{
					Vector3[] array10 = array5;
					int num10 = i;
					array10[num10].x = array10[num10].x + rotations[i].x;
					Vector3[] array11 = array5;
					int num11 = i;
					array11[num11].y = array11[num11].y + rotations[i].y;
					Vector3[] array12 = array5;
					int num12 = i;
					array12[num12].z = array12[num12].z + rotations[i].z;
				}
				num6 += array6[i];
				vector = positions[i];
			}
			array5[0] = (positions[1] - positions[0]).normalized;
			if (flag2)
			{
				array5[0] += rotations[0];
			}
			vector = positions[0];
			int num13 = 0;
			Vector3 b = Vector3.Cross(array5[0], Vector3.forward);
			int num14 = array5.Length - 1;
			for (int i = 0; i < num2; i += num)
			{
				int num15 = i / num;
				a = positions[num15];
				float d = sizes[num15] * 0.5f;
				if (flag)
				{
					color = colors[num15];
				}
				Vector3 vector2 = Vector3.Cross(array5[num15], Vector3.forward);
				if (num15 < num14)
				{
					b = Vector3.Cross(array5[num15 + 1], Vector3.forward);
				}
				num5 += array6[num15] / num6;
				for (int j = 0; j < num; j++)
				{
					int num16 = i + j;
					float num17 = (float)j / (float)(num - 1);
					array[num16] = a + Vector3.Lerp(vector2, b, 0.5f).normalized * (-1f + num17 * 2f) * d;
					if (flag)
					{
						array3[num16] = color;
					}
					array4[num16].x = num17 * SVGMeshUtils.lineUVScale.x + SVGMeshUtils.lineUVOffset.x;
					array4[num16].y = num5 * SVGMeshUtils.lineUVScale.y + SVGMeshUtils.lineUVOffset.y;
					if (i != 0 && j != 0)
					{
						array2[num13] = num16 - num - 1;
						array2[num13 + 1] = num16 - 1;
						array2[num13 + 2] = num16;
						array2[num13 + 3] = num16 - num - 1;
						array2[num13 + 4] = num16;
						array2[num13 + 5] = num16 - num;
						num13 += 6;
					}
				}
				b = vector2;
			}
			if (closeLine)
			{
				float d = Mathf.Lerp(sizes[0], sizes[num3 - 1], 0.5f) * 0.5f;
				Vector3 a2 = Vector3.Cross(Vector3.Lerp(array5[0], array5[num3 - 1], 0.5f).normalized, Vector3.forward);
				Vector3 a3 = Vector3.Lerp(positions[0], positions[num3 - 1], 0.5f);
				Vector3 a4 = a3 - a2 * d;
				Vector3 b2 = a3 + a2 * d;
				float num18 = (float)(num - 1);
				for (int i = 0; i < num; i++)
				{
					float t = (float)i / num18;
					int num19 = num2 - num + i;
					int num20 = i;
					array[num19] = (array[num20] = Vector3.Lerp(a4, b2, t));
					if (flag)
					{
						array3[num19] = (array3[num20] = Color32.Lerp(array3[num19], array3[num20], 0.5f));
					}
				}
			}
			else
			{
				float d = sizes[num3 - 1] * 0.5f;
				Vector3 a5 = Vector3.Cross(array5[num3 - 1], Vector3.forward);
				Vector3 a6 = positions[num3 - 1];
				Vector3 a7 = a6 - a5 * d;
				Vector3 b3 = a6 + a5 * d;
				float num21 = (float)(num - 1);
				for (int i = 0; i < num; i++)
				{
					float t2 = (float)i / num21;
					int num22 = num2 - num + i;
					array[num22] = Vector3.Lerp(a7, b3, t2);
					if (flag)
					{
						array3[num22] = array3[num22];
					}
				}
			}
			Mesh mesh = new Mesh();
			mesh.vertices = array;
			mesh.triangles = array2;
			mesh.uv = array4;
			if (flag)
			{
				mesh.colors32 = array3;
			}
			SVGMeshUtils.ResetLineSettings();
			return mesh;
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x000368C4 File Offset: 0x00034AC4
		public static bool VectorLine(Vector2[] positions, out SVGShape svgLayer, Color32 colorA, Color32 colorB, float size, float offset, ClosePathRule closeLine = ClosePathRule.NEVER)
		{
			svgLayer = default(SVGShape);
			if (positions == null)
			{
				return false;
			}
			if (positions.Length < 2)
			{
				return false;
			}
			if (positions.Length == 2)
			{
				closeLine = ClosePathRule.NEVER;
			}
			else if (closeLine == ClosePathRule.AUTO && positions[0] == positions[positions.Length - 1])
			{
				closeLine = ClosePathRule.ALWAYS;
			}
			SVGLineData svglineData = new SVGLineData(positions);
			svglineData.UpdateAll();
			size *= 0.5f;
			int capacity = positions.Length * 2;
			int capacity2 = (positions.Length - 1) * 6;
			int num = 0;
			List<Vector2> list = new List<Vector2>(capacity);
			List<int> list2 = new List<int>(capacity2);
			List<Color32> list3 = new List<Color32>(capacity);
			List<Vector2> list4 = new List<Vector2>(capacity);
			int edgeCount = svglineData.GetEdgeCount();
			int index = edgeCount - 1;
			float num2 = size;
			int i;
			for (i = 0; i <= edgeCount; i++)
			{
				Vector2 vector = positions[i];
				Vector2 a;
				Vector2 a2;
				Vector2 a3;
				Vector2 vector2;
				if (i == 0)
				{
					a = positions[0];
					a2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(0));
					a3 = positions[1];
					vector2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(0));
				}
				else if (i == edgeCount)
				{
					a = positions[i - 1];
					a2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(i - 1));
					if (closeLine == ClosePathRule.ALWAYS)
					{
						a3 = positions[0];
						vector2 = SVGMath.RotateVectorClockwise((positions[positions.Length - 1] - positions[0]).normalized);
					}
					else
					{
						a3 = positions[positions.Length - 1];
						vector2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(index));
					}
				}
				else
				{
					a = positions[i - 1];
					a2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(i - 1));
					vector2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(i));
					a3 = positions[i + 1];
				}
				Vector2 line1Start = a + a2 * num2 + a2 * offset;
				Vector2 vector3 = vector + a2 * num2 + a2 * offset;
				Vector2 vector4 = vector + vector2 * num2 + vector2 * offset;
				Vector2 line2End = a3 + vector2 * num2 + vector2 * offset;
				Vector2 vector5;
				if (i == 0)
				{
					Vector2[] array = new Vector2[]
					{
						vector + a2 * -num2 + a2 * offset,
						vector + a2 * num2 + a2 * offset
					};
					list.AddRange(array);
					list3.AddRange(new Color32[]
					{
						colorA,
						colorB
					});
					list4.AddRange(new Vector2[]
					{
						Vector2.zero,
						array[1] - array[0]
					});
					num += 2;
				}
				else if (!SVGMath.LineLineIntersection(out vector5, line1Start, vector3, vector4, line2End))
				{
					Vector2 normalized = Vector2.Lerp(a2, vector2, 0.5f).normalized;
					Vector2 b = normalized * offset;
					if (i == edgeCount && closeLine != ClosePathRule.ALWAYS)
					{
						Vector2[] collection = new Vector2[]
						{
							vector3,
							vector + normalized * -num2 + b
						};
						list.AddRange(collection);
						list3.AddRange(new Color32[]
						{
							colorB,
							colorA
						});
						list4.AddRange(new Vector2[]
						{
							Vector2.zero,
							Vector2.zero
						});
						num += 2;
						list2.AddRange(new int[]
						{
							num - 4,
							num - 2,
							num - 1,
							num - 2,
							num - 4,
							num - 3
						});
					}
					else
					{
						Vector2[] array2 = new Vector2[]
						{
							vector3,
							vector + normalized * -num2 + b,
							vector4
						};
						list.AddRange(array2);
						list3.AddRange(new Color32[]
						{
							colorB,
							colorA,
							colorB
						});
						list4.AddRange(new Vector2[]
						{
							array2[0] - vector,
							Vector2.zero,
							array2[2] - vector
						});
						num += 3;
						list2.AddRange(new int[]
						{
							num - 3,
							num - 2,
							num - 5,
							num - 5,
							num - 4,
							num - 3,
							num - 1,
							num - 2,
							num - 3
						});
					}
				}
				else
				{
					Vector2 normalized = Vector2.Lerp(a2, vector2, 0.5f).normalized;
					Vector2 b = normalized * offset;
					Vector2[] array3 = new Vector2[]
					{
						vector + normalized * -num2 + b,
						vector5
					};
					list.AddRange(array3);
					list3.AddRange(new Color32[]
					{
						colorA,
						colorB
					});
					list4.AddRange(new Vector2[]
					{
						Vector2.zero,
						array3[1] - array3[0]
					});
					num += 2;
					list2.AddRange(new int[]
					{
						num - 4,
						num - 2,
						num - 1,
						num - 4,
						num - 1,
						num - 3
					});
				}
			}
			if (closeLine == ClosePathRule.ALWAYS)
			{
				Vector2 a = positions[positions.Length - 1];
				Vector2 vector = positions[0];
				Vector2 a3 = positions[1];
				Vector2 a2 = SVGMath.RotateVectorClockwise((a - vector).normalized);
				Vector2 vector2 = SVGMath.RotateVectorClockwise(svglineData.GetNormal(0));
				Vector2 line1Start2 = a + a2 * num2 + a2 * offset;
				Vector2 vector6 = vector + a2 * num2 + a2 * offset;
				Vector2 vector7 = vector + vector2 * num2 + vector2 * offset;
				Vector2 line2End2 = a3 + vector2 * num2 + vector2 * offset;
				Vector2 vector5;
				if (!SVGMath.LineLineIntersection(out vector5, line1Start2, vector6, vector7, line2End2))
				{
					Vector2 normalized = Vector2.Lerp(a2, vector2, 0.5f).normalized;
					Vector2 b = normalized * offset;
					Vector2[] array4 = new Vector2[]
					{
						vector6,
						vector + normalized * -num2 + b,
						vector7
					};
					list.AddRange(array4);
					list3.AddRange(new Color32[]
					{
						colorB,
						colorA,
						colorB
					});
					list4.AddRange(new Vector2[]
					{
						array4[0] - array4[1],
						Vector2.zero,
						array4[2] - array4[1]
					});
					num += 3;
					if (i != 0)
					{
						list2.AddRange(new int[]
						{
							num - 3,
							num - 2,
							num - 5,
							num - 5,
							num - 4,
							num - 3,
							num - 1,
							num - 2,
							num - 3
						});
					}
				}
				else
				{
					Vector2 normalized = Vector2.Lerp(a2, vector2, 0.5f).normalized;
					Vector2 b = normalized * offset;
					Vector2[] array5 = new Vector2[]
					{
						vector + normalized * -num2 + b,
						vector5
					};
					list.AddRange(array5);
					list3.AddRange(new Color32[]
					{
						colorA,
						colorB
					});
					list4.AddRange(new Vector2[]
					{
						Vector2.zero,
						array5[1] - array5[0]
					});
					num += 2;
					if (i != 0)
					{
						list2.AddRange(new int[]
						{
							num - 4,
							num - 2,
							num - 1,
							num - 4,
							num - 1,
							num - 3
						});
					}
				}
				list[1] = list[list.Count - 1];
				list[0] = list[list.Count - 2];
			}
			for (int j = 0; j < list4.Count; j++)
			{
				List<Vector2> list5 = list;
				int index2 = j;
				list5[index2] -= list4[j];
				list4[j].Normalize();
				list4[j] = new Vector2(list4[j].x, list4[j].y * -1f);
			}
			svgLayer.vertices = list.ToArray();
			svgLayer.triangles = list2.ToArray();
			svgLayer.colors = list3.ToArray();
			svgLayer.angles = list4.ToArray();
			svgLayer.RecalculateBounds();
			return true;
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x0003725C File Offset: 0x0003545C
		public static void ChangeMeshUV1(Mesh mesh, Vector2 uv)
		{
			Vector2[] array = mesh.uv;
			int vertexCount = mesh.vertexCount;
			if (array.Length != vertexCount)
			{
				array = new Vector2[vertexCount];
			}
			for (int i = 0; i < vertexCount; i++)
			{
				array[i].x = uv.x;
				array[i].y = uv.y;
			}
			mesh.uv = array;
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x000372BC File Offset: 0x000354BC
		public static void ChangeMeshUV2(Mesh mesh, Vector2 uv)
		{
			int num = mesh.vertices.Length;
			Vector2[] array = new Vector2[num];
			for (int i = 0; i < num; i++)
			{
				array[i].x = uv.x;
				array[i].y = uv.y;
			}
			mesh.uv2 = array;
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00037310 File Offset: 0x00035510
		public static void ChangeMeshUV3(Mesh mesh, Vector2 uv)
		{
			int num = mesh.vertices.Length;
			Vector2[] array = new Vector2[num];
			for (int i = 0; i < num; i++)
			{
				array[i].x = uv.x;
				array[i].y = uv.y;
			}
			mesh.uv3 = array;
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x00037364 File Offset: 0x00035564
		public static void ChangeMeshColor(Mesh mesh, Color32 color)
		{
			Color32[] array = mesh.colors32;
			int vertexCount = mesh.vertexCount;
			if (array.Length != vertexCount)
			{
				array = new Color32[vertexCount];
			}
			for (int i = 0; i < vertexCount; i++)
			{
				array[i].r = color.r;
				array[i].g = color.g;
				array[i].b = color.b;
				array[i].a = color.a;
			}
			mesh.colors32 = array;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x000373E8 File Offset: 0x000355E8
		public static void ChangeMeshColor(Mesh mesh, SVGMeshUtils.ColorChannel channel, byte value)
		{
			Color32[] array = mesh.colors32;
			int vertexCount = mesh.vertexCount;
			if (array.Length != vertexCount)
			{
				array = new Color32[vertexCount];
			}
			switch (channel)
			{
			case SVGMeshUtils.ColorChannel.RED:
				for (int i = 0; i < vertexCount; i++)
				{
					array[i].r = value;
				}
				break;
			case SVGMeshUtils.ColorChannel.GREEN:
				for (int j = 0; j < vertexCount; j++)
				{
					array[j].g = value;
				}
				break;
			case SVGMeshUtils.ColorChannel.BLUE:
				for (int k = 0; k < vertexCount; k++)
				{
					array[k].b = value;
				}
				break;
			case SVGMeshUtils.ColorChannel.ALPHA:
				for (int l = 0; l < vertexCount; l++)
				{
					array[l].a = value;
				}
				break;
			}
			mesh.colors32 = array;
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x000374A3 File Offset: 0x000356A3
		public static void ChangeMeshColor(Mesh mesh, SVGMeshUtils.ColorChannel channel, float value)
		{
			SVGMeshUtils.ChangeMeshColor(mesh, channel, (byte)Mathf.RoundToInt(Mathf.Lerp(0f, 255f, value)));
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x000374C2 File Offset: 0x000356C2
		public static void ChangeMeshColor(Mesh mesh, Color color)
		{
			SVGMeshUtils.ChangeMeshColor(mesh, color);
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x000374D0 File Offset: 0x000356D0
		public static void ChengeMeshPosition(Mesh mesh, Vector3 offset)
		{
			Vector3[] vertices = mesh.vertices;
			int num = vertices.Length;
			for (int i = 0; i < num; i++)
			{
				Vector3[] array = vertices;
				int num2 = i;
				array[num2].x = array[num2].x + offset.x;
				Vector3[] array2 = vertices;
				int num3 = i;
				array2[num3].y = array2[num3].y + offset.y;
				Vector3[] array3 = vertices;
				int num4 = i;
				array3[num4].z = array3[num4].z + offset.z;
			}
			mesh.vertices = vertices;
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00037540 File Offset: 0x00035740
		public static void ChangeMeshRotation(Mesh mesh, Quaternion rotation)
		{
			Vector3[] vertices = mesh.vertices;
			int num = vertices.Length;
			for (int i = 0; i < num; i++)
			{
				vertices[i] = rotation * vertices[i];
			}
			mesh.vertices = vertices;
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x00037580 File Offset: 0x00035780
		public static void ChangeMeshScale(Mesh mesh, Vector3 scale)
		{
			if (mesh == null)
			{
				return;
			}
			if (scale == Vector3.one)
			{
				return;
			}
			Vector3[] vertices = mesh.vertices;
			int vertexCount = mesh.vertexCount;
			for (int i = 0; i < vertexCount; i++)
			{
				Vector3[] array = vertices;
				int num = i;
				array[num].x = array[num].x * scale.x;
				Vector3[] array2 = vertices;
				int num2 = i;
				array2[num2].y = array2[num2].y * scale.y;
				Vector3[] array3 = vertices;
				int num3 = i;
				array3[num3].z = array3[num3].z * scale.z;
			}
			mesh.vertices = vertices;
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00037608 File Offset: 0x00035808
		public static void ChangeMeshScale(Mesh mesh, float scale)
		{
			if (scale == 1f)
			{
				return;
			}
			SVGMeshUtils.ChangeMeshScale(mesh, new Vector3(scale, scale, scale));
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00037624 File Offset: 0x00035824
		public static void AutoWeldVertices(Mesh mesh, float threshold)
		{
			float num = threshold * threshold;
			Vector3[] vertices = mesh.vertices;
			List<int> list = new List<int>();
			int num2 = vertices.Length;
			int num3 = 0;
			Vector3 vector;
			for (int i = 0; i < num2; i++)
			{
				bool flag = true;
				for (int j = 0; j < num3; j++)
				{
					vector.x = vertices[list[j]].x - vertices[i].x;
					vector.y = vertices[list[j]].y - vertices[i].y;
					vector.z = vertices[list[j]].z - vertices[i].z;
					if (vector.x * vector.x + vector.y * vector.y + vector.z * vector.z <= num)
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					list.Add(i);
					num3 = list.Count;
				}
			}
			int[] triangles = mesh.triangles;
			for (int i = 0; i < triangles.Length; i++)
			{
				for (int j = 0; j < list.Count; j++)
				{
					vector.x = vertices[list[j]].x - vertices[triangles[i]].x;
					vector.y = vertices[list[j]].y - vertices[triangles[i]].y;
					vector.z = vertices[list[j]].z - vertices[triangles[i]].z;
					if (vector.x * vector.x + vector.y * vector.y + vector.z * vector.z <= num)
					{
						triangles[i] = j;
						break;
					}
				}
			}
			int count = list.Count;
			Vector3[] array = new Vector3[count];
			for (int i = 0; i < count; i++)
			{
				int num4 = list[i];
				array[i] = vertices[num4];
			}
			mesh.triangles = null;
			mesh.vertices = array;
			mesh.triangles = triangles;
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x00037894 File Offset: 0x00035A94
		public static GameObject MergeMeshes(GameObject source)
		{
			string name = source.name;
			Transform parent = null;
			if (source.transform.parent != null)
			{
				parent = source.transform.parent.transform;
			}
			source.transform.parent = null;
			GameObject gameObject = Object.Instantiate<GameObject>(source, source.transform.position, source.transform.rotation);
			source.transform.parent = parent;
			MeshFilter[] componentsInChildren = gameObject.GetComponentsInChildren<MeshFilter>();
			MeshRenderer[] componentsInChildren2 = gameObject.GetComponentsInChildren<MeshRenderer>();
			Material sharedMaterial = null;
			for (int i = 0; i < componentsInChildren2.Length; i++)
			{
				if (!(componentsInChildren2[i] == null) && !(componentsInChildren2[i].sharedMaterial == null))
				{
					sharedMaterial = componentsInChildren2[i].sharedMaterial;
					break;
				}
			}
			CombineInstance[] array = new CombineInstance[componentsInChildren.Length];
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				MeshFilter meshFilter = componentsInChildren[i];
				array[i].mesh = meshFilter.sharedMesh;
				array[i].transform = meshFilter.transform.localToWorldMatrix;
			}
			MeshFilter meshFilter2 = gameObject.GetComponent<MeshFilter>();
			if (meshFilter2 == null)
			{
				meshFilter2 = gameObject.AddComponent<MeshFilter>();
			}
			MeshRenderer meshRenderer = gameObject.GetComponent<MeshRenderer>();
			if (meshRenderer == null)
			{
				meshRenderer = gameObject.AddComponent<MeshRenderer>();
			}
			meshRenderer.sharedMaterial = sharedMaterial;
			meshFilter2.sharedMesh = new Mesh();
			meshFilter2.sharedMesh.CombineMeshes(array);
			meshFilter2.sharedMesh.RecalculateBounds();
			Vector3 center = meshFilter2.sharedMesh.bounds.center;
			int vertexCount = meshFilter2.sharedMesh.vertexCount;
			Vector3[] vertices = meshFilter2.sharedMesh.vertices;
			for (int i = 0; i < vertexCount; i++)
			{
				vertices[i] -= center;
			}
			meshFilter2.sharedMesh.vertices = vertices;
			meshFilter2.sharedMesh.RecalculateBounds();
			Transform[] componentsInChildren3 = gameObject.GetComponentsInChildren<Transform>();
			for (int i = 0; i < componentsInChildren3.Length; i++)
			{
				if (!(componentsInChildren3[i] == null) && componentsInChildren3[i].gameObject != gameObject)
				{
					Object.Destroy(componentsInChildren3[i].gameObject);
				}
			}
			gameObject.transform.position = center;
			gameObject.transform.localScale = Vector3.one;
			gameObject.transform.parent = parent;
			gameObject.name = name;
			return gameObject;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00037B00 File Offset: 0x00035D00
		public static void Fill(Mesh source, Mesh destination)
		{
			if (destination == null)
			{
				return;
			}
			if (source == null)
			{
				return;
			}
			destination.name = source.name;
			destination.vertices = (Vector3[])source.vertices.Clone();
			destination.triangles = (int[])source.triangles.Clone();
			Color32[] colors = source.colors32;
			if (colors != null && colors.Length != 0)
			{
				destination.colors32 = (Color32[])colors.Clone();
			}
			Vector2[] uv = source.uv;
			if (uv != null && uv.Length != 0)
			{
				destination.uv = (Vector2[])uv.Clone();
			}
			Vector2[] uv2 = source.uv2;
			if (uv2 != null && uv2.Length != 0)
			{
				destination.uv2 = (Vector2[])uv2.Clone();
			}
			Vector2[] uv3 = source.uv3;
			if (uv3 != null && uv3.Length != 0)
			{
				destination.uv3 = (Vector2[])uv3.Clone();
			}
			Vector2[] uv4 = source.uv4;
			if (uv4 != null && uv4.Length != 0)
			{
				destination.uv4 = (Vector2[])uv4.Clone();
			}
			Vector3[] normals = source.normals;
			if (normals != null && normals.Length != 0)
			{
				destination.normals = (Vector3[])normals.Clone();
			}
			Vector4[] tangents = source.tangents;
			if (tangents != null && tangents.Length != 0)
			{
				destination.tangents = (Vector4[])tangents.Clone();
			}
			int subMeshCount = source.subMeshCount;
			destination.subMeshCount = subMeshCount;
			if (subMeshCount > 0)
			{
				for (int i = 0; i < subMeshCount; i++)
				{
					destination.SetTriangles(source.GetTriangles(i), i);
				}
			}
			destination.bounds = source.bounds;
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00037C80 File Offset: 0x00035E80
		public static Mesh Clone(Mesh mesh)
		{
			if (mesh == null)
			{
				return null;
			}
			Mesh mesh2 = new Mesh();
			mesh2.name = mesh.name;
			SVGMeshUtils.Fill(mesh, mesh2);
			return mesh2;
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00037CB2 File Offset: 0x00035EB2
		public static Material CloneMaterial(Material original)
		{
			if (original == null)
			{
				return null;
			}
			Material material = new Material(original.shader);
			material.CopyPropertiesFromMaterial(original);
			return material;
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00037CD4 File Offset: 0x00035ED4
		public static List<Vector3> GetEdgePoints(int[] triangles, Vector3[] positions)
		{
			List<int> list = new List<int>();
			for (int i = 0; i < triangles.Length; i += 3)
			{
				list.Add(triangles[i]);
				list.Add(triangles[i + 1]);
				list.Add(triangles[i + 1]);
				list.Add(triangles[i + 2]);
				list.Add(triangles[i + 2]);
				list.Add(triangles[i]);
			}
			Dictionary<int, bool> dictionary = new Dictionary<int, bool>();
			List<int> list2 = new List<int>();
			List<Vector3> list3 = new List<Vector3>();
			int num = -1;
			while (list3.Count < list.Count)
			{
				if (num < 0)
				{
					for (int j = 0; j < list.Count; j += 2)
					{
						if (!dictionary.ContainsKey(j))
						{
							num = list[j];
							break;
						}
					}
				}
				for (int k = 0; k < list.Count; k += 2)
				{
					if (!dictionary.ContainsKey(k))
					{
						int num2 = k + 1;
						int num3 = -1;
						if (list[k] == num)
						{
							num3 = num2;
						}
						else if (list[num2] == num)
						{
							num3 = k;
						}
						if (num3 >= 0)
						{
							int num4 = list[num3];
							dictionary[k] = true;
							list2.Add(num);
							list2.Add(num4);
							num = num4;
							k = 0;
						}
					}
				}
				List<Vector3> borderPoints = new List<Vector3>();
				list2.ForEach(delegate(int ei)
				{
					borderPoints.Add(positions[ei]);
				});
				if (SVGMeshUtils.CalculateWindingOrder(borderPoints) > 0)
				{
					borderPoints.Reverse();
				}
				list3.AddRange(borderPoints);
				list2.Clear();
				num = -1;
			}
			return list3;
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x00037E84 File Offset: 0x00036084
		public static int CalculateWindingOrder(IList<Vector3> points)
		{
			double num = SVGMeshUtils.CalculateSignedArea(points);
			if (num < 0.0)
			{
				return 1;
			}
			if (num > 0.0)
			{
				return -1;
			}
			return 0;
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x00037EB8 File Offset: 0x000360B8
		public static int CalculateWindingOrder(IList<Vector2> points)
		{
			double num = SVGMeshUtils.CalculateSignedArea(points);
			if (num < 0.0)
			{
				return 1;
			}
			if (num > 0.0)
			{
				return -1;
			}
			return 0;
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x00037EEC File Offset: 0x000360EC
		public static int CalculateWindingOrder(Vector2[] points)
		{
			double num = SVGMeshUtils.CalculateSignedArea(points);
			if (num < 0.0)
			{
				return 1;
			}
			if (num > 0.0)
			{
				return -1;
			}
			return 0;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00037F20 File Offset: 0x00036120
		public static double CalculateSignedArea(IList<Vector3> points)
		{
			double num = 0.0;
			for (int i = 0; i < points.Count; i++)
			{
				int index = (i + 1) % points.Count;
				num += (double)(points[i].x * points[index].y);
				num -= (double)(points[i].y * points[index].x);
			}
			return num / 2.0;
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00037F9C File Offset: 0x0003619C
		public static double CalculateSignedArea(Vector3[] points)
		{
			double num = 0.0;
			for (int i = 0; i < points.Length; i++)
			{
				int num2 = (i + 1) % points.Length;
				num += (double)(points[i].x * points[num2].y);
				num -= (double)(points[i].y * points[num2].x);
			}
			return num / 2.0;
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00038010 File Offset: 0x00036210
		public static double CalculateSignedArea(IList<Vector2> points)
		{
			double num = 0.0;
			for (int i = 0; i < points.Count; i++)
			{
				int index = (i + 1) % points.Count;
				num += (double)(points[i].x * points[index].y);
				num -= (double)(points[i].y * points[index].x);
			}
			return num / 2.0;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x0003808C File Offset: 0x0003628C
		public static double CalculateSignedArea(Vector2[] points)
		{
			double num = 0.0;
			for (int i = 0; i < points.Length; i++)
			{
				int num2 = (i + 1) % points.Length;
				num += (double)(points[i].x * points[num2].y);
				num -= (double)(points[i].y * points[num2].x);
			}
			return num / 2.0;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00038100 File Offset: 0x00036300
		public static List<int[]> BuildManifoldPoints(Vector3[] vertices, int[] triangles)
		{
			List<int[]> list = new List<int[]>();
			Edge[] array = SVGMeshUtils.BuildManifoldEdges(vertices, triangles);
			int num = array.Length;
			List<int> list2 = new List<int>();
			if (num == 0)
			{
				return list;
			}
			if (num == 1)
			{
				list.Add(new int[]
				{
					array[0].vertexIndex[0],
					array[0].vertexIndex[1]
				});
				return list;
			}
			Edge edge = array[0];
			for (int i = 1; i < num; i++)
			{
				Edge edge2 = array[i];
				if (list2.Count > 0 && edge.vertexIndex[1] != edge2.vertexIndex[0])
				{
					list.Add(list2.ToArray());
					list2 = new List<int>();
				}
				list2.Add(edge2.vertexIndex[0]);
				edge = edge2;
			}
			if (list2.Count > 0)
			{
				list.Add(list2.ToArray());
			}
			return list;
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x000381CC File Offset: 0x000363CC
		public static Edge[] BuildManifoldEdges(Vector3[] vertices, int[] triangles)
		{
			Edge[] array = SVGMeshUtils.BuildEdges(vertices.Length, triangles);
			List<Edge> list = new List<Edge>();
			foreach (Edge edge in array)
			{
				if (edge.faceIndex[0] == edge.faceIndex[1])
				{
					list.Add(edge);
				}
			}
			return list.ToArray();
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x0003821C File Offset: 0x0003641C
		public static Edge[] BuildEdges(int vertexCount, int[] triangleArray)
		{
			int num = triangleArray.Length;
			int[] array = new int[vertexCount + num];
			int num2 = triangleArray.Length / 3;
			for (int i = 0; i < vertexCount; i++)
			{
				array[i] = -1;
			}
			Edge[] array2 = new Edge[num];
			int num3 = 0;
			for (int j = 0; j < num2; j++)
			{
				int num4 = triangleArray[j * 3 + 2];
				for (int k = 0; k < 3; k++)
				{
					int num5 = triangleArray[j * 3 + k];
					if (num4 < num5)
					{
						Edge edge = new Edge();
						edge.vertexIndex[0] = num4;
						edge.vertexIndex[1] = num5;
						edge.faceIndex[0] = j;
						edge.faceIndex[1] = j;
						array2[num3] = edge;
						int num6 = array[num4];
						if (num6 == -1)
						{
							array[num4] = num3;
						}
						else
						{
							for (;;)
							{
								int num7 = array[vertexCount + num6];
								if (num7 == -1)
								{
									break;
								}
								num6 = num7;
							}
							array[vertexCount + num6] = num3;
						}
						array[vertexCount + num3] = -1;
						num3++;
					}
					num4 = num5;
				}
			}
			for (int l = 0; l < num2; l++)
			{
				int num8 = triangleArray[l * 3 + 2];
				for (int m = 0; m < 3; m++)
				{
					int num9 = triangleArray[l * 3 + m];
					if (num8 > num9)
					{
						bool flag = false;
						for (int num10 = array[num9]; num10 != -1; num10 = array[vertexCount + num10])
						{
							Edge edge2 = array2[num10];
							if (edge2.vertexIndex[1] == num8 && edge2.faceIndex[0] == edge2.faceIndex[1])
							{
								array2[num10].faceIndex[1] = l;
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							Edge edge3 = new Edge();
							edge3.vertexIndex[0] = num8;
							edge3.vertexIndex[1] = num9;
							edge3.faceIndex[0] = l;
							edge3.faceIndex[1] = l;
							array2[num3] = edge3;
							num3++;
						}
					}
					num8 = num9;
				}
			}
			Edge[] array3 = new Edge[num3];
			for (int n = 0; n < num3; n++)
			{
				array3[n] = array2[n];
			}
			return array3;
		}

		// Token: 0x04000816 RID: 2070
		private const float PI2 = 6.2831855f;

		// Token: 0x04000817 RID: 2071
		public static Vector2 lineUVScale = Vector2.one;

		// Token: 0x04000818 RID: 2072
		public static Vector2 lineUVOffset = Vector2.zero;

		// Token: 0x02000352 RID: 850
		public enum ColorChannel
		{
			// Token: 0x0400124C RID: 4684
			RED,
			// Token: 0x0400124D RID: 4685
			GREEN,
			// Token: 0x0400124E RID: 4686
			BLUE,
			// Token: 0x0400124F RID: 4687
			ALPHA
		}
	}
}
