﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000108 RID: 264
	public class SVGDebugPoints : MonoBehaviour
	{
	}
}
