﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000F3 RID: 243
	public struct SVGLength
	{
		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060007A6 RID: 1958 RVA: 0x0002F11D File Offset: 0x0002D31D
		public float value
		{
			get
			{
				return this._value;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060007A7 RID: 1959 RVA: 0x0002F125 File Offset: 0x0002D325
		public SVGLengthType unitType
		{
			get
			{
				return this._unitType;
			}
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x0002F12D File Offset: 0x0002D32D
		public SVGLength(SVGLengthType unitType, float valueInSpecifiedUnits)
		{
			this._unitType = unitType;
			this._valueInSpecifiedUnits = valueInSpecifiedUnits;
			this._value = SVGLengthConvertor.ConvertToPX(this._valueInSpecifiedUnits, this._unitType);
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x0002F154 File Offset: 0x0002D354
		public SVGLength(float valueInSpecifiedUnits)
		{
			this._unitType = SVGLengthType.Number;
			this._valueInSpecifiedUnits = valueInSpecifiedUnits;
			this._value = SVGLengthConvertor.ConvertToPX(this._valueInSpecifiedUnits, this._unitType);
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0002F17C File Offset: 0x0002D37C
		public SVGLength(string valueText)
		{
			float valueInSpecifiedUnits = 0f;
			SVGLengthType unitType = SVGLengthType.Unknown;
			SVGLengthConvertor.ExtractType(valueText, ref valueInSpecifiedUnits, ref unitType);
			this._unitType = unitType;
			this._valueInSpecifiedUnits = valueInSpecifiedUnits;
			this._value = SVGLengthConvertor.ConvertToPX(this._valueInSpecifiedUnits, this._unitType);
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0002F1C1 File Offset: 0x0002D3C1
		public void NewValueSpecifiedUnits(float valueInSpecifiedUnits)
		{
			this._unitType = SVGLengthType.Unknown;
			this._valueInSpecifiedUnits = valueInSpecifiedUnits;
			this._value = SVGLengthConvertor.ConvertToPX(this._valueInSpecifiedUnits, this._unitType);
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x0002F1E8 File Offset: 0x0002D3E8
		public static float GetPXLength(string valueText)
		{
			float value = 0f;
			SVGLengthType lengthType = SVGLengthType.Unknown;
			SVGLengthConvertor.ExtractType(valueText, ref value, ref lengthType);
			return SVGLengthConvertor.ConvertToPX(value, lengthType);
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0002F20F File Offset: 0x0002D40F
		public SVGLength Multiply(SVGLength svglength)
		{
			if (this.unitType == SVGLengthType.Percentage && svglength.unitType == SVGLengthType.Percentage)
			{
				return new SVGLength(SVGLengthType.Percentage, this.value * svglength.value);
			}
			return new SVGLength(SVGLengthType.PX, this.value * svglength.value);
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x0002F250 File Offset: 0x0002D450
		public override string ToString()
		{
			return this.value.ToString();
		}

		// Token: 0x040007DF RID: 2015
		private SVGLengthType _unitType;

		// Token: 0x040007E0 RID: 2016
		private float _valueInSpecifiedUnits;

		// Token: 0x040007E1 RID: 2017
		private float _value;
	}
}
