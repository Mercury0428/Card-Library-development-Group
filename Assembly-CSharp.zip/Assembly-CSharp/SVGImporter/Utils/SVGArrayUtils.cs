﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x0200010A RID: 266
	public class SVGArrayUtils
	{
		// Token: 0x06000895 RID: 2197 RVA: 0x000388A8 File Offset: 0x00036AA8
		public static T[] CreatePreinitializedArray<T>(T value, int length)
		{
			T[] array = new T[length];
			for (int i = 0; i < length; i++)
			{
				array[i] = value;
			}
			return array;
		}
	}
}
