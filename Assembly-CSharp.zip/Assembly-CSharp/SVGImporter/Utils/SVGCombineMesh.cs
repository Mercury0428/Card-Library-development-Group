﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000FD RID: 253
	public class SVGCombineMesh
	{
		// Token: 0x06000839 RID: 2105 RVA: 0x00033584 File Offset: 0x00031784
		public static Mesh Combine(Mesh[] meshes)
		{
			CombineInstance[] array = new CombineInstance[meshes.Length];
			for (int i = 0; i < meshes.Length; i++)
			{
				array[i].mesh = meshes[i];
			}
			Mesh mesh = new Mesh();
			mesh.CombineMeshes(array, false, false);
			return mesh;
		}
	}
}
