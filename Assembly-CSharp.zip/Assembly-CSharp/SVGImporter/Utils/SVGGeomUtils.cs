﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000FE RID: 254
	public class SVGGeomUtils
	{
		// Token: 0x0600083B RID: 2107 RVA: 0x000335C8 File Offset: 0x000317C8
		public static List<Vector2> RoundedRect(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4, Vector2 p5, Vector2 p6, Vector2 p7, Vector2 p8, float r1, float r2, float angle)
		{
			List<Vector2> list = new List<Vector2>();
			list.Add(p1);
			list.Add(p2);
			list.AddRange(SVGGeomUtils.Arc(p2, r1, r2, angle, false, true, p3));
			list.Add(p3);
			list.Add(p4);
			list.AddRange(SVGGeomUtils.Arc(p4, r1, r2, angle, false, true, p5));
			list.Add(p5);
			list.Add(p6);
			list.AddRange(SVGGeomUtils.Arc(p6, r1, r2, angle, false, true, p7));
			list.Add(p7);
			list.Add(p8);
			list.AddRange(SVGGeomUtils.Arc(p8, r1, r2, angle, false, true, p1));
			return list;
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00033670 File Offset: 0x00031870
		public static List<Vector2> Arc(Vector2 p1, float rx, float ry, float angle, bool largeArcFlag, bool sweepFlag, Vector2 p2)
		{
			List<Vector2> list = new List<Vector2>();
			float f = angle * 3.1415927f / 180f;
			float num = Mathf.Cos(f);
			float num2 = Mathf.Sin(f);
			float num3 = (p1.x - p2.x) / 2f;
			float num4 = (p1.y - p2.y) / 2f;
			float num5 = num * num3 + num2 * num4;
			float num6 = -num2 * num3 + num * num4;
			double num7 = (double)(rx * rx);
			double num8 = (double)(ry * ry);
			double num9 = (double)(num5 * num5);
			double num10 = (double)(num6 * num6);
			double num11 = num9 / num7 + num10 / num8;
			if (num11 > 1.0)
			{
				rx = Mathf.Sqrt((float)num11) * rx;
				ry = Mathf.Sqrt((float)num11) * ry;
				num7 = (double)(rx * rx);
				num8 = (double)(ry * ry);
			}
			double num12 = (num7 * num8 - num7 * num10 - num8 * num9) / (num7 * num10 + num8 * num9);
			num12 = ((num12 < 0.0) ? 0.0 : num12);
			float num13 = (largeArcFlag == sweepFlag) ? (-Mathf.Sqrt((float)num12)) : Mathf.Sqrt((float)num12);
			float num14 = num13 * (rx * num6 / ry);
			float num15 = num13 * (-(ry * num5) / rx);
			float num16 = num * num14 - num2 * num15 + (p1.x + p2.x) / 2f;
			float num17 = num2 * num14 + num * num15 + (p1.y + p2.y) / 2f;
			float num18 = (num5 - num14) / rx;
			float num19 = (num6 - num15) / ry;
			float num20 = (-num5 - num14) / rx;
			float num21 = (-num6 - num15) / ry;
			float num22 = Mathf.Sqrt(num18 * num18 + num19 * num19);
			float num23 = num18;
			float num24 = (num19 < 0f) ? (-Mathf.Acos(num23 / num22)) : Mathf.Acos(num23 / num22);
			num24 = num24 * 180f / 3.1415927f;
			num24 %= 360f;
			num22 = Mathf.Sqrt((num18 * num18 + num19 * num19) * (num20 * num20 + num21 * num21));
			num23 = num18 * num20 + num19 * num21;
			float num25 = num23 / num22;
			if (Mathf.Abs(num25) >= 0.99999f && Mathf.Abs(num25) < 1.000009f)
			{
				if (num25 > 0f)
				{
					num25 = 1f;
				}
				else
				{
					num25 = -1f;
				}
			}
			float num26 = (num18 * num21 - num19 * num20 < 0f) ? (-Mathf.Acos(num25)) : Mathf.Acos(num25);
			num26 = num26 * 180f / 3.1415927f;
			if (!sweepFlag && num26 > 0f)
			{
				num26 -= 360f;
			}
			else if (sweepFlag && num26 < 0f)
			{
				num26 += 360f;
			}
			num26 %= 360f;
			int num27 = Mathf.RoundToInt(Mathf.Clamp(100f / SVGGraphics.vpm * Mathf.Abs(num26) / 360f, 2f, 100f));
			float num28 = num26 / (float)num27;
			Vector2 item = new Vector2(0f, 0f);
			for (int i = 0; i <= num27; i++)
			{
				float f2 = (num28 * (float)i + num24) * 3.1415927f / 180f;
				item.x = num * rx * Mathf.Cos(f2) - num2 * ry * Mathf.Sin(f2) + num16;
				item.y = num2 * rx * Mathf.Cos(f2) + num * ry * Mathf.Sin(f2) + num17;
				list.Add(item);
			}
			return list;
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x000339ED File Offset: 0x00031BED
		public static Vector2 TransformPoint(Vector2 point, SVGMatrix matrix)
		{
			point = matrix.Transform(point);
			return point;
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x000339FC File Offset: 0x00031BFC
		private static float BelongPosition(Vector2 a, Vector2 b, Vector2 c)
		{
			float num = (a.y - c.y) * (b.x - a.x) - (a.x - c.x) * (b.y - a.y);
			float num2 = (b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y);
			return num / num2;
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00033A7C File Offset: 0x00031C7C
		private static int NumberOfLimitForCubic(Vector2 a, Vector2 b, Vector2 c, Vector2 d)
		{
			float num = SVGGeomUtils.BelongPosition(a, d, b);
			float num2 = SVGGeomUtils.BelongPosition(a, d, c);
			if (num * num2 > 0f)
			{
				return 0;
			}
			return 1;
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00033AA8 File Offset: 0x00031CA8
		private static float Distance(Vector2 a, Vector2 b, Vector2 c)
		{
			float num = (a.y - c.y) * (b.x - a.x) - (a.x - c.x) * (b.y - a.y);
			float num2 = (b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y);
			return Mathf.Abs(num / num2) * Mathf.Sqrt(num2);
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00033B34 File Offset: 0x00031D34
		private static Vector2 EvaluateForCubic(float t, Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
		{
			Vector2 result = new Vector2(0f, 0f);
			float num = 1f - t;
			float num2 = num * num * num;
			float num3 = 3f * t * num * num;
			float num4 = 3f * t * t * num;
			float num5 = t * t * t;
			result.x = num2 * p1.x + num3 * p2.x + num4 * p3.x + num5 * p4.x;
			result.y = num2 * p1.y + num3 * p2.y + num4 * p3.y + num5 * p4.y;
			return result;
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x00033BDC File Offset: 0x00031DDC
		private static Vector2 EvaluateForQuadratic(float t, Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
		{
			Vector2 result = new Vector2(0f, 0f);
			float num = 1f - t;
			float num2 = num * num;
			float num3 = 2f * t * num;
			float num4 = t * t;
			result.x = num2 * p1.x + num3 * p2.x + num4 * p3.x;
			result.y = num2 * p1.y + num3 * p2.y + num4 * p3.y;
			return result;
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x00033C5C File Offset: 0x00031E5C
		private static List<Vector2> CubicCurve(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4, int numberOfLimit, bool cubic)
		{
			List<Vector2> list = new List<Vector2>();
			float num = 0f;
			float num2 = 1f;
			float num3 = 1f;
			SVGGeomUtils.Vector2Ext vector2Ext = new SVGGeomUtils.Vector2Ext(cubic ? SVGGeomUtils.EvaluateForCubic(num, p1, p2, p3, p4) : SVGGeomUtils.EvaluateForQuadratic(num, p1, p2, p3, p4), num);
			SVGGeomUtils.Vector2Ext obj = new SVGGeomUtils.Vector2Ext(cubic ? SVGGeomUtils.EvaluateForCubic(num2, p1, p2, p3, p4) : SVGGeomUtils.EvaluateForQuadratic(num2, p1, p2, p3, p4), num2);
			SVGGeomUtils._stack.Clear();
			SVGGeomUtils._stack.Push(obj);
			SVGGeomUtils._limitList.Clear();
			if (SVGGeomUtils._limitList.Capacity < numberOfLimit + 1)
			{
				SVGGeomUtils._limitList.Capacity = numberOfLimit + 1;
			}
			int num4 = 0;
			for (;;)
			{
				num4++;
				float num5 = (num + num2) / 2f;
				SVGGeomUtils.Vector2Ext obj2 = new SVGGeomUtils.Vector2Ext(cubic ? SVGGeomUtils.EvaluateForCubic(num5, p1, p2, p3, p4) : SVGGeomUtils.EvaluateForQuadratic(num5, p1, p2, p3, p4), num5);
				float num6 = SVGGeomUtils.Distance(vector2Ext.point, SVGGeomUtils._stack.Peek().point, obj2.point);
				bool flag = false;
				if (num6 < num3)
				{
					float num7 = 0f;
					int i;
					for (i = 0; i < numberOfLimit; i++)
					{
						num7 = (num + num5) / 2f;
						SVGGeomUtils.Vector2Ext vector2Ext2 = new SVGGeomUtils.Vector2Ext(cubic ? SVGGeomUtils.EvaluateForCubic(num7, p1, p2, p3, p4) : SVGGeomUtils.EvaluateForQuadratic(num7, p1, p2, p3, p4), num7);
						if (SVGGeomUtils._limitList.Count - 1 < i)
						{
							SVGGeomUtils._limitList.Add(vector2Ext2);
						}
						else
						{
							SVGGeomUtils._limitList[i] = vector2Ext2;
						}
						if (SVGGeomUtils.Distance(vector2Ext.point, obj2.point, vector2Ext2.point) >= num3)
						{
							break;
						}
						num5 = num7;
					}
					if (i == numberOfLimit)
					{
						flag = true;
					}
					else
					{
						SVGGeomUtils._stack.Push(obj2);
						for (int j = 0; j <= i; j++)
						{
							SVGGeomUtils._stack.Push(SVGGeomUtils._limitList[j]);
						}
						num2 = num7;
					}
				}
				if (flag)
				{
					list.Add(vector2Ext.point);
					list.Add(obj2.point);
					vector2Ext = SVGGeomUtils._stack.Pop();
					if (SVGGeomUtils._stack.Count == 0)
					{
						break;
					}
					obj2 = SVGGeomUtils._stack.Peek();
					num = num2;
					num2 = obj2.t;
				}
				else if (num2 > num5)
				{
					SVGGeomUtils._stack.Push(obj2);
					num2 = num5;
				}
			}
			list.Add(vector2Ext.point);
			return list;
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00033EC8 File Offset: 0x000320C8
		public static List<Vector2> CubicCurve(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
		{
			return new List<Vector2>(SVGBezier.AdaptiveCubicCurve(SVGGraphics.vpm, p1, p2, p3, p4));
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00033EE0 File Offset: 0x000320E0
		public static List<Vector2> QuadraticCurve(Vector2 p1, Vector2 p2, Vector2 p3)
		{
			Vector2 handle = p1 + 0.6666667f * (p2 - p1);
			Vector2 handle2 = p3 + 0.6666667f * (p2 - p3);
			return new List<Vector2>(SVGBezier.AdaptiveCubicCurve(SVGGraphics.vpm, p1, handle, handle2, p3));
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00033F30 File Offset: 0x00032130
		public static bool IsWindingClockWise(List<Vector2> points)
		{
			if (points == null || points.Count < 2)
			{
				return false;
			}
			int count = points.Count;
			Vector2 vector = points[0];
			float num = 0f;
			for (int i = 1; i < count; i++)
			{
				num += (points[i].x - vector.x) * (points[i].y + vector.y);
				vector = points[i];
			}
			return num >= 0f;
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x00033FAC File Offset: 0x000321AC
		public static bool IsWindingClockWise(Vector2[] points)
		{
			if (points == null || points.Length < 2)
			{
				return false;
			}
			int num = points.Length;
			Vector2 vector = points[0];
			float num2 = 0f;
			for (int i = 1; i < num; i++)
			{
				num2 += (points[i].x - vector.x) * (points[i].y + vector.y);
				vector = points[i];
			}
			return num2 >= 0f;
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00034020 File Offset: 0x00032220
		public static Vector2[] GetPathNormals(List<Vector2> points)
		{
			if (points == null || points.Count < 2)
			{
				return null;
			}
			Vector2[] array = new Vector2[points.Count];
			int count = points.Count;
			Vector2 b = points[0];
			Vector2 normalized;
			for (int i = 1; i < count; i++)
			{
				normalized = (points[i] - b).normalized;
				array[i].x = normalized.y;
				array[i].y = -normalized.x;
				b = points[i];
			}
			normalized = (points[0] - b).normalized;
			array[0] = new Vector2(normalized.y, -normalized.x);
			return array;
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x000340E0 File Offset: 0x000322E0
		public static Vector2[] GetPathNormals(Vector2[] points)
		{
			if (points == null || points.Length < 2)
			{
				return null;
			}
			Vector2[] array = new Vector2[points.Length];
			int num = points.Length;
			Vector2 b = points[0];
			Vector2 normalized;
			for (int i = 1; i < num; i++)
			{
				normalized = (points[i] - b).normalized;
				array[i].x = normalized.y;
				array[i].y = -normalized.x;
				b = points[i];
			}
			normalized = (points[0] - b).normalized;
			array[0] = new Vector2(normalized.y, -normalized.x);
			return array;
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00034198 File Offset: 0x00032398
		public static Vector2[] OffsetVerts(Vector2[] aSegment, float scale)
		{
			Vector2[] array = (Vector2[])aSegment.Clone();
			for (int i = aSegment.Length - 1; i >= 0; i--)
			{
				array[i] += SVGGeomUtils.GetNormal(aSegment, i, false) * scale;
			}
			return array;
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x000341E8 File Offset: 0x000323E8
		public static Vector2 GetNormal(Vector2[] aSegment, int i, bool aClosed)
		{
			if (aSegment.Length < 2)
			{
				return Vector2.up;
			}
			Vector2 vector = (aClosed && i == aSegment.Length - 1) ? aSegment[0] : aSegment[i];
			Vector2 vector2 = Vector2.zero;
			if (i - 1 < 0)
			{
				if (aClosed)
				{
					vector2 = aSegment[aSegment.Length - 2];
				}
				else
				{
					vector2 = vector - (aSegment[i + 1] - vector);
				}
			}
			else
			{
				vector2 = aSegment[i - 1];
			}
			Vector2 vector3 = Vector2.zero;
			if (i + 1 > aSegment.Length - 1)
			{
				if (aClosed)
				{
					vector3 = aSegment[1];
				}
				else
				{
					vector3 = vector - (aSegment[i - 1] - vector);
				}
			}
			else
			{
				vector3 = aSegment[i + 1];
			}
			vector2 -= vector;
			vector3 -= vector;
			vector2.Normalize();
			vector3.Normalize();
			vector2 = new Vector2(-vector2.y, vector2.x);
			vector3 = new Vector2(vector3.y, -vector3.x);
			Vector2 result = (vector2 + vector3) / 2f;
			result.Normalize();
			return result;
		}

		// Token: 0x040007FF RID: 2047
		private static LiteStack<SVGGeomUtils.Vector2Ext> _stack = new LiteStack<SVGGeomUtils.Vector2Ext>();

		// Token: 0x04000800 RID: 2048
		private static List<SVGGeomUtils.Vector2Ext> _limitList = new List<SVGGeomUtils.Vector2Ext>();

		// Token: 0x02000351 RID: 849
		private struct Vector2Ext
		{
			// Token: 0x17000443 RID: 1091
			// (get) Token: 0x06001699 RID: 5785 RVA: 0x000731C4 File Offset: 0x000713C4
			public float t
			{
				get
				{
					return this._delta;
				}
			}

			// Token: 0x17000444 RID: 1092
			// (get) Token: 0x0600169A RID: 5786 RVA: 0x000731CC File Offset: 0x000713CC
			public Vector2 point
			{
				get
				{
					return this._point;
				}
			}

			// Token: 0x0600169B RID: 5787 RVA: 0x000731D4 File Offset: 0x000713D4
			public Vector2Ext(Vector2 point, float t)
			{
				this._point = point;
				this._delta = t;
			}

			// Token: 0x04001249 RID: 4681
			private float _delta;

			// Token: 0x0400124A RID: 4682
			private Vector2 _point;
		}
	}
}
