﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000F1 RID: 241
	public struct SVGColor
	{
		// Token: 0x060007A5 RID: 1957 RVA: 0x0002F060 File Offset: 0x0002D260
		public SVGColor(string colorString)
		{
			if (SVGColorExtractor.IsRGBColor(colorString))
			{
				this.colorType = SVGColorType.RGB;
				this.color = SVGColorExtractor.RGBColor(colorString);
				return;
			}
			if (SVGColorExtractor.IsHexColor(colorString))
			{
				this.colorType = SVGColorType.RGB;
				this.color = SVGColorExtractor.HexColor(colorString);
				return;
			}
			if (SVGColorExtractor.IsConstName(colorString))
			{
				this.colorType = SVGColorType.RGB;
				this.color = SVGColorExtractor.ConstColor(colorString);
				return;
			}
			if (colorString.ToLower() == "current")
			{
				this.colorType = SVGColorType.Current;
				this.color = Color.black;
				return;
			}
			if (colorString.ToLower() == "none")
			{
				this.colorType = SVGColorType.None;
				this.color = Color.black;
				return;
			}
			this.colorType = SVGColorType.Unknown;
			this.color = Color.black;
		}

		// Token: 0x040007D1 RID: 2001
		public SVGColorType colorType;

		// Token: 0x040007D2 RID: 2002
		public Color color;
	}
}
