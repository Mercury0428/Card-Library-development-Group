﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000FC RID: 252
	public class SVGMath
	{
		// Token: 0x0600080A RID: 2058 RVA: 0x000321C6 File Offset: 0x000303C6
		public static Vector2 RotateVectorClockwise(Vector2 vector)
		{
			return new Vector2(vector.y, -vector.x);
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x000321DA File Offset: 0x000303DA
		public static Vector2 RotateVectorAntiClockwise(Vector2 vector)
		{
			return new Vector2(-vector.y, vector.x);
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x000321EE File Offset: 0x000303EE
		public static int PositiveModulo(int a, int b)
		{
			return (Mathf.Abs(a * b) + a) % b;
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x000321FC File Offset: 0x000303FC
		public static Vector3 AddVectorLength(Vector3 vector, float size)
		{
			float num = Vector3.Magnitude(vector);
			num += size;
			return Vector3.Scale(Vector3.Normalize(vector), new Vector3(num, num, num));
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x00032227 File Offset: 0x00030427
		public static Vector3 SetVectorLength(Vector3 vector, float size)
		{
			return Vector3.Normalize(vector) * size;
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x00032235 File Offset: 0x00030435
		public static Quaternion SubtractRotation(Quaternion B, Quaternion A)
		{
			return Quaternion.Inverse(A) * B;
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x00032244 File Offset: 0x00030444
		public static bool PlanePlaneIntersection(out Vector3 linePoint, out Vector3 lineVec, Vector3 plane1Normal, Vector3 plane1Position, Vector3 plane2Normal, Vector3 plane2Position)
		{
			linePoint = Vector3.zero;
			lineVec = Vector3.zero;
			lineVec = Vector3.Cross(plane1Normal, plane2Normal);
			Vector3 vector = Vector3.Cross(plane2Normal, lineVec);
			float num = Vector3.Dot(plane1Normal, vector);
			if (Mathf.Abs(num) > 0.006f)
			{
				Vector3 rhs = plane1Position - plane2Position;
				float d = Vector3.Dot(plane1Normal, rhs) / num;
				linePoint = plane2Position + d * vector;
				return true;
			}
			return false;
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x000322C4 File Offset: 0x000304C4
		public static bool LinePlaneIntersection(out Vector3 intersection, Vector3 linePoint, Vector3 lineVec, Vector3 planeNormal, Vector3 planePoint)
		{
			intersection = Vector3.zero;
			float num = Vector3.Dot(planePoint - linePoint, planeNormal);
			float num2 = Vector3.Dot(lineVec, planeNormal);
			if (num2 != 0f)
			{
				float size = num / num2;
				Vector3 b = SVGMath.SetVectorLength(lineVec, size);
				intersection = linePoint + b;
				return true;
			}
			return false;
		}

		// Token: 0x06000812 RID: 2066 RVA: 0x00032318 File Offset: 0x00030518
		public static bool LineLineIntersection(out Vector3 intersection, Vector3 line1Start, Vector3 line1End, Vector3 line2Start, Vector3 line2End)
		{
			intersection = Vector3.zero;
			Vector3 lhs = line2Start - line1Start;
			Vector3 rhs = Vector3.Cross(line1End, line2End);
			Vector3 lhs2 = Vector3.Cross(lhs, line2End);
			float num = Vector3.Dot(lhs, rhs);
			if (num >= 1E-05f || num <= -1E-05f)
			{
				return false;
			}
			float num2 = Vector3.Dot(lhs2, rhs) / rhs.sqrMagnitude;
			if (num2 >= 0f && num2 <= 1f)
			{
				intersection = line1Start + line1End * num2;
				return true;
			}
			return false;
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x00032398 File Offset: 0x00030598
		public static bool LineLineIntersection(out Vector2 intersection, Vector2 line1Start, Vector2 line1End, Vector2 line2Start, Vector2 line2End)
		{
			intersection = Vector2.zero;
			float num = line1End.x - line1Start.x;
			float num2 = line1End.y - line1Start.y;
			float num3 = line2End.x - line2Start.x;
			float num4 = line2End.y - line2Start.y;
			float num5 = (-num2 * (line1Start.x - line2Start.x) + num * (line1Start.y - line2Start.y)) / (-num3 * num2 + num * num4);
			float num6 = (num3 * (line1Start.y - line2Start.y) - num4 * (line1Start.x - line2Start.x)) / (-num3 * num2 + num * num4);
			intersection.x = line1Start.x + num6 * num;
			intersection.y = line1Start.y + num6 * num2;
			return num5 >= 0f && num5 <= 1f && num6 >= 0f && num6 <= 1f;
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x00032488 File Offset: 0x00030688
		public static float ClosestDistanceToLine(Vector2 lineStart, Vector2 lineEnd, Vector2 point)
		{
			Vector2 vector = new Vector2(lineEnd.x - lineStart.x, lineEnd.y - lineStart.y);
			float num = vector.x * vector.x + vector.y * vector.y;
			float num2 = (point.x - lineStart.x) * vector.x + (point.y - lineStart.y) * vector.y;
			if (num != 0f)
			{
				num2 /= num;
			}
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			else if (num2 < 0f)
			{
				num2 = 0f;
			}
			float num3 = lineStart.x + num2 * vector.x;
			float num4 = lineStart.y + num2 * vector.y;
			float num5 = num3 - point.x;
			float num6 = num4 - point.y;
			return Mathf.Sqrt(num5 * num5 + num6 * num6);
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x00032568 File Offset: 0x00030768
		public static float ClosestDistanceToPolygon(Vector2[] points, Vector2 point)
		{
			int num = points.Length;
			if (num <= 1)
			{
				return 0f;
			}
			if (num == 2)
			{
				return SVGMath.ClosestDistanceToLine(points[0], points[1], point);
			}
			float num2 = float.MaxValue;
			Vector2 lineStart = points[0];
			for (int i = 1; i < num; i++)
			{
				float num3 = SVGMath.ClosestDistanceToLine(lineStart, points[i], point);
				if (num3 < num2)
				{
					num2 = num3;
				}
				lineStart = points[i];
			}
			return num2;
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x000325DC File Offset: 0x000307DC
		public static float ClosestPointToPolygon(Vector2[] points, Vector2 point, out Vector2 pointOnLine)
		{
			float num;
			return SVGMath.ClosestPointToPolygon(points, point, out pointOnLine, out num);
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x000325F4 File Offset: 0x000307F4
		public static float ClosestPointToPolygon(Vector2[] points, Vector2 point, out Vector2 pointOnLine, out float pointIndex)
		{
			pointOnLine = Vector2.zero;
			pointIndex = 0f;
			if (points == null)
			{
				return 0f;
			}
			int num = points.Length;
			if (num == 0)
			{
				return 0f;
			}
			if (num == 1)
			{
				pointOnLine = points[0];
				return 0f;
			}
			if (num == 2)
			{
				float result = SVGMath.ClosestPointToLine(points[0], points[1], point, out pointOnLine);
				pointIndex = Vector2.Distance(points[0], pointOnLine) / Vector2.Distance(points[0], points[1]);
				return result;
			}
			float num2 = float.MaxValue;
			Vector2 vector = points[0];
			for (int i = 1; i < num; i++)
			{
				Vector2 vector2;
				float num3 = SVGMath.ClosestPointToLine(vector, points[i], point, out vector2);
				if (num3 < num2)
				{
					pointOnLine = vector2;
					num2 = num3;
					pointIndex = (float)(i - 1) + Vector2.Distance(vector, pointOnLine) / Vector2.Distance(vector, points[i]);
				}
				vector = points[i];
			}
			return num2;
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x000326F0 File Offset: 0x000308F0
		public static float ClosestPointToLine(Vector2 lineStart, Vector2 lineEnd, Vector2 point, out Vector2 pointOnLine)
		{
			Vector2 vector = new Vector2(lineEnd.x - lineStart.x, lineEnd.y - lineStart.y);
			float num = vector.x * vector.x + vector.y * vector.y;
			float num2 = (point.x - lineStart.x) * vector.x + (point.y - lineStart.y) * vector.y;
			if (num != 0f)
			{
				num2 /= num;
			}
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			else if (num2 < 0f)
			{
				num2 = 0f;
			}
			pointOnLine.x = lineStart.x + num2 * vector.x;
			pointOnLine.y = lineStart.y + num2 * vector.y;
			float num3 = pointOnLine.x - point.x;
			float num4 = pointOnLine.y - point.y;
			return Mathf.Sqrt(num3 * num3 + num4 * num4);
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x000327E0 File Offset: 0x000309E0
		public static float ClosestPointToLine(Vector3 lineStart, Vector3 lineEnd, Vector3 point, out Vector3 pointOnLine)
		{
			Vector3 vector = new Vector3(lineEnd.x - lineStart.x, lineEnd.y - lineStart.y, lineEnd.z - lineStart.z);
			float num = vector.x * vector.x + vector.y * vector.y + vector.z * vector.z;
			float num2 = (point.x - lineStart.x) * vector.x + (point.y - lineStart.y) * vector.y + (point.z - lineStart.z) * vector.z;
			if (num != 0f)
			{
				num2 /= num;
			}
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			else if (num2 < 0f)
			{
				num2 = 0f;
			}
			pointOnLine.x = lineStart.x + num2 * vector.x;
			pointOnLine.y = lineStart.y + num2 * vector.y;
			pointOnLine.z = lineStart.z + num2 * vector.z;
			float num3 = pointOnLine.x - point.x;
			float num4 = pointOnLine.y - point.y;
			float num5 = pointOnLine.z - point.z;
			return Mathf.Sqrt(num3 * num3 + num4 * num4 + num5 * num5);
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00032928 File Offset: 0x00030B28
		public static Vector3 DeCasteljau(Vector3 start, Vector3 startHandle, Vector3 endHandle, Vector3 end, float progress)
		{
			Vector3 vector = start + progress * (startHandle - start);
			Vector3 vector2 = startHandle + progress * (endHandle - startHandle);
			Vector3 a = endHandle + progress * (end - endHandle);
			Vector3 vector3 = vector + progress * (vector2 - vector);
			Vector3 a2 = vector2 + progress * (a - vector2);
			return vector3 + progress * (a2 - vector3);
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x000329B4 File Offset: 0x00030BB4
		public static bool ClosestPointsOnTwoLines(out Vector3 closestPointLine1, out Vector3 closestPointLine2, Vector3 line1Start, Vector3 line1End, Vector3 line2Start, Vector3 line2End)
		{
			closestPointLine1 = Vector3.zero;
			closestPointLine2 = Vector3.zero;
			float num = Vector3.Dot(line1End, line1End);
			float num2 = Vector3.Dot(line1End, line2End);
			float num3 = Vector3.Dot(line2End, line2End);
			float num4 = num * num3 - num2 * num2;
			if (num4 != 0f)
			{
				Vector3 rhs = line1Start - line2Start;
				float num5 = Vector3.Dot(line1End, rhs);
				float num6 = Vector3.Dot(line2End, rhs);
				float d = (num2 * num6 - num5 * num3) / num4;
				float d2 = (num * num6 - num5 * num2) / num4;
				closestPointLine1 = line1Start + line1End * d;
				closestPointLine2 = line2Start + line2End * d2;
				return true;
			}
			return false;
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x00032A68 File Offset: 0x00030C68
		public static Vector3 ProjectPointOnLine(Vector3 linePoint, Vector3 lineVec, Vector3 point)
		{
			float d = Vector3.Dot(point - linePoint, lineVec);
			return linePoint + lineVec * d;
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x00032A90 File Offset: 0x00030C90
		public static Vector3 ProjectPointOnLineSegment(Vector3 line1Start, Vector3 line2Start, Vector3 point)
		{
			Vector3 vector = SVGMath.ProjectPointOnLine(line1Start, (line2Start - line1Start).normalized, point);
			int num = SVGMath.PointOnWhichSideOfLineSegment(line1Start, line2Start, vector);
			if (num == 0)
			{
				return vector;
			}
			if (num == 1)
			{
				return line1Start;
			}
			if (num == 2)
			{
				return line2Start;
			}
			return Vector3.zero;
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00032AD4 File Offset: 0x00030CD4
		public static Vector3 ProjectPointOnPlane(Vector3 planeNormal, Vector3 planePoint, Vector3 point)
		{
			float num = SVGMath.SignedDistancePlanePoint(planeNormal, planePoint, point);
			num *= -1f;
			Vector3 b = SVGMath.SetVectorLength(planeNormal, num);
			return point + b;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00032B01 File Offset: 0x00030D01
		public static Vector3 ProjectVectorOnPlane(Vector3 planeNormal, Vector3 vector)
		{
			return vector - Vector3.Dot(vector, planeNormal) * planeNormal;
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x00032B16 File Offset: 0x00030D16
		public static float SignedDistancePlanePoint(Vector3 planeNormal, Vector3 planePoint, Vector3 point)
		{
			return Vector3.Dot(planeNormal, point - planePoint);
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00032B25 File Offset: 0x00030D25
		public static float SignedDotProduct(Vector3 vectorA, Vector3 vectorB, Vector3 normal)
		{
			return Vector3.Dot(Vector3.Cross(normal, vectorA), vectorB);
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x00032B34 File Offset: 0x00030D34
		public static float SignedVectorAngle(Vector3 referenceVector, Vector3 otherVector, Vector3 normal)
		{
			Vector3 lhs = Vector3.Cross(normal, referenceVector);
			return Vector3.Angle(referenceVector, otherVector) * Mathf.Sign(Vector3.Dot(lhs, otherVector));
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x00032B60 File Offset: 0x00030D60
		public static float AngleVectorPlane(Vector3 vector, Vector3 normal)
		{
			float num = (float)Math.Acos((double)Vector3.Dot(vector, normal));
			return 1.5707964f - num;
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00032B84 File Offset: 0x00030D84
		public static float DotProductAngle(Vector3 vec1, Vector3 vec2)
		{
			double num = (double)Vector3.Dot(vec1, vec2);
			if (num < -1.0)
			{
				num = -1.0;
			}
			if (num > 1.0)
			{
				num = 1.0;
			}
			return (float)Math.Acos(num);
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x00032BD0 File Offset: 0x00030DD0
		public static void PlaneFrom3Points(out Vector3 planeNormal, out Vector3 planePoint, Vector3 pointA, Vector3 pointB, Vector3 pointC)
		{
			planeNormal = Vector3.zero;
			planePoint = Vector3.zero;
			Vector3 vector = pointB - pointA;
			Vector3 vector2 = pointC - pointA;
			planeNormal = Vector3.Normalize(Vector3.Cross(vector, vector2));
			Vector3 vector3 = pointA + vector / 2f;
			Vector3 vector4 = pointA + vector2 / 2f;
			Vector3 line1End = pointC - vector3;
			Vector3 line2End = pointB - vector4;
			Vector3 vector5;
			SVGMath.ClosestPointsOnTwoLines(out planePoint, out vector5, vector3, line1End, vector4, line2End);
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x00032C5C File Offset: 0x00030E5C
		public static Vector3 GetForwardVector(Quaternion q)
		{
			return q * Vector3.forward;
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x00032C69 File Offset: 0x00030E69
		public static Vector3 GetUpVector(Quaternion q)
		{
			return q * Vector3.up;
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00032C76 File Offset: 0x00030E76
		public static Vector3 GetRightVector(Quaternion q)
		{
			return q * Vector3.right;
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00032C83 File Offset: 0x00030E83
		public static Quaternion QuaternionFromMatrix(Matrix4x4 m)
		{
			return Quaternion.LookRotation(m.GetColumn(2), m.GetColumn(1));
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00032CA4 File Offset: 0x00030EA4
		public static Vector3 PositionFromMatrix(Matrix4x4 m)
		{
			Vector4 column = m.GetColumn(3);
			return new Vector3(column.x, column.y, column.z);
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00032CD4 File Offset: 0x00030ED4
		public static void LookRotationExtended(ref GameObject gameObjectInOut, Vector3 alignWithVector, Vector3 alignWithNormal, Vector3 customForward, Vector3 customUp)
		{
			Quaternion lhs = Quaternion.LookRotation(alignWithVector, alignWithNormal);
			Quaternion rotation = Quaternion.LookRotation(customForward, customUp);
			gameObjectInOut.transform.rotation = lhs * Quaternion.Inverse(rotation);
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00032D0C File Offset: 0x00030F0C
		public static void PreciseAlign(ref GameObject gameObjectInOut, Vector3 alignWithVector, Vector3 alignWithNormal, Vector3 alignWithPosition, Vector3 triangleForward, Vector3 triangleNormal, Vector3 trianglePosition)
		{
			SVGMath.LookRotationExtended(ref gameObjectInOut, alignWithVector, alignWithNormal, triangleForward, triangleNormal);
			Vector3 b = gameObjectInOut.transform.TransformPoint(trianglePosition);
			Vector3 translation = alignWithPosition - b;
			gameObjectInOut.transform.Translate(translation, Space.World);
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00032D4A File Offset: 0x00030F4A
		private void VectorsToTransform(ref GameObject gameObjectInOut, Vector3 positionVector, Vector3 directionVector, Vector3 normalVector)
		{
			gameObjectInOut.transform.position = positionVector;
			gameObjectInOut.transform.rotation = Quaternion.LookRotation(directionVector, normalVector);
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00032D70 File Offset: 0x00030F70
		public static int PointOnWhichSideOfLineSegment(Vector3 line1Start, Vector3 line2Start, Vector3 point)
		{
			Vector3 rhs = line2Start - line1Start;
			Vector3 lhs = point - line1Start;
			if (Vector3.Dot(lhs, rhs) <= 0f)
			{
				return 1;
			}
			if (lhs.magnitude <= rhs.magnitude)
			{
				return 0;
			}
			return 2;
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x00032DB0 File Offset: 0x00030FB0
		public static float MouseDistanceToLine(Vector3 line1Start, Vector3 line2Start)
		{
			Camera main = Camera.main;
			Vector3 mousePosition = global::Input.mousePosition;
			Vector3 line1Start2 = main.WorldToScreenPoint(line1Start);
			Vector3 line2Start2 = main.WorldToScreenPoint(line2Start);
			Vector3 vector = SVGMath.ProjectPointOnLineSegment(line1Start2, line2Start2, mousePosition);
			vector = new Vector3(vector.x, vector.y, 0f);
			return (vector - mousePosition).magnitude;
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x00032E08 File Offset: 0x00031008
		public static float MouseDistanceToCircle(Vector3 point, float radius)
		{
			Camera main = Camera.main;
			Vector3 mousePosition = global::Input.mousePosition;
			Vector3 vector = main.WorldToScreenPoint(point);
			vector = new Vector3(vector.x, vector.y, 0f);
			return (vector - mousePosition).magnitude - radius;
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x00032E50 File Offset: 0x00031050
		public static bool IsLineInRectangle(Vector3 line1Start, Vector3 line2Start, Vector3 rectA, Vector3 rectB, Vector3 rectC, Vector3 rectD)
		{
			bool flag = false;
			bool flag2 = SVGMath.IsPointInRectangle(line1Start, rectA, rectC, rectB, rectD);
			if (!flag2)
			{
				flag = SVGMath.IsPointInRectangle(line2Start, rectA, rectC, rectB, rectD);
			}
			if (!flag2 && !flag)
			{
				bool flag3 = SVGMath.AreLineSegmentsCrossing(line1Start, line2Start, rectA, rectB);
				bool flag4 = SVGMath.AreLineSegmentsCrossing(line1Start, line2Start, rectB, rectC);
				bool flag5 = SVGMath.AreLineSegmentsCrossing(line1Start, line2Start, rectC, rectD);
				bool flag6 = SVGMath.AreLineSegmentsCrossing(line1Start, line2Start, rectD, rectA);
				return flag3 || flag4 || flag5 || flag6;
			}
			return true;
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x00032EB8 File Offset: 0x000310B8
		public static bool IsPointInRectangle(Vector3 point, Vector3 rectA, Vector3 rectC, Vector3 rectB, Vector3 rectD)
		{
			Vector3 vector = rectC - rectA;
			float size = -(vector.magnitude / 2f);
			vector = SVGMath.AddVectorLength(vector, size);
			Vector3 linePoint = rectA + vector;
			Vector3 vector2 = rectB - rectA;
			float num = vector2.magnitude / 2f;
			Vector3 vector3 = rectD - rectA;
			float num2 = vector3.magnitude / 2f;
			float magnitude = (SVGMath.ProjectPointOnLine(linePoint, vector2.normalized, point) - point).magnitude;
			return (SVGMath.ProjectPointOnLine(linePoint, vector3.normalized, point) - point).magnitude <= num && magnitude <= num2;
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00032F60 File Offset: 0x00031160
		public static bool AreLineSegmentsCrossing(Vector3 pointA1, Vector3 pointA2, Vector3 pointB1, Vector3 pointB2)
		{
			Vector3 vector = pointA2 - pointA1;
			Vector3 vector2 = pointB2 - pointB1;
			Vector3 point;
			Vector3 point2;
			if (SVGMath.ClosestPointsOnTwoLines(out point, out point2, pointA1, vector.normalized, pointB1, vector2.normalized))
			{
				bool flag = SVGMath.PointOnWhichSideOfLineSegment(pointA1, pointA2, point) != 0;
				int num = SVGMath.PointOnWhichSideOfLineSegment(pointB1, pointB2, point2);
				return !flag && num == 0;
			}
			return false;
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x00032FB4 File Offset: 0x000311B4
		public static Bounds GetWorldBounds(Transform transform, Bounds bounds)
		{
			Bounds result = new Bounds(transform.TransformPoint(bounds.center), Vector3.zero);
			Vector3 b = new Vector3(bounds.size.x, bounds.size.y, bounds.size.z) * 0.5f;
			Vector3 b2 = new Vector3(-bounds.size.x, bounds.size.y, bounds.size.z) * 0.5f;
			Vector3 b3 = new Vector3(bounds.size.x, -bounds.size.y, bounds.size.z) * 0.5f;
			Vector3 b4 = new Vector3(-bounds.size.x, -bounds.size.y, bounds.size.z) * 0.5f;
			Vector3 b5 = new Vector3(bounds.size.x, bounds.size.y, -bounds.size.z) * 0.5f;
			Vector3 b6 = new Vector3(-bounds.size.x, bounds.size.y, -bounds.size.z) * 0.5f;
			Vector3 b7 = new Vector3(bounds.size.x, -bounds.size.y, -bounds.size.z) * 0.5f;
			Vector3 b8 = new Vector3(-bounds.size.x, -bounds.size.y, -bounds.size.z) * 0.5f;
			result.Encapsulate(transform.TransformPoint(bounds.center + b));
			result.Encapsulate(transform.TransformPoint(bounds.center + b2));
			result.Encapsulate(transform.TransformPoint(bounds.center + b3));
			result.Encapsulate(transform.TransformPoint(bounds.center + b4));
			result.Encapsulate(transform.TransformPoint(bounds.center + b5));
			result.Encapsulate(transform.TransformPoint(bounds.center + b6));
			result.Encapsulate(transform.TransformPoint(bounds.center + b7));
			result.Encapsulate(transform.TransformPoint(bounds.center + b8));
			return result;
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00033264 File Offset: 0x00031464
		public static bool IsPolygonsIntersecting(Vector2[] a, Vector2[] b)
		{
			foreach (Vector2[] array2 in new Vector2[][]
			{
				a,
				b
			})
			{
				for (int j = 0; j < array2.Length; j++)
				{
					int num = (j + 1) % array2.Length;
					Vector2 vector = array2[j];
					Vector2 vector2 = array2[num];
					Vector2 vector3 = new Vector2(vector2.y - vector.y, vector.x - vector2.x);
					float num2 = float.MaxValue;
					float num3 = float.MinValue;
					foreach (Vector2 vector4 in a)
					{
						float num4 = vector3.x * vector4.x + vector3.y * vector4.y;
						if (num4 < num2)
						{
							num2 = num4;
						}
						if (num4 > num3)
						{
							num3 = num4;
						}
					}
					float num5 = float.MaxValue;
					float num6 = float.MinValue;
					foreach (Vector2 vector5 in b)
					{
						float num7 = vector3.x * vector5.x + vector3.y * vector5.y;
						if (num7 < num5)
						{
							num5 = num7;
						}
						if (num7 > num6)
						{
							num6 = num7;
						}
					}
					if (num3 < num5 || num6 < num2)
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x000333C4 File Offset: 0x000315C4
		public static bool PolygonContainsPoint(Vector2[] polyPoints, Vector2 point)
		{
			int num = polyPoints.Length;
			int num2 = num - 1;
			bool flag = false;
			int i = 0;
			while (i < num)
			{
				if (((polyPoints[i].y <= point.y && point.y < polyPoints[num2].y) || (polyPoints[num2].y <= point.y && point.y < polyPoints[i].y)) && point.x < (polyPoints[num2].x - polyPoints[i].x) * (point.y - polyPoints[i].y) / (polyPoints[num2].y - polyPoints[i].y) + polyPoints[i].x)
				{
					flag = !flag;
				}
				num2 = i++;
			}
			return flag;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000334A4 File Offset: 0x000316A4
		public static bool PolygonContainsPoint(List<Vector2> polyPoints, Vector2 point)
		{
			int count = polyPoints.Count;
			int index = count - 1;
			bool flag = false;
			int i = 0;
			while (i < count)
			{
				if (((polyPoints[i].y <= point.y && point.y < polyPoints[index].y) || (polyPoints[index].y <= point.y && point.y < polyPoints[i].y)) && point.x < (polyPoints[index].x - polyPoints[i].x) * (point.y - polyPoints[i].y) / (polyPoints[index].y - polyPoints[i].y) + polyPoints[i].x)
				{
					flag = !flag;
				}
				index = i++;
			}
			return flag;
		}
	}
}
