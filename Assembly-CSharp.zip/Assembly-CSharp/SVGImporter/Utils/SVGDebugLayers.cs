﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000106 RID: 262
	public class SVGDebugLayers : MonoBehaviour
	{
		// Token: 0x06000885 RID: 2181 RVA: 0x00003D07 File Offset: 0x00001F07
		private void Start()
		{
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00003D07 File Offset: 0x00001F07
		private void Update()
		{
		}
	}
}
