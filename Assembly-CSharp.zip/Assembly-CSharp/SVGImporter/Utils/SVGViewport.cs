﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000F9 RID: 249
	public class SVGViewport
	{
		// Token: 0x060007CA RID: 1994 RVA: 0x00030C98 File Offset: 0x0002EE98
		public static SVGViewport.MeetOrSlice GetMeetOrSliceFromStrings(string[] inputStrings)
		{
			if (inputStrings == null || inputStrings.Length == 0)
			{
				return SVGViewport.MeetOrSlice.Meet;
			}
			for (int i = 0; i < inputStrings.Length; i++)
			{
				if (!string.IsNullOrEmpty(inputStrings[i]))
				{
					string a = inputStrings[i].ToLower();
					if (a == "meet")
					{
						return SVGViewport.MeetOrSlice.Meet;
					}
					if (a == "slice")
					{
						return SVGViewport.MeetOrSlice.Slice;
					}
				}
			}
			return SVGViewport.MeetOrSlice.Meet;
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x00030CF0 File Offset: 0x0002EEF0
		public static SVGViewport.MeetOrSlice GetMeetOrSliceFromString(string inputText)
		{
			if (string.IsNullOrEmpty(inputText))
			{
				return SVGViewport.MeetOrSlice.Meet;
			}
			string a = inputText.ToLower();
			if (a == "meet")
			{
				return SVGViewport.MeetOrSlice.Meet;
			}
			if (!(a == "slice"))
			{
				return SVGViewport.MeetOrSlice.Meet;
			}
			return SVGViewport.MeetOrSlice.Slice;
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x00030D2F File Offset: 0x0002EF2F
		public static string GetStringFromMeetOrSlice(SVGViewport.MeetOrSlice meetOrSlice)
		{
			if (meetOrSlice == SVGViewport.MeetOrSlice.Meet)
			{
				return "meet";
			}
			if (meetOrSlice != SVGViewport.MeetOrSlice.Slice)
			{
				return "meet";
			}
			return "slice";
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x00030D4C File Offset: 0x0002EF4C
		public static SVGViewport.Align GetAlignFromStrings(string[] inputStrings)
		{
			if (inputStrings == null || inputStrings.Length == 0)
			{
				return SVGViewport.Align.xMidYMid;
			}
			for (int i = 0; i < inputStrings.Length; i++)
			{
				if (!string.IsNullOrEmpty(inputStrings[i]))
				{
					string text = inputStrings[i].ToLower();
					uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
					if (num <= 3156277968U)
					{
						if (num <= 1236531748U)
						{
							if (num != 1135866034U)
							{
								if (num == 1236531748U)
								{
									if (text == "xminymin")
									{
										return SVGViewport.Align.xMinYMin;
									}
								}
							}
							else if (text == "xminymid")
							{
								return SVGViewport.Align.xMinYMid;
							}
						}
						else if (num != 1472698342U)
						{
							if (num != 2913447899U)
							{
								if (num == 3156277968U)
								{
									if (text == "xmidymax")
									{
										return SVGViewport.Align.xMidYMax;
									}
								}
							}
							else if (text == "none")
							{
								return SVGViewport.Align.None;
							}
						}
						else if (text == "xminymax")
						{
							return SVGViewport.Align.xMinYMax;
						}
					}
					else if (num <= 3486015172U)
					{
						if (num != 3356226300U)
						{
							if (num == 3486015172U)
							{
								if (text == "xmaxymax")
								{
									return SVGViewport.Align.xMaxYMax;
								}
							}
						}
						else if (text == "xmidymid")
						{
							return SVGViewport.Align.xMidYMid;
						}
					}
					else if (num != 3524002490U)
					{
						if (num != 3719621910U)
						{
							if (num == 3820287624U)
							{
								if (text == "xmaxymid")
								{
									return SVGViewport.Align.xMaxYMid;
								}
							}
						}
						else if (text == "xmaxymin")
						{
							return SVGViewport.Align.xMaxYMin;
						}
					}
					else if (text == "xmidymin")
					{
						return SVGViewport.Align.xMidYMin;
					}
				}
			}
			return SVGViewport.Align.xMidYMid;
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x00030ED4 File Offset: 0x0002F0D4
		public static SVGViewport.Align GetAlignFromString(string inputText)
		{
			if (string.IsNullOrEmpty(inputText))
			{
				return SVGViewport.Align.xMidYMid;
			}
			string text = inputText.ToLower();
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
			if (num <= 3156277968U)
			{
				if (num <= 1236531748U)
				{
					if (num != 1135866034U)
					{
						if (num == 1236531748U)
						{
							if (text == "xminymin")
							{
								return SVGViewport.Align.xMinYMin;
							}
						}
					}
					else if (text == "xminymid")
					{
						return SVGViewport.Align.xMinYMid;
					}
				}
				else if (num != 1472698342U)
				{
					if (num != 2913447899U)
					{
						if (num == 3156277968U)
						{
							if (text == "xmidymax")
							{
								return SVGViewport.Align.xMidYMax;
							}
						}
					}
					else if (text == "none")
					{
						return SVGViewport.Align.None;
					}
				}
				else if (text == "xminymax")
				{
					return SVGViewport.Align.xMinYMax;
				}
			}
			else if (num <= 3486015172U)
			{
				if (num != 3356226300U)
				{
					if (num == 3486015172U)
					{
						if (text == "xmaxymax")
						{
							return SVGViewport.Align.xMaxYMax;
						}
					}
				}
				else if (text == "xmidymid")
				{
					return SVGViewport.Align.xMidYMid;
				}
			}
			else if (num != 3524002490U)
			{
				if (num != 3719621910U)
				{
					if (num == 3820287624U)
					{
						if (text == "xmaxymid")
						{
							return SVGViewport.Align.xMaxYMid;
						}
					}
				}
				else if (text == "xmaxymin")
				{
					return SVGViewport.Align.xMaxYMin;
				}
			}
			else if (text == "xmidymin")
			{
				return SVGViewport.Align.xMidYMin;
			}
			return SVGViewport.Align.xMidYMid;
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x0003103C File Offset: 0x0002F23C
		public static string GetStringFromAlign(SVGViewport.Align align)
		{
			switch (align)
			{
			case SVGViewport.Align.None:
				return "none";
			case SVGViewport.Align.xMinYMin:
				return "xminymin";
			case SVGViewport.Align.xMidYMin:
				return "xmidymin";
			case SVGViewport.Align.xMaxYMin:
				return "xmaxymin";
			case SVGViewport.Align.xMinYMid:
				return "xminymid";
			case SVGViewport.Align.xMidYMid:
				return "xmidymid";
			case SVGViewport.Align.xMaxYMid:
				return "xmaxymid";
			case SVGViewport.Align.xMinYMax:
				return "xminymax";
			case SVGViewport.Align.xMidYMax:
				return "xmidymax";
			case SVGViewport.Align.xMaxYMax:
				return "xmaxymax";
			default:
				return null;
			}
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x000310B8 File Offset: 0x0002F2B8
		public static Rect GetViewport(Rect viewport, Rect content, SVGViewport.Align viewportAlign = SVGViewport.Align.xMidYMid, SVGViewport.MeetOrSlice viewportMeetOrSlice = SVGViewport.MeetOrSlice.Meet)
		{
			viewport.x -= content.x;
			viewport.y -= content.y;
			if (viewportAlign != SVGViewport.Align.None)
			{
				Vector2 vector = new Vector2(viewport.width / content.width, viewport.height / content.height);
				Vector2 vector2;
				if (viewportMeetOrSlice == SVGViewport.MeetOrSlice.Meet)
				{
					float num = Mathf.Min(vector.x, vector.y);
					vector2.x = content.width * num;
					vector2.y = content.height * num;
					Vector2 vector3 = SVGViewport.Getalign(viewport, vector2, viewportAlign);
					return new Rect(vector3.x, vector3.y, vector2.x, vector2.y);
				}
				if (viewportMeetOrSlice == SVGViewport.MeetOrSlice.Slice)
				{
					float num = Mathf.Max(vector.x, vector.y);
					vector2.x = content.width * num;
					vector2.y = content.height * num;
					Vector2 vector3 = SVGViewport.Getalign(viewport, vector2, viewportAlign);
					return new Rect(vector3.x, vector3.y, vector2.x, vector2.y);
				}
			}
			return viewport;
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x000311DC File Offset: 0x0002F3DC
		protected static Vector2 Getalign(Rect viewport, Vector2 size, SVGViewport.Align align)
		{
			switch (align)
			{
			case SVGViewport.Align.xMinYMin:
				return new Vector2(viewport.x, viewport.y);
			case SVGViewport.Align.xMidYMin:
				return new Vector2(viewport.x + (viewport.width - size.x) * 0.5f, viewport.y);
			case SVGViewport.Align.xMaxYMin:
				return new Vector2(viewport.x + (viewport.width - size.x), viewport.y);
			case SVGViewport.Align.xMinYMid:
				return new Vector2(viewport.x, viewport.y + (viewport.height - size.y) * 0.5f);
			case SVGViewport.Align.xMidYMid:
				return new Vector2(viewport.x + (viewport.width - size.x) * 0.5f, viewport.y + (viewport.height - size.y) * 0.5f);
			case SVGViewport.Align.xMaxYMid:
				return new Vector2(viewport.x + (viewport.width - size.x), viewport.y + (viewport.height - size.y) * 0.5f);
			case SVGViewport.Align.xMinYMax:
				return new Vector2(viewport.x, viewport.y + (viewport.height - size.y));
			case SVGViewport.Align.xMidYMax:
				return new Vector2(viewport.x + (viewport.width - size.x) * 0.5f, viewport.y + (viewport.height - size.y));
			case SVGViewport.Align.xMaxYMax:
				return new Vector2(viewport.x + (viewport.width - size.x), viewport.y + (viewport.height - size.y));
			default:
				return new Vector2(viewport.x, viewport.y);
			}
		}

		// Token: 0x040007EA RID: 2026
		private const string None = "none";

		// Token: 0x040007EB RID: 2027
		private const string xMinYMin = "xminymin";

		// Token: 0x040007EC RID: 2028
		private const string xMidYMin = "xmidymin";

		// Token: 0x040007ED RID: 2029
		private const string xMaxYMin = "xmaxymin";

		// Token: 0x040007EE RID: 2030
		private const string xMinYMid = "xminymid";

		// Token: 0x040007EF RID: 2031
		private const string xMidYMid = "xmidymid";

		// Token: 0x040007F0 RID: 2032
		private const string xMaxYMid = "xmaxymid";

		// Token: 0x040007F1 RID: 2033
		private const string xMinYMax = "xminymax";

		// Token: 0x040007F2 RID: 2034
		private const string xMidYMax = "xmidymax";

		// Token: 0x040007F3 RID: 2035
		private const string xMaxYMax = "xmaxymax";

		// Token: 0x040007F4 RID: 2036
		private const string Meet = "meet";

		// Token: 0x040007F5 RID: 2037
		private const string Slice = "slice";

		// Token: 0x0200034F RID: 847
		public enum Align
		{
			// Token: 0x0400123C RID: 4668
			None,
			// Token: 0x0400123D RID: 4669
			xMinYMin,
			// Token: 0x0400123E RID: 4670
			xMidYMin,
			// Token: 0x0400123F RID: 4671
			xMaxYMin,
			// Token: 0x04001240 RID: 4672
			xMinYMid,
			// Token: 0x04001241 RID: 4673
			xMidYMid,
			// Token: 0x04001242 RID: 4674
			xMaxYMid,
			// Token: 0x04001243 RID: 4675
			xMinYMax,
			// Token: 0x04001244 RID: 4676
			xMidYMax,
			// Token: 0x04001245 RID: 4677
			xMaxYMax
		}

		// Token: 0x02000350 RID: 848
		public enum MeetOrSlice
		{
			// Token: 0x04001247 RID: 4679
			Meet,
			// Token: 0x04001248 RID: 4680
			Slice
		}
	}
}
