﻿using System;
using System.Collections.Generic;

namespace SVGImporter.Utils
{
	// Token: 0x020000F4 RID: 244
	public class LiteStack<T>
	{
		// Token: 0x060007AF RID: 1967 RVA: 0x0002F26C File Offset: 0x0002D46C
		public void Push(T obj)
		{
			this.idx++;
			if (this.idx > this.stack.Count)
			{
				this.stack.Add(obj);
				return;
			}
			this.stack[this.idx - 1] = obj;
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x0002F2BC File Offset: 0x0002D4BC
		public T Pop()
		{
			T result = this.Peek();
			if (this.idx > 0)
			{
				this.idx--;
				this.stack[this.idx] = default(T);
			}
			return result;
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x0002F300 File Offset: 0x0002D500
		public T Peek()
		{
			if (this.idx > 0)
			{
				return this.stack[this.idx - 1];
			}
			return default(T);
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x0002F333 File Offset: 0x0002D533
		public int Count
		{
			get
			{
				return this.idx;
			}
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x0002F33B File Offset: 0x0002D53B
		public void Clear()
		{
			this.stack.Clear();
			this.idx = 0;
		}

		// Token: 0x040007E2 RID: 2018
		private int idx;

		// Token: 0x040007E3 RID: 2019
		private List<T> stack = new List<T>();
	}
}
