﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x020000F6 RID: 246
	public struct SVGColorExtractor
	{
		// Token: 0x060007B6 RID: 1974 RVA: 0x0002F36A File Offset: 0x0002D56A
		private static Color change(int r, int g, int b)
		{
			return new Color((float)r / 255f, (float)g / 255f, (float)b / 255f);
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x0002F389 File Offset: 0x0002D589
		public static Color ConstColor(string name)
		{
			if (name.Length == 0)
			{
				return Color.black;
			}
			return SVGColorExtractor.ConstantColors[name.ToLower()];
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x0002F3A9 File Offset: 0x0002D5A9
		public static bool IsConstName(string textColor)
		{
			return textColor.Length != 0 && textColor[0] != '#' && SVGColorExtractor.ConstantColors.ContainsKey(textColor.ToLower());
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0002F3D2 File Offset: 0x0002D5D2
		public static bool IsHexColor(string colorStr)
		{
			return colorStr.Length > 0 && colorStr[0] == '#' && (colorStr.Length == 4 || colorStr.Length == 7);
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x0002F3FD File Offset: 0x0002D5FD
		public static bool IsRGBColor(string colorStr)
		{
			return colorStr.Length > 0 && colorStr.ToLower().Contains("rgb");
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x0002F420 File Offset: 0x0002D620
		private static int ParseHexDigit(char c)
		{
			int num = (int)(c - '0');
			if (num >= 0 && num < 10)
			{
				return num;
			}
			num = (int)(c - 'a');
			if (num >= 0 && num < 6)
			{
				return 10 + num;
			}
			num = (int)(c - 'A');
			if (num >= 0 && num < 6)
			{
				return 10 + num;
			}
			return 0;
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x0002F464 File Offset: 0x0002D664
		public static Color HexColor(string colorStr)
		{
			int r = 0;
			int g = 0;
			int b = 0;
			if (colorStr.Length > 0 && colorStr[0] == '#')
			{
				if (colorStr.Length == 4)
				{
					int num = SVGColorExtractor.ParseHexDigit(colorStr[1]);
					r = num * 16 + num;
					num = SVGColorExtractor.ParseHexDigit(colorStr[2]);
					g = num * 16 + num;
					num = SVGColorExtractor.ParseHexDigit(colorStr[3]);
					b = num * 16 + num;
				}
				else if (colorStr.Length == 7)
				{
					r = SVGColorExtractor.ParseHexDigit(colorStr[1]) * 16 + SVGColorExtractor.ParseHexDigit(colorStr[2]);
					g = SVGColorExtractor.ParseHexDigit(colorStr[3]) * 16 + SVGColorExtractor.ParseHexDigit(colorStr[4]);
					b = SVGColorExtractor.ParseHexDigit(colorStr[5]) * 16 + SVGColorExtractor.ParseHexDigit(colorStr[6]);
				}
			}
			return SVGColorExtractor.change(r, g, b);
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x0002F540 File Offset: 0x0002D740
		public static Color RGBColor(string colorStr)
		{
			int r = 0;
			int g = 0;
			int b = 0;
			if (colorStr.Length > 0)
			{
				int num = colorStr.IndexOf("rgb");
				if (num != -1)
				{
					colorStr = colorStr.Substring(num + 3);
					if (!string.IsNullOrEmpty(colorStr))
					{
						colorStr = colorStr.Replace("(", "").Replace(")", "");
						string[] array = colorStr.Split(new char[]
						{
							','
						});
						if (array != null && array.Length != 0)
						{
							r = SVGColorExtractor.GetColorValue(array[0]);
							if (array.Length > 1)
							{
								g = SVGColorExtractor.GetColorValue(array[1]);
							}
							if (array.Length > 2)
							{
								b = SVGColorExtractor.GetColorValue(array[2]);
							}
						}
					}
				}
			}
			return SVGColorExtractor.change(r, g, b);
		}

		// Token: 0x060007BE RID: 1982 RVA: 0x0002F5F4 File Offset: 0x0002D7F4
		private static int GetColorValue(string value)
		{
			float num = 0f;
			if (value.Contains("%"))
			{
				float.TryParse(value.Replace("%", ""), out num);
				num *= 2.56f;
			}
			else
			{
				float.TryParse(value, out num);
			}
			return Mathf.RoundToInt(num);
		}

		// Token: 0x040007E4 RID: 2020
		public static Dictionary<string, Color> ConstantColors = new Dictionary<string, Color>
		{
			{
				"aliceblue",
				SVGColorExtractor.change(240, 248, 255)
			},
			{
				"antiquewhite",
				SVGColorExtractor.change(250, 235, 215)
			},
			{
				"aqua",
				SVGColorExtractor.change(0, 255, 255)
			},
			{
				"aquamarine",
				SVGColorExtractor.change(127, 255, 212)
			},
			{
				"azure",
				SVGColorExtractor.change(240, 255, 255)
			},
			{
				"beige",
				SVGColorExtractor.change(245, 245, 220)
			},
			{
				"bisque",
				SVGColorExtractor.change(255, 228, 196)
			},
			{
				"black",
				SVGColorExtractor.change(0, 0, 0)
			},
			{
				"blanchedalmond",
				SVGColorExtractor.change(255, 235, 205)
			},
			{
				"blue",
				SVGColorExtractor.change(0, 0, 255)
			},
			{
				"blueviolet",
				SVGColorExtractor.change(138, 43, 226)
			},
			{
				"brown",
				SVGColorExtractor.change(165, 42, 42)
			},
			{
				"burlywood",
				SVGColorExtractor.change(222, 184, 135)
			},
			{
				"cadetblue",
				SVGColorExtractor.change(95, 158, 160)
			},
			{
				"chartreuse",
				SVGColorExtractor.change(127, 255, 0)
			},
			{
				"chocolate",
				SVGColorExtractor.change(210, 105, 30)
			},
			{
				"coral",
				SVGColorExtractor.change(255, 127, 80)
			},
			{
				"cornflowerblue",
				SVGColorExtractor.change(100, 149, 237)
			},
			{
				"cornsilk",
				SVGColorExtractor.change(255, 248, 220)
			},
			{
				"crimson",
				SVGColorExtractor.change(220, 20, 60)
			},
			{
				"cyan",
				SVGColorExtractor.change(0, 255, 255)
			},
			{
				"darkblue",
				SVGColorExtractor.change(0, 0, 139)
			},
			{
				"darkcyan",
				SVGColorExtractor.change(0, 139, 139)
			},
			{
				"darkgoldenrod",
				SVGColorExtractor.change(184, 134, 11)
			},
			{
				"darkgray",
				SVGColorExtractor.change(169, 169, 169)
			},
			{
				"darkgreen",
				SVGColorExtractor.change(0, 100, 0)
			},
			{
				"darkgrey",
				SVGColorExtractor.change(169, 169, 169)
			},
			{
				"darkkhaki",
				SVGColorExtractor.change(189, 183, 107)
			},
			{
				"darkmagenta",
				SVGColorExtractor.change(139, 0, 139)
			},
			{
				"darkolivegreen",
				SVGColorExtractor.change(85, 107, 47)
			},
			{
				"darkorange",
				SVGColorExtractor.change(255, 140, 0)
			},
			{
				"darkorchid",
				SVGColorExtractor.change(153, 50, 204)
			},
			{
				"darkred",
				SVGColorExtractor.change(139, 0, 0)
			},
			{
				"darksalmon",
				SVGColorExtractor.change(233, 150, 122)
			},
			{
				"darkseagreen",
				SVGColorExtractor.change(143, 188, 143)
			},
			{
				"darkslateblue",
				SVGColorExtractor.change(72, 61, 139)
			},
			{
				"darkslategray",
				SVGColorExtractor.change(47, 79, 79)
			},
			{
				"darkslategrey",
				SVGColorExtractor.change(47, 79, 79)
			},
			{
				"darkturquoise",
				SVGColorExtractor.change(0, 206, 209)
			},
			{
				"darkviolet",
				SVGColorExtractor.change(148, 0, 211)
			},
			{
				"deeppink",
				SVGColorExtractor.change(255, 20, 147)
			},
			{
				"deepskyblue",
				SVGColorExtractor.change(0, 191, 255)
			},
			{
				"dimgray",
				SVGColorExtractor.change(105, 105, 105)
			},
			{
				"dimgrey",
				SVGColorExtractor.change(105, 105, 105)
			},
			{
				"dodgerblue",
				SVGColorExtractor.change(30, 144, 255)
			},
			{
				"firebrick",
				SVGColorExtractor.change(178, 34, 34)
			},
			{
				"floralwhite",
				SVGColorExtractor.change(255, 250, 240)
			},
			{
				"forestgreen",
				SVGColorExtractor.change(34, 139, 34)
			},
			{
				"fuchsia",
				SVGColorExtractor.change(255, 0, 255)
			},
			{
				"gainsboro",
				SVGColorExtractor.change(220, 220, 220)
			},
			{
				"ghostwhite",
				SVGColorExtractor.change(248, 248, 255)
			},
			{
				"gold",
				SVGColorExtractor.change(255, 215, 0)
			},
			{
				"goldenrod",
				SVGColorExtractor.change(218, 165, 32)
			},
			{
				"gray",
				SVGColorExtractor.change(128, 128, 128)
			},
			{
				"grey",
				SVGColorExtractor.change(128, 128, 128)
			},
			{
				"green",
				SVGColorExtractor.change(0, 128, 0)
			},
			{
				"greenyellow",
				SVGColorExtractor.change(173, 255, 47)
			},
			{
				"honeydew",
				SVGColorExtractor.change(240, 255, 240)
			},
			{
				"hotpink",
				SVGColorExtractor.change(255, 105, 180)
			},
			{
				"indianred",
				SVGColorExtractor.change(205, 92, 92)
			},
			{
				"indigo",
				SVGColorExtractor.change(75, 0, 130)
			},
			{
				"ivory",
				SVGColorExtractor.change(255, 255, 240)
			},
			{
				"khaki",
				SVGColorExtractor.change(240, 230, 140)
			},
			{
				"lavender",
				SVGColorExtractor.change(230, 230, 250)
			},
			{
				"lavenderblush",
				SVGColorExtractor.change(255, 240, 245)
			},
			{
				"lawngreen",
				SVGColorExtractor.change(124, 252, 0)
			},
			{
				"lemonchiffon",
				SVGColorExtractor.change(255, 250, 205)
			},
			{
				"lightblue",
				SVGColorExtractor.change(173, 216, 230)
			},
			{
				"lightcoral",
				SVGColorExtractor.change(240, 128, 128)
			},
			{
				"lightcyan",
				SVGColorExtractor.change(224, 255, 255)
			},
			{
				"lightgoldenrodyellow",
				SVGColorExtractor.change(250, 250, 210)
			},
			{
				"lightgray",
				SVGColorExtractor.change(211, 211, 211)
			},
			{
				"lightgreen",
				SVGColorExtractor.change(144, 238, 144)
			},
			{
				"lightgrey",
				SVGColorExtractor.change(211, 211, 211)
			},
			{
				"lightpink",
				SVGColorExtractor.change(255, 182, 193)
			},
			{
				"lightsalmon",
				SVGColorExtractor.change(255, 160, 122)
			},
			{
				"lightseagreen",
				SVGColorExtractor.change(32, 178, 170)
			},
			{
				"lightskyblue",
				SVGColorExtractor.change(135, 206, 250)
			},
			{
				"lightslategray",
				SVGColorExtractor.change(119, 136, 153)
			},
			{
				"lightslategrey",
				SVGColorExtractor.change(119, 136, 153)
			},
			{
				"lightsteelblue",
				SVGColorExtractor.change(176, 196, 222)
			},
			{
				"lightyellow",
				SVGColorExtractor.change(255, 255, 224)
			},
			{
				"lime",
				SVGColorExtractor.change(0, 255, 0)
			},
			{
				"limegreen",
				SVGColorExtractor.change(50, 205, 50)
			},
			{
				"linen",
				SVGColorExtractor.change(250, 240, 230)
			},
			{
				"magenta",
				SVGColorExtractor.change(255, 0, 255)
			},
			{
				"maroon",
				SVGColorExtractor.change(128, 0, 0)
			},
			{
				"mediumaquamarine",
				SVGColorExtractor.change(102, 205, 170)
			},
			{
				"mediumblue",
				SVGColorExtractor.change(0, 0, 205)
			},
			{
				"mediumorchid",
				SVGColorExtractor.change(186, 85, 211)
			},
			{
				"mediumpurple",
				SVGColorExtractor.change(147, 112, 219)
			},
			{
				"mediumseagreen",
				SVGColorExtractor.change(60, 179, 113)
			},
			{
				"mediumslateblue",
				SVGColorExtractor.change(123, 104, 238)
			},
			{
				"mediumspringgreen",
				SVGColorExtractor.change(0, 250, 154)
			},
			{
				"mediumturquoise",
				SVGColorExtractor.change(72, 209, 204)
			},
			{
				"mediumvioletred",
				SVGColorExtractor.change(199, 21, 133)
			},
			{
				"midnightblue",
				SVGColorExtractor.change(25, 25, 112)
			},
			{
				"mintcream",
				SVGColorExtractor.change(245, 255, 250)
			},
			{
				"mistyrose",
				SVGColorExtractor.change(255, 228, 225)
			},
			{
				"moccasin",
				SVGColorExtractor.change(255, 228, 181)
			},
			{
				"navajowhite",
				SVGColorExtractor.change(255, 222, 173)
			},
			{
				"navy",
				SVGColorExtractor.change(0, 0, 128)
			},
			{
				"oldlace",
				SVGColorExtractor.change(253, 245, 230)
			},
			{
				"olive",
				SVGColorExtractor.change(128, 128, 0)
			},
			{
				"olivedrab",
				SVGColorExtractor.change(107, 142, 35)
			},
			{
				"orange",
				SVGColorExtractor.change(255, 165, 0)
			},
			{
				"orangered",
				SVGColorExtractor.change(255, 69, 0)
			},
			{
				"orchid",
				SVGColorExtractor.change(218, 112, 214)
			},
			{
				"palegoldenrod",
				SVGColorExtractor.change(238, 232, 170)
			},
			{
				"palegreen",
				SVGColorExtractor.change(152, 251, 152)
			},
			{
				"paleturquoise",
				SVGColorExtractor.change(175, 238, 238)
			},
			{
				"palevioletred",
				SVGColorExtractor.change(219, 112, 147)
			},
			{
				"papayawhip",
				SVGColorExtractor.change(255, 239, 213)
			},
			{
				"peachpuff",
				SVGColorExtractor.change(255, 218, 185)
			},
			{
				"peru",
				SVGColorExtractor.change(205, 133, 63)
			},
			{
				"pink",
				SVGColorExtractor.change(255, 192, 203)
			},
			{
				"plum",
				SVGColorExtractor.change(221, 160, 221)
			},
			{
				"powderblue",
				SVGColorExtractor.change(176, 224, 230)
			},
			{
				"purple",
				SVGColorExtractor.change(128, 0, 128)
			},
			{
				"red",
				SVGColorExtractor.change(255, 0, 0)
			},
			{
				"rosybrown",
				SVGColorExtractor.change(188, 143, 143)
			},
			{
				"royalblue",
				SVGColorExtractor.change(65, 105, 225)
			},
			{
				"saddlebrown",
				SVGColorExtractor.change(139, 69, 19)
			},
			{
				"salmon",
				SVGColorExtractor.change(250, 128, 114)
			},
			{
				"sandybrown",
				SVGColorExtractor.change(244, 164, 96)
			},
			{
				"seagreen",
				SVGColorExtractor.change(46, 139, 87)
			},
			{
				"seashell",
				SVGColorExtractor.change(255, 245, 238)
			},
			{
				"sienna",
				SVGColorExtractor.change(160, 82, 45)
			},
			{
				"silver",
				SVGColorExtractor.change(192, 192, 192)
			},
			{
				"skyblue",
				SVGColorExtractor.change(135, 206, 235)
			},
			{
				"slateblue",
				SVGColorExtractor.change(106, 90, 205)
			},
			{
				"slategray",
				SVGColorExtractor.change(112, 128, 144)
			},
			{
				"slategrey",
				SVGColorExtractor.change(112, 128, 144)
			},
			{
				"snow",
				SVGColorExtractor.change(255, 250, 250)
			},
			{
				"springgreen",
				SVGColorExtractor.change(0, 255, 127)
			},
			{
				"steelblue",
				SVGColorExtractor.change(70, 130, 180)
			},
			{
				"tan",
				SVGColorExtractor.change(210, 180, 140)
			},
			{
				"teal",
				SVGColorExtractor.change(0, 128, 128)
			},
			{
				"thistle",
				SVGColorExtractor.change(216, 191, 216)
			},
			{
				"tomato",
				SVGColorExtractor.change(255, 99, 71)
			},
			{
				"turquoise",
				SVGColorExtractor.change(64, 224, 208)
			},
			{
				"violet",
				SVGColorExtractor.change(238, 130, 238)
			},
			{
				"wheat",
				SVGColorExtractor.change(245, 222, 179)
			},
			{
				"white",
				SVGColorExtractor.change(255, 255, 255)
			},
			{
				"whitesmoke",
				SVGColorExtractor.change(245, 245, 245)
			},
			{
				"yellow",
				SVGColorExtractor.change(255, 255, 0)
			},
			{
				"yellowgreen",
				SVGColorExtractor.change(154, 205, 50)
			}
		};
	}
}
