﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000107 RID: 263
	public static class SVGDebug
	{
		// Token: 0x06000888 RID: 2184 RVA: 0x0003842C File Offset: 0x0003662C
		public static void DebugArray(ICollection array)
		{
			if (array == null)
			{
				Debug.Log("Array is null!");
				return;
			}
			IEnumerator enumerator = array.GetEnumerator();
			int num = 0;
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				Debug.Log(string.Concat(new object[]
				{
					"i: ",
					num,
					", ",
					obj
				}));
				num++;
			}
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00038490 File Offset: 0x00036690
		public static void DebugPoint(Vector3 point)
		{
			new GameObject("Debug Points")
			{
				transform = 
				{
					position = point
				}
			}.AddComponent<SVGDebugPoints>();
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x000384B0 File Offset: 0x000366B0
		public static void DebugPoints(List<List<Vector2>> path)
		{
			GameObject gameObject = new GameObject("Debug Points");
			for (int i = 0; i < path.Count; i++)
			{
				GameObject gameObject2 = new GameObject("Path");
				gameObject2.transform.SetParent(gameObject.transform);
				gameObject2.AddComponent<SVGDebugPoints>();
				for (int j = 0; j < path[i].Count; j++)
				{
					GameObject gameObject3 = new GameObject("Point");
					gameObject3.transform.SetParent(gameObject2.transform);
					Vector3 localPosition = path[i][j];
					localPosition.y *= -1f;
					gameObject3.transform.localPosition = localPosition;
				}
			}
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x00038564 File Offset: 0x00036764
		public static void DebugPoints(List<List<Vector3>> path)
		{
			GameObject gameObject = new GameObject("Debug Points");
			for (int i = 0; i < path.Count; i++)
			{
				GameObject gameObject2 = new GameObject("Path");
				gameObject2.transform.SetParent(gameObject.transform);
				gameObject2.AddComponent<SVGDebugPoints>();
				for (int j = 0; j < path[i].Count; j++)
				{
					GameObject gameObject3 = new GameObject("Point");
					gameObject3.transform.SetParent(gameObject2.transform);
					Vector3 localPosition = path[i][j];
					localPosition.y *= -1f;
					gameObject3.transform.localPosition = localPosition;
				}
			}
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00038613 File Offset: 0x00036813
		public static void DebugPoints(List<Vector2> path)
		{
			SVGDebug.DebugPoints(new List<List<Vector2>>
			{
				path
			});
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x00038626 File Offset: 0x00036826
		public static void DebugPoints(List<Vector3> path)
		{
			SVGDebug.DebugPoints(new List<List<Vector3>>
			{
				path
			});
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x0003863C File Offset: 0x0003683C
		public static void DebugSegments(StrokeSegment[] segments)
		{
			GameObject gameObject = new GameObject("Debug Segments");
			for (int i = 0; i < segments.Length; i++)
			{
				GameObject gameObject2 = new GameObject("Segment");
				gameObject2.transform.SetParent(gameObject.transform);
				gameObject2.AddComponent<SVGDebugPoints>();
				GameObject gameObject3 = new GameObject("StartPoint");
				gameObject3.transform.SetParent(gameObject2.transform);
				Vector3 localPosition = segments[i].startPoint;
				localPosition.y *= -1f;
				gameObject3.transform.localPosition = localPosition;
				GameObject gameObject4 = new GameObject("EndPoint");
				gameObject4.transform.SetParent(gameObject2.transform);
				Vector3 localPosition2 = segments[i].endPoint;
				localPosition2.y *= -1f;
				gameObject4.transform.localPosition = localPosition2;
			}
		}
	}
}
