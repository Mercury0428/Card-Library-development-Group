﻿using System;
using System.Globalization;

namespace SVGImporter.Utils
{
	// Token: 0x020000F7 RID: 247
	public static class SVGLengthConvertor
	{
		// Token: 0x060007C0 RID: 1984 RVA: 0x00030664 File Offset: 0x0002E864
		public static bool ExtractType(string text, ref float value, ref SVGLengthType lengthType)
		{
			string text2 = "";
			int i;
			for (i = 0; i < text.Length; i++)
			{
				if (('0' <= text[i] && text[i] <= '9') || text[i] == '+' || text[i] == '-' || text[i] == '.' || text[i] == 'e')
				{
					text2 += text[i].ToString();
				}
				else if (text[i] != ' ')
				{
					break;
				}
			}
			string text3 = text.Substring(i);
			if (text2 == "")
			{
				return false;
			}
			value = float.Parse(text2, CultureInfo.InvariantCulture);
			string text4 = text3.ToUpper();
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text4);
			if (num <= 771752996U)
			{
				if (num <= 537692064U)
				{
					if (num != 533467831U)
					{
						if (num == 537692064U)
						{
							if (text4 == "%")
							{
								lengthType = SVGLengthType.Percentage;
								return true;
							}
						}
					}
					else if (text4 == "EM")
					{
						lengthType = SVGLengthType.EMs;
						return true;
					}
				}
				else if (num != 718021640U)
				{
					if (num == 771752996U)
					{
						if (text4 == "PC")
						{
							lengthType = SVGLengthType.PC;
							return true;
						}
					}
				}
				else if (text4 == "EX")
				{
					lengthType = SVGLengthType.EXs;
					return true;
				}
			}
			else if (num <= 1023417281U)
			{
				if (num != 956306805U)
				{
					if (num == 1023417281U)
					{
						if (text4 == "PT")
						{
							lengthType = SVGLengthType.PT;
							return true;
						}
					}
				}
				else if (text4 == "PX")
				{
					lengthType = SVGLengthType.PX;
					return true;
				}
			}
			else if (num != 1071631567U)
			{
				if (num != 1625881374U)
				{
					if (num == 2212112301U)
					{
						if (text4 == "CM")
						{
							lengthType = SVGLengthType.CM;
							return true;
						}
					}
				}
				else if (text4 == "IN")
				{
					lengthType = SVGLengthType.IN;
					return true;
				}
			}
			else if (text4 == "MM")
			{
				lengthType = SVGLengthType.MM;
				return true;
			}
			lengthType = SVGLengthType.Unknown;
			return true;
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x0003087C File Offset: 0x0002EA7C
		public static float ConvertToPX(float value, SVGLengthType lengthType)
		{
			switch (lengthType)
			{
			case SVGLengthType.CM:
				return value * 35.43307f;
			case SVGLengthType.MM:
				return value * 3.543307f;
			case SVGLengthType.IN:
				return value * 90f;
			case SVGLengthType.PT:
				return value * 1.25f;
			case SVGLengthType.PC:
				return value * 15f;
			default:
				return value;
			}
		}
	}
}
