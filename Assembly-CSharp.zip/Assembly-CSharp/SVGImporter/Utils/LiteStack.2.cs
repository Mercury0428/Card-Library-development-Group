﻿using System;

namespace SVGImporter.Utils
{
	// Token: 0x020000F5 RID: 245
	public class LiteStack : LiteStack<object>
	{
	}
}
