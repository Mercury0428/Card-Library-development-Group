﻿using System;
using UnityEngine;

namespace SVGImporter.Utils
{
	// Token: 0x02000102 RID: 258
	public struct StrokeSegment
	{
		// Token: 0x0600084E RID: 2126 RVA: 0x00034314 File Offset: 0x00032514
		public StrokeSegment(Vector2 startPoint, Vector2 endPoint)
		{
			this.startPoint = startPoint;
			this.endPoint = endPoint;
			this.direction = endPoint - startPoint;
			this.length = this.direction.magnitude;
			if (this.length != 0f)
			{
				this.directionNormalized.x = this.direction.x / this.length;
				this.directionNormalized.y = this.direction.y / this.length;
				this.directionNormalizedRotated = Quaternion.Euler(0f, 0f, 90f) * this.directionNormalized;
				return;
			}
			this.directionNormalized = (this.directionNormalizedRotated = Vector2.zero);
		}

		// Token: 0x0400080E RID: 2062
		public Vector2 startPoint;

		// Token: 0x0400080F RID: 2063
		public Vector2 endPoint;

		// Token: 0x04000810 RID: 2064
		public Vector2 direction;

		// Token: 0x04000811 RID: 2065
		public Vector2 directionNormalized;

		// Token: 0x04000812 RID: 2066
		public Vector2 directionNormalizedRotated;

		// Token: 0x04000813 RID: 2067
		public float length;
	}
}
