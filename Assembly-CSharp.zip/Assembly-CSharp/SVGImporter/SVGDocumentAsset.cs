﻿using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace SVGImporter
{
	// Token: 0x020000C9 RID: 201
	public class SVGDocumentAsset : ScriptableObject
	{
		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x00025316 File Offset: 0x00023516
		// (set) Token: 0x06000647 RID: 1607 RVA: 0x0002531E File Offset: 0x0002351E
		public SVGError[] errors
		{
			get
			{
				return this._errors;
			}
			set
			{
				this._errors = value;
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06000648 RID: 1608 RVA: 0x00025327 File Offset: 0x00023527
		// (set) Token: 0x06000649 RID: 1609 RVA: 0x0002532F File Offset: 0x0002352F
		public string svgFile
		{
			get
			{
				return this._svgFile;
			}
			set
			{
				this._svgFile = value;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600064A RID: 1610 RVA: 0x00025338 File Offset: 0x00023538
		// (set) Token: 0x0600064B RID: 1611 RVA: 0x00025340 File Offset: 0x00023540
		public string title
		{
			get
			{
				return this._title;
			}
			set
			{
				this._title = value;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600064C RID: 1612 RVA: 0x00025349 File Offset: 0x00023549
		// (set) Token: 0x0600064D RID: 1613 RVA: 0x00025351 File Offset: 0x00023551
		public string description
		{
			get
			{
				return this._description;
			}
			set
			{
				this._description = value;
			}
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x0002535A File Offset: 0x0002355A
		public static SVGDocumentAsset CreateInstance(string svgFile, SVGError[] errors = null, string title = null, string description = null)
		{
			SVGDocumentAsset svgdocumentAsset = ScriptableObject.CreateInstance<SVGDocumentAsset>();
			svgdocumentAsset._description = description;
			svgdocumentAsset._title = title;
			svgdocumentAsset._svgFile = svgFile;
			svgdocumentAsset._errors = errors;
			return svgdocumentAsset;
		}

		// Token: 0x040006E3 RID: 1763
		[FormerlySerializedAs("errors")]
		[SerializeField]
		protected SVGError[] _errors;

		// Token: 0x040006E4 RID: 1764
		[FormerlySerializedAs("svgFile")]
		[SerializeField]
		protected string _svgFile;

		// Token: 0x040006E5 RID: 1765
		[FormerlySerializedAs("title")]
		[SerializeField]
		protected string _title;

		// Token: 0x040006E6 RID: 1766
		[FormerlySerializedAs("description")]
		[SerializeField]
		protected string _description;
	}
}
