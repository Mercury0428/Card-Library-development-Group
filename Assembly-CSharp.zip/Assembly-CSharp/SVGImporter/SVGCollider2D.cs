﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000C7 RID: 199
	[ExecuteInEditMode]
	[RequireComponent(typeof(SVGRenderer))]
	[RequireComponent(typeof(PolygonCollider2D))]
	[AddComponentMenu("Physics 2D/SVG Collider 2D", 20)]
	public class SVGCollider2D : MonoBehaviour
	{
		// Token: 0x1700007A RID: 122
		// (get) Token: 0x0600063C RID: 1596 RVA: 0x0002501C File Offset: 0x0002321C
		// (set) Token: 0x0600063D RID: 1597 RVA: 0x00025024 File Offset: 0x00023224
		public float quality
		{
			get
			{
				return this._quality;
			}
			set
			{
				if (this._quality != value)
				{
					this._quality = value;
					this.UpdateCollider();
				}
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x0002503C File Offset: 0x0002323C
		// (set) Token: 0x0600063F RID: 1599 RVA: 0x00025044 File Offset: 0x00023244
		public float offset
		{
			get
			{
				return this._offset;
			}
			set
			{
				if (this._offset != value)
				{
					this._offset = value;
					this.UpdateCollider();
				}
			}
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0002505C File Offset: 0x0002325C
		private void OnValidate()
		{
			this.UpdateCollider();
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00025064 File Offset: 0x00023264
		protected virtual void UpdateCollider()
		{
			if (this.svgRenderer == null)
			{
				this.svgRenderer = base.GetComponent<SVGRenderer>();
			}
			if (this.polygonCollider2D == null)
			{
				this.polygonCollider2D = base.GetComponent<PolygonCollider2D>();
			}
			if (this.svgRenderer.vectorGraphics == null || this.svgRenderer.vectorGraphics.colliderShape == null || this.svgRenderer.vectorGraphics.colliderShape.Length == 0)
			{
				this.polygonCollider2D.pathCount = 0;
				this.polygonCollider2D.points = null;
				return;
			}
			SVGPath[] colliderShape = this.svgRenderer.vectorGraphics.colliderShape;
			this.polygonCollider2D.pathCount = 0;
			if (this._quality < 1f)
			{
				Bounds bounds = this.svgRenderer.vectorGraphics.bounds;
				float num = this._quality;
				if (num < 0.001f)
				{
					num = 0.001f;
				}
				this.precision = Mathf.Max(bounds.size.x, bounds.size.y) / num;
				if (this.precision < 0.001f)
				{
					this.precision = 0.001f;
				}
				this.precision *= 0.05f;
			}
			List<Vector2[]> list = new List<Vector2[]>();
			for (int i = 0; i < colliderShape.Length; i++)
			{
				Vector2[] array;
				if (this._quality < 1f)
				{
					array = SVGBezier.Optimise(colliderShape[i].points, this.precision, 0, -1);
				}
				else
				{
					array = (Vector2[])colliderShape[i].points.Clone();
				}
				if (this._offset != 0f)
				{
					array = SVGGeomUtils.OffsetVerts(array, this._offset);
				}
				if (array != null && array.Length > 2)
				{
					list.Add(array);
				}
			}
			if (list.Count > 0)
			{
				this.polygonCollider2D.pathCount = list.Count;
				for (int j = 0; j < list.Count; j++)
				{
					this.polygonCollider2D.SetPath(j, list[j]);
				}
			}
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0002525C File Offset: 0x0002345C
		private void OnEnable()
		{
			if (this.svgRenderer == null)
			{
				this.svgRenderer = base.GetComponent<SVGRenderer>();
			}
			SVGRenderer svgrenderer = this.svgRenderer;
			svgrenderer.onVectorGraphicsChanged = (Action<SVGAsset>)Delegate.Combine(svgrenderer.onVectorGraphicsChanged, new Action<SVGAsset>(this.OnVectorGraphicsChanged));
			this.UpdateCollider();
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x000252B4 File Offset: 0x000234B4
		private void OnDisable()
		{
			if (this.svgRenderer == null)
			{
				this.svgRenderer = base.GetComponent<SVGRenderer>();
			}
			SVGRenderer svgrenderer = this.svgRenderer;
			svgrenderer.onVectorGraphicsChanged = (Action<SVGAsset>)Delegate.Remove(svgrenderer.onVectorGraphicsChanged, new Action<SVGAsset>(this.OnVectorGraphicsChanged));
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x0002505C File Offset: 0x0002325C
		protected virtual void OnVectorGraphicsChanged(SVGAsset svgAsset)
		{
			this.UpdateCollider();
		}

		// Token: 0x040006D5 RID: 1749
		[Range(0f, 1f)]
		[SerializeField]
		protected float _quality = 0.9f;

		// Token: 0x040006D6 RID: 1750
		[SerializeField]
		protected float _offset;

		// Token: 0x040006D7 RID: 1751
		protected SVGRenderer svgRenderer;

		// Token: 0x040006D8 RID: 1752
		protected PolygonCollider2D polygonCollider2D;

		// Token: 0x040006D9 RID: 1753
		private float precision;
	}
}
