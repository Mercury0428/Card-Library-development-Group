﻿using System;

namespace SVGImporter
{
	// Token: 0x020000BD RID: 189
	public enum SVGShapeType
	{
		// Token: 0x04000668 RID: 1640
		NONE,
		// Token: 0x04000669 RID: 1641
		FILL,
		// Token: 0x0400066A RID: 1642
		STROKE,
		// Token: 0x0400066B RID: 1643
		ANTIALIASING
	}
}
