﻿using System;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000BB RID: 187
	[ExecuteInEditMode]
	[RequireComponent(typeof(ISVGShape), typeof(ISVGRenderer))]
	[AddComponentMenu("Rendering/SVG Modifiers/UV Modifier", 22)]
	public class SVGUVModifier : SVGModifier
	{
		// Token: 0x060005AE RID: 1454 RVA: 0x000213FC File Offset: 0x0001F5FC
		protected override void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force)
		{
			SVGMatrix svgmatrix = SVGMatrix.identity.Translate(-this.position);
			SVGMatrix svgmatrix2 = SVGMatrix.identity.Rotate(this.rotation);
			SVGMatrix svgmatrix3 = SVGMatrix.identity.Scale(this.scale);
			SVGMatrix svgmatrix4 = SVGMatrix.identity;
			if (this.preprocess)
			{
				svgmatrix4 = svgmatrix4.Translate(Vector2.one * 0.5f).Scale(0.25f, 0.25f);
			}
			switch (this.transformOrder)
			{
			case SVGUVModifier.TransformOrder.TRS:
				svgmatrix4 *= svgmatrix3 * svgmatrix2 * svgmatrix;
				break;
			case SVGUVModifier.TransformOrder.TSR:
				svgmatrix4 *= svgmatrix2 * svgmatrix3 * svgmatrix;
				break;
			case SVGUVModifier.TransformOrder.RTS:
				svgmatrix4 *= svgmatrix3 * svgmatrix * svgmatrix2;
				break;
			case SVGUVModifier.TransformOrder.RST:
				svgmatrix4 *= svgmatrix * svgmatrix3 * svgmatrix2;
				break;
			case SVGUVModifier.TransformOrder.STR:
				svgmatrix4 *= svgmatrix3 * svgmatrix * svgmatrix3;
				break;
			case SVGUVModifier.TransformOrder.SRT:
				svgmatrix4 *= svgmatrix * svgmatrix2 * svgmatrix3;
				break;
			}
			if (layers == null)
			{
				return;
			}
			int num = layers.Length;
			if (!this.useSelection)
			{
				for (int i = 0; i < num; i++)
				{
					if (layers[i].shapes != null)
					{
						int num2 = layers[i].shapes.Length;
						for (int j = 0; j < num2; j++)
						{
							int vertexCount = layers[i].shapes[j].vertexCount;
							for (int k = 0; k < vertexCount; k++)
							{
								layers[i].shapes[j].fill.fillType = FILL_TYPE.TEXTURE;
								layers[i].shapes[j].fill.transform = svgmatrix4;
							}
						}
					}
				}
				return;
			}
			for (int l = 0; l < num; l++)
			{
				if (layers[l].shapes != null && this.layerSelection.Contains(l))
				{
					int num3 = layers[l].shapes.Length;
					for (int m = 0; m < num3; m++)
					{
						int vertexCount2 = layers[l].shapes[m].vertexCount;
						for (int n = 0; n < vertexCount2; n++)
						{
							layers[l].shapes[m].fill.fillType = FILL_TYPE.TEXTURE;
							layers[l].shapes[m].fill.transform = svgmatrix4;
						}
					}
				}
			}
		}

		// Token: 0x04000656 RID: 1622
		public Vector2 position;

		// Token: 0x04000657 RID: 1623
		public float rotation;

		// Token: 0x04000658 RID: 1624
		public Vector2 scale = Vector2.one;

		// Token: 0x04000659 RID: 1625
		public bool preprocess = true;

		// Token: 0x0400065A RID: 1626
		public SVGUVModifier.TransformOrder transformOrder;

		// Token: 0x0200033F RID: 831
		public enum TransformOrder
		{
			// Token: 0x040011FC RID: 4604
			TRS,
			// Token: 0x040011FD RID: 4605
			TSR,
			// Token: 0x040011FE RID: 4606
			RTS,
			// Token: 0x040011FF RID: 4607
			RST,
			// Token: 0x04001200 RID: 4608
			STR,
			// Token: 0x04001201 RID: 4609
			SRT
		}
	}
}
