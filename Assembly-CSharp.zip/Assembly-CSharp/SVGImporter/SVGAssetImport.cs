﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000C4 RID: 196
	public class SVGAssetImport
	{
		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060005EB RID: 1515 RVA: 0x000237E7 File Offset: 0x000219E7
		public static bool importingSVG
		{
			get
			{
				return SVGAssetImport._importingSVG;
			}
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x000237EE File Offset: 0x000219EE
		public SVGAssetImport(string svgFile, float vertexPerMeter = 1000f)
		{
			SVGAssetImport.vpm = vertexPerMeter;
			this._SVGFile = svgFile;
			this._graphics = new SVGGraphics(vertexPerMeter, SVGAssetImport.antialiasing);
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00023814 File Offset: 0x00021A14
		private void CreateEmptySVGDocument()
		{
			this._svgDocument = new SVGDocument(this._SVGFile, this._graphics);
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x0002382D File Offset: 0x00021A2D
		public static void Clear()
		{
			if (SVGAssetImport.atlasData != null)
			{
				SVGAssetImport.atlasData.Clear();
				SVGAssetImport.atlasData = null;
			}
			SVGParser.Clear();
			SVGGraphics.Clear();
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x00023850 File Offset: 0x00021A50
		public void NewSVGFile(string svgFile)
		{
			this._SVGFile = svgFile;
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x00023859 File Offset: 0x00021A59
		public Texture2D GetTexture()
		{
			if (this._texture == null)
			{
				return new Texture2D(0, 0, TextureFormat.ARGB32, false);
			}
			return this._texture;
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0002387C File Offset: 0x00021A7C
		public Texture2D CloneTexture(Texture2D texture)
		{
			if (texture == null)
			{
				return null;
			}
			Texture2D texture2D = new Texture2D(texture.width, texture.height, texture.format, false);
			texture2D.name = texture.name;
			texture2D.SetPixels32(texture.GetPixels32());
			texture2D.wrapMode = TextureWrapMode.Clamp;
			texture2D.anisoLevel = 0;
			texture2D.filterMode = FilterMode.Bilinear;
			texture2D.Apply();
			return texture2D;
		}

		// Token: 0x040006A2 RID: 1698
		public static SVGAtlasData atlasData;

		// Token: 0x040006A3 RID: 1699
		public static List<SVGError> errors;

		// Token: 0x040006A4 RID: 1700
		protected static bool _importingSVG = false;

		// Token: 0x040006A5 RID: 1701
		public static SVGUseGradients useGradients;

		// Token: 0x040006A6 RID: 1702
		public static bool antialiasing;

		// Token: 0x040006A7 RID: 1703
		public static float vpm;

		// Token: 0x040006A8 RID: 1704
		public static Vector2 pivotPoint;

		// Token: 0x040006A9 RID: 1705
		public static bool ignoreSVGCanvas;

		// Token: 0x040006AA RID: 1706
		public static float meshScale = 1f;

		// Token: 0x040006AB RID: 1707
		public static Vector4 border;

		// Token: 0x040006AC RID: 1708
		public static bool sliceMesh = false;

		// Token: 0x040006AD RID: 1709
		public static float minDepthOffset = 0.001f;

		// Token: 0x040006AE RID: 1710
		public static SVGAssetFormat format = SVGAssetFormat.Opaque;

		// Token: 0x040006AF RID: 1711
		public static bool compressDepth = true;

		// Token: 0x040006B0 RID: 1712
		private string _SVGFile;

		// Token: 0x040006B1 RID: 1713
		private Texture2D _texture;

		// Token: 0x040006B2 RID: 1714
		private SVGGraphics _graphics;

		// Token: 0x040006B3 RID: 1715
		private SVGDocument _svgDocument;
	}
}
