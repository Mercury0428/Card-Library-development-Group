﻿using System;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000BC RID: 188
	[ExecuteInEditMode]
	[RequireComponent(typeof(MeshFilter))]
	[RequireComponent(typeof(MeshRenderer))]
	public class StrokeRendererLegacy : MonoBehaviour
	{
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x000216DE File Offset: 0x0001F8DE
		public MeshFilter meshFilter
		{
			get
			{
				if (this._meshFilter == null)
				{
					this._meshFilter = base.GetComponent<MeshFilter>();
				}
				return this._meshFilter;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060005B1 RID: 1457 RVA: 0x00021700 File Offset: 0x0001F900
		public MeshRenderer meshRenderer
		{
			get
			{
				if (this._meshRenderer == null)
				{
					this._meshRenderer = base.GetComponent<MeshRenderer>();
				}
				return this._meshRenderer;
			}
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x00021722 File Offset: 0x0001F922
		private void LateUpdate()
		{
			if (this.points == null || this.points.Length <= 1)
			{
				return;
			}
			this.RenderStroke();
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x00021740 File Offset: 0x0001F940
		protected virtual void RenderStroke()
		{
			int num = this.points.Length - 1;
			StrokeSegment[] array = new StrokeSegment[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = new StrokeSegment(this.points[i].GetPosition(), this.points[i + 1].GetPosition());
			}
			this.meshFilter.sharedMesh = SVGLineUtils.StrokeMesh(array, this.width, this.color, this.lineJoin, this.lineCap, this.mitterLimit, this.dashArray, this.dashOffset, this.closeLine, this.roundQuality);
		}

		// Token: 0x0400065B RID: 1627
		public StrokeRendererLegacy.StrokePoint[] points;

		// Token: 0x0400065C RID: 1628
		[Header("Line Style")]
		public StrokeLineJoin lineJoin;

		// Token: 0x0400065D RID: 1629
		public StrokeLineCap lineCap;

		// Token: 0x0400065E RID: 1630
		public Color32 color = Color.white;

		// Token: 0x0400065F RID: 1631
		public float width = 1f;

		// Token: 0x04000660 RID: 1632
		public float mitterLimit = 4f;

		// Token: 0x04000661 RID: 1633
		public float roundQuality = 10f;

		// Token: 0x04000662 RID: 1634
		public float[] dashArray;

		// Token: 0x04000663 RID: 1635
		public float dashOffset;

		// Token: 0x04000664 RID: 1636
		public ClosePathRule closeLine;

		// Token: 0x04000665 RID: 1637
		protected MeshFilter _meshFilter;

		// Token: 0x04000666 RID: 1638
		protected MeshRenderer _meshRenderer;

		// Token: 0x02000340 RID: 832
		[Serializable]
		public struct StrokePoint
		{
			// Token: 0x06001666 RID: 5734 RVA: 0x00072AB3 File Offset: 0x00070CB3
			public Vector2 GetPosition()
			{
				if (this.transform == null)
				{
					return this.position;
				}
				return this.transform.position;
			}

			// Token: 0x04001202 RID: 4610
			public Vector2 position;

			// Token: 0x04001203 RID: 4611
			public Transform transform;
		}
	}
}
