﻿using System;

namespace SVGImporter
{
	// Token: 0x020000C0 RID: 192
	public enum SVGUseGradients
	{
		// Token: 0x04000677 RID: 1655
		Always,
		// Token: 0x04000678 RID: 1656
		Auto,
		// Token: 0x04000679 RID: 1657
		Never
	}
}
