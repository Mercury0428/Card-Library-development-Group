﻿using System;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B5 RID: 181
	[ExecuteInEditMode]
	[RequireComponent(typeof(ISVGRenderer))]
	[AddComponentMenu("Rendering/SVG Modifiers/Blur Modifier", 22)]
	public class SVGBlurModifier : SVGModifier
	{
		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000591 RID: 1425 RVA: 0x0002053A File Offset: 0x0001E73A
		protected Camera mainCamera
		{
			get
			{
				if (!(this.camera == null))
				{
					return this.camera;
				}
				if (Camera.current != null)
				{
					return Camera.current;
				}
				return Camera.main;
			}
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0002056C File Offset: 0x0001E76C
		private void LateUpdate()
		{
			this.transformVelocity = base.transform.position - this.lastPosition;
			if (Time.deltaTime > 0f)
			{
				this.transformVelocity.x = this.transformVelocity.x / Time.deltaTime;
				this.transformVelocity.y = this.transformVelocity.y / Time.deltaTime;
			}
			this.lastPosition = base.transform.position;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x000205DF File Offset: 0x0001E7DF
		protected override void OnEnable()
		{
			base.OnEnable();
			this.lastPosition = base.transform.position;
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x000205F8 File Offset: 0x0001E7F8
		protected override void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force)
		{
			if (layers == null)
			{
				return;
			}
			Camera mainCamera = this.mainCamera;
			SVGMatrix svgmatrix = SVGMatrix.identity;
			SVGMatrix svgmatrix2 = SVGMatrix.identity;
			Matrix4x4 worldToCameraMatrix = mainCamera.worldToCameraMatrix;
			Matrix4x4 matrix4x = mainCamera.projectionMatrix * worldToCameraMatrix;
			float num = this.radius;
			float magnitude = matrix4x.MultiplyVector(Vector2.one * this.radius).magnitude;
			if (mainCamera.orthographic)
			{
				num *= magnitude;
			}
			else
			{
				float num2 = Vector3.Distance(base.transform.position, mainCamera.transform.position);
				if (num2 > 0f)
				{
					num *= magnitude / num2;
				}
				else
				{
					num *= magnitude;
				}
			}
			if (!this.motionBlur)
			{
				svgmatrix = svgmatrix.Scale(num);
			}
			else
			{
				float num3 = num;
				if (!this.manualMotionBlur)
				{
					Vector2 vector = this.transformVelocity;
					if (this.useCameraVelocity)
					{
						vector += base.transform.InverseTransformVector(mainCamera.velocity);
					}
					float num4 = Mathf.Sqrt(vector.x * vector.x + vector.y * vector.y);
					Vector2 zero = Vector2.zero;
					if (num4 > 0f)
					{
						zero.x = vector.x / num4;
						zero.y = vector.y / num4;
					}
					this.direction = Mathf.Atan2(zero.y, zero.x) * 57.29578f;
					num3 = num4 * num;
				}
				svgmatrix = svgmatrix.Scale(1f + num3, 1f);
			}
			svgmatrix2 = svgmatrix2.Rotate(-this.direction);
			SVGMatrix svgmatrix3 = SVGMatrix.identity.Rotate(this.direction);
			int num5 = layers.Length;
			if (!this.useSelection)
			{
				for (int i = 0; i < num5; i++)
				{
					if (layers[i].shapes != null)
					{
						int num6 = layers[i].shapes.Length;
						for (int j = 0; j < num6; j++)
						{
							if (layers[i].shapes[j].type == SVGShapeType.ANTIALIASING && layers[i].shapes[j].angles != null)
							{
								int vertexCount = layers[i].shapes[j].vertexCount;
								for (int k = 0; k < vertexCount; k++)
								{
									Vector2 vector2 = layers[i].shapes[j].angles[k];
									vector2 = svgmatrix2.Transform(vector2);
									vector2 = svgmatrix.Transform(vector2);
									vector2 = svgmatrix3.Transform(vector2);
									layers[i].shapes[j].angles[k] = vector2;
								}
							}
						}
					}
				}
				return;
			}
			for (int l = 0; l < num5; l++)
			{
				if (layers[l].shapes != null && this.layerSelection.Contains(l))
				{
					int num7 = layers[l].shapes.Length;
					for (int m = 0; m < num7; m++)
					{
						if (layers[l].shapes[m].type == SVGShapeType.ANTIALIASING && layers[l].shapes[m].angles != null)
						{
							int vertexCount2 = layers[l].shapes[m].vertexCount;
							for (int n = 0; n < vertexCount2; n++)
							{
								Vector2 vector3 = layers[l].shapes[m].angles[n];
								vector3 = svgmatrix2.Transform(vector3);
								vector3 = svgmatrix.Transform(vector3);
								vector3 = svgmatrix3.Transform(vector3);
								layers[l].shapes[m].angles[n] = vector3;
							}
						}
					}
				}
			}
		}

		// Token: 0x04000641 RID: 1601
		public Camera camera;

		// Token: 0x04000642 RID: 1602
		public bool useCameraVelocity;

		// Token: 0x04000643 RID: 1603
		public float radius = 20f;

		// Token: 0x04000644 RID: 1604
		public bool motionBlur;

		// Token: 0x04000645 RID: 1605
		public bool manualMotionBlur = true;

		// Token: 0x04000646 RID: 1606
		public float direction;

		// Token: 0x04000647 RID: 1607
		protected Vector3 lastPosition;

		// Token: 0x04000648 RID: 1608
		protected Vector2 transformVelocity;
	}
}
