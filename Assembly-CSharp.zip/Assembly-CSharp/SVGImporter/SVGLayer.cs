﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000BE RID: 190
	[Serializable]
	public struct SVGLayer
	{
		// Token: 0x060005B5 RID: 1461 RVA: 0x0002181C File Offset: 0x0001FA1C
		public SVGLayer Clone()
		{
			SVGLayer svglayer = this;
			if (this.shapes != null)
			{
				int num = this.shapes.Length;
				svglayer.shapes = new SVGShape[num];
				for (int i = 0; i < num; i++)
				{
					svglayer.shapes[i] = this.shapes[i];
					if (this.shapes[i].vertices != null)
					{
						svglayer.shapes[i].vertices = (this.shapes[i].vertices.Clone() as Vector2[]);
					}
					if (this.shapes[i].triangles != null)
					{
						svglayer.shapes[i].triangles = (this.shapes[i].triangles.Clone() as int[]);
					}
					if (this.shapes[i].colors != null)
					{
						svglayer.shapes[i].colors = (this.shapes[i].colors.Clone() as Color32[]);
					}
					if (this.shapes[i].angles != null)
					{
						svglayer.shapes[i].angles = (this.shapes[i].angles.Clone() as Vector2[]);
					}
					if (this.shapes[i].fill != null)
					{
						svglayer.shapes[i].fill = this.shapes[i].fill.Clone();
					}
				}
			}
			return svglayer;
		}

		// Token: 0x0400066C RID: 1644
		public string name;

		// Token: 0x0400066D RID: 1645
		public SVGShape[] shapes;
	}
}
