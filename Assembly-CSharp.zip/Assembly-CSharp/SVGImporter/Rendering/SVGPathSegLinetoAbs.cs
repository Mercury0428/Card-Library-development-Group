﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014D RID: 333
	public class SVGPathSegLinetoAbs : SVGPathSeg
	{
		// Token: 0x06000A30 RID: 2608 RVA: 0x00041772 File Offset: 0x0003F972
		public SVGPathSegLinetoAbs(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
		}
	}
}
