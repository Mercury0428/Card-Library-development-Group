﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012C RID: 300
	[Serializable]
	public class SVGPaintable
	{
		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000955 RID: 2389 RVA: 0x0003D3B7 File Offset: 0x0003B5B7
		public Rect viewport
		{
			get
			{
				return this._viewport;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000956 RID: 2390 RVA: 0x0003D3BF File Offset: 0x0003B5BF
		public SVGVisibility visibility
		{
			get
			{
				return this._visibility;
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000957 RID: 2391 RVA: 0x0003D3C7 File Offset: 0x0003B5C7
		public SVGDisplay display
		{
			get
			{
				return this._display;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x06000958 RID: 2392 RVA: 0x0003D3CF File Offset: 0x0003B5CF
		public SVGOverflow overflow
		{
			get
			{
				return this._overflow;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000959 RID: 2393 RVA: 0x0003D3D7 File Offset: 0x0003B5D7
		public SVGClipPathUnits clipPathUnits
		{
			get
			{
				return this._clipPathUnits;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x0600095A RID: 2394 RVA: 0x0003D3DF File Offset: 0x0003B5DF
		public SVGClipRule clipRule
		{
			get
			{
				return this._clipRule;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600095B RID: 2395 RVA: 0x0003D3E7 File Offset: 0x0003B5E7
		public SVGColor? fillColor
		{
			get
			{
				return this._fillColor;
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600095C RID: 2396 RVA: 0x0003D3F0 File Offset: 0x0003B5F0
		public SVGColor? strokeColor
		{
			get
			{
				if (this.IsStroke())
				{
					return this._strokeColor;
				}
				return null;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600095D RID: 2397 RVA: 0x0003D415 File Offset: 0x0003B615
		public float opacity
		{
			get
			{
				return this._opacity;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x0600095E RID: 2398 RVA: 0x0003D41D File Offset: 0x0003B61D
		public float fillOpacity
		{
			get
			{
				return this._fillOpacity;
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x0600095F RID: 2399 RVA: 0x0003D425 File Offset: 0x0003B625
		public float strokeOpacity
		{
			get
			{
				return this._strokeOpacity;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000960 RID: 2400 RVA: 0x0003D42D File Offset: 0x0003B62D
		public float strokeWidth
		{
			get
			{
				return this._strokeWidth.value;
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000961 RID: 2401 RVA: 0x0003D43A File Offset: 0x0003B63A
		public float miterLimit
		{
			get
			{
				return this._miterLimit.value;
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000962 RID: 2402 RVA: 0x0003D447 File Offset: 0x0003B647
		public float[] dashArray
		{
			get
			{
				return this._dashArray;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000963 RID: 2403 RVA: 0x0003D44F File Offset: 0x0003B64F
		public float dashOffset
		{
			get
			{
				return this._dashOfset.value;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000964 RID: 2404 RVA: 0x0003D45C File Offset: 0x0003B65C
		public SVGStrokeLineCapMethod strokeLineCap
		{
			get
			{
				return this._strokeLineCap;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000965 RID: 2405 RVA: 0x0003D464 File Offset: 0x0003B664
		public SVGStrokeLineJoinMethod strokeLineJoin
		{
			get
			{
				return this._strokeLineJoin;
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000966 RID: 2406 RVA: 0x0003D46C File Offset: 0x0003B66C
		public SVGFillRule fillRule
		{
			get
			{
				return this._fillRule;
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000967 RID: 2407 RVA: 0x0003D474 File Offset: 0x0003B674
		public Dictionary<string, Dictionary<string, string>> cssStyle
		{
			get
			{
				return this._cssStyle;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000968 RID: 2408 RVA: 0x0003D47C File Offset: 0x0003B67C
		public List<List<Vector2>> clipPathList
		{
			get
			{
				return this._clipPathList;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000969 RID: 2409 RVA: 0x0003D484 File Offset: 0x0003B684
		public Dictionary<string, SVGLinearGradientElement> linearGradList
		{
			get
			{
				return this._linearGradList;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600096A RID: 2410 RVA: 0x0003D48C File Offset: 0x0003B68C
		public Dictionary<string, SVGRadialGradientElement> radialGradList
		{
			get
			{
				return this._radialGradList;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600096B RID: 2411 RVA: 0x0003D494 File Offset: 0x0003B694
		public Dictionary<string, SVGConicalGradientElement> conicalGradList
		{
			get
			{
				return this._conicalGradList;
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x0600096C RID: 2412 RVA: 0x0003D49C File Offset: 0x0003B69C
		public string gradientID
		{
			get
			{
				return this._gradientID;
			}
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x0003D4A4 File Offset: 0x0003B6A4
		private void InitDefaults()
		{
			this.isStrokeWidth = false;
			this._visibility = SVGVisibility.Visible;
			this._display = SVGDisplay.Inline;
			this._overflow = SVGOverflow.visible;
			this._clipPathUnits = SVGClipPathUnits.UserSpaceOnUse;
			this._clipRule = SVGClipRule.nonzero;
			this._opacity = 1f;
			this._fillOpacity = 1f;
			this._strokeOpacity = 1f;
			this._fillColor = new SVGColor?(default(SVGColor));
			this._strokeColor = new SVGColor?(default(SVGColor));
			this._strokeWidth = new SVGLength(1f);
			this._strokeLineJoin = SVGStrokeLineJoinMethod.Miter;
			this._strokeLineCap = SVGStrokeLineCapMethod.Butt;
			this._fillRule = SVGFillRule.NonZero;
			this._miterLimit = new SVGLength(4f);
			this._dashArray = null;
			this._dashOfset = new SVGLength(0f);
			this._cssStyle = new Dictionary<string, Dictionary<string, string>>();
			this._clipPathList = new List<List<Vector2>>();
			this._linearGradList = new Dictionary<string, SVGLinearGradientElement>();
			this._radialGradList = new Dictionary<string, SVGRadialGradientElement>();
			this._conicalGradList = new Dictionary<string, SVGConicalGradientElement>();
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x0003D5A7 File Offset: 0x0003B7A7
		public SVGPaintable()
		{
			this.InitDefaults();
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x0003D5C0 File Offset: 0x0003B7C0
		public SVGPaintable(Node node)
		{
			this.InitDefaults();
			this.Initialize(node.attributes);
			this.ReadCSS(node);
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x0003D5EC File Offset: 0x0003B7EC
		public void AddCSS(string cssString)
		{
			if (string.IsNullOrEmpty(cssString))
			{
				return;
			}
			Dictionary<string, Dictionary<string, string>> dictionary = CSSParser.Parse(cssString);
			if (dictionary == null || dictionary.Count == 0)
			{
				return;
			}
			foreach (KeyValuePair<string, Dictionary<string, string>> keyValuePair in dictionary)
			{
				if (this._cssStyle.ContainsKey(keyValuePair.Key))
				{
					this._cssStyle[keyValuePair.Key] = keyValuePair.Value;
				}
				else
				{
					this._cssStyle.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x0003D698 File Offset: 0x0003B898
		private List<List<Vector2>> CloneClipPathList(List<List<Vector2>> input)
		{
			if (input != null)
			{
				List<List<Vector2>> list = new List<List<Vector2>>();
				for (int i = 0; i < input.Count; i++)
				{
					if (input[i] != null && input[i].Count != 0)
					{
						list.Add(new List<Vector2>(input[i].ToArray()));
					}
				}
				return list;
			}
			return null;
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x0003D6F0 File Offset: 0x0003B8F0
		public SVGPaintable(SVGPaintable inheritPaintable, Node node)
		{
			this.InitDefaults();
			if (inheritPaintable != null)
			{
				this._visibility = inheritPaintable.visibility;
				this._display = inheritPaintable.display;
				this._clipRule = inheritPaintable.clipRule;
				this._viewport = inheritPaintable._viewport;
				this._fillRule = inheritPaintable._fillRule;
				this._cssStyle = inheritPaintable._cssStyle;
				this._clipPathList = this.CloneClipPathList(inheritPaintable._clipPathList);
				this._linearGradList = inheritPaintable._linearGradList;
				this._radialGradList = inheritPaintable._radialGradList;
				this._conicalGradList = inheritPaintable._conicalGradList;
			}
			if (inheritPaintable != null)
			{
				if (!this.IsFillX())
				{
					if (inheritPaintable.IsLinearGradiantFill())
					{
						this._gradientID = inheritPaintable.gradientID;
					}
					else if (inheritPaintable.IsRadialGradiantFill())
					{
						this._gradientID = inheritPaintable.gradientID;
					}
					else
					{
						this._fillColor = inheritPaintable.fillColor;
					}
				}
				if (!this.IsStroke() && inheritPaintable.IsStroke())
				{
					this._strokeColor = inheritPaintable.strokeColor;
				}
				if (this._strokeLineCap == SVGStrokeLineCapMethod.Unknown)
				{
					this._strokeLineCap = inheritPaintable.strokeLineCap;
				}
				if (this._strokeLineJoin == SVGStrokeLineJoinMethod.Unknown)
				{
					this._strokeLineJoin = inheritPaintable.strokeLineJoin;
				}
				if (!this.isStrokeWidth)
				{
					this._strokeWidth.NewValueSpecifiedUnits(inheritPaintable.strokeWidth);
				}
			}
			this.Initialize(node.attributes);
			this.ReadCSS(node);
			if (inheritPaintable != null)
			{
				this._opacity *= inheritPaintable._opacity;
				this._fillOpacity *= inheritPaintable._fillOpacity;
				this._strokeOpacity *= inheritPaintable._strokeOpacity;
			}
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x0003D887 File Offset: 0x0003BA87
		private void Initialize(AttributeList attrList)
		{
			this.ReadStyle(attrList.Get);
			this.ReadStyle(attrList.GetValue("style"));
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x0003D8A8 File Offset: 0x0003BAA8
		public void ReadCSS(Node node)
		{
			if (this._cssStyle == null || this._cssStyle.Count == 0)
			{
				return;
			}
			AttributeList attributes = node.attributes;
			string value = attributes.GetValue("class");
			if (!string.IsNullOrEmpty(value))
			{
				string[] array = value.Split(new char[]
				{
					' '
				});
				for (int i = 0; i < array.Length; i++)
				{
					string key = "." + array[i];
					if (this._cssStyle.ContainsKey(key))
					{
						this.ReadCSSElement(this._cssStyle[key]);
					}
				}
			}
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x0003D938 File Offset: 0x0003BB38
		public void ReadCSSElement(Dictionary<string, string> element)
		{
			if (element == null || element.Count == 0)
			{
				return;
			}
			this.ReadStyle(element);
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x0003D94D File Offset: 0x0003BB4D
		public void SetViewport(Rect viewport)
		{
			this._viewport = viewport;
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x0003D958 File Offset: 0x0003BB58
		private void ReadStyle(string styleString)
		{
			if (string.IsNullOrEmpty(styleString))
			{
				return;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			SVGStringExtractor.ExtractStyleValue(styleString, ref dictionary);
			this.ReadStyle(dictionary);
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x0003D984 File Offset: 0x0003BB84
		private void ReadClipPath(string clipPathValue)
		{
			if (clipPathValue.IndexOf("url") >= 0)
			{
				string text = SVGStringExtractor.ExtractUrl(clipPathValue);
				if (!string.IsNullOrEmpty(text) && SVGParser._defs.ContainsKey(text))
				{
					Node node = SVGParser._defs[text];
					if (node != null)
					{
						SVGMatrix identity = SVGMatrix.identity;
						string a = node.attributes.GetValue("clipPathUnits").ToLower();
						if (!(a == "userSpaceOnUse"))
						{
							if (a == "objectBoundingBox")
							{
								this._clipPathUnits = SVGClipPathUnits.ObjectBoundingBox;
							}
						}
						else
						{
							this._clipPathUnits = SVGClipPathUnits.UserSpaceOnUse;
						}
						List<Node> nodes = node.GetNodes();
						List<List<Vector2>> list = new List<List<Vector2>>();
						if (nodes != null && nodes.Count > 0)
						{
							for (int i = 0; i < nodes.Count; i++)
							{
								List<List<Vector2>> clipPath = this.GetClipPath(nodes[i], identity);
								if (clipPath != null)
								{
									list.AddRange(clipPath);
								}
							}
						}
						if (list.Count > 0)
						{
							list = SVGGeom.MergePolygon(list);
						}
						if (this._clipPathList != null && this._clipPathList.Count > 0)
						{
							this._clipPathList = SVGGeom.ClipPolygon(this._clipPathList, list);
							return;
						}
						this._clipPathList = list;
					}
				}
			}
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x0003DAB4 File Offset: 0x0003BCB4
		private List<List<Vector2>> GetClipPath(Node node, SVGMatrix svgMatrix)
		{
			SVGTransformList svgtransformList = new SVGTransformList();
			svgtransformList.AppendItem(new SVGTransform(svgMatrix));
			SVGNodeName name = node.name;
			switch (name)
			{
			case SVGNodeName.Rect:
				return new SVGRectElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.Line:
				return new SVGLineElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.Circle:
				return new SVGCircleElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.Ellipse:
				return new SVGEllipseElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.PolyLine:
				return new SVGPolylineElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.Polygon:
				return new SVGPolygonElement(node, svgtransformList, null).GetClipPath();
			case SVGNodeName.Path:
				return new SVGPathElement(node, svgtransformList, null).GetClipPath();
			default:
				if (name == SVGNodeName.Use)
				{
					string text = node.attributes.GetValue("xlink:href");
					if (!string.IsNullOrEmpty(text))
					{
						if (text[0] == '#')
						{
							text = text.Remove(0, 1);
						}
						if (SVGParser._defs.ContainsKey(text))
						{
							Node node2 = SVGParser._defs[text];
							if (node2 != null && node2 != node)
							{
								return this.GetClipPath(node2, svgMatrix);
							}
						}
					}
				}
				return null;
			}
		}

		// Token: 0x0600097A RID: 2426 RVA: 0x0003DBC0 File Offset: 0x0003BDC0
		private void ReadStyle(Dictionary<string, string> _dictionary)
		{
			if (_dictionary == null || _dictionary.Count == 0)
			{
				return;
			}
			if (_dictionary.ContainsKey("visibility"))
			{
				this.SetVisibility(_dictionary["visibility"]);
			}
			if (_dictionary.ContainsKey("display"))
			{
				this.SetDisplay(_dictionary["display"]);
			}
			if (_dictionary.ContainsKey("overflow"))
			{
				this.SetOverflow(_dictionary["overflow"]);
			}
			if (_dictionary.ContainsKey("clip-rule"))
			{
				this.SetClipRule(_dictionary["clip-rule"]);
			}
			if (_dictionary.ContainsKey("clip-path"))
			{
				this.ReadClipPath(_dictionary["clip-path"]);
			}
			if (_dictionary.ContainsKey("fill"))
			{
				string text = _dictionary["fill"];
				if (text.IndexOf("url") >= 0)
				{
					this._gradientID = SVGStringExtractor.ExtractUrl(text);
				}
				else
				{
					this._fillColor = new SVGColor?(new SVGColor(_dictionary["fill"]));
				}
			}
			if (_dictionary.ContainsKey("opacity"))
			{
				this._opacity *= new SVGLength(_dictionary["opacity"]).value;
			}
			if (_dictionary.ContainsKey("fill-opacity"))
			{
				this._fillOpacity *= new SVGLength(_dictionary["fill-opacity"]).value;
			}
			if (_dictionary.ContainsKey("stroke-opacity"))
			{
				this._strokeOpacity *= new SVGLength(_dictionary["stroke-opacity"]).value;
			}
			if (_dictionary.ContainsKey("fill-rule"))
			{
				this.SetFillRule(_dictionary["fill-rule"]);
			}
			if (_dictionary.ContainsKey("stroke"))
			{
				this._strokeColor = new SVGColor?(new SVGColor(_dictionary["stroke"]));
			}
			if (_dictionary.ContainsKey("stroke-width"))
			{
				this.isStrokeWidth = true;
				this._strokeWidth = new SVGLength(_dictionary["stroke-width"]);
			}
			if (_dictionary.ContainsKey("stroke-linecap"))
			{
				this.SetStrokeLineCap(_dictionary["stroke-linecap"]);
			}
			if (_dictionary.ContainsKey("stroke-linejoin"))
			{
				this.SetStrokeLineJoin(_dictionary["stroke-linejoin"]);
			}
			if (_dictionary.ContainsKey("stroke-miterlimit"))
			{
				this._miterLimit = new SVGLength(_dictionary["stroke-miterlimit"]);
			}
			if (_dictionary.ContainsKey("stroke-dasharray"))
			{
				this.SetDashArray(_dictionary["stroke-dasharray"].Split(new char[]
				{
					','
				}));
			}
			if (_dictionary.ContainsKey("stroke-dashoffset"))
			{
				this._dashOfset = new SVGLength(_dictionary["stroke-dashoffset"]);
			}
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x0003DE78 File Offset: 0x0003C078
		private void SetVisibility(string visibilityType)
		{
			if (visibilityType == "visible")
			{
				this._visibility = SVGVisibility.Visible;
				return;
			}
			if (visibilityType == "hidden")
			{
				this._visibility = SVGVisibility.Hidden;
				return;
			}
			if (!(visibilityType == "collapse"))
			{
				return;
			}
			this._visibility = SVGVisibility.Collapse;
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x0003DEC4 File Offset: 0x0003C0C4
		private void SetOverflow(string overflowType)
		{
			if (overflowType == "visible")
			{
				this._overflow = SVGOverflow.visible;
				return;
			}
			if (overflowType == "auto")
			{
				this._overflow = SVGOverflow.auto;
				return;
			}
			if (overflowType == "hidden")
			{
				this._overflow = SVGOverflow.hidden;
				return;
			}
			if (!(overflowType == "scroll"))
			{
				return;
			}
			this._overflow = SVGOverflow.scroll;
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x0003DF25 File Offset: 0x0003C125
		private void SetClipRule(string clipRuleType)
		{
			if (clipRuleType == "nonzero")
			{
				this._clipRule = SVGClipRule.nonzero;
				return;
			}
			if (!(clipRuleType == "evenodd"))
			{
				return;
			}
			this._clipRule = SVGClipRule.evenodd;
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x0003DF54 File Offset: 0x0003C154
		private void SetDisplay(string displayType)
		{
			if (this._display == SVGDisplay.None)
			{
				return;
			}
			uint num = <PrivateImplementationDetails>.ComputeStringHash(displayType);
			if (num <= 3222146762U)
			{
				if (num <= 675151018U)
				{
					if (num <= 300961693U)
					{
						if (num != 126687312U)
						{
							if (num != 300961693U)
							{
								return;
							}
							if (!(displayType == "inline-table"))
							{
								return;
							}
							this._display = SVGDisplay.InlineTable;
							return;
						}
						else
						{
							if (!(displayType == "table-caption"))
							{
								return;
							}
							this._display = SVGDisplay.TableCaption;
							return;
						}
					}
					else if (num != 453163156U)
					{
						if (num != 675151018U)
						{
							return;
						}
						if (!(displayType == "table-row"))
						{
							return;
						}
						this._display = SVGDisplay.TableRow;
						return;
					}
					else
					{
						if (!(displayType == "inline-block"))
						{
							return;
						}
						this._display = SVGDisplay.InlineBlock;
						return;
					}
				}
				else if (num <= 1251777503U)
				{
					if (num != 1180230732U)
					{
						if (num != 1251777503U)
						{
							return;
						}
						if (!(displayType == "table"))
						{
							return;
						}
						this._display = SVGDisplay.Table;
						return;
					}
					else
					{
						if (!(displayType == "table-row-group"))
						{
							return;
						}
						this._display = SVGDisplay.TableRowGroup;
						return;
					}
				}
				else if (num != 1449114139U)
				{
					if (num != 2913447899U)
					{
						if (num != 3222146762U)
						{
							return;
						}
						if (!(displayType == "table-column-group"))
						{
							return;
						}
						this._display = SVGDisplay.TableColumnGroup;
						return;
					}
					else
					{
						if (!(displayType == "none"))
						{
							return;
						}
						this._display = SVGDisplay.None;
						return;
					}
				}
				else
				{
					if (!(displayType == "list-item"))
					{
						return;
					}
					this._display = SVGDisplay.ListItem;
					return;
				}
			}
			else if (num <= 3268104244U)
			{
				if (num <= 3258575918U)
				{
					if (num != 3228262988U)
					{
						if (num != 3258575918U)
						{
							return;
						}
						if (!(displayType == "table-cell"))
						{
							return;
						}
						this._display = SVGDisplay.TableCell;
						return;
					}
					else
					{
						if (!(displayType == "inline-flex"))
						{
							return;
						}
						this._display = SVGDisplay.InlineFlex;
						return;
					}
				}
				else if (num != 3265876631U)
				{
					if (num != 3268104244U)
					{
						return;
					}
					if (!(displayType == "inline"))
					{
						return;
					}
					this._display = SVGDisplay.Inline;
					return;
				}
				else
				{
					if (!(displayType == "table-footer-group"))
					{
						return;
					}
					this._display = SVGDisplay.TableFooterGroup;
					return;
				}
			}
			else if (num <= 3615688129U)
			{
				if (num != 3403689970U)
				{
					if (num != 3615688129U)
					{
						return;
					}
					if (!(displayType == "table-header-group"))
					{
						return;
					}
					this._display = SVGDisplay.TableHeaderGroup;
					return;
				}
				else
				{
					if (!(displayType == "flex"))
					{
						return;
					}
					this._display = SVGDisplay.Flex;
					return;
				}
			}
			else if (num != 3728508030U)
			{
				if (num != 3943480674U)
				{
					if (num != 4034808716U)
					{
						return;
					}
					if (!(displayType == "table-column"))
					{
						return;
					}
					this._display = SVGDisplay.TableColumn;
					return;
				}
				else
				{
					if (!(displayType == "block"))
					{
						return;
					}
					this._display = SVGDisplay.Block;
					return;
				}
			}
			else
			{
				if (!(displayType == "run-in"))
				{
					return;
				}
				this._display = SVGDisplay.RunIn;
				return;
			}
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x0003E23C File Offset: 0x0003C43C
		private void SetDashArray(string[] dashArrayType)
		{
			if (dashArrayType != null && dashArrayType.Length != 0)
			{
				this._dashArray = new float[dashArrayType.Length];
				for (int i = 0; i < this._dashArray.Length; i++)
				{
					this._dashArray[i] = new SVGLength(dashArrayType[i]).value;
				}
			}
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x0003E289 File Offset: 0x0003C489
		private void SetFillRule(string fillRuleType)
		{
			if (fillRuleType == "nonzero")
			{
				this._fillRule = SVGFillRule.NonZero;
				return;
			}
			if (!(fillRuleType == "evenodd"))
			{
				return;
			}
			this._fillRule = SVGFillRule.EvenOdd;
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x0003E2B8 File Offset: 0x0003C4B8
		private void SetStrokeLineCap(string lineCapType)
		{
			if (lineCapType == "butt")
			{
				this._strokeLineCap = SVGStrokeLineCapMethod.Butt;
				return;
			}
			if (lineCapType == "round")
			{
				this._strokeLineCap = SVGStrokeLineCapMethod.Round;
				return;
			}
			if (!(lineCapType == "square"))
			{
				return;
			}
			this._strokeLineCap = SVGStrokeLineCapMethod.Square;
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x0003E304 File Offset: 0x0003C504
		private void SetStrokeLineJoin(string lineCapType)
		{
			if (lineCapType == "miter")
			{
				this._strokeLineJoin = SVGStrokeLineJoinMethod.Miter;
				return;
			}
			if (lineCapType == "miter-clip")
			{
				this._strokeLineJoin = SVGStrokeLineJoinMethod.MiterClip;
				return;
			}
			if (lineCapType == "round")
			{
				this._strokeLineJoin = SVGStrokeLineJoinMethod.Round;
				return;
			}
			if (!(lineCapType == "bevel"))
			{
				return;
			}
			this._strokeLineJoin = SVGStrokeLineJoinMethod.Bevel;
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x0003E365 File Offset: 0x0003C565
		public bool IsLinearGradiantFill()
		{
			return !string.IsNullOrEmpty(this._gradientID) && this._linearGradList.ContainsKey(this._gradientID);
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x0003E387 File Offset: 0x0003C587
		public bool IsRadialGradiantFill()
		{
			return !string.IsNullOrEmpty(this._gradientID) && this._radialGradList.ContainsKey(this._gradientID);
		}

		// Token: 0x06000985 RID: 2437 RVA: 0x0003E3A9 File Offset: 0x0003C5A9
		public bool IsConicalGradiantFill()
		{
			return !string.IsNullOrEmpty(this._gradientID) && this._conicalGradList.ContainsKey(this._gradientID);
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x0003E3CB File Offset: 0x0003C5CB
		public bool IsSolidFill()
		{
			return this._fillColor != null && this._fillColor.Value.colorType != SVGColorType.None;
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x0003E3F2 File Offset: 0x0003C5F2
		public bool IsFill()
		{
			if (this._fillColor == null)
			{
				return this.IsLinearGradiantFill() || this.IsRadialGradiantFill();
			}
			return this._fillColor.Value.colorType != SVGColorType.None;
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x0003E428 File Offset: 0x0003C628
		public bool IsFillX()
		{
			if (this._fillColor == null)
			{
				return this.IsLinearGradiantFill() || this.IsRadialGradiantFill();
			}
			return this._fillColor.Value.colorType > SVGColorType.Unknown;
		}

		// Token: 0x06000989 RID: 2441 RVA: 0x0003E45B File Offset: 0x0003C65B
		public bool IsStroke()
		{
			return this._strokeColor != null && this._strokeColor.Value.colorType != SVGColorType.Unknown && this._strokeColor.Value.colorType != SVGColorType.None;
		}

		// Token: 0x0600098A RID: 2442 RVA: 0x0003E494 File Offset: 0x0003C694
		public SVGPaintMethod GetPaintType()
		{
			if (this.IsLinearGradiantFill())
			{
				return SVGPaintMethod.LinearGradientFill;
			}
			if (this.IsRadialGradiantFill())
			{
				return SVGPaintMethod.RadialGradientFill;
			}
			if (this.IsConicalGradiantFill())
			{
				return SVGPaintMethod.ConicalGradientFill;
			}
			if (this.IsSolidFill())
			{
				return SVGPaintMethod.SolidFill;
			}
			if (this.IsStroke())
			{
				return SVGPaintMethod.PathDraw;
			}
			return SVGPaintMethod.NoDraw;
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x0003E4C9 File Offset: 0x0003C6C9
		public void AppendLinearGradient(SVGLinearGradientElement linearGradElement)
		{
			if (this._linearGradList.ContainsKey(linearGradElement.id))
			{
				this._linearGradList[linearGradElement.id] = linearGradElement;
				return;
			}
			this._linearGradList.Add(linearGradElement.id, linearGradElement);
		}

		// Token: 0x0600098C RID: 2444 RVA: 0x0003E503 File Offset: 0x0003C703
		public void AppendRadialGradient(SVGRadialGradientElement radialGradElement)
		{
			if (this._radialGradList.ContainsKey(radialGradElement.id))
			{
				this._radialGradList[radialGradElement.id] = radialGradElement;
				return;
			}
			this._radialGradList.Add(radialGradElement.id, radialGradElement);
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x0003E53D File Offset: 0x0003C73D
		public void AppendConicalGradient(SVGConicalGradientElement conicalGradElement)
		{
			if (this._conicalGradList.ContainsKey(conicalGradElement.id))
			{
				this._conicalGradList[conicalGradElement.id] = conicalGradElement;
				return;
			}
			this._conicalGradList.Add(conicalGradElement.id, conicalGradElement);
		}

		// Token: 0x0600098E RID: 2446 RVA: 0x0003E577 File Offset: 0x0003C777
		public SVGLinearGradientBrush GetLinearGradientBrush(Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			if (!this._linearGradList.ContainsKey(this._gradientID))
			{
				return null;
			}
			return new SVGLinearGradientBrush(this._linearGradList[this._gradientID], bounds, matrix, viewport);
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x0003E5A7 File Offset: 0x0003C7A7
		public SVGRadialGradientBrush GetRadialGradientBrush(Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			if (!this._radialGradList.ContainsKey(this._gradientID))
			{
				return null;
			}
			return new SVGRadialGradientBrush(this._radialGradList[this._gradientID], bounds, matrix, viewport);
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x0003E5D7 File Offset: 0x0003C7D7
		public SVGConicalGradientBrush GetConicalGradientBrush(Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			if (!this._conicalGradList.ContainsKey(this._gradientID))
			{
				return null;
			}
			return new SVGConicalGradientBrush(this._conicalGradList[this._gradientID], bounds, matrix, viewport);
		}

		// Token: 0x040008D7 RID: 2263
		private Rect _viewport;

		// Token: 0x040008D8 RID: 2264
		private SVGVisibility _visibility;

		// Token: 0x040008D9 RID: 2265
		private SVGDisplay _display;

		// Token: 0x040008DA RID: 2266
		private SVGOverflow _overflow;

		// Token: 0x040008DB RID: 2267
		private SVGClipPathUnits _clipPathUnits;

		// Token: 0x040008DC RID: 2268
		private SVGClipRule _clipRule;

		// Token: 0x040008DD RID: 2269
		private float _opacity;

		// Token: 0x040008DE RID: 2270
		private float _fillOpacity;

		// Token: 0x040008DF RID: 2271
		private float _strokeOpacity;

		// Token: 0x040008E0 RID: 2272
		private SVGColor? _fillColor;

		// Token: 0x040008E1 RID: 2273
		private SVGColor? _strokeColor;

		// Token: 0x040008E2 RID: 2274
		private SVGLength _strokeWidth;

		// Token: 0x040008E3 RID: 2275
		private SVGLength _miterLimit;

		// Token: 0x040008E4 RID: 2276
		private float[] _dashArray;

		// Token: 0x040008E5 RID: 2277
		private SVGLength _dashOfset;

		// Token: 0x040008E6 RID: 2278
		private bool isStrokeWidth;

		// Token: 0x040008E7 RID: 2279
		private SVGStrokeLineCapMethod _strokeLineCap;

		// Token: 0x040008E8 RID: 2280
		private SVGStrokeLineJoinMethod _strokeLineJoin;

		// Token: 0x040008E9 RID: 2281
		private SVGFillRule _fillRule;

		// Token: 0x040008EA RID: 2282
		private Dictionary<string, Dictionary<string, string>> _cssStyle;

		// Token: 0x040008EB RID: 2283
		private List<List<Vector2>> _clipPathList;

		// Token: 0x040008EC RID: 2284
		private Dictionary<string, SVGLinearGradientElement> _linearGradList;

		// Token: 0x040008ED RID: 2285
		private Dictionary<string, SVGRadialGradientElement> _radialGradList;

		// Token: 0x040008EE RID: 2286
		private Dictionary<string, SVGConicalGradientElement> _conicalGradList;

		// Token: 0x040008EF RID: 2287
		private string _gradientID = "";

		// Token: 0x040008F0 RID: 2288
		public SVGFill svgFill;
	}
}
