﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000124 RID: 292
	public enum SVGClipPathUnits
	{
		// Token: 0x040008A6 RID: 2214
		UserSpaceOnUse,
		// Token: 0x040008A7 RID: 2215
		ObjectBoundingBox
	}
}
