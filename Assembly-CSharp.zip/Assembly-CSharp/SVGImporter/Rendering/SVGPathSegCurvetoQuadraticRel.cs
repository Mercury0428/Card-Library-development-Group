﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014A RID: 330
	public class SVGPathSegCurvetoQuadraticRel : SVGPathSegCurvetoQuadratic
	{
		// Token: 0x06000A2A RID: 2602 RVA: 0x000415F0 File Offset: 0x0003F7F0
		public SVGPathSegCurvetoQuadraticRel(float x1, float y1, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Quadratic_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
			this._controlPoint1 = this._previousPoint + new Vector2(x1, y1);
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000A2B RID: 2603 RVA: 0x00041658 File Offset: 0x0003F858
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x0400095B RID: 2395
		protected Vector2 _controlPoint1 = Vector2.zero;
	}
}
