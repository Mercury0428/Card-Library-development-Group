﻿using System;
using SVGImporter.Document;
using SVGImporter.Utils;

namespace SVGImporter.Rendering
{
	// Token: 0x02000133 RID: 307
	public class SVGConicalGradientElement : SVGGradientElement
	{
		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060009CF RID: 2511 RVA: 0x0003FA62 File Offset: 0x0003DC62
		public SVGLength cx
		{
			get
			{
				return this._cx;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060009D0 RID: 2512 RVA: 0x0003FA6A File Offset: 0x0003DC6A
		public SVGLength cy
		{
			get
			{
				return this._cy;
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060009D1 RID: 2513 RVA: 0x0003FA72 File Offset: 0x0003DC72
		public SVGLength r
		{
			get
			{
				return this._r;
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060009D2 RID: 2514 RVA: 0x0003FA7A File Offset: 0x0003DC7A
		public SVGLength fx
		{
			get
			{
				return this._fx;
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060009D3 RID: 2515 RVA: 0x0003FA82 File Offset: 0x0003DC82
		public SVGLength fy
		{
			get
			{
				return this._fy;
			}
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0003FA8C File Offset: 0x0003DC8C
		public SVGConicalGradientElement(SVGParser xmlImp, Node node) : base(xmlImp, node)
		{
			string value = this._attrList.GetValue("cx");
			this._cx = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("cy");
			this._cy = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("r");
			this._r = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("fx");
			this._fx = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("fy");
			this._fy = new SVGLength((value == "") ? "50%" : value);
		}

		// Token: 0x04000907 RID: 2311
		private SVGLength _cx;

		// Token: 0x04000908 RID: 2312
		private SVGLength _cy;

		// Token: 0x04000909 RID: 2313
		private SVGLength _r;

		// Token: 0x0400090A RID: 2314
		private SVGLength _fx;

		// Token: 0x0400090B RID: 2315
		private SVGLength _fy;
	}
}
