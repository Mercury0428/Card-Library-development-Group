﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000123 RID: 291
	public enum SVGOverflow
	{
		// Token: 0x040008A1 RID: 2209
		visible,
		// Token: 0x040008A2 RID: 2210
		hidden,
		// Token: 0x040008A3 RID: 2211
		scroll,
		// Token: 0x040008A4 RID: 2212
		auto
	}
}
