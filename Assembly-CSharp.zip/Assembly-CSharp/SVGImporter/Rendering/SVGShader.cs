﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000158 RID: 344
	public class SVGShader
	{
		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000A70 RID: 2672 RVA: 0x000443B4 File Offset: 0x000425B4
		public static Shader GradientColorAlphaBlended
		{
			get
			{
				if (SVGShader._GradientColorAlphaBlended == null)
				{
					SVGShader._GradientColorAlphaBlended = Shader.Find("SVG Importer/GradientColor/GradientColorAlphaBlended");
				}
				return SVGShader._GradientColorAlphaBlended;
			}
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000A71 RID: 2673 RVA: 0x000443D7 File Offset: 0x000425D7
		public static Shader GradientColorAlphaBlendedAntialiased
		{
			get
			{
				if (SVGShader._GradientColorAlphaBlendedAntialiased == null)
				{
					SVGShader._GradientColorAlphaBlendedAntialiased = Shader.Find("SVG Importer/GradientColor/GradientColorAlphaBlendedAntialiased");
				}
				return SVGShader._GradientColorAlphaBlendedAntialiased;
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000A72 RID: 2674 RVA: 0x000443FA File Offset: 0x000425FA
		public static Shader GradientColorOpaque
		{
			get
			{
				if (SVGShader._GradientColorOpaque == null)
				{
					SVGShader._GradientColorOpaque = Shader.Find("SVG Importer/GradientColor/GradientColorOpaque");
				}
				return SVGShader._GradientColorOpaque;
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000A73 RID: 2675 RVA: 0x0004441D File Offset: 0x0004261D
		public static Shader SolidColorAlphaBlended
		{
			get
			{
				if (SVGShader._SolidColorAlphaBlended == null)
				{
					SVGShader._SolidColorAlphaBlended = Shader.Find("SVG Importer/SolidColor/SolidColorAlphaBlended");
				}
				return SVGShader._SolidColorAlphaBlended;
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000A74 RID: 2676 RVA: 0x00044440 File Offset: 0x00042640
		public static Shader SolidColorAlphaBlendedAntialiased
		{
			get
			{
				if (SVGShader._SolidColorAlphaBlendedAntialiased == null)
				{
					SVGShader._SolidColorAlphaBlendedAntialiased = Shader.Find("SVG Importer/SolidColor/SolidColorAlphaBlendedAntialiased");
				}
				return SVGShader._SolidColorAlphaBlendedAntialiased;
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000A75 RID: 2677 RVA: 0x00044463 File Offset: 0x00042663
		public static Shader SolidColorOpaque
		{
			get
			{
				if (SVGShader._SolidColorOpaque == null)
				{
					SVGShader._SolidColorOpaque = Shader.Find("SVG Importer/SolidColor/SolidColorOpaque");
				}
				return SVGShader._SolidColorOpaque;
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000A76 RID: 2678 RVA: 0x00044486 File Offset: 0x00042686
		public static Shader UI
		{
			get
			{
				if (SVGShader._UI == null)
				{
					SVGShader._UI = Shader.Find("SVG Importer/UI/UI");
				}
				return SVGShader._UI;
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000A77 RID: 2679 RVA: 0x000444A9 File Offset: 0x000426A9
		public static Shader UIAntialiased
		{
			get
			{
				if (SVGShader._UIAntialiased == null)
				{
					SVGShader._UI = Shader.Find("SVG Importer/UI/UIAntialiased");
				}
				return SVGShader._UI;
			}
		}

		// Token: 0x04000963 RID: 2403
		protected static Shader _GradientColorAlphaBlended;

		// Token: 0x04000964 RID: 2404
		protected static Shader _GradientColorAlphaBlendedAntialiased;

		// Token: 0x04000965 RID: 2405
		protected static Shader _GradientColorOpaque;

		// Token: 0x04000966 RID: 2406
		protected static Shader _SolidColorAlphaBlended;

		// Token: 0x04000967 RID: 2407
		protected static Shader _SolidColorAlphaBlendedAntialiased;

		// Token: 0x04000968 RID: 2408
		protected static Shader _SolidColorOpaque;

		// Token: 0x04000969 RID: 2409
		protected static Shader _UI;

		// Token: 0x0400096A RID: 2410
		protected static Shader _UIAntialiased;
	}
}
