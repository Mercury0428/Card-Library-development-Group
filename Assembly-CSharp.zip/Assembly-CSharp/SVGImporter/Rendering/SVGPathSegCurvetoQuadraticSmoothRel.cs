﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014C RID: 332
	public class SVGPathSegCurvetoQuadraticSmoothRel : SVGPathSegCurvetoQuadratic
	{
		// Token: 0x06000A2E RID: 2606 RVA: 0x000416E4 File Offset: 0x0003F8E4
		public SVGPathSegCurvetoQuadraticSmoothRel(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Quadratic_Smooth_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
			SVGPathSegCurvetoQuadratic svgpathSegCurvetoQuadratic = segment as SVGPathSegCurvetoQuadratic;
			if (svgpathSegCurvetoQuadratic != null)
			{
				this._controlPoint1 = this._previousPoint + (this._previousPoint - svgpathSegCurvetoQuadratic.controlPoint1);
				return;
			}
			this._controlPoint1 = this._previousPoint;
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000A2F RID: 2607 RVA: 0x0004176A File Offset: 0x0003F96A
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x0400095D RID: 2397
		protected Vector2 _controlPoint1 = Vector2.zero;
	}
}
