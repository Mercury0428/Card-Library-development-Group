﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000121 RID: 289
	public class SVGPolylineElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600093F RID: 2367 RVA: 0x0003CB9F File Offset: 0x0003AD9F
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000940 RID: 2368 RVA: 0x0003CBA7 File Offset: 0x0003ADA7
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06000941 RID: 2369 RVA: 0x0003CBAF File Offset: 0x0003ADAF
		public List<Vector2> listPoints
		{
			get
			{
				return this._listPoints;
			}
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x0003CBB8 File Offset: 0x0003ADB8
		public SVGPolylineElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._listPoints = this.ExtractPoints(this._attrList.GetValue("points"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0003CC58 File Offset: 0x0003AE58
		private List<Vector2> ExtractPoints(string inputText)
		{
			List<Vector2> list = new List<Vector2>();
			string[] array = SVGStringExtractor.ExtractTransformValue(inputText);
			int num = array.Length;
			for (int i = 0; i < num - 1; i++)
			{
				string valueText = array[i];
				string valueText2 = array[i + 1];
				SVGLength svglength = new SVGLength(valueText);
				SVGLength svglength2 = new SVGLength(valueText2);
				Vector2 item = new Vector2(svglength.value, svglength2.value);
				list.Add(item);
				i++;
			}
			return list;
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x0003CCC4 File Offset: 0x0003AEC4
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> list = new List<Vector2>(this.listPoints.Count + 1);
			for (int i = 0; i < this.listPoints.Count; i++)
			{
				list.Add(base.transformMatrix.Transform(this.listPoints[i]));
			}
			return new List<List<Vector2>>
			{
				SVGBezier.Optimise(list, SVGGraphics.vpm, 0, -1)
			};
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x0003CD34 File Offset: 0x0003AF34
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.Add(path[0]);
			}
			if (this.paintable.IsStroke())
			{
				List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
				{
					SVGSimplePath.GetSegments(path[0])
				}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.NEVER, SVGGraphics.roundQuality);
				if (list2 != null && list2.Count > 0)
				{
					list.AddRange(list2);
				}
			}
			return list;
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x0003CE29 File Offset: 0x0003B029
		public void Render()
		{
			SVGGraphics.Create(this, "Polyline Element", ClosePathRule.NEVER);
		}

		// Token: 0x04000895 RID: 2197
		private List<Vector2> _listPoints;

		// Token: 0x04000896 RID: 2198
		private AttributeList _attrList;

		// Token: 0x04000897 RID: 2199
		private SVGPaintable _paintable;
	}
}
