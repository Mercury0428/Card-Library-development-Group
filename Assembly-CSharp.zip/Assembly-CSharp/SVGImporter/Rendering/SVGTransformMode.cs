﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000130 RID: 304
	public enum SVGTransformMode : ushort
	{
		// Token: 0x040008FC RID: 2300
		Unknown,
		// Token: 0x040008FD RID: 2301
		Matrix,
		// Token: 0x040008FE RID: 2302
		Translate,
		// Token: 0x040008FF RID: 2303
		Scale,
		// Token: 0x04000900 RID: 2304
		Rotate,
		// Token: 0x04000901 RID: 2305
		SkewX,
		// Token: 0x04000902 RID: 2306
		SkewY
	}
}
