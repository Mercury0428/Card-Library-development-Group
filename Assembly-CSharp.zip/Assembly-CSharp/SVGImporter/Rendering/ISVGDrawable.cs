﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013B RID: 315
	public interface ISVGDrawable
	{
		// Token: 0x060009EE RID: 2542
		void BeforeRender(SVGTransformList transformList);

		// Token: 0x060009EF RID: 2543
		void Render();
	}
}
