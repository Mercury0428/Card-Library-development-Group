﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000125 RID: 293
	public enum SVGClipRule
	{
		// Token: 0x040008A9 RID: 2217
		nonzero,
		// Token: 0x040008AA RID: 2218
		evenodd
	}
}
