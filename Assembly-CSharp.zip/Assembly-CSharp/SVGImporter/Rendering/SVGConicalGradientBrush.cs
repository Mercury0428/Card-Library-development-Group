﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000119 RID: 281
	public class SVGConicalGradientBrush
	{
		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060008E2 RID: 2274 RVA: 0x0003A2C5 File Offset: 0x000384C5
		public bool alphaBlended
		{
			get
			{
				return this._alphaBlended;
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060008E3 RID: 2275 RVA: 0x0003A2CD File Offset: 0x000384CD
		public SVGFill fill
		{
			get
			{
				return this._fill;
			}
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x0003A2D5 File Offset: 0x000384D5
		public SVGConicalGradientBrush(SVGConicalGradientElement conicalGradElement)
		{
			this._transform = SVGMatrix.identity;
			this._conicalGradElement = conicalGradElement;
			this.Initialize();
			this.CreateFill();
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x0003A2FB File Offset: 0x000384FB
		public SVGConicalGradientBrush(SVGConicalGradientElement conicalGradElement, Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			this._viewport = viewport;
			this._transform = matrix;
			this._conicalGradElement = conicalGradElement;
			this.Initialize();
			this.CreateFill(bounds);
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x0003A326 File Offset: 0x00038526
		protected Color GetColor(SVGColor svgColor)
		{
			if (svgColor.color.a != 1f)
			{
				this._alphaBlended = true;
			}
			return svgColor.color;
		}

		// Token: 0x060008E7 RID: 2279 RVA: 0x0003A348 File Offset: 0x00038548
		private void Initialize()
		{
			this._cx = this._conicalGradElement.cx;
			this._cy = this._conicalGradElement.cy;
			this._r = this._conicalGradElement.r;
			this._stopColorList = new List<Color>();
			this._stopOffsetList = new List<float>();
			this.GetStopList();
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x0003A3A4 File Offset: 0x000385A4
		private void CreateFill()
		{
			if (this._alphaBlended)
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.ALPHA_BLENDED, FILL_TYPE.GRADIENT, GRADIENT_TYPE.CONICAL);
			}
			else
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.OPAQUE, FILL_TYPE.GRADIENT, GRADIENT_TYPE.CONICAL);
			}
			this._gradientTransform = this._conicalGradElement.gradientTransform.Consolidate().matrix;
			this._fill.gradientColors = SVGAssetImport.atlasData.AddGradient(this.ParseGradientColors());
			this._fill.viewport = this._viewport;
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x0003A434 File Offset: 0x00038634
		private void CreateFill(Rect bounds)
		{
			this.CreateFill();
			this._fill.transform = SVGSimplePath.GetFillTransform(this._fill, bounds, new SVGLength[]
			{
				this._cx,
				this._cy
			}, new SVGLength[]
			{
				this._r,
				this._r
			}, this._transform, this._gradientTransform);
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x0003A4AC File Offset: 0x000386AC
		public CCGradient ParseGradientColors()
		{
			int count = this._stopColorList.Count;
			CCGradientColorKey[] array = new CCGradientColorKey[count];
			CCGradientAlphaKey[] array2 = new CCGradientAlphaKey[count];
			for (int i = 0; i < count; i++)
			{
				float time = Mathf.Clamp01(this._stopOffsetList[i] * 0.01f);
				array[i] = new CCGradientColorKey(this._stopColorList[i], time);
				array2[i] = new CCGradientAlphaKey(this._stopColorList[i].a, time);
			}
			return new CCGradient(array, array2, true);
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0003A54C File Offset: 0x0003874C
		private void GetStopList()
		{
			List<SVGStopElement> stopList = this._conicalGradElement.stopList;
			int count = stopList.Count;
			if (count == 0)
			{
				return;
			}
			this._stopColorList.Add(this.GetColor(stopList[0].stopColor));
			this._stopOffsetList.Add(0f);
			for (int i = 0; i < count; i++)
			{
				float offset = stopList[i].offset;
				if (offset > this._stopOffsetList[this._stopOffsetList.Count - 1] && offset <= 100f)
				{
					this._stopColorList.Add(this.GetColor(stopList[i].stopColor));
					this._stopOffsetList.Add(offset);
				}
				else if (offset == this._stopOffsetList[this._stopOffsetList.Count - 1])
				{
					this._stopColorList[this._stopOffsetList.Count - 1] = this.GetColor(stopList[i].stopColor);
				}
			}
			if (this._stopOffsetList[this._stopOffsetList.Count - 1] != 100f)
			{
				this._stopColorList.Add(this._stopColorList[this._stopOffsetList.Count - 1]);
				this._stopOffsetList.Add(100f);
			}
		}

		// Token: 0x04000854 RID: 2132
		private SVGConicalGradientElement _conicalGradElement;

		// Token: 0x04000855 RID: 2133
		private SVGLength _cx;

		// Token: 0x04000856 RID: 2134
		private SVGLength _cy;

		// Token: 0x04000857 RID: 2135
		private SVGLength _r;

		// Token: 0x04000858 RID: 2136
		private List<Color> _stopColorList;

		// Token: 0x04000859 RID: 2137
		private List<float> _stopOffsetList;

		// Token: 0x0400085A RID: 2138
		protected bool _alphaBlended;

		// Token: 0x0400085B RID: 2139
		protected SVGFill _fill;

		// Token: 0x0400085C RID: 2140
		protected SVGMatrix _gradientTransform;

		// Token: 0x0400085D RID: 2141
		protected SVGMatrix _transform;

		// Token: 0x0400085E RID: 2142
		protected Rect _viewport;
	}
}
