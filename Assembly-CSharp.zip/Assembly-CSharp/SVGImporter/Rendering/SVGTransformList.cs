﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;

namespace SVGImporter.Rendering
{
	// Token: 0x02000132 RID: 306
	public class SVGTransformList
	{
		// Token: 0x1700012F RID: 303
		// (get) Token: 0x060009C3 RID: 2499 RVA: 0x0003F930 File Offset: 0x0003DB30
		public int Count
		{
			get
			{
				return this._listTransform.Count;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x060009C4 RID: 2500 RVA: 0x0003F940 File Offset: 0x0003DB40
		public SVGMatrix totalMatrix
		{
			get
			{
				if (this._listTransform.Count == 0)
				{
					return SVGMatrix.identity;
				}
				SVGMatrix result = this._listTransform[0].matrix;
				for (int i = 1; i < this._listTransform.Count; i++)
				{
					result = result.Multiply(this._listTransform[i].matrix);
				}
				return result;
			}
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x0003F9A2 File Offset: 0x0003DBA2
		public SVGTransformList()
		{
			this._listTransform = new List<SVGTransform>();
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0003F9B5 File Offset: 0x0003DBB5
		public SVGTransformList(int capacity)
		{
			this._listTransform = new List<SVGTransform>(capacity);
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x0003F9C9 File Offset: 0x0003DBC9
		public SVGTransformList(string listString)
		{
			this._listTransform = SVGStringExtractor.ExtractTransformList(listString);
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x0003F9DD File Offset: 0x0003DBDD
		public void Clear()
		{
			this._listTransform.Clear();
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x0003F9EA File Offset: 0x0003DBEA
		public void AppendItem(SVGTransform newItem)
		{
			this._listTransform.Add(newItem);
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x0003F9F8 File Offset: 0x0003DBF8
		public void AppendItemAt(SVGTransform newItem, int index)
		{
			this._listTransform.Insert(index, newItem);
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x0003FA07 File Offset: 0x0003DC07
		public void AppendItems(SVGTransformList newListItem)
		{
			this._listTransform.AddRange(newListItem._listTransform);
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x0003FA1A File Offset: 0x0003DC1A
		public void AppendItemsAt(SVGTransformList newListItem, int index)
		{
			this._listTransform.InsertRange(index, newListItem._listTransform);
		}

		// Token: 0x17000131 RID: 305
		public SVGTransform this[int index]
		{
			get
			{
				if (index < 0 || index >= this._listTransform.Count)
				{
					throw new DOMException(DOMExceptionType.IndexSizeErr);
				}
				return this._listTransform[index];
			}
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x0003FA55 File Offset: 0x0003DC55
		public SVGTransform Consolidate()
		{
			return new SVGTransform(this.totalMatrix);
		}

		// Token: 0x04000906 RID: 2310
		private List<SVGTransform> _listTransform;
	}
}
