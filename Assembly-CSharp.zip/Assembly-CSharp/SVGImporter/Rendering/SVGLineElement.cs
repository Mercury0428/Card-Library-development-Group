﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011F RID: 287
	public class SVGLineElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x0600092B RID: 2347 RVA: 0x0003C666 File Offset: 0x0003A866
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x0600092C RID: 2348 RVA: 0x0003C66E File Offset: 0x0003A86E
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600092D RID: 2349 RVA: 0x0003C676 File Offset: 0x0003A876
		public SVGLength x1
		{
			get
			{
				return this._x1;
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600092E RID: 2350 RVA: 0x0003C67E File Offset: 0x0003A87E
		public SVGLength y1
		{
			get
			{
				return this._y1;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600092F RID: 2351 RVA: 0x0003C686 File Offset: 0x0003A886
		public SVGLength x2
		{
			get
			{
				return this._x2;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000930 RID: 2352 RVA: 0x0003C68E File Offset: 0x0003A88E
		public SVGLength y2
		{
			get
			{
				return this._y2;
			}
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x0003C698 File Offset: 0x0003A898
		public SVGLineElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._x1 = new SVGLength(this.attrList.GetValue("x1"));
			this._y1 = new SVGLength(this.attrList.GetValue("y1"));
			this._x2 = new SVGLength(this.attrList.GetValue("x2"));
			this._y2 = new SVGLength(this.attrList.GetValue("y2"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x0003C794 File Offset: 0x0003A994
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> item = new List<Vector2>
			{
				base.transformMatrix.Transform(new Vector2(this.x1.value, this.y1.value)),
				base.transformMatrix.Transform(new Vector2(this.x2.value, this.y2.value))
			};
			return new List<List<Vector2>>
			{
				item
			};
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x0003C820 File Offset: 0x0003AA20
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
			{
				SVGSimplePath.GetSegments(path[0])
			}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.NEVER, SVGGraphics.roundQuality);
			if (list2 != null && list2.Count > 0)
			{
				list.AddRange(list2);
			}
			return list;
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x0003C8EB File Offset: 0x0003AAEB
		public void Render()
		{
			SVGGraphics.Create(this, "Line Element", ClosePathRule.NEVER);
		}

		// Token: 0x0400088C RID: 2188
		private SVGLength _x1;

		// Token: 0x0400088D RID: 2189
		private SVGLength _y1;

		// Token: 0x0400088E RID: 2190
		private SVGLength _x2;

		// Token: 0x0400088F RID: 2191
		private SVGLength _y2;

		// Token: 0x04000890 RID: 2192
		private AttributeList _attrList;

		// Token: 0x04000891 RID: 2193
		private SVGPaintable _paintable;
	}
}
