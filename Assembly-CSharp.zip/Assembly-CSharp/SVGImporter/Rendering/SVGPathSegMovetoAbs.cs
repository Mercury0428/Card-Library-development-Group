﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000154 RID: 340
	public class SVGPathSegMovetoAbs : SVGPathSeg
	{
		// Token: 0x06000A3E RID: 2622 RVA: 0x00041989 File Offset: 0x0003FB89
		public SVGPathSegMovetoAbs(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.MoveTo_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			else
			{
				this._previousPoint = this._currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
		}
	}
}
