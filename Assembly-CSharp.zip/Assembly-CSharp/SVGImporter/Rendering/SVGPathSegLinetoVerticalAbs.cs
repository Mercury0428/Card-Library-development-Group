﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000151 RID: 337
	public class SVGPathSegLinetoVerticalAbs : SVGPathSeg
	{
		// Token: 0x06000A34 RID: 2612 RVA: 0x00041844 File Offset: 0x0003FA44
		public SVGPathSegLinetoVerticalAbs(float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Vertical_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(this._previousPoint.x, y);
		}
	}
}
