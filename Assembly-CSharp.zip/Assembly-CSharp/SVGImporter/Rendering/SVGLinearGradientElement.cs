﻿using System;
using SVGImporter.Document;
using SVGImporter.Utils;

namespace SVGImporter.Rendering
{
	// Token: 0x02000137 RID: 311
	public class SVGLinearGradientElement : SVGGradientElement
	{
		// Token: 0x1700013C RID: 316
		// (get) Token: 0x060009DD RID: 2525 RVA: 0x0003FD39 File Offset: 0x0003DF39
		public SVGLength x1
		{
			get
			{
				return this._x1;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x060009DE RID: 2526 RVA: 0x0003FD41 File Offset: 0x0003DF41
		public SVGLength y1
		{
			get
			{
				return this._y1;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060009DF RID: 2527 RVA: 0x0003FD49 File Offset: 0x0003DF49
		public SVGLength x2
		{
			get
			{
				return this._x2;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060009E0 RID: 2528 RVA: 0x0003FD51 File Offset: 0x0003DF51
		public SVGLength y2
		{
			get
			{
				return this._y2;
			}
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x0003FD5C File Offset: 0x0003DF5C
		public SVGLinearGradientElement(SVGParser xmlImp, Node node) : base(xmlImp, node)
		{
			string value = this._attrList.GetValue("x1");
			this._x1 = new SVGLength((value == "") ? "0%" : value);
			value = this._attrList.GetValue("y1");
			this._y1 = new SVGLength((value == "") ? "0%" : value);
			value = this._attrList.GetValue("x2");
			this._x2 = new SVGLength((value == "") ? "100%" : value);
			value = this._attrList.GetValue("y2");
			this._y2 = new SVGLength((value == "") ? "0%" : value);
		}

		// Token: 0x0400091B RID: 2331
		private SVGLength _x1;

		// Token: 0x0400091C RID: 2332
		private SVGLength _y1;

		// Token: 0x0400091D RID: 2333
		private SVGLength _x2;

		// Token: 0x0400091E RID: 2334
		private SVGLength _y2;
	}
}
