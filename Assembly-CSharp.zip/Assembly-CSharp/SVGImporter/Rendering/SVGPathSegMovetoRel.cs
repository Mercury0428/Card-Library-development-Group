﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000155 RID: 341
	public class SVGPathSegMovetoRel : SVGPathSeg
	{
		// Token: 0x06000A3F RID: 2623 RVA: 0x000419C2 File Offset: 0x0003FBC2
		public SVGPathSegMovetoRel(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.MoveTo_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
		}
	}
}
