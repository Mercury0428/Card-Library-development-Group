﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000117 RID: 279
	public enum GRADIENT_TYPE : byte
	{
		// Token: 0x04000848 RID: 2120
		LINEAR,
		// Token: 0x04000849 RID: 2121
		RADIAL,
		// Token: 0x0400084A RID: 2122
		CONICAL
	}
}
