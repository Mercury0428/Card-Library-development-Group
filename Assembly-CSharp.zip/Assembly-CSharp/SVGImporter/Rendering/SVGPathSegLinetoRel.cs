﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000150 RID: 336
	public class SVGPathSegLinetoRel : SVGPathSeg
	{
		// Token: 0x06000A33 RID: 2611 RVA: 0x0004180E File Offset: 0x0003FA0E
		public SVGPathSegLinetoRel(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
		}
	}
}
