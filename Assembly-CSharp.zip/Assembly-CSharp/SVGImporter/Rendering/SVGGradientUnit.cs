﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000135 RID: 309
	public enum SVGGradientUnit : ushort
	{
		// Token: 0x04000912 RID: 2322
		UserSpaceOnUse,
		// Token: 0x04000913 RID: 2323
		ObjectBoundingBox
	}
}
