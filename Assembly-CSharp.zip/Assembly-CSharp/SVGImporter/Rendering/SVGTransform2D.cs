﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000159 RID: 345
	[Serializable]
	public class SVGTransform2D : ICloneable
	{
		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000A79 RID: 2681 RVA: 0x000444CC File Offset: 0x000426CC
		// (set) Token: 0x06000A7A RID: 2682 RVA: 0x000444D4 File Offset: 0x000426D4
		[HideInInspector]
		public Vector2 position
		{
			get
			{
				return this._position;
			}
			set
			{
				if (this._position == value)
				{
					return;
				}
				this._position = value;
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000A7B RID: 2683 RVA: 0x000444EC File Offset: 0x000426EC
		// (set) Token: 0x06000A7C RID: 2684 RVA: 0x000444F4 File Offset: 0x000426F4
		public float rotation
		{
			get
			{
				return this._rotation;
			}
			set
			{
				if (this._rotation == value)
				{
					return;
				}
				this._rotation = value;
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000A7D RID: 2685 RVA: 0x00044507 File Offset: 0x00042707
		// (set) Token: 0x06000A7E RID: 2686 RVA: 0x0004450F File Offset: 0x0004270F
		public Vector2 scale
		{
			get
			{
				return this._scale;
			}
			set
			{
				if (this._scale == value)
				{
					return;
				}
				this._scale = value;
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x06000A7F RID: 2687 RVA: 0x00044528 File Offset: 0x00042728
		public Matrix4x4 matrix4x4
		{
			get
			{
				return Matrix4x4.TRS(new Vector3(this._position.x, this._position.y, 0f), Quaternion.Euler(0f, 0f, this._rotation), new Vector3(this._scale.x, this._scale.y, 1f));
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000A80 RID: 2688 RVA: 0x00044590 File Offset: 0x00042790
		public SVGMatrix matrix
		{
			get
			{
				return SVGMatrix.TRS(new Vector3(this._position.x, this._position.y, 0f), this._rotation, new Vector2(this._scale.x, this._scale.y));
			}
		}

		// Token: 0x06000A81 RID: 2689 RVA: 0x000445E8 File Offset: 0x000427E8
		public SVGTransform2D()
		{
			this._position = Vector2.zero;
			this._rotation = 0f;
			this._scale = Vector2.one;
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x0004461C File Offset: 0x0004281C
		public SVGTransform2D(Vector2 position, float rotation, Vector2 scale)
		{
			this._position = position;
			this._rotation = rotation;
			this._scale = scale;
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x00044644 File Offset: 0x00042844
		public SVGTransform2D(SVGTransform2D transform)
		{
			this.SetTransform(transform);
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0004465E File Offset: 0x0004285E
		public object Clone()
		{
			return new SVGTransform2D(this._position, this._rotation, this._scale);
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x00044677 File Offset: 0x00042877
		public void SetTransform(SVGTransform2D transform)
		{
			if (transform == null)
			{
				return;
			}
			this._position = transform._position;
			this._rotation = transform._rotation;
			this._scale = transform._scale;
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x000446A1 File Offset: 0x000428A1
		public void Reset()
		{
			this._position = Vector2.zero;
			this._rotation = 0f;
			this._scale = Vector2.one;
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x000446C4 File Offset: 0x000428C4
		public void TRS(Vector2 position, float rotation, Vector2 scale)
		{
			this._position = position;
			this._rotation = rotation;
			this._scale = scale;
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x000446DB File Offset: 0x000428DB
		public bool Compare(SVGTransform2D transform)
		{
			return transform != null && (this._position == transform._position && this._rotation == transform._rotation) && this._scale == transform._scale;
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x00044718 File Offset: 0x00042918
		public static SVGTransform2D DecomposeMatrix(Matrix4x4 matrix)
		{
			return new SVGTransform2D(new Vector2(matrix[0, 3], matrix[1, 3]), Quaternion.LookRotation(new Vector3(matrix[0, 2], matrix[1, 2], matrix[2, 2]), new Vector3(matrix[0, 1], matrix[1, 1], matrix[2, 1])).eulerAngles.z, new Vector2(new Vector2(matrix[0, 0], matrix[1, 0]).magnitude, new Vector2(matrix[0, 1], matrix[1, 1]).magnitude));
		}

		// Token: 0x0400096B RID: 2411
		[SerializeField]
		protected Vector2 _position;

		// Token: 0x0400096C RID: 2412
		[SerializeField]
		protected float _rotation;

		// Token: 0x0400096D RID: 2413
		[SerializeField]
		protected Vector2 _scale = Vector2.one;
	}
}
