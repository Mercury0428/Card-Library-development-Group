﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000141 RID: 321
	public class SVGPathSegArcRel : SVGPathSeg
	{
		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000A10 RID: 2576 RVA: 0x00041254 File Offset: 0x0003F454
		public float r1
		{
			get
			{
				return this._r1;
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000A11 RID: 2577 RVA: 0x0004125C File Offset: 0x0003F45C
		public float r2
		{
			get
			{
				return this._r2;
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000A12 RID: 2578 RVA: 0x00041264 File Offset: 0x0003F464
		public float angle
		{
			get
			{
				return this._angle;
			}
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000A13 RID: 2579 RVA: 0x0004126C File Offset: 0x0003F46C
		public bool largeArcFlag
		{
			get
			{
				return this._largeArcFlag;
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x06000A14 RID: 2580 RVA: 0x00041274 File Offset: 0x0003F474
		public bool sweepFlag
		{
			get
			{
				return this._sweepFlag;
			}
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0004127C File Offset: 0x0003F47C
		public SVGPathSegArcRel(float r1, float r2, float angle, bool largeArcFlag, bool sweepFlag, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.Arc_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
			this._r1 = r1;
			this._r2 = r2;
			this._angle = angle;
			this._largeArcFlag = largeArcFlag;
			this._sweepFlag = sweepFlag;
		}

		// Token: 0x0400094D RID: 2381
		private float _r1;

		// Token: 0x0400094E RID: 2382
		private float _r2;

		// Token: 0x0400094F RID: 2383
		private float _angle;

		// Token: 0x04000950 RID: 2384
		private bool _largeArcFlag;

		// Token: 0x04000951 RID: 2385
		private bool _sweepFlag;
	}
}
