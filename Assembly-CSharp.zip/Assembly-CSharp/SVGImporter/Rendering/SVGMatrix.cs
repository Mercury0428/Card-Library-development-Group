﻿using System;
using SVGImporter.Document;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012F RID: 303
	[Serializable]
	public struct SVGMatrix
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x0600099C RID: 2460 RVA: 0x0003EC4B File Offset: 0x0003CE4B
		public static SVGMatrix identity
		{
			get
			{
				return new SVGMatrix(1f, 0f, 0f, 1f, 0f, 0f);
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x0003EC70 File Offset: 0x0003CE70
		public SVGMatrix(float a, float b, float c, float d, float e, float f)
		{
			this.a = a;
			this.b = b;
			this.c = c;
			this.d = d;
			this.e = e;
			this.f = f;
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x0600099E RID: 2462 RVA: 0x0003EC9F File Offset: 0x0003CE9F
		// (set) Token: 0x0600099F RID: 2463 RVA: 0x0003ECB2 File Offset: 0x0003CEB2
		public Vector2 position
		{
			get
			{
				return new Vector2(this.e, this.f);
			}
			set
			{
				this.e = value.x;
				this.f = value.y;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x060009A0 RID: 2464 RVA: 0x0003ECCC File Offset: 0x0003CECC
		public Vector2 scale
		{
			get
			{
				return new Vector2(Mathf.Sqrt(this.a * this.a + this.b * this.b), Mathf.Sqrt(this.c * this.c + this.d * this.d));
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x060009A1 RID: 2465 RVA: 0x0003ED20 File Offset: 0x0003CF20
		public float skewX
		{
			get
			{
				Vector2 vector = this.DeltaTransformPoint(new Vector2(0f, 1f));
				return 57.295776f * Mathf.Atan2(vector.y, vector.x) - 90f;
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x060009A2 RID: 2466 RVA: 0x0003ED60 File Offset: 0x0003CF60
		public float skewY
		{
			get
			{
				Vector2 vector = this.DeltaTransformPoint(new Vector2(1f, 0f));
				return 57.295776f * Mathf.Atan2(vector.y, vector.x);
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060009A3 RID: 2467 RVA: 0x0003ED9A File Offset: 0x0003CF9A
		public float rotation
		{
			get
			{
				return this.skewX;
			}
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x0003EDA2 File Offset: 0x0003CFA2
		private Vector2 DeltaTransformPoint(Vector2 point)
		{
			return new Vector2(point.x * this.a + point.y * this.c, point.x * this.b + point.y * this.d);
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x0003EDE0 File Offset: 0x0003CFE0
		public SVGMatrix Multiply(SVGMatrix secondMatrix)
		{
			float num = secondMatrix.a;
			float num2 = secondMatrix.b;
			float num3 = secondMatrix.c;
			float num4 = secondMatrix.d;
			float num5 = secondMatrix.e;
			float num6 = secondMatrix.f;
			return new SVGMatrix(this.a * num + this.c * num2, this.b * num + this.d * num2, this.a * num3 + this.c * num4, this.b * num3 + this.d * num4, this.a * num5 + this.c * num6 + this.e, this.b * num5 + this.d * num6 + this.f);
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x0003EE98 File Offset: 0x0003D098
		public static SVGMatrix operator *(SVGMatrix left, SVGMatrix right)
		{
			return new SVGMatrix(left.a * right.a + left.c * right.b, left.b * right.a + left.d * right.b, left.a * right.c + left.c * right.d, left.b * right.c + left.d * right.d, left.a * right.e + left.c * right.f + left.e, left.b * right.e + left.d * right.f + left.f);
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x0003EF5C File Offset: 0x0003D15C
		public SVGMatrix Inverse()
		{
			double num = (double)(this.a * this.d - this.c * this.b);
			if (num == 0.0)
			{
				throw new SVGException(SVGExceptionType.MatrixNotInvertable);
			}
			return new SVGMatrix((float)((double)this.d / num), (float)((double)(-(double)this.b) / num), (float)((double)(-(double)this.c) / num), (float)((double)this.a / num), (float)((double)(this.c * this.f - this.e * this.d) / num), (float)((double)(this.e * this.b - this.a * this.f) / num));
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x0003F006 File Offset: 0x0003D206
		public SVGMatrix Scale(float scaleFactor)
		{
			return new SVGMatrix(this.a * scaleFactor, this.b * scaleFactor, this.c * scaleFactor, this.d * scaleFactor, this.e, this.f);
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x0003F039 File Offset: 0x0003D239
		public SVGMatrix Scale(float scaleFactorX, float scaleFactorY)
		{
			return new SVGMatrix(this.a * scaleFactorX, this.b * scaleFactorX, this.c * scaleFactorY, this.d * scaleFactorY, this.e, this.f);
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x0003F06C File Offset: 0x0003D26C
		public SVGMatrix Scale(Vector2 scaleFactor)
		{
			return new SVGMatrix(this.a * scaleFactor.x, this.b * scaleFactor.x, this.c * scaleFactor.y, this.d * scaleFactor.y, this.e, this.f);
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x0003F0C0 File Offset: 0x0003D2C0
		public SVGMatrix Rotate(float angle)
		{
			float num = Mathf.Cos(angle * 0.017453292f);
			float num2 = Mathf.Sin(angle * 0.017453292f);
			return new SVGMatrix(this.a * num + this.c * num2, this.b * num + this.d * num2, this.c * num - this.a * num2, this.d * num - this.b * num2, this.e, this.f);
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x0003F140 File Offset: 0x0003D340
		public SVGMatrix Translate(float x, float y)
		{
			return new SVGMatrix(this.a, this.b, this.c, this.d, this.a * x + this.c * y + this.e, this.b * x + this.d * y + this.f);
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x0003F19C File Offset: 0x0003D39C
		public SVGMatrix Translate(Vector2 position)
		{
			return new SVGMatrix(this.a, this.b, this.c, this.d, this.a * position.x + this.c * position.y + this.e, this.b * position.x + this.d * position.y + this.f);
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x0003F20C File Offset: 0x0003D40C
		public SVGMatrix SkewX(float angle)
		{
			float num = Mathf.Tan(angle * 0.017453292f);
			return new SVGMatrix(this.a, this.b, this.c + this.a * num, this.d + this.b * num, this.e, this.f);
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x0003F264 File Offset: 0x0003D464
		public SVGMatrix SkewY(float angle)
		{
			float num = Mathf.Tan(angle * 0.017453292f);
			return new SVGMatrix(this.a + this.c * num, this.b + this.d * num, this.c, this.d, this.e, this.f);
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x0003F2BC File Offset: 0x0003D4BC
		public Vector2 Transform(Vector2 point)
		{
			return new Vector2(this.a * point.x + this.c * point.y + this.e, this.b * point.x + this.d * point.y + this.f);
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x0003F314 File Offset: 0x0003D514
		public Vector3 Transform(Vector3 point)
		{
			return new Vector3(this.a * point.x + this.c * point.y + this.e, this.b * point.x + this.d * point.y + this.f, 0f);
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x0003F370 File Offset: 0x0003D570
		public static SVGMatrix TRS(Vector2 position, float rotation, Vector2 scale)
		{
			float num = Mathf.Cos(rotation * 0.017453292f);
			float num2 = Mathf.Sin(rotation * 0.017453292f);
			return new SVGMatrix((1f * num + 0f * num2) * scale.x, (0f * num + 1f * num2) * scale.x, (0f * num - 1f * num2) * scale.y, (1f * num - 0f * num2) * scale.y, 1f * position.x + 0f * position.y + 0f, 0f * position.x + 1f * position.y + 0f);
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0003F434 File Offset: 0x0003D634
		public Matrix4x4 ToMatrix4x4()
		{
			Matrix4x4 identity = Matrix4x4.identity;
			identity[0, 0] = this.a;
			identity[0, 1] = this.b;
			identity[1, 0] = this.c;
			identity[1, 1] = this.d;
			identity[2, 0] = this.e;
			identity[2, 1] = this.f;
			return identity;
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0003F4A4 File Offset: 0x0003D6A4
		public void Reset()
		{
			this.a = 1f;
			this.b = 0f;
			this.c = 0f;
			this.d = 1f;
			this.e = 0f;
			this.f = 0f;
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x0003F4F4 File Offset: 0x0003D6F4
		public override string ToString()
		{
			return string.Format("[SVGMatrix] a: {0}, b: {1}, c: {2}, d: {3}, e: {4}, f: {5}", new object[]
			{
				this.a,
				this.b,
				this.c,
				this.d,
				this.e,
				this.f
			}) + string.Format("\nposition: {0}, rotation: {1}, skewX: {2}, skewY: {3}, scale: {4}", new object[]
			{
				this.position,
				this.rotation,
				this.skewX,
				this.skewY,
				this.scale
			});
		}

		// Token: 0x040008F5 RID: 2293
		public float a;

		// Token: 0x040008F6 RID: 2294
		public float b;

		// Token: 0x040008F7 RID: 2295
		public float c;

		// Token: 0x040008F8 RID: 2296
		public float d;

		// Token: 0x040008F9 RID: 2297
		public float e;

		// Token: 0x040008FA RID: 2298
		public float f;
	}
}
