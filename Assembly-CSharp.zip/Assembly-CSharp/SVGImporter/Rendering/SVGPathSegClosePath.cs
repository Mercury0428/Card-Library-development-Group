﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000142 RID: 322
	public class SVGPathSegClosePath : SVGPathSeg
	{
		// Token: 0x06000A16 RID: 2582 RVA: 0x000412E7 File Offset: 0x0003F4E7
		public SVGPathSegClosePath(Vector2 value, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.Close;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = value;
		}
	}
}
