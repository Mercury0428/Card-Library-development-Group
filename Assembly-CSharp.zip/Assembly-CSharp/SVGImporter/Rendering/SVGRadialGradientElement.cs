﻿using System;
using SVGImporter.Document;
using SVGImporter.Utils;

namespace SVGImporter.Rendering
{
	// Token: 0x02000138 RID: 312
	public class SVGRadialGradientElement : SVGGradientElement
	{
		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060009E2 RID: 2530 RVA: 0x0003FE35 File Offset: 0x0003E035
		public SVGLength cx
		{
			get
			{
				return this._cx;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060009E3 RID: 2531 RVA: 0x0003FE3D File Offset: 0x0003E03D
		public SVGLength cy
		{
			get
			{
				return this._cy;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060009E4 RID: 2532 RVA: 0x0003FE45 File Offset: 0x0003E045
		public SVGLength r
		{
			get
			{
				return this._r;
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060009E5 RID: 2533 RVA: 0x0003FE4D File Offset: 0x0003E04D
		public SVGLength fx
		{
			get
			{
				return this._fx;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060009E6 RID: 2534 RVA: 0x0003FE55 File Offset: 0x0003E055
		public SVGLength fy
		{
			get
			{
				return this._fy;
			}
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x0003FE60 File Offset: 0x0003E060
		public SVGRadialGradientElement(SVGParser xmlImp, Node node) : base(xmlImp, node)
		{
			string value = this._attrList.GetValue("cx");
			this._cx = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("cy");
			this._cy = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("r");
			this._r = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("fx");
			this._fx = new SVGLength((value == "") ? "50%" : value);
			value = this._attrList.GetValue("fy");
			this._fy = new SVGLength((value == "") ? "50%" : value);
		}

		// Token: 0x0400091F RID: 2335
		private SVGLength _cx;

		// Token: 0x04000920 RID: 2336
		private SVGLength _cy;

		// Token: 0x04000921 RID: 2337
		private SVGLength _r;

		// Token: 0x04000922 RID: 2338
		private SVGLength _fx;

		// Token: 0x04000923 RID: 2339
		private SVGLength _fy;
	}
}
