﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011A RID: 282
	public class SVGGraphics
	{
		// Token: 0x060008EC RID: 2284 RVA: 0x0003A6A3 File Offset: 0x000388A3
		public static void AddLayer(SVGLayer layer)
		{
			SVGGraphics.layers.Add(layer);
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x0003A6B0 File Offset: 0x000388B0
		public static void Create(ISVGElement svgElement, string defaultName = null, ClosePathRule closePathRule = ClosePathRule.ALWAYS)
		{
			if (svgElement == null)
			{
				return;
			}
			if (svgElement.paintable.visibility != SVGVisibility.Visible || svgElement.paintable.display == SVGDisplay.None)
			{
				return;
			}
			List<SVGShape> list = new List<SVGShape>();
			List<List<Vector2>> path = svgElement.GetPath();
			if (path.Count == 1)
			{
				if (svgElement.paintable.IsFill())
				{
					List<List<Vector2>> inputShapes = path;
					if (svgElement.paintable.clipPathList != null && svgElement.paintable.clipPathList.Count > 0)
					{
						inputShapes = SVGGeom.ClipPolygon(new List<List<Vector2>>
						{
							path[0]
						}, svgElement.paintable.clipPathList);
					}
					SVGShape[] shapes = SVGGraphics.GetShapes(inputShapes, svgElement.paintable, svgElement.transformMatrix, false);
					if (shapes != null && shapes.Length != 0)
					{
						list.AddRange(shapes);
					}
				}
				if (svgElement.paintable.IsStroke())
				{
					List<List<Vector2>> list2 = SVGSimplePath.CreateStroke(path[0], svgElement.paintable, closePathRule);
					if (svgElement.paintable.clipPathList != null && svgElement.paintable.clipPathList.Count > 0)
					{
						list2 = SVGGeom.ClipPolygon(list2, svgElement.paintable.clipPathList);
					}
					SVGShape[] shapes2 = SVGGraphics.GetShapes(list2, svgElement.paintable, svgElement.transformMatrix, true);
					if (shapes2 != null && shapes2.Length != 0)
					{
						list.AddRange(shapes2);
					}
				}
			}
			else
			{
				if (svgElement.paintable.IsFill())
				{
					List<List<Vector2>> inputShapes2 = path;
					if (svgElement.paintable.clipPathList != null && svgElement.paintable.clipPathList.Count > 0)
					{
						inputShapes2 = SVGGeom.ClipPolygon(path, svgElement.paintable.clipPathList);
					}
					SVGShape[] shapes3 = SVGGraphics.GetShapes(inputShapes2, svgElement.paintable, svgElement.transformMatrix, false);
					if (shapes3 != null && shapes3.Length != 0)
					{
						list.AddRange(shapes3);
					}
				}
				if (svgElement.paintable.IsStroke())
				{
					List<List<Vector2>> list3 = SVGSimplePath.CreateStroke(path, svgElement.paintable, closePathRule);
					if (svgElement.paintable.clipPathList != null && svgElement.paintable.clipPathList.Count > 0)
					{
						list3 = SVGGeom.ClipPolygon(list3, svgElement.paintable.clipPathList);
					}
					SVGShape[] shapes4 = SVGGraphics.GetShapes(list3, svgElement.paintable, svgElement.transformMatrix, true);
					if (shapes4 != null && shapes4.Length != 0)
					{
						list.AddRange(shapes4);
					}
				}
			}
			if (list.Count > 0)
			{
				string text = svgElement.attrList.GetValue("id");
				if (string.IsNullOrEmpty(text))
				{
					text = defaultName;
				}
				SVGGraphics.AddLayer(new SVGLayer
				{
					shapes = list.ToArray(),
					name = text
				});
			}
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x0003A928 File Offset: 0x00038B28
		public static void CorrectSVGLayers(List<SVGLayer> layers, Rect viewport, SVGAsset asset, out Vector2 offset)
		{
			offset = Vector2.zero;
			if (layers == null)
			{
				return;
			}
			int count = layers.Count;
			for (int i = 0; i < count; i++)
			{
				SVGGraphics.CorrectSVGLayerShape(layers[i].shapes);
			}
			float num = float.MaxValue;
			float num2 = float.MinValue;
			float num3 = float.MaxValue;
			float num4 = float.MinValue;
			for (int j = 0; j < count; j++)
			{
				if (layers[j].shapes != null)
				{
					int num5 = layers[j].shapes.Length;
					for (int k = 0; k < num5; k++)
					{
						Vector2 min = layers[j].shapes[k].bounds.min;
						Vector2 max = layers[j].shapes[k].bounds.max;
						if (min.x < num)
						{
							num = min.x;
						}
						if (max.x > num2)
						{
							num2 = max.x;
						}
						if (min.y < num3)
						{
							num3 = min.y;
						}
						if (max.y > num4)
						{
							num4 = max.y;
						}
					}
				}
			}
			Rect rect = new Rect(num, num3, num2 - num, num4 - num3);
			if (asset.ignoreSVGCanvas)
			{
				offset = new Vector2(rect.min.x + rect.size.x * asset.pivotPoint.x, rect.max.y - rect.size.y * asset.pivotPoint.y);
			}
			else
			{
				offset = new Vector2(viewport.min.x + viewport.size.x * asset.pivotPoint.x, viewport.max.y - viewport.size.y * asset.pivotPoint.y);
			}
			for (int l = 0; l < count; l++)
			{
				if (layers[l].shapes != null)
				{
					int num5 = layers[l].shapes.Length;
					for (int m = 0; m < num5; m++)
					{
						if (layers[l].shapes[m].vertices != null)
						{
							int num6 = layers[l].shapes[m].vertices.Length;
							for (int n = 0; n < num6; n++)
							{
								layers[l].shapes[m].vertices[n] -= offset;
							}
							SVGShape[] shapes = layers[l].shapes;
							int num7 = m;
							shapes[num7].bounds.center = shapes[num7].bounds.center - offset;
							if (layers[l].shapes[m].fill != null)
							{
								layers[l].shapes[m].fill.transform = layers[l].shapes[m].fill.transform.Translate(offset);
							}
						}
					}
				}
			}
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x0003AC90 File Offset: 0x00038E90
		protected static void CorrectSVGLayerShape(SVGShape[] shapes)
		{
			for (int i = 0; i < shapes.Length; i++)
			{
				int vertexCount = shapes[i].vertexCount;
				if (vertexCount != 0)
				{
					if (shapes[i].fill != null)
					{
						shapes[i].fill.transform = shapes[i].fill.transform.Scale(1f, -1f);
					}
					for (int j = 0; j < vertexCount; j++)
					{
						Vector2[] vertices = shapes[i].vertices;
						int num = j;
						vertices[num].y = vertices[num].y * -1f;
					}
					shapes[i].bounds.center = new Vector2(shapes[i].bounds.center.x, shapes[i].bounds.center.y * -1f);
				}
			}
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x0003AD78 File Offset: 0x00038F78
		public static SVGShape[] GetShapes(List<List<Vector2>> inputShapes, SVGPaintable paintable, SVGMatrix matrix, bool isStroke = false)
		{
			SVGShape[] result = null;
			SVGShape svgshape;
			SVGShape svgshape2;
			if (SVGSimplePath.CreatePolygon(inputShapes, paintable, matrix, out svgshape, out svgshape2, isStroke, SVGGraphics._antialiasing))
			{
				if (SVGGraphics._antialiasing)
				{
					result = new SVGShape[]
					{
						svgshape,
						svgshape2
					};
				}
				else
				{
					result = new SVGShape[]
					{
						svgshape
					};
				}
			}
			return result;
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060008F1 RID: 2289 RVA: 0x0003ADCB File Offset: 0x00038FCB
		public static float vpm
		{
			get
			{
				return SVGGraphics._vpm;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060008F2 RID: 2290 RVA: 0x0003ADD2 File Offset: 0x00038FD2
		public static float roundQuality
		{
			get
			{
				return SVGGraphics._roundQuality;
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060008F3 RID: 2291 RVA: 0x0003ADD9 File Offset: 0x00038FD9
		public static float vertexPerMeter
		{
			get
			{
				return SVGGraphics._vertexPerMeter;
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060008F4 RID: 2292 RVA: 0x0003ADE0 File Offset: 0x00038FE0
		public static bool antialiasing
		{
			get
			{
				return SVGGraphics._antialiasing;
			}
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0003ADE7 File Offset: 0x00038FE7
		public static void Clear()
		{
			if (SVGGraphics.layers != null)
			{
				SVGGraphics.layers.Clear();
				SVGGraphics.layers = null;
			}
			if (SVGGraphics.paths != null)
			{
				SVGGraphics.paths.Clear();
				SVGGraphics.paths = null;
			}
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0003AE17 File Offset: 0x00039017
		public static void Init()
		{
			if (SVGGraphics.layers == null)
			{
				SVGGraphics.layers = new List<SVGLayer>();
			}
			if (SVGGraphics.paths == null)
			{
				SVGGraphics.paths = new List<SVGPath>();
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060008F7 RID: 2295 RVA: 0x0003AE3B File Offset: 0x0003903B
		public SVGStrokeLineCapMethod strokeLineCap
		{
			get
			{
				return this._strokeLineCap;
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060008F8 RID: 2296 RVA: 0x0003AE43 File Offset: 0x00039043
		public SVGStrokeLineJoinMethod strokeLineJoin
		{
			get
			{
				return this._strokeLineJoin;
			}
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0003AE4C File Offset: 0x0003904C
		public SVGGraphics(float vertexPerMeter = 1000f, bool antialiasing = false)
		{
			SVGGraphics._vpm = 1f;
			if (vertexPerMeter > 0f)
			{
				SVGGraphics._vpm = 1000f / vertexPerMeter;
			}
			else
			{
				SVGGraphics._vpm = 1000f;
			}
			if (SVGGraphics._vpm != 0f)
			{
				SVGGraphics._roundQuality = 1f / SVGGraphics._vpm * 0.5f;
			}
			else
			{
				SVGGraphics._roundQuality = 0f;
			}
			SVGGraphics._vertexPerMeter = vertexPerMeter;
			SVGGraphics._antialiasing = antialiasing;
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0003AEC3 File Offset: 0x000390C3
		public void SetStrokeLineCap(SVGStrokeLineCapMethod strokeLineCap)
		{
			this._strokeLineCap = strokeLineCap;
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x0003AECC File Offset: 0x000390CC
		public void SetStrokeLineJoin(SVGStrokeLineJoinMethod strokeLineJoin)
		{
			this._strokeLineJoin = strokeLineJoin;
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x0003AED8 File Offset: 0x000390D8
		public bool GetThickLine(Vector2 p1, Vector2 p2, float width, ref Vector2 rp1, ref Vector2 rp2, ref Vector2 rp3, ref Vector2 rp4)
		{
			int num = (int)(width / 2f);
			int num2 = (int)(width - (float)num + 0.5f);
			float num3 = p2.x - p1.x;
			float num4 = p2.y - p1.y;
			float num5 = num3 * num3 + num4 * num4;
			if (num5 == 0f)
			{
				rp1.x = p1.x - (float)num2;
				rp1.y = p1.y + (float)num2;
				rp2.x = p1.x - (float)num2;
				rp2.y = p1.y - (float)num2;
				rp3.x = p1.x + (float)num;
				rp3.y = p1.y + (float)num;
				rp4.x = p1.x + (float)num;
				rp4.y = p1.y - (float)num;
				return false;
			}
			float num6 = (float)num * num3 / (float)Math.Sqrt((double)num5) + p1.y;
			float num7;
			if (num3 == 0f)
			{
				if (num4 > 0f)
				{
					num7 = p1.x - (float)num;
				}
				else
				{
					num7 = p1.x + (float)num;
				}
			}
			else
			{
				num7 = -(num6 - p1.y) * num4 / num3 + p1.x;
			}
			float num8 = -((float)num2 * num3 / (float)Math.Sqrt((double)num5)) + p1.y;
			float x;
			if (num3 == 0f)
			{
				if (num4 > 0f)
				{
					x = p1.x + (float)num2;
				}
				else
				{
					x = p1.x - (float)num2;
				}
			}
			else
			{
				x = -(num8 - p1.y) * num4 / num3 + p1.x;
			}
			num3 = p1.x - p2.x;
			num4 = p1.y - p2.y;
			num5 = num3 * num3 + num4 * num4;
			float num9 = (float)num * num3 / (float)Math.Sqrt((double)num5) + p2.y;
			float x2;
			if (num3 == 0f)
			{
				if (num4 > 0f)
				{
					x2 = p2.x - (float)num;
				}
				else
				{
					x2 = p2.x + (float)num;
				}
			}
			else
			{
				x2 = -(num9 - p2.y) * num4 / num3 + p2.x;
			}
			float num10 = -((float)num2 * num3 / (float)Math.Sqrt((double)num5)) + p2.y;
			float num11;
			if (num3 == 0f)
			{
				if (num4 > 0f)
				{
					num11 = p2.x + (float)num2;
				}
				else
				{
					num11 = p2.x - (float)num2;
				}
			}
			else
			{
				num11 = -(num10 - p2.y) * num4 / num3 + p2.x;
			}
			rp1.x = num7;
			rp1.y = num6;
			rp2.x = x;
			rp2.y = num8;
			float num12 = (p1.y - num6) * (p2.x - p1.x) - (p1.x - num7) * (p2.y - p1.y);
			float num13 = (p1.y - num10) * (p2.x - p1.x) - (p1.x - num11) * (p2.y - p1.y);
			if (num12 * num13 > 0f)
			{
				if (num != num2)
				{
					num9 = (float)num2 * num3 / (float)Math.Sqrt((double)num5) + p2.y;
					if (num3 == 0f)
					{
						if (num4 > 0f)
						{
							x2 = p2.x - (float)num2;
						}
						else
						{
							x2 = p2.x + (float)num2;
						}
					}
					else
					{
						x2 = -(num9 - p2.y) * num4 / num3 + p2.x;
					}
					num10 = -((float)num * num3 / (float)Math.Sqrt((double)num5)) + p2.y;
					if (num3 == 0f)
					{
						if (num4 > 0f)
						{
							num11 = p2.x + (float)num;
						}
						else
						{
							num11 = p2.x - (float)num;
						}
					}
					else
					{
						num11 = -(num10 - p2.y) * num4 / num3 + p2.x;
					}
				}
				rp3.x = num11;
				rp3.y = num10;
				rp4.x = x2;
				rp4.y = num9;
			}
			else
			{
				rp3.x = x2;
				rp3.y = num9;
				rp4.x = num11;
				rp4.y = num10;
			}
			return true;
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x0003B304 File Offset: 0x00039504
		public Vector2 GetCrossPoint(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
		{
			Vector2 result = new Vector2(0f, 0f);
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			float num5 = p1.x - p2.x;
			float num6 = p1.y - p2.y;
			float num7 = p3.x - p4.x;
			float num8 = p3.y - p4.y;
			if (num5 != 0f)
			{
				num = num6 / num5;
				num2 = p1.y - num * p1.x;
			}
			if (num7 != 0f)
			{
				num3 = num8 / num7;
				num4 = p3.y - num3 * p3.x;
			}
			float num9 = 0f;
			float num10 = 0f;
			if (num == num3 && num2 == num4)
			{
				Vector2 vector = p1;
				Vector2 vector2 = p1;
				if (num5 == 0f)
				{
					if (p2.y < vector.y)
					{
						vector = p2;
					}
					if (p3.y < vector.y)
					{
						vector = p3;
					}
					if (p4.y < vector.y)
					{
						vector = p4;
					}
					if (p2.y > vector2.y)
					{
						vector2 = p2;
					}
					if (p3.y > vector2.y)
					{
						vector2 = p3;
					}
					if (p4.y > vector2.y)
					{
						vector2 = p4;
					}
				}
				else
				{
					if (p2.x < vector.x)
					{
						vector = p2;
					}
					if (p3.x < vector.x)
					{
						vector = p3;
					}
					if (p4.x < vector.x)
					{
						vector = p4;
					}
					if (p2.x > vector2.x)
					{
						vector2 = p2;
					}
					if (p3.x > vector2.x)
					{
						vector2 = p3;
					}
					if (p4.x > vector2.x)
					{
						vector2 = p4;
					}
				}
				num9 = (vector.x - vector2.x) / 2f;
				num9 = vector2.x + num9;
				num10 = (vector.y - vector2.y) / 2f;
				num10 = vector2.y + num10;
				result.x = num9;
				result.y = num10;
				return result;
			}
			if (num5 != 0f && num7 != 0f)
			{
				num9 = -(num2 - num4) / (num - num3);
				num10 = num * num9 + num2;
			}
			else if (num5 == 0f && num7 != 0f)
			{
				num9 = p1.x;
				num10 = num3 * num9 + num4;
			}
			else if (num5 != 0f && num7 == 0f)
			{
				num9 = p3.x;
				num10 = num * num9 + num2;
			}
			result.x = num9;
			result.y = num10;
			return result;
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x0003B5A4 File Offset: 0x000397A4
		public float AngleBetween2Vector(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
		{
			Vector2 vector = new Vector2(p2.x - p1.x, p2.y - p1.y);
			Vector2 vector2 = new Vector2(p4.x - p3.x, p4.y - p3.y);
			double num = (double)(vector.x * vector2.x + vector.y * vector2.y);
			float num2 = (float)Math.Sqrt((double)(vector.x * vector.x + vector.y * vector.y));
			float num3 = (float)Math.Sqrt((double)(vector2.x * vector2.x + vector2.y * vector2.y));
			float num4 = num2 * num3;
			return (float)Math.Acos(num / (double)num4);
		}

		// Token: 0x0400085F RID: 2143
		public static List<SVGPath> paths;

		// Token: 0x04000860 RID: 2144
		public static List<SVGLayer> layers;

		// Token: 0x04000861 RID: 2145
		protected static float _vpm;

		// Token: 0x04000862 RID: 2146
		public static float _roundQuality = 0f;

		// Token: 0x04000863 RID: 2147
		private static float _vertexPerMeter = 1000f;

		// Token: 0x04000864 RID: 2148
		private static bool _antialiasing = false;

		// Token: 0x04000865 RID: 2149
		private SVGStrokeLineCapMethod _strokeLineCap;

		// Token: 0x04000866 RID: 2150
		private SVGStrokeLineJoinMethod _strokeLineJoin;
	}
}
