﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000112 RID: 274
	[Serializable]
	public struct CCGradientColorKey
	{
		// Token: 0x060008C7 RID: 2247 RVA: 0x00039776 File Offset: 0x00037976
		public CCGradientColorKey(Color32 color, float time)
		{
			this.time = time;
			this.color = color;
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x00039786 File Offset: 0x00037986
		public override string ToString()
		{
			return string.Format("[CCGradientColorKey: time={0}, color={1}", this.time, this.color);
		}

		// Token: 0x04000832 RID: 2098
		public float time;

		// Token: 0x04000833 RID: 2099
		public Color32 color;
	}
}
