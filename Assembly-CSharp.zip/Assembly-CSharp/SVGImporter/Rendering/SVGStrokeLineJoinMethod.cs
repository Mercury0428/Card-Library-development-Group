﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012A RID: 298
	public enum SVGStrokeLineJoinMethod
	{
		// Token: 0x040008CB RID: 2251
		Unknown,
		// Token: 0x040008CC RID: 2252
		Miter,
		// Token: 0x040008CD RID: 2253
		MiterClip,
		// Token: 0x040008CE RID: 2254
		Round,
		// Token: 0x040008CF RID: 2255
		Bevel
	}
}
