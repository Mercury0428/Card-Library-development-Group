﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011D RID: 285
	public class SVGCircleElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000914 RID: 2324 RVA: 0x0003BE4B File Offset: 0x0003A04B
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000915 RID: 2325 RVA: 0x0003BE53 File Offset: 0x0003A053
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000916 RID: 2326 RVA: 0x0003BE5B File Offset: 0x0003A05B
		public SVGLength cx
		{
			get
			{
				return this._cx;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000917 RID: 2327 RVA: 0x0003BE63 File Offset: 0x0003A063
		public SVGLength cy
		{
			get
			{
				return this._cy;
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000918 RID: 2328 RVA: 0x0003BE6B File Offset: 0x0003A06B
		public SVGLength r
		{
			get
			{
				return this._r;
			}
		}

		// Token: 0x06000919 RID: 2329 RVA: 0x0003BE74 File Offset: 0x0003A074
		public SVGCircleElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._cx = new SVGLength(this.attrList.GetValue("cx"));
			this._cy = new SVGLength(this.attrList.GetValue("cy"));
			this._r = new SVGLength(this.attrList.GetValue("r"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x0003BF58 File Offset: 0x0003A158
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> list = SVGCircleElement.Circle(this.cx.value, this.cy.value, this.r.value, base.transformMatrix);
			list.Add(list[0]);
			return new List<List<Vector2>>
			{
				list
			};
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x0003BFB4 File Offset: 0x0003A1B4
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.Add(path[0]);
			}
			if (this.paintable.IsStroke())
			{
				List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
				{
					SVGSimplePath.GetSegments(path[0])
				}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.ALWAYS, SVGGraphics.roundQuality);
				if (list2 != null && list2.Count > 0)
				{
					list.AddRange(list2);
				}
			}
			return list;
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x0003C0A9 File Offset: 0x0003A2A9
		public void Render()
		{
			SVGGraphics.Create(this, "Circle Element", ClosePathRule.ALWAYS);
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x0003C0B8 File Offset: 0x0003A2B8
		public static List<Vector2> Circle(float x0, float y0, float radius, SVGMatrix matrix)
		{
			List<Vector2> list = new List<Vector2>();
			x0 -= radius;
			y0 -= radius;
			float num = 0.55191505f * radius;
			Vector2 b = new Vector2(num, 0f);
			Vector2 b2 = new Vector2(-num, 0f);
			Vector2 b3 = new Vector2(0f, -num);
			Vector2 b4 = new Vector2(0f, num);
			Vector2 vector = new Vector2(x0 + radius, y0);
			Vector2 vector2 = new Vector2(x0, y0 + radius);
			Vector2 vector3 = new Vector2(x0 + radius * 2f, y0 + radius);
			Vector2 vector4 = new Vector2(x0 + radius, y0 + radius * 2f);
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector), matrix.Transform(vector + b), matrix.Transform(vector3 + b3), matrix.Transform(vector3)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector3), matrix.Transform(vector3 + b4), matrix.Transform(vector4 + b), matrix.Transform(vector4)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector4), matrix.Transform(vector4 + b2), matrix.Transform(vector2 + b4), matrix.Transform(vector2)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector2), matrix.Transform(vector2 + b3), matrix.Transform(vector + b2), matrix.Transform(vector)));
			return list;
		}

		// Token: 0x0400087E RID: 2174
		private SVGLength _cx;

		// Token: 0x0400087F RID: 2175
		private SVGLength _cy;

		// Token: 0x04000880 RID: 2176
		private SVGLength _r;

		// Token: 0x04000881 RID: 2177
		private AttributeList _attrList;

		// Token: 0x04000882 RID: 2178
		private SVGPaintable _paintable;

		// Token: 0x04000883 RID: 2179
		private const float circleConstant = 0.55191505f;
	}
}
