﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000115 RID: 277
	public enum FILL_BLEND : byte
	{
		// Token: 0x0400083F RID: 2111
		OPAQUE,
		// Token: 0x04000840 RID: 2112
		ALPHA_BLENDED,
		// Token: 0x04000841 RID: 2113
		ADDITIVE,
		// Token: 0x04000842 RID: 2114
		MULTIPLY
	}
}
