﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011B RID: 283
	public class SVGLinearGradientBrush
	{
		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000900 RID: 2304 RVA: 0x0003B67D File Offset: 0x0003987D
		public bool alphaBlended
		{
			get
			{
				return this._alphaBlended;
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000901 RID: 2305 RVA: 0x0003B685 File Offset: 0x00039885
		public SVGFill fill
		{
			get
			{
				return this._fill;
			}
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0003B68D File Offset: 0x0003988D
		public SVGLinearGradientBrush(SVGLinearGradientElement linearGradElement)
		{
			this._transform = SVGMatrix.identity;
			this._linearGradElement = linearGradElement;
			this.Initialize();
			this.CreateFill();
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0003B6B3 File Offset: 0x000398B3
		public SVGLinearGradientBrush(SVGLinearGradientElement linearGradElement, Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			this._viewport = viewport;
			this._transform = matrix;
			this._linearGradElement = linearGradElement;
			this.Initialize();
			this.CreateFill(bounds);
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0003B6E0 File Offset: 0x000398E0
		private void Initialize()
		{
			this._x1 = this._linearGradElement.x1;
			this._y1 = this._linearGradElement.y1;
			this._x2 = this._linearGradElement.x2;
			this._y2 = this._linearGradElement.y2;
			this._stopColorList = new List<Color>();
			this._stopOffsetList = new List<float>();
			this.GetStopList();
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x0003B750 File Offset: 0x00039950
		private void CreateFill()
		{
			if (this._alphaBlended)
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.ALPHA_BLENDED, FILL_TYPE.GRADIENT, GRADIENT_TYPE.LINEAR);
			}
			else
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.OPAQUE, FILL_TYPE.GRADIENT, GRADIENT_TYPE.LINEAR);
			}
			this._gradientTransform = this._linearGradElement.gradientTransform.Consolidate().matrix;
			this._fill.gradientColors = SVGAssetImport.atlasData.AddGradient(this.ParseGradientColors());
			this._fill.viewport = this._viewport;
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x0003B7E0 File Offset: 0x000399E0
		private void CreateFill(Rect bounds)
		{
			this.CreateFill();
			this._fill.transform = SVGSimplePath.GetFillTransform(this._fill, bounds, new SVGLength[]
			{
				this._x1,
				this._y1
			}, new SVGLength[]
			{
				this._x2,
				this._y2
			}, this._transform, this._gradientTransform);
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x0003B858 File Offset: 0x00039A58
		public CCGradient ParseGradientColors()
		{
			int count = this._stopColorList.Count;
			CCGradientColorKey[] array = new CCGradientColorKey[count];
			CCGradientAlphaKey[] array2 = new CCGradientAlphaKey[count];
			for (int i = 0; i < count; i++)
			{
				float time = Mathf.Clamp01(this._stopOffsetList[i] * 0.01f);
				array[i] = new CCGradientColorKey(this._stopColorList[i], time);
				array2[i] = new CCGradientAlphaKey(this._stopColorList[i].a, time);
			}
			return new CCGradient(array, array2, true);
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x0003B8F8 File Offset: 0x00039AF8
		private void GetStopList()
		{
			List<SVGStopElement> stopList = this._linearGradElement.stopList;
			int count = stopList.Count;
			if (count == 0)
			{
				return;
			}
			this._stopColorList.Add(this.GetColor(stopList[0].stopColor));
			this._stopOffsetList.Add(0f);
			for (int i = 0; i < count; i++)
			{
				float offset = stopList[i].offset;
				if (offset > this._stopOffsetList[this._stopOffsetList.Count - 1] && offset <= 100f)
				{
					this._stopColorList.Add(this.GetColor(stopList[i].stopColor));
					this._stopOffsetList.Add(offset);
				}
				else if (offset == this._stopOffsetList[this._stopOffsetList.Count - 1])
				{
					this._stopColorList[this._stopOffsetList.Count - 1] = this.GetColor(stopList[i].stopColor);
				}
			}
			if (this._stopOffsetList[this._stopOffsetList.Count - 1] != 100f)
			{
				this._stopColorList.Add(this._stopColorList[this._stopOffsetList.Count - 1]);
				this._stopOffsetList.Add(100f);
			}
		}

		// Token: 0x06000909 RID: 2313 RVA: 0x0003BA4D File Offset: 0x00039C4D
		protected Color GetColor(SVGColor svgColor)
		{
			if (svgColor.color.a != 1f)
			{
				this._alphaBlended = true;
			}
			return svgColor.color;
		}

		// Token: 0x04000867 RID: 2151
		private SVGLinearGradientElement _linearGradElement;

		// Token: 0x04000868 RID: 2152
		private SVGLength _x1;

		// Token: 0x04000869 RID: 2153
		private SVGLength _y1;

		// Token: 0x0400086A RID: 2154
		private SVGLength _x2;

		// Token: 0x0400086B RID: 2155
		private SVGLength _y2;

		// Token: 0x0400086C RID: 2156
		private List<Color> _stopColorList;

		// Token: 0x0400086D RID: 2157
		private List<float> _stopOffsetList;

		// Token: 0x0400086E RID: 2158
		protected bool _alphaBlended;

		// Token: 0x0400086F RID: 2159
		protected SVGFill _fill;

		// Token: 0x04000870 RID: 2160
		protected SVGMatrix _gradientTransform;

		// Token: 0x04000871 RID: 2161
		protected SVGMatrix _transform;

		// Token: 0x04000872 RID: 2162
		protected Rect _viewport;
	}
}
