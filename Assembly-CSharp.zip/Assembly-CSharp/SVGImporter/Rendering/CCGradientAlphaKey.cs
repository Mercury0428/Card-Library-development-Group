﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000113 RID: 275
	[Serializable]
	public struct CCGradientAlphaKey
	{
		// Token: 0x060008C9 RID: 2249 RVA: 0x000397A8 File Offset: 0x000379A8
		public CCGradientAlphaKey(float alpha, float time)
		{
			this.time = time;
			this.alpha = alpha;
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x000397B8 File Offset: 0x000379B8
		public override string ToString()
		{
			return string.Format("[CCGradientAlphaKey: time={0}, alpha={1}]", this.time, this.alpha);
		}

		// Token: 0x04000834 RID: 2100
		public float time;

		// Token: 0x04000835 RID: 2101
		public float alpha;
	}
}
