﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011E RID: 286
	public class SVGEllipseElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600091F RID: 2335 RVA: 0x0003C23C File Offset: 0x0003A43C
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x06000920 RID: 2336 RVA: 0x0003C244 File Offset: 0x0003A444
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000921 RID: 2337 RVA: 0x0003C24C File Offset: 0x0003A44C
		public SVGLength cx
		{
			get
			{
				return this._cx;
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000922 RID: 2338 RVA: 0x0003C254 File Offset: 0x0003A454
		public SVGLength cy
		{
			get
			{
				return this._cy;
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000923 RID: 2339 RVA: 0x0003C25C File Offset: 0x0003A45C
		public SVGLength rx
		{
			get
			{
				return this._rx;
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000924 RID: 2340 RVA: 0x0003C264 File Offset: 0x0003A464
		public SVGLength ry
		{
			get
			{
				return this._ry;
			}
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x0003C26C File Offset: 0x0003A46C
		public SVGEllipseElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._cx = new SVGLength(this.attrList.GetValue("cx"));
			this._cy = new SVGLength(this.attrList.GetValue("cy"));
			this._rx = new SVGLength(this.attrList.GetValue("rx"));
			this._ry = new SVGLength(this.attrList.GetValue("ry"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x0003C368 File Offset: 0x0003A568
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> list = SVGEllipseElement.Ellipse(this.cx.value, this.cy.value, this.rx.value, this.ry.value, base.transformMatrix);
			list.Add(list[0]);
			return new List<List<Vector2>>
			{
				list
			};
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x0003C3D4 File Offset: 0x0003A5D4
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.Add(path[0]);
			}
			if (this.paintable.IsStroke())
			{
				List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
				{
					SVGSimplePath.GetSegments(path[0])
				}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.ALWAYS, SVGGraphics.roundQuality);
				if (list2 != null && list2.Count > 0)
				{
					list.AddRange(list2);
				}
			}
			return list;
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x0003C4C9 File Offset: 0x0003A6C9
		public void Render()
		{
			SVGGraphics.Create(this, "Ellipse Element", ClosePathRule.ALWAYS);
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x0003C4D8 File Offset: 0x0003A6D8
		public static List<Vector2> Ellipse(float cx, float cy, float rx, float ry, SVGMatrix matrix)
		{
			List<Vector2> list = new List<Vector2>();
			cx -= rx;
			cy -= ry;
			float num = 0.55191505f * rx;
			float num2 = 0.55191505f * ry;
			Vector2 b = new Vector2(num, 0f);
			Vector2 b2 = new Vector2(-num, 0f);
			Vector2 b3 = new Vector2(0f, -num2);
			Vector2 b4 = new Vector2(0f, num2);
			Vector2 vector = new Vector2(cx + rx, cy);
			Vector2 vector2 = new Vector2(cx, cy + ry);
			Vector2 vector3 = new Vector2(cx + rx * 2f, cy + ry);
			Vector2 vector4 = new Vector2(cx + rx, cy + ry * 2f);
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector), matrix.Transform(vector + b), matrix.Transform(vector3 + b3), matrix.Transform(vector3)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector3), matrix.Transform(vector3 + b4), matrix.Transform(vector4 + b), matrix.Transform(vector4)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector4), matrix.Transform(vector4 + b2), matrix.Transform(vector2 + b4), matrix.Transform(vector2)));
			list.AddRange(SVGGeomUtils.CubicCurve(matrix.Transform(vector2), matrix.Transform(vector2 + b3), matrix.Transform(vector + b2), matrix.Transform(vector)));
			return list;
		}

		// Token: 0x04000884 RID: 2180
		private SVGLength _cx;

		// Token: 0x04000885 RID: 2181
		private SVGLength _cy;

		// Token: 0x04000886 RID: 2182
		private SVGLength _rx;

		// Token: 0x04000887 RID: 2183
		private SVGLength _ry;

		// Token: 0x04000888 RID: 2184
		private AttributeList _attrList;

		// Token: 0x04000889 RID: 2185
		private SVGPaintable _paintable;

		// Token: 0x0400088A RID: 2186
		private const float PI2 = 6.2831855f;

		// Token: 0x0400088B RID: 2187
		private const float circleConstant = 0.55191505f;
	}
}
