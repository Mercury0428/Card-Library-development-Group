﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012B RID: 299
	public enum SVGPaintMethod
	{
		// Token: 0x040008D1 RID: 2257
		SolidFill,
		// Token: 0x040008D2 RID: 2258
		LinearGradientFill,
		// Token: 0x040008D3 RID: 2259
		RadialGradientFill,
		// Token: 0x040008D4 RID: 2260
		ConicalGradientFill,
		// Token: 0x040008D5 RID: 2261
		PathDraw,
		// Token: 0x040008D6 RID: 2262
		NoDraw
	}
}
