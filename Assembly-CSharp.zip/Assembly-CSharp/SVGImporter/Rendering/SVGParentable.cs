﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012D RID: 301
	public class SVGParentable : SVGTransformable
	{
		// Token: 0x06000991 RID: 2449 RVA: 0x0003E607 File Offset: 0x0003C807
		public SVGParentable(SVGTransformList inheritTransformList) : base(inheritTransformList)
		{
		}

		// Token: 0x040008F1 RID: 2289
		public SVGParentable parent;
	}
}
