﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000140 RID: 320
	public class SVGPathSegArcAbs : SVGPathSeg
	{
		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000A0A RID: 2570 RVA: 0x000411CC File Offset: 0x0003F3CC
		public float r1
		{
			get
			{
				return this._r1;
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000A0B RID: 2571 RVA: 0x000411D4 File Offset: 0x0003F3D4
		public float r2
		{
			get
			{
				return this._r2;
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000A0C RID: 2572 RVA: 0x000411DC File Offset: 0x0003F3DC
		public float angle
		{
			get
			{
				return this._angle;
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000A0D RID: 2573 RVA: 0x000411E4 File Offset: 0x0003F3E4
		public bool largeArcFlag
		{
			get
			{
				return this._largeArcFlag;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x06000A0E RID: 2574 RVA: 0x000411EC File Offset: 0x0003F3EC
		public bool sweepFlag
		{
			get
			{
				return this._sweepFlag;
			}
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x000411F4 File Offset: 0x0003F3F4
		public SVGPathSegArcAbs(float r1, float r2, float angle, bool largeArcFlag, bool sweepFlag, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.Arc_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
			this._r1 = r1;
			this._r2 = r2;
			this._angle = angle;
			this._largeArcFlag = largeArcFlag;
			this._sweepFlag = sweepFlag;
		}

		// Token: 0x04000948 RID: 2376
		private float _r1;

		// Token: 0x04000949 RID: 2377
		private float _r2;

		// Token: 0x0400094A RID: 2378
		private float _angle;

		// Token: 0x0400094B RID: 2379
		private bool _largeArcFlag;

		// Token: 0x0400094C RID: 2380
		private bool _sweepFlag;
	}
}
