﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000111 RID: 273
	public class SVGClipPath
	{
		// Token: 0x060008C4 RID: 2244 RVA: 0x00002050 File Offset: 0x00000250
		public SVGClipPath()
		{
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00039751 File Offset: 0x00037951
		public SVGClipPath(List<Vector2> path)
		{
			this.path = path;
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x00039760 File Offset: 0x00037960
		public SVGClipPath(List<Vector2> path, List<List<Vector2>> holes)
		{
			this.path = path;
			this.holes = holes;
		}

		// Token: 0x04000830 RID: 2096
		public List<Vector2> path;

		// Token: 0x04000831 RID: 2097
		public List<List<Vector2>> holes;
	}
}
