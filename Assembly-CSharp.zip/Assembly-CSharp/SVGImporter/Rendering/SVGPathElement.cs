﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013D RID: 317
	public class SVGPathElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060009F5 RID: 2549 RVA: 0x000401C9 File Offset: 0x0003E3C9
		public SVGPathSegList segList
		{
			get
			{
				return this._segList;
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060009F6 RID: 2550 RVA: 0x000401D1 File Offset: 0x0003E3D1
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060009F7 RID: 2551 RVA: 0x000401D9 File Offset: 0x0003E3D9
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x000401E4 File Offset: 0x0003E3E4
		public SVGPathElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			base.currentTransformList = new SVGTransformList(this._attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
			this.Initial();
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x00040268 File Offset: 0x0003E468
		private void Initial()
		{
			string value = this._attrList.GetValue("d");
			SVGPathSeg svgpathSeg = null;
			SVGPathSeg svgpathSeg2 = null;
			List<char> list = new List<char>();
			List<string> list2 = new List<string>();
			SVGStringExtractor.ExtractPathSegList(value, ref list, ref list2);
			this._segList = new SVGPathSegList(list.Count);
			int i = 0;
			while (i < list.Count)
			{
				char c = list[i];
				float[] array = SVGStringExtractor.ExtractTransformValueAsPX(list2[i]);
				int num = array.Length;
				if (c <= 'Z')
				{
					if (c <= 'C')
					{
						if (c != 'A')
						{
							if (c == 'C')
							{
								if (num >= 6)
								{
									for (int j = 0; j < num; j += 6)
									{
										if (num - j >= 6)
										{
											svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoCubicAbs(array[j], array[j + 1], array[j + 2], array[j + 3], array[j + 4], array[j + 5], svgpathSeg));
											if (svgpathSeg2 == null)
											{
												svgpathSeg2 = svgpathSeg;
											}
										}
									}
								}
							}
						}
						else if (num >= 7)
						{
							for (int j = 0; j < num; j += 7)
							{
								if (num - j >= 7)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegArcAbs(array[j], array[j + 1], array[j + 2], array[j + 3] == 1f, array[j + 4] == 1f, array[j + 5], array[j + 6], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
					}
					else if (c != 'H')
					{
						switch (c)
						{
						case 'L':
							if (num >= 2)
							{
								for (int j = 0; j < num; j += 2)
								{
									if (num - j >= 2)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoAbs(array[j], array[j + 1], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
							break;
						case 'M':
							if (svgpathSeg != null && svgpathSeg.type != SVGPathSegTypes.Close && svgpathSeg.type != SVGPathSegTypes.MoveTo_Abs && svgpathSeg.type != SVGPathSegTypes.MoveTo_Rel)
							{
								svgpathSeg2 = null;
							}
							if (num >= 2)
							{
								for (int j = 0; j < num; j += 2)
								{
									if (num - j >= 2)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegMovetoAbs(array[j], array[j + 1], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
							break;
						case 'N':
						case 'O':
						case 'P':
						case 'R':
						case 'U':
							break;
						case 'Q':
							if (num >= 4)
							{
								for (int j = 0; j < num; j += 4)
								{
									if (num - j >= 4)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoQuadraticAbs(array[j], array[j + 1], array[j + 2], array[j + 3], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
							break;
						case 'S':
							if (num >= 4)
							{
								for (int j = 0; j < num; j += 4)
								{
									if (num - j >= 4)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoCubicSmoothAbs(array[j], array[j + 1], array[j + 2], array[j + 3], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
							break;
						case 'T':
							if (num >= 2)
							{
								for (int j = 0; j < num; j += 2)
								{
									if (num - j >= 2)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoQuadraticSmoothAbs(array[j], array[j + 1], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
							break;
						case 'V':
							for (int j = 0; j < num; j++)
							{
								svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoVerticalAbs(array[j], svgpathSeg));
								if (svgpathSeg2 == null)
								{
									svgpathSeg2 = svgpathSeg;
								}
							}
							break;
						default:
							if (c == 'Z')
							{
								goto IL_133;
							}
							break;
						}
					}
					else
					{
						for (int j = 0; j < num; j++)
						{
							svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoHorizontalAbs(array[j], svgpathSeg));
							if (svgpathSeg2 == null)
							{
								svgpathSeg2 = svgpathSeg;
							}
						}
					}
				}
				else if (c <= 'c')
				{
					if (c != 'a')
					{
						if (c == 'c')
						{
							if (num >= 6)
							{
								for (int j = 0; j < num; j += 6)
								{
									if (num - j >= 6)
									{
										svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoCubicRel(array[j], array[j + 1], array[j + 2], array[j + 3], array[j + 4], array[j + 5], svgpathSeg));
										if (svgpathSeg2 == null)
										{
											svgpathSeg2 = svgpathSeg;
										}
									}
								}
							}
						}
					}
					else if (num >= 7)
					{
						for (int j = 0; j < num; j += 7)
						{
							if (num - j >= 7)
							{
								svgpathSeg = this._segList.AppendItem(new SVGPathSegArcRel(array[j], array[j + 1], array[j + 2], array[j + 3] == 1f, array[j + 4] == 1f, array[j + 5], array[j + 6], svgpathSeg));
								if (svgpathSeg2 == null)
								{
									svgpathSeg2 = svgpathSeg;
								}
							}
						}
					}
				}
				else if (c != 'h')
				{
					switch (c)
					{
					case 'l':
						if (num >= 2)
						{
							for (int j = 0; j < num; j += 2)
							{
								if (num - j >= 2)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoRel(array[j], array[j + 1], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
						break;
					case 'm':
						if (svgpathSeg != null && svgpathSeg.type != SVGPathSegTypes.Close && svgpathSeg.type != SVGPathSegTypes.MoveTo_Abs && svgpathSeg.type != SVGPathSegTypes.MoveTo_Rel)
						{
							svgpathSeg2 = null;
						}
						if (num >= 2)
						{
							for (int j = 0; j < num; j += 2)
							{
								if (num - j >= 2)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegMovetoRel(array[j], array[j + 1], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
						break;
					case 'n':
					case 'o':
					case 'p':
					case 'r':
					case 'u':
						break;
					case 'q':
						if (num >= 4)
						{
							for (int j = 0; j < num; j += 4)
							{
								if (num - j >= 4)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoQuadraticRel(array[j], array[j + 1], array[j + 2], array[j + 3], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
						break;
					case 's':
						if (num >= 4)
						{
							for (int j = 0; j < num; j += 4)
							{
								if (num - j >= 4)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoCubicSmoothRel(array[j], array[j + 1], array[j + 2], array[j + 3], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
						break;
					case 't':
						if (num >= 2)
						{
							for (int j = 0; j < num; j += 2)
							{
								if (num - j >= 2)
								{
									svgpathSeg = this._segList.AppendItem(new SVGPathSegCurvetoQuadraticSmoothRel(array[j], array[j + 1], svgpathSeg));
									if (svgpathSeg2 == null)
									{
										svgpathSeg2 = svgpathSeg;
									}
								}
							}
						}
						break;
					case 'v':
						for (int j = 0; j < num; j++)
						{
							svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoVerticalRel(array[j], svgpathSeg));
							if (svgpathSeg2 == null)
							{
								svgpathSeg2 = svgpathSeg;
							}
						}
						break;
					default:
						if (c == 'z')
						{
							goto IL_133;
						}
						break;
					}
				}
				else
				{
					for (int j = 0; j < num; j++)
					{
						svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoHorizontalRel(array[j], svgpathSeg));
						if (svgpathSeg2 == null)
						{
							svgpathSeg2 = svgpathSeg;
						}
					}
				}
				IL_752:
				i++;
				continue;
				IL_133:
				if (this._segList.Count > 0 && svgpathSeg2 != null)
				{
					svgpathSeg = this._segList.AppendItem(new SVGPathSegLinetoAbs(svgpathSeg2.currentPoint.x, svgpathSeg2.currentPoint.y, svgpathSeg));
				}
				this._segList.AppendItem(this.CreateSVGPathSegClosePath());
				svgpathSeg2 = null;
				goto IL_752;
			}
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x000409DC File Offset: 0x0003EBDC
		private SVGPathSegClosePath CreateSVGPathSegClosePath()
		{
			SVGPathSeg lastItem = this._segList.GetLastItem();
			SVGPathSeg item = this._segList.GetItem(0);
			if (item != null)
			{
				return new SVGPathSegClosePath(item.currentPoint, lastItem);
			}
			return null;
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x00040A14 File Offset: 0x0003EC14
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
			for (int i = 0; i < this._segList.Count; i++)
			{
				ISVGDrawable isvgdrawable = this._segList.GetItem(i) as ISVGDrawable;
				if (isvgdrawable != null)
				{
					isvgdrawable.BeforeRender(base.summaryTransformList);
				}
			}
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x00040A60 File Offset: 0x0003EC60
		public List<List<Vector2>> GetPath()
		{
			SVGPathElement.lastCommand = SVGPathSegTypes.Unknown;
			List<Vector2> list = new List<Vector2>();
			List<List<Vector2>> list2 = new List<List<Vector2>>();
			for (int i = 0; i < this.segList.Count; i++)
			{
				this.GetSegment(this, this.segList.GetItem(i), list2, list, base.transformMatrix);
			}
			if (SVGPathElement.lastCommand != SVGPathSegTypes.Close && list.Count > 0)
			{
				list2.Add(new List<Vector2>(list.ToArray()));
			}
			for (int j = 0; j < list2.Count; j++)
			{
				if (list2[j] != null && list2[j].Count >= 3)
				{
					list2[j] = SVGBezier.Optimise(list2[j], SVGGraphics.vpm, 0, -1);
				}
			}
			return list2;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x00040B18 File Offset: 0x0003ED18
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.AddRange(path);
			}
			if (this.paintable.IsStroke())
			{
				List<StrokeSegment[]> list2 = new List<StrokeSegment[]>();
				for (int i = 0; i < path.Count; i++)
				{
					if (path[i] != null && path[i].Count >= 2)
					{
						list2.Add(SVGSimplePath.GetSegments(path[i]));
					}
				}
				List<List<Vector2>> list3 = SVGLineUtils.StrokeShape(list2, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.AUTO, SVGGraphics.roundQuality);
				if (list3 != null && list3.Count > 0)
				{
					list.AddRange(list3);
				}
			}
			return list;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x00040C22 File Offset: 0x0003EE22
		public void Render()
		{
			SVGGraphics.Create(this, "Path Element", ClosePathRule.AUTO);
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x00040C30 File Offset: 0x0003EE30
		private bool GetSegment(SVGPathElement svgElement, SVGPathSeg segment, List<List<Vector2>> output, List<Vector2> positionBuffer, SVGMatrix matrix)
		{
			if (segment == null)
			{
				return false;
			}
			switch (segment.type)
			{
			case SVGPathSegTypes.Close:
				if (positionBuffer.Count > 0)
				{
					output.Add(new List<Vector2>(positionBuffer.ToArray()));
				}
				positionBuffer.Clear();
				break;
			case SVGPathSegTypes.MoveTo_Abs:
			{
				if (SVGPathElement.lastCommand != SVGPathSegTypes.Close && SVGPathElement.lastCommand != SVGPathSegTypes.MoveTo_Abs && SVGPathElement.lastCommand != SVGPathSegTypes.MoveTo_Rel && positionBuffer.Count > 0)
				{
					output.Add(new List<Vector2>(positionBuffer.ToArray()));
					positionBuffer.Clear();
				}
				SVGPathSegMovetoAbs svgpathSegMovetoAbs = segment as SVGPathSegMovetoAbs;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegMovetoAbs.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.MoveTo_Rel:
			{
				if (SVGPathElement.lastCommand != SVGPathSegTypes.Close && SVGPathElement.lastCommand != SVGPathSegTypes.MoveTo_Abs && SVGPathElement.lastCommand != SVGPathSegTypes.MoveTo_Rel && positionBuffer.Count > 0)
				{
					output.Add(new List<Vector2>(positionBuffer.ToArray()));
					positionBuffer.Clear();
				}
				SVGPathSegMovetoRel svgpathSegMovetoRel = segment as SVGPathSegMovetoRel;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegMovetoRel.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.LineTo_Abs:
			{
				SVGPathSegLinetoAbs svgpathSegLinetoAbs = segment as SVGPathSegLinetoAbs;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoAbs.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.LineTo_Rel:
			{
				SVGPathSegLinetoRel svgpathSegLinetoRel = segment as SVGPathSegLinetoRel;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoRel.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.CurveTo_Cubic_Abs:
			{
				SVGPathSegCurvetoCubicAbs svgpathSegCurvetoCubicAbs = segment as SVGPathSegCurvetoCubicAbs;
				positionBuffer.AddRange(SVGGeomUtils.CubicCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicAbs.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicAbs.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicAbs.controlPoint2, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicAbs.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Cubic_Rel:
			{
				SVGPathSegCurvetoCubicRel svgpathSegCurvetoCubicRel = segment as SVGPathSegCurvetoCubicRel;
				positionBuffer.AddRange(SVGGeomUtils.CubicCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicRel.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicRel.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicRel.controlPoint2, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicRel.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Quadratic_Abs:
			{
				SVGPathSegCurvetoQuadraticAbs svgpathSegCurvetoQuadraticAbs = segment as SVGPathSegCurvetoQuadraticAbs;
				positionBuffer.AddRange(SVGGeomUtils.QuadraticCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticAbs.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticAbs.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticAbs.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Quadratic_Rel:
			{
				SVGPathSegCurvetoQuadraticRel svgpathSegCurvetoQuadraticRel = segment as SVGPathSegCurvetoQuadraticRel;
				positionBuffer.AddRange(SVGGeomUtils.QuadraticCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticRel.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticRel.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticRel.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.Arc_Abs:
			{
				SVGPathSegArcAbs svgpathSegArcAbs = segment as SVGPathSegArcAbs;
				positionBuffer.AddRange(SVGGeomUtils.Arc(SVGGeomUtils.TransformPoint(svgpathSegArcAbs.previousPoint, matrix), svgpathSegArcAbs.r1, svgpathSegArcAbs.r2, svgpathSegArcAbs.angle, svgpathSegArcAbs.largeArcFlag, svgpathSegArcAbs.sweepFlag, SVGGeomUtils.TransformPoint(svgpathSegArcAbs.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.Arc_Rel:
			{
				SVGPathSegArcRel svgpathSegArcRel = segment as SVGPathSegArcRel;
				positionBuffer.AddRange(SVGGeomUtils.Arc(SVGGeomUtils.TransformPoint(svgpathSegArcRel.previousPoint, matrix), svgpathSegArcRel.r1, svgpathSegArcRel.r2, svgpathSegArcRel.angle, svgpathSegArcRel.largeArcFlag, svgpathSegArcRel.sweepFlag, SVGGeomUtils.TransformPoint(svgpathSegArcRel.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.LineTo_Horizontal_Abs:
			{
				SVGPathSegLinetoHorizontalAbs svgpathSegLinetoHorizontalAbs = segment as SVGPathSegLinetoHorizontalAbs;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoHorizontalAbs.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.LineTo_Horizontal_Rel:
			{
				SVGPathSegLinetoHorizontalRel svgpathSegLinetoHorizontalRel = segment as SVGPathSegLinetoHorizontalRel;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoHorizontalRel.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.LineTo_Vertical_Abs:
			{
				SVGPathSegLinetoVerticalAbs svgpathSegLinetoVerticalAbs = segment as SVGPathSegLinetoVerticalAbs;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoVerticalAbs.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.LineTo_Vertical_Rel:
			{
				SVGPathSegLinetoVerticalRel svgpathSegLinetoVerticalRel = segment as SVGPathSegLinetoVerticalRel;
				positionBuffer.Add(SVGGeomUtils.TransformPoint(svgpathSegLinetoVerticalRel.currentPoint, matrix));
				break;
			}
			case SVGPathSegTypes.CurveTo_Cubic_Smooth_Abs:
			{
				SVGPathSegCurvetoCubicSmoothAbs svgpathSegCurvetoCubicSmoothAbs = segment as SVGPathSegCurvetoCubicSmoothAbs;
				positionBuffer.AddRange(SVGGeomUtils.CubicCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothAbs.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothAbs.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothAbs.controlPoint2, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothAbs.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Cubic_Smooth_Rel:
			{
				SVGPathSegCurvetoCubicSmoothRel svgpathSegCurvetoCubicSmoothRel = segment as SVGPathSegCurvetoCubicSmoothRel;
				positionBuffer.AddRange(SVGGeomUtils.CubicCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothRel.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothRel.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothRel.controlPoint2, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoCubicSmoothRel.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Quadratic_Smooth_Abs:
			{
				SVGPathSegCurvetoQuadraticSmoothAbs svgpathSegCurvetoQuadraticSmoothAbs = segment as SVGPathSegCurvetoQuadraticSmoothAbs;
				positionBuffer.AddRange(SVGGeomUtils.QuadraticCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothAbs.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothAbs.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothAbs.currentPoint, matrix)));
				break;
			}
			case SVGPathSegTypes.CurveTo_Quadratic_Smooth_Rel:
			{
				SVGPathSegCurvetoQuadraticSmoothRel svgpathSegCurvetoQuadraticSmoothRel = segment as SVGPathSegCurvetoQuadraticSmoothRel;
				positionBuffer.AddRange(SVGGeomUtils.QuadraticCurve(SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothRel.previousPoint, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothRel.controlPoint1, matrix), SVGGeomUtils.TransformPoint(svgpathSegCurvetoQuadraticSmoothRel.currentPoint, matrix)));
				break;
			}
			}
			SVGPathElement.lastCommand = segment.type;
			return true;
		}

		// Token: 0x04000929 RID: 2345
		private SVGPathSegList _segList;

		// Token: 0x0400092A RID: 2346
		private AttributeList _attrList;

		// Token: 0x0400092B RID: 2347
		private SVGPaintable _paintable;

		// Token: 0x0400092C RID: 2348
		private static SVGPathSegTypes lastCommand;
	}
}
