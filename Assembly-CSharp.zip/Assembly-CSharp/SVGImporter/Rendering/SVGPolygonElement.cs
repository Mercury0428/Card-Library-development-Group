﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000120 RID: 288
	public class SVGPolygonElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000936 RID: 2358 RVA: 0x0003C8F9 File Offset: 0x0003AAF9
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000937 RID: 2359 RVA: 0x0003C901 File Offset: 0x0003AB01
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000938 RID: 2360 RVA: 0x0003C909 File Offset: 0x0003AB09
		public List<Vector2> listPoints
		{
			get
			{
				return this._listPoints;
			}
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x0003C914 File Offset: 0x0003AB14
		public SVGPolygonElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._listPoints = this.ExtractPoints(this._attrList.GetValue("points"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x0003C9B4 File Offset: 0x0003ABB4
		private List<Vector2> ExtractPoints(string inputText)
		{
			List<Vector2> list = new List<Vector2>();
			string[] array = SVGStringExtractor.ExtractTransformValue(inputText);
			int num = array.Length;
			for (int i = 0; i < num - 1; i++)
			{
				string valueText = array[i];
				string valueText2 = array[i + 1];
				SVGLength svglength = new SVGLength(valueText);
				SVGLength svglength2 = new SVGLength(valueText2);
				Vector2 item = new Vector2(svglength.value, svglength2.value);
				list.Add(item);
				i++;
			}
			return list;
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x0003CA20 File Offset: 0x0003AC20
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> list = new List<Vector2>(this.listPoints.Count + 1);
			for (int i = 0; i < this.listPoints.Count; i++)
			{
				list.Add(base.transformMatrix.Transform(this.listPoints[i]));
			}
			list.Add(list[0]);
			return new List<List<Vector2>>
			{
				SVGBezier.Optimise(list, SVGGraphics.vpm, 0, -1)
			};
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x0003CA9C File Offset: 0x0003AC9C
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.Add(path[0]);
			}
			if (this.paintable.IsStroke())
			{
				List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
				{
					SVGSimplePath.GetSegments(path[0])
				}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.ALWAYS, SVGGraphics.roundQuality);
				if (list2 != null && list2.Count > 0)
				{
					list.AddRange(list2);
				}
			}
			return list;
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x0003CB91 File Offset: 0x0003AD91
		public void Render()
		{
			SVGGraphics.Create(this, "Polygon Element", ClosePathRule.ALWAYS);
		}

		// Token: 0x04000892 RID: 2194
		private List<Vector2> _listPoints;

		// Token: 0x04000893 RID: 2195
		private AttributeList _attrList;

		// Token: 0x04000894 RID: 2196
		private SVGPaintable _paintable;
	}
}
