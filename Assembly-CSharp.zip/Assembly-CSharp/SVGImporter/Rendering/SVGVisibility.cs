﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000126 RID: 294
	public enum SVGVisibility
	{
		// Token: 0x040008AC RID: 2220
		Visible,
		// Token: 0x040008AD RID: 2221
		Hidden,
		// Token: 0x040008AE RID: 2222
		Collapse
	}
}
