﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000129 RID: 297
	public enum SVGStrokeLineCapMethod
	{
		// Token: 0x040008C6 RID: 2246
		Unknown,
		// Token: 0x040008C7 RID: 2247
		Butt,
		// Token: 0x040008C8 RID: 2248
		Round,
		// Token: 0x040008C9 RID: 2249
		Square
	}
}
