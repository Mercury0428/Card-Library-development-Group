﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000146 RID: 326
	public class SVGPathSegCurvetoCubicSmoothAbs : SVGPathSegCurvetoCubic
	{
		// Token: 0x06000A20 RID: 2592 RVA: 0x0004142C File Offset: 0x0003F62C
		public SVGPathSegCurvetoCubicSmoothAbs(float x2, float y2, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Cubic_Smooth_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
			SVGPathSegCurvetoCubic svgpathSegCurvetoCubic = segment as SVGPathSegCurvetoCubic;
			if (svgpathSegCurvetoCubic != null)
			{
				this._controlPoint1 = this._previousPoint + (this._previousPoint - svgpathSegCurvetoCubic.controlPoint2);
			}
			else
			{
				this._controlPoint1 = this._previousPoint;
			}
			this._controlPoint2 = new Vector2(x2, y2);
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000A21 RID: 2593 RVA: 0x000414C4 File Offset: 0x0003F6C4
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x06000A22 RID: 2594 RVA: 0x000414CC File Offset: 0x0003F6CC
		public override Vector2 controlPoint2
		{
			get
			{
				return this._controlPoint2;
			}
		}

		// Token: 0x04000956 RID: 2390
		protected Vector2 _controlPoint1 = Vector2.zero;

		// Token: 0x04000957 RID: 2391
		protected Vector2 _controlPoint2 = Vector2.zero;
	}
}
