﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000116 RID: 278
	public enum FILL_TYPE : byte
	{
		// Token: 0x04000844 RID: 2116
		SOLID,
		// Token: 0x04000845 RID: 2117
		GRADIENT,
		// Token: 0x04000846 RID: 2118
		TEXTURE
	}
}
