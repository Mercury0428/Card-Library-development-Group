﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014E RID: 334
	public class SVGPathSegLinetoHorizontalAbs : SVGPathSeg
	{
		// Token: 0x06000A31 RID: 2609 RVA: 0x0004179D File Offset: 0x0003F99D
		public SVGPathSegLinetoHorizontalAbs(float x, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Horizontal_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, this._previousPoint.y);
		}
	}
}
