﻿using System;
using System.Globalization;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000131 RID: 305
	public class SVGTransform
	{
		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060009B6 RID: 2486 RVA: 0x0003F5C0 File Offset: 0x0003D7C0
		public SVGMatrix matrix
		{
			get
			{
				return this._matrix;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x060009B7 RID: 2487 RVA: 0x0003F5C8 File Offset: 0x0003D7C8
		public float angle
		{
			get
			{
				SVGTransformMode type = this._type;
				if (type - SVGTransformMode.Rotate <= 2)
				{
					return (float)this._angle;
				}
				return 0f;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x060009B8 RID: 2488 RVA: 0x0003F5EF File Offset: 0x0003D7EF
		public SVGTransformMode type
		{
			get
			{
				return this._type;
			}
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x0003F5F7 File Offset: 0x0003D7F7
		public SVGTransform()
		{
			this._matrix = SVGMatrix.identity;
			this._type = SVGTransformMode.Matrix;
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x0003F611 File Offset: 0x0003D811
		public SVGTransform(SVGMatrix matrix)
		{
			this._type = SVGTransformMode.Matrix;
			this._matrix = matrix;
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x0003F628 File Offset: 0x0003D828
		public SVGTransform(string strKey, string strValue)
		{
			string[] array = SVGStringExtractor.ExtractTransformValue(strValue);
			int num = array.Length;
			float[] array2 = new float[num];
			for (int i = 0; i < num; i++)
			{
				try
				{
					array2.SetValue(float.Parse(array[i], CultureInfo.InvariantCulture), i);
				}
				catch (Exception arg)
				{
					Debug.Log("SVGTransform: e: " + arg);
				}
			}
			if (!(strKey == "translate"))
			{
				if (!(strKey == "rotate"))
				{
					if (!(strKey == "scale"))
					{
						if (!(strKey == "skewX"))
						{
							if (!(strKey == "skewY"))
							{
								if (!(strKey == "matrix"))
								{
									this._type = SVGTransformMode.Unknown;
									return;
								}
								if (num != 6)
								{
									throw new ApplicationException("Wrong number of arguments in matrix transform");
								}
								this.SetMatrix(new SVGMatrix(array2[0], array2[1], array2[2], array2[3], array2[4], array2[5]));
								return;
							}
							else
							{
								if (num != 1)
								{
									throw new ApplicationException("Wrong number of arguments in skewY transform");
								}
								this.SetSkewY(array2[0]);
								return;
							}
						}
						else
						{
							if (num != 1)
							{
								throw new ApplicationException("Wrong number of arguments in skewX transform");
							}
							this.SetSkewX(array2[0]);
							return;
						}
					}
					else
					{
						if (num == 1)
						{
							this.SetScale(array2[0], array2[0]);
							return;
						}
						if (num != 2)
						{
							throw new ApplicationException("Wrong number of arguments in scale transform");
						}
						this.SetScale(array2[0], array2[1]);
						return;
					}
				}
				else
				{
					if (num == 1)
					{
						this.SetRotate(array2[0]);
						return;
					}
					if (num != 3)
					{
						throw new ApplicationException("Wrong number of arguments in rotate transform");
					}
					this.SetRotate(array2[0], array2[1], array2[2]);
					return;
				}
			}
			else
			{
				if (num == 1)
				{
					this.SetTranslate(array2[0], 0f);
					return;
				}
				if (num != 2)
				{
					throw new ApplicationException("Wrong number of arguments in translate transform");
				}
				this.SetTranslate(array2[0], array2[1]);
				return;
			}
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x0003F7F0 File Offset: 0x0003D9F0
		public void SetMatrix(SVGMatrix matrix)
		{
			this._type = SVGTransformMode.Matrix;
			this._matrix = matrix;
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x0003F800 File Offset: 0x0003DA00
		public void SetTranslate(float tx, float ty)
		{
			this._type = SVGTransformMode.Translate;
			this._matrix = SVGMatrix.identity.Translate(tx, ty);
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x0003F82C File Offset: 0x0003DA2C
		public void SetScale(float sx, float sy)
		{
			this._type = SVGTransformMode.Scale;
			this._matrix = SVGMatrix.identity.Scale(sx, sy);
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x0003F858 File Offset: 0x0003DA58
		public void SetRotate(float angle)
		{
			this._type = SVGTransformMode.Rotate;
			this._angle = (double)angle;
			this._matrix = SVGMatrix.identity.Rotate(angle);
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x0003F888 File Offset: 0x0003DA88
		public void SetRotate(float angle, float cx, float cy)
		{
			this._type = SVGTransformMode.Rotate;
			this._angle = (double)angle;
			this._matrix = SVGMatrix.identity.Translate(cx, cy).Rotate(angle).Translate(-cx, -cy);
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x0003F8D0 File Offset: 0x0003DAD0
		public void SetSkewX(float angle)
		{
			this._type = SVGTransformMode.SkewX;
			this._angle = (double)angle;
			this._matrix = SVGMatrix.identity.SkewX(angle);
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x0003F900 File Offset: 0x0003DB00
		public void SetSkewY(float angle)
		{
			this._type = SVGTransformMode.SkewY;
			this._angle = (double)angle;
			this._matrix = SVGMatrix.identity.SkewY(angle);
		}

		// Token: 0x04000903 RID: 2307
		private SVGTransformMode _type;

		// Token: 0x04000904 RID: 2308
		private SVGMatrix _matrix;

		// Token: 0x04000905 RID: 2309
		private double _angle;
	}
}
