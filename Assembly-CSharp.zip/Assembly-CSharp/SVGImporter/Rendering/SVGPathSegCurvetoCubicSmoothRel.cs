﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000147 RID: 327
	public class SVGPathSegCurvetoCubicSmoothRel : SVGPathSegCurvetoCubic
	{
		// Token: 0x06000A23 RID: 2595 RVA: 0x000414D4 File Offset: 0x0003F6D4
		public SVGPathSegCurvetoCubicSmoothRel(float x2, float y2, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Cubic_Smooth_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
			SVGPathSegCurvetoCubic svgpathSegCurvetoCubic = segment as SVGPathSegCurvetoCubic;
			if (svgpathSegCurvetoCubic != null)
			{
				this._controlPoint1 = this._previousPoint + (this._previousPoint - svgpathSegCurvetoCubic.controlPoint2);
			}
			else
			{
				this._controlPoint1 = this._previousPoint;
			}
			this._controlPoint2 = this._previousPoint + new Vector2(x2, y2);
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000A24 RID: 2596 RVA: 0x00041582 File Offset: 0x0003F782
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000A25 RID: 2597 RVA: 0x0004158A File Offset: 0x0003F78A
		public override Vector2 controlPoint2
		{
			get
			{
				return this._controlPoint2;
			}
		}

		// Token: 0x04000958 RID: 2392
		protected Vector2 _controlPoint1 = Vector2.zero;

		// Token: 0x04000959 RID: 2393
		protected Vector2 _controlPoint2 = Vector2.zero;
	}
}
