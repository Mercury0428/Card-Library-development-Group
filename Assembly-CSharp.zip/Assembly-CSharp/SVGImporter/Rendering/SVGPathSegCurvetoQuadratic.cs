﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000148 RID: 328
	public abstract class SVGPathSegCurvetoQuadratic : SVGPathSeg
	{
		// Token: 0x17000167 RID: 359
		// (get) Token: 0x06000A26 RID: 2598
		public abstract Vector2 controlPoint1 { get; }
	}
}
