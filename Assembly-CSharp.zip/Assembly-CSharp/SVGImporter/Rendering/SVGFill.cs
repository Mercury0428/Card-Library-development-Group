﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000118 RID: 280
	[Serializable]
	public class SVGFill
	{
		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060008DA RID: 2266 RVA: 0x0003A18D File Offset: 0x0003838D
		public string gradientHash
		{
			get
			{
				return this.gradientColors.hash;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060008DB RID: 2267 RVA: 0x0003A19C File Offset: 0x0003839C
		public Color32 finalColor
		{
			get
			{
				return new Color32(this.color.r, this.color.g, this.color.b, (byte)Mathf.RoundToInt((float)this.color.a * this.opacity));
			}
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x00002050 File Offset: 0x00000250
		public SVGFill()
		{
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x0003A1E8 File Offset: 0x000383E8
		public SVGFill(Color32 color)
		{
			this.color = color;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x0003A1F7 File Offset: 0x000383F7
		public SVGFill(Color32 color, FILL_BLEND blend)
		{
			this.color = color;
			this.blend = blend;
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x0003A20D File Offset: 0x0003840D
		public SVGFill(Color32 color, FILL_BLEND blend, FILL_TYPE fillType)
		{
			this.color = color;
			this.blend = blend;
			this.fillType = fillType;
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x0003A22A File Offset: 0x0003842A
		public SVGFill(Color32 color, FILL_BLEND blend, FILL_TYPE fillType, GRADIENT_TYPE gradientType)
		{
			this.color = color;
			this.blend = blend;
			this.fillType = fillType;
			this.gradientType = gradientType;
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x0003A250 File Offset: 0x00038450
		public SVGFill Clone()
		{
			SVGFill svgfill = new SVGFill(this.color, this.blend, this.fillType, this.gradientType);
			svgfill.gradientId = this.gradientId;
			svgfill.transform = this.transform;
			svgfill.opacity = this.opacity;
			svgfill.viewport = this.viewport;
			if (this.gradientColors != null)
			{
				svgfill.gradientColors = this.gradientColors.Clone();
			}
			return svgfill;
		}

		// Token: 0x0400084B RID: 2123
		public FILL_TYPE fillType;

		// Token: 0x0400084C RID: 2124
		public FILL_BLEND blend;

		// Token: 0x0400084D RID: 2125
		public GRADIENT_TYPE gradientType;

		// Token: 0x0400084E RID: 2126
		public Color32 color;

		// Token: 0x0400084F RID: 2127
		public float opacity;

		// Token: 0x04000850 RID: 2128
		public Rect viewport;

		// Token: 0x04000851 RID: 2129
		public SVGMatrix transform;

		// Token: 0x04000852 RID: 2130
		public string gradientId;

		// Token: 0x04000853 RID: 2131
		public CCGradient gradientColors;
	}
}
