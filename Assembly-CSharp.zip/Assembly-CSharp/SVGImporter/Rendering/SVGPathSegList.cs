﻿using System;
using System.Collections.Generic;

namespace SVGImporter.Rendering
{
	// Token: 0x02000153 RID: 339
	public class SVGPathSegList
	{
		// Token: 0x06000A36 RID: 2614 RVA: 0x000418B5 File Offset: 0x0003FAB5
		public SVGPathSegList(int size)
		{
			this._segList = new List<object>(size);
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x06000A37 RID: 2615 RVA: 0x000418C9 File Offset: 0x0003FAC9
		public int Count
		{
			get
			{
				return this._segList.Count;
			}
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x000418D6 File Offset: 0x0003FAD6
		public void Clear()
		{
			this._segList.Clear();
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x000418E3 File Offset: 0x0003FAE3
		public SVGPathSeg GetItem(int index)
		{
			if (index < 0 || index >= this._segList.Count)
			{
				return null;
			}
			return (SVGPathSeg)this._segList[index];
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x0004190A File Offset: 0x0003FB0A
		public SVGPathSeg GetLastItem()
		{
			if (this._segList.Count == 0)
			{
				return null;
			}
			return (SVGPathSeg)this._segList[this._segList.Count - 1];
		}

		// Token: 0x06000A3B RID: 2619 RVA: 0x00041938 File Offset: 0x0003FB38
		public SVGPathSeg AppendItem(SVGPathSeg newItem)
		{
			if (newItem == null)
			{
				return null;
			}
			int count = this._segList.Count;
			newItem.SetIndex(count);
			this._segList.Add(newItem);
			this.SetList(newItem);
			return newItem;
		}

		// Token: 0x06000A3C RID: 2620 RVA: 0x00041972 File Offset: 0x0003FB72
		internal SVGPathSeg GetPreviousSegment(int index)
		{
			return this.GetItem(index - 1);
		}

		// Token: 0x06000A3D RID: 2621 RVA: 0x0004197D File Offset: 0x0003FB7D
		private void SetList(SVGPathSeg newItem)
		{
			if (newItem != null)
			{
				newItem.SetList(this);
			}
		}

		// Token: 0x0400095E RID: 2398
		private List<object> _segList;
	}
}
