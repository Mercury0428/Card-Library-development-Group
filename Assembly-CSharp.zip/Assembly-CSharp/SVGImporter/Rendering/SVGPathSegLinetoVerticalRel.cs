﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000152 RID: 338
	public class SVGPathSegLinetoVerticalRel : SVGPathSeg
	{
		// Token: 0x06000A35 RID: 2613 RVA: 0x0004187A File Offset: 0x0003FA7A
		public SVGPathSegLinetoVerticalRel(float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Vertical_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(0f, y);
		}
	}
}
