﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;

namespace SVGImporter.Rendering
{
	// Token: 0x02000136 RID: 310
	public class SVGGradientElement
	{
		// Token: 0x17000137 RID: 311
		// (get) Token: 0x060009D5 RID: 2517 RVA: 0x0003FB96 File Offset: 0x0003DD96
		public SVGGradientUnit gradientUnits
		{
			get
			{
				return this._gradientUnits;
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060009D6 RID: 2518 RVA: 0x0003FB9E File Offset: 0x0003DD9E
		public SVGSpreadMethod spreadMethod
		{
			get
			{
				return this._spreadMethod;
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060009D7 RID: 2519 RVA: 0x0003FBA6 File Offset: 0x0003DDA6
		public string id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060009D8 RID: 2520 RVA: 0x0003FBAE File Offset: 0x0003DDAE
		public List<SVGStopElement> stopList
		{
			get
			{
				return this._stopList;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060009D9 RID: 2521 RVA: 0x0003FBB6 File Offset: 0x0003DDB6
		public SVGTransformList gradientTransform
		{
			get
			{
				return this._gradientTransform;
			}
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x0003FBC0 File Offset: 0x0003DDC0
		public SVGGradientElement(SVGParser xmlImp, Node node)
		{
			this._attrList = node.attributes;
			this._xmlImp = xmlImp;
			this._stopList = new List<SVGStopElement>();
			this._id = this._attrList.GetValue("id");
			this._gradientUnits = SVGGradientUnit.ObjectBoundingBox;
			if (this._attrList.GetValue("gradiantUnits") == "userSpaceOnUse")
			{
				this._gradientUnits = SVGGradientUnit.UserSpaceOnUse;
			}
			this._gradientTransform = new SVGTransformList(this._attrList.GetValue("gradientTransform"));
			this._spreadMethod = SVGSpreadMethod.Pad;
			if (this._attrList.GetValue("spreadMethod") == "reflect")
			{
				this._spreadMethod = SVGSpreadMethod.Reflect;
			}
			else if (this._attrList.GetValue("spreadMethod") == "repeat")
			{
				this._spreadMethod = SVGSpreadMethod.Repeat;
			}
			if (node is BlockOpenNode)
			{
				this.GetElementList();
			}
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x0003FCAC File Offset: 0x0003DEAC
		protected void GetElementList()
		{
			bool flag = false;
			while (!flag && this._xmlImp.Next())
			{
				if (this._xmlImp.node is BlockCloseNode)
				{
					flag = true;
				}
				else if (this._xmlImp.node.name == SVGNodeName.Stop)
				{
					this._stopList.Add(new SVGStopElement(this._xmlImp.node.attributes));
				}
			}
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x0003FD17 File Offset: 0x0003DF17
		public SVGStopElement GetStopElement(int i)
		{
			if (i >= 0 && i < this._stopList.Count)
			{
				return this._stopList[i];
			}
			return null;
		}

		// Token: 0x04000914 RID: 2324
		private SVGGradientUnit _gradientUnits;

		// Token: 0x04000915 RID: 2325
		private SVGSpreadMethod _spreadMethod;

		// Token: 0x04000916 RID: 2326
		private SVGTransformList _gradientTransform;

		// Token: 0x04000917 RID: 2327
		private string _id;

		// Token: 0x04000918 RID: 2328
		private SVGParser _xmlImp;

		// Token: 0x04000919 RID: 2329
		private List<SVGStopElement> _stopList;

		// Token: 0x0400091A RID: 2330
		protected AttributeList _attrList;
	}
}
