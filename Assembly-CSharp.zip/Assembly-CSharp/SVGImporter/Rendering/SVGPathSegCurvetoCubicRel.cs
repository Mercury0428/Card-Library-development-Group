﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000145 RID: 325
	public class SVGPathSegCurvetoCubicRel : SVGPathSegCurvetoCubic
	{
		// Token: 0x06000A1D RID: 2589 RVA: 0x00041390 File Offset: 0x0003F590
		public SVGPathSegCurvetoCubicRel(float x1, float y1, float x2, float y2, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Cubic_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, y);
			this._controlPoint1 = this._previousPoint + new Vector2(x1, y1);
			this._controlPoint2 = this._previousPoint + new Vector2(x2, y2);
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000A1E RID: 2590 RVA: 0x0004141C File Offset: 0x0003F61C
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000A1F RID: 2591 RVA: 0x00041424 File Offset: 0x0003F624
		public override Vector2 controlPoint2
		{
			get
			{
				return this._controlPoint2;
			}
		}

		// Token: 0x04000954 RID: 2388
		protected Vector2 _controlPoint1 = Vector2.zero;

		// Token: 0x04000955 RID: 2389
		protected Vector2 _controlPoint2 = Vector2.zero;
	}
}
