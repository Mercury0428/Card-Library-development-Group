﻿using System;
using System.Globalization;
using SVGImporter.Document;
using SVGImporter.Utils;

namespace SVGImporter.Rendering
{
	// Token: 0x02000139 RID: 313
	public class SVGStopElement
	{
		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060009E8 RID: 2536 RVA: 0x0003FF6A File Offset: 0x0003E16A
		public float offset
		{
			get
			{
				return this._offset;
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060009E9 RID: 2537 RVA: 0x0003FF72 File Offset: 0x0003E172
		public SVGColor stopColor
		{
			get
			{
				return this._stopColor;
			}
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0003FF7C File Offset: 0x0003E17C
		public SVGStopElement(AttributeList attrList)
		{
			string text = attrList.GetValue("stop-color");
			string text2 = attrList.GetValue("offset");
			string text3 = attrList.GetValue("stop-opacity");
			string value = attrList.GetValue("style");
			if (value != null)
			{
				string[] array = value.Split(new char[]
				{
					';'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].Contains("stop-color"))
					{
						text = array[i].Split(new char[]
						{
							':'
						})[1];
					}
					else if (array[i].Contains("stop-opacity"))
					{
						text3 = array[i].Split(new char[]
						{
							':'
						})[1];
					}
					else if (array[i].Contains("offset"))
					{
						text2 = array[i].Split(new char[]
						{
							':'
						})[1];
					}
				}
			}
			if (text == null)
			{
				text = "black";
			}
			if (text2 == null)
			{
				text2 = "0%";
			}
			this._stopColor = new SVGColor(text);
			if (!string.IsNullOrEmpty(text3))
			{
				if (text3.EndsWith("%"))
				{
					this._stopColor.color.a = float.Parse(text3.TrimEnd(new char[]
					{
						'%'
					}), CultureInfo.InvariantCulture) * 0.01f;
				}
				else
				{
					this._stopColor.color.a = float.Parse(text3, CultureInfo.InvariantCulture);
				}
			}
			string text4 = text2.Trim();
			if (text4 != "")
			{
				if (text4.EndsWith("%"))
				{
					this._offset = float.Parse(text4.TrimEnd(new char[]
					{
						'%'
					}), CultureInfo.InvariantCulture);
					return;
				}
				this._offset = float.Parse(text4, CultureInfo.InvariantCulture) * 100f;
			}
		}

		// Token: 0x04000924 RID: 2340
		private float _offset;

		// Token: 0x04000925 RID: 2341
		private SVGColor _stopColor;
	}
}
