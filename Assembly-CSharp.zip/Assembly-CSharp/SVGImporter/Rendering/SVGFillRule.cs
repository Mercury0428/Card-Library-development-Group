﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000128 RID: 296
	public enum SVGFillRule
	{
		// Token: 0x040008C3 RID: 2243
		NonZero,
		// Token: 0x040008C4 RID: 2244
		EvenOdd
	}
}
