﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013E RID: 318
	public enum SVGPathSegTypes : ushort
	{
		// Token: 0x0400092E RID: 2350
		Unknown,
		// Token: 0x0400092F RID: 2351
		Close,
		// Token: 0x04000930 RID: 2352
		MoveTo_Abs,
		// Token: 0x04000931 RID: 2353
		MoveTo_Rel,
		// Token: 0x04000932 RID: 2354
		LineTo_Abs,
		// Token: 0x04000933 RID: 2355
		LineTo_Rel,
		// Token: 0x04000934 RID: 2356
		CurveTo_Cubic_Abs,
		// Token: 0x04000935 RID: 2357
		CurveTo_Cubic_Rel,
		// Token: 0x04000936 RID: 2358
		CurveTo_Quadratic_Abs,
		// Token: 0x04000937 RID: 2359
		CurveTo_Quadratic_Rel,
		// Token: 0x04000938 RID: 2360
		Arc_Abs,
		// Token: 0x04000939 RID: 2361
		Arc_Rel,
		// Token: 0x0400093A RID: 2362
		LineTo_Horizontal_Abs,
		// Token: 0x0400093B RID: 2363
		LineTo_Horizontal_Rel,
		// Token: 0x0400093C RID: 2364
		LineTo_Vertical_Abs,
		// Token: 0x0400093D RID: 2365
		LineTo_Vertical_Rel,
		// Token: 0x0400093E RID: 2366
		CurveTo_Cubic_Smooth_Abs,
		// Token: 0x0400093F RID: 2367
		CurveTo_Cubic_Smooth_Rel,
		// Token: 0x04000940 RID: 2368
		CurveTo_Quadratic_Smooth_Abs,
		// Token: 0x04000941 RID: 2369
		CurveTo_Quadratic_Smooth_Rel
	}
}
