﻿using System;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200012E RID: 302
	public class SVGTransformable
	{
		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000992 RID: 2450 RVA: 0x0003E610 File Offset: 0x0003C810
		// (set) Token: 0x06000993 RID: 2451 RVA: 0x0003E618 File Offset: 0x0003C818
		public SVGTransformList inheritTransformList
		{
			get
			{
				return this._inheritTransformList;
			}
			set
			{
				int num = 0;
				if (this._inheritTransformList != null)
				{
					num += this._inheritTransformList.Count;
				}
				if (this._currentTransformList != null)
				{
					num += this._currentTransformList.Count;
				}
				this._inheritTransformList = value;
				this._summaryTransformList = new SVGTransformList(num);
				if (this._inheritTransformList != null)
				{
					this._summaryTransformList.AppendItems(this._inheritTransformList);
				}
				if (this._currentTransformList != null)
				{
					this._summaryTransformList.AppendItems(this._currentTransformList);
				}
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000994 RID: 2452 RVA: 0x0003E698 File Offset: 0x0003C898
		// (set) Token: 0x06000995 RID: 2453 RVA: 0x0003E6A0 File Offset: 0x0003C8A0
		public SVGTransformList currentTransformList
		{
			get
			{
				return this._currentTransformList;
			}
			set
			{
				this._currentTransformList = value;
				int num = 0;
				if (this._inheritTransformList != null)
				{
					num += this._inheritTransformList.Count;
				}
				if (this._currentTransformList != null)
				{
					num += this._currentTransformList.Count;
				}
				this._summaryTransformList = new SVGTransformList(num);
				if (this._inheritTransformList != null)
				{
					this._summaryTransformList.AppendItems(this._inheritTransformList);
				}
				if (this._currentTransformList != null)
				{
					this._summaryTransformList.AppendItems(this._currentTransformList);
				}
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000996 RID: 2454 RVA: 0x0003E720 File Offset: 0x0003C920
		public SVGTransformList summaryTransformList
		{
			get
			{
				return this._summaryTransformList;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000997 RID: 2455 RVA: 0x0003E728 File Offset: 0x0003C928
		public float transformAngle
		{
			get
			{
				float num = 0f;
				for (int i = 0; i < this._summaryTransformList.Count; i++)
				{
					SVGTransform svgtransform = this._summaryTransformList[i];
					if (svgtransform.type == SVGTransformMode.Rotate)
					{
						num += svgtransform.angle;
					}
				}
				return num;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000998 RID: 2456 RVA: 0x0003E771 File Offset: 0x0003C971
		public SVGMatrix transformMatrix
		{
			get
			{
				return this.summaryTransformList.Consolidate().matrix;
			}
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x0003E783 File Offset: 0x0003C983
		public SVGTransformable(SVGTransformList transformList)
		{
			this.inheritTransformList = transformList;
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x0003E794 File Offset: 0x0003C994
		public static SVGMatrix GetRootViewBoxTransform(AttributeList attributeList, ref Rect viewport)
		{
			SVGMatrix identity = SVGMatrix.identity;
			string value = attributeList.GetValue("x");
			string value2 = attributeList.GetValue("y");
			string value3 = attributeList.GetValue("width");
			string value4 = attributeList.GetValue("height");
			SVGLength svglength = new SVGLength(SVGLengthType.PX, 0f);
			SVGLength svglength2 = new SVGLength(SVGLengthType.PX, 0f);
			SVGLength svglength3 = new SVGLength(SVGLengthType.PX, 1f);
			SVGLength svglength4 = new SVGLength(SVGLengthType.PX, 1f);
			if (!string.IsNullOrEmpty(value))
			{
				svglength = new SVGLength(value);
			}
			if (!string.IsNullOrEmpty(value2))
			{
				svglength2 = new SVGLength(value2);
			}
			if (!string.IsNullOrEmpty(value3))
			{
				svglength3 = new SVGLength(value3);
			}
			if (!string.IsNullOrEmpty(value4))
			{
				svglength4 = new SVGLength(value4);
			}
			string value5 = attributeList.GetValue("viewBox");
			if (!string.IsNullOrEmpty(value5))
			{
				string[] array = SVGStringExtractor.ExtractTransformValue(value5);
				if (array.Length != 0 && string.IsNullOrEmpty(value))
				{
					svglength = new SVGLength(array[0]);
				}
				if (array.Length > 1 && string.IsNullOrEmpty(value2))
				{
					svglength2 = new SVGLength(array[1]);
				}
				if (array.Length > 2 && string.IsNullOrEmpty(value3))
				{
					svglength3 = new SVGLength(array[2]);
				}
				if (array.Length > 3 && string.IsNullOrEmpty(value4))
				{
					svglength4 = new SVGLength(array[3]);
				}
				viewport = new Rect(svglength.value, svglength2.value, svglength3.value, svglength4.value);
				if (string.IsNullOrEmpty(value))
				{
					viewport.x = svglength.value;
				}
				if (string.IsNullOrEmpty(value2))
				{
					viewport.y = svglength2.value;
				}
				if (string.IsNullOrEmpty(value3))
				{
					viewport.width = svglength3.value;
				}
				if (string.IsNullOrEmpty(value4))
				{
					viewport.height = svglength4.value;
					return identity;
				}
			}
			else
			{
				viewport = new Rect(svglength.value, svglength2.value, svglength3.value, svglength4.value);
			}
			return identity;
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x0003E97C File Offset: 0x0003CB7C
		public static SVGMatrix GetViewBoxTransform(AttributeList attributeList, ref Rect viewport, bool negotiate = false)
		{
			SVGMatrix result = SVGMatrix.identity;
			string value = attributeList.GetValue("preserveAspectRatio");
			string value2 = attributeList.GetValue("viewBox");
			if (!string.IsNullOrEmpty(value2))
			{
				string[] array = SVGStringExtractor.ExtractTransformValue(value2);
				if (array.Length == 4)
				{
					Rect content = new Rect(new SVGLength(array[0]).value, new SVGLength(array[1]).value, new SVGLength(array[2]).value, new SVGLength(array[3]).value);
					SVGViewport.Align viewportAlign = SVGViewport.Align.xMidYMid;
					SVGViewport.MeetOrSlice viewportMeetOrSlice = SVGViewport.MeetOrSlice.Meet;
					if (!string.IsNullOrEmpty(value))
					{
						string[] inputStrings = SVGStringExtractor.ExtractStringArray(value);
						viewportAlign = SVGViewport.GetAlignFromStrings(inputStrings);
						viewportMeetOrSlice = SVGViewport.GetMeetOrSliceFromStrings(inputStrings);
					}
					Rect rect = viewport;
					viewport = SVGViewport.GetViewport(viewport, content, viewportAlign, viewportMeetOrSlice);
					float scaleFactorX = 0f;
					float scaleFactorY = 0f;
					if (rect.size.x != 0f)
					{
						scaleFactorX = viewport.size.x / rect.size.x;
					}
					if (rect.size.y != 0f)
					{
						scaleFactorY = viewport.size.y / rect.size.y;
					}
					result.Scale(scaleFactorX, scaleFactorY);
					result = result.Translate(viewport.x - rect.x, viewport.y - rect.y);
				}
			}
			else if (negotiate)
			{
				string value3 = attributeList.GetValue("x");
				string value4 = attributeList.GetValue("y");
				string value5 = attributeList.GetValue("width");
				string value6 = attributeList.GetValue("height");
				SVGLength svglength = new SVGLength(SVGLengthType.PX, 0f);
				SVGLength svglength2 = new SVGLength(SVGLengthType.PX, 0f);
				SVGLength svglength3 = new SVGLength(SVGLengthType.PX, 1f);
				SVGLength svglength4 = new SVGLength(SVGLengthType.PX, 1f);
				if (!string.IsNullOrEmpty(value3))
				{
					svglength = new SVGLength(value3);
				}
				if (!string.IsNullOrEmpty(value4))
				{
					svglength2 = new SVGLength(value4);
				}
				if (!string.IsNullOrEmpty(value5))
				{
					svglength3 = new SVGLength(value5);
				}
				if (!string.IsNullOrEmpty(value6))
				{
					svglength4 = new SVGLength(value6);
				}
				float value7 = svglength.value;
				float value8 = svglength2.value;
				float value9 = svglength3.value;
				float value10 = svglength4.value;
				float scaleFactorX2 = 1f;
				if (value9 != 0f)
				{
					scaleFactorX2 = svglength3.value / value9;
				}
				float scaleFactorY2 = 1f;
				if (value10 != 0f)
				{
					scaleFactorY2 = svglength4.value / value10;
				}
				result = result.Scale(scaleFactorX2, scaleFactorY2).Translate(value7, value8);
				viewport = new Rect(value7, value8, value9, value10);
			}
			return result;
		}

		// Token: 0x040008F2 RID: 2290
		private SVGTransformList _inheritTransformList;

		// Token: 0x040008F3 RID: 2291
		private SVGTransformList _currentTransformList;

		// Token: 0x040008F4 RID: 2292
		private SVGTransformList _summaryTransformList;
	}
}
