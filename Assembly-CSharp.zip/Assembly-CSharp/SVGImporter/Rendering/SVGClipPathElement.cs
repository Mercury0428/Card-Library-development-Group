﻿using System;
using SVGImporter.Document;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013A RID: 314
	public class SVGClipPathElement
	{
		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060009EB RID: 2539 RVA: 0x00040154 File Offset: 0x0003E354
		public string id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0004015C File Offset: 0x0003E35C
		public SVGClipPathElement(SVGParser xmlImp, Node node)
		{
			this._attrList = node.attributes;
			this._xmlImp = xmlImp;
			this._id = this._attrList.GetValue("id");
			this.GetElementList();
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x00040194 File Offset: 0x0003E394
		protected void GetElementList()
		{
			bool flag = false;
			while (!flag && this._xmlImp.Next())
			{
				if (this._xmlImp.node is BlockCloseNode)
				{
					flag = true;
				}
			}
		}

		// Token: 0x04000926 RID: 2342
		private string _id;

		// Token: 0x04000927 RID: 2343
		private SVGParser _xmlImp;

		// Token: 0x04000928 RID: 2344
		protected AttributeList _attrList;
	}
}
