﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200011C RID: 284
	public class SVGRadialGradientBrush
	{
		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600090A RID: 2314 RVA: 0x0003BA6E File Offset: 0x00039C6E
		public bool alphaBlended
		{
			get
			{
				return this._alphaBlended;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600090B RID: 2315 RVA: 0x0003BA76 File Offset: 0x00039C76
		public SVGFill fill
		{
			get
			{
				return this._fill;
			}
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x0003BA7E File Offset: 0x00039C7E
		public SVGRadialGradientBrush(SVGRadialGradientElement radialGradElement)
		{
			this._transform = SVGMatrix.identity;
			this._radialGradElement = radialGradElement;
			this.Initialize();
			this.CreateFill();
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x0003BAA4 File Offset: 0x00039CA4
		public SVGRadialGradientBrush(SVGRadialGradientElement radialGradElement, Rect bounds, SVGMatrix matrix, Rect viewport)
		{
			this._viewport = viewport;
			this._transform = matrix;
			this._radialGradElement = radialGradElement;
			this.Initialize();
			this.CreateFill(bounds);
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0003BACF File Offset: 0x00039CCF
		protected Color GetColor(SVGColor svgColor)
		{
			if (svgColor.color.a != 1f)
			{
				this._alphaBlended = true;
			}
			return svgColor.color;
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x0003BAF0 File Offset: 0x00039CF0
		private void Initialize()
		{
			this._cx = this._radialGradElement.cx;
			this._cy = this._radialGradElement.cy;
			this._r = this._radialGradElement.r;
			this._stopColorList = new List<Color>();
			this._stopOffsetList = new List<float>();
			this.GetStopList();
		}

		// Token: 0x06000910 RID: 2320 RVA: 0x0003BB4C File Offset: 0x00039D4C
		private void CreateFill()
		{
			if (this._alphaBlended)
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.ALPHA_BLENDED, FILL_TYPE.GRADIENT, GRADIENT_TYPE.RADIAL);
			}
			else
			{
				this._fill = new SVGFill(Color.white, FILL_BLEND.OPAQUE, FILL_TYPE.GRADIENT, GRADIENT_TYPE.RADIAL);
			}
			this._gradientTransform = this._radialGradElement.gradientTransform.Consolidate().matrix;
			this._fill.gradientColors = SVGAssetImport.atlasData.AddGradient(this.ParseGradientColors());
			this._fill.viewport = this._viewport;
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x0003BBDC File Offset: 0x00039DDC
		private void CreateFill(Rect bounds)
		{
			this.CreateFill();
			this._fill.transform = SVGSimplePath.GetFillTransform(this._fill, bounds, new SVGLength[]
			{
				this._cx,
				this._cy
			}, new SVGLength[]
			{
				this._r,
				this._r
			}, this._transform, this._gradientTransform);
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x0003BC54 File Offset: 0x00039E54
		public CCGradient ParseGradientColors()
		{
			int count = this._stopColorList.Count;
			CCGradientColorKey[] array = new CCGradientColorKey[count];
			CCGradientAlphaKey[] array2 = new CCGradientAlphaKey[count];
			for (int i = 0; i < count; i++)
			{
				float time = Mathf.Clamp01(this._stopOffsetList[i] * 0.01f);
				array[i] = new CCGradientColorKey(this._stopColorList[i], time);
				array2[i] = new CCGradientAlphaKey(this._stopColorList[i].a, time);
			}
			return new CCGradient(array, array2, true);
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x0003BCF4 File Offset: 0x00039EF4
		private void GetStopList()
		{
			List<SVGStopElement> stopList = this._radialGradElement.stopList;
			int count = stopList.Count;
			if (count == 0)
			{
				return;
			}
			this._stopColorList.Add(this.GetColor(stopList[0].stopColor));
			this._stopOffsetList.Add(0f);
			for (int i = 0; i < count; i++)
			{
				float offset = stopList[i].offset;
				if (offset > this._stopOffsetList[this._stopOffsetList.Count - 1] && offset <= 100f)
				{
					this._stopColorList.Add(this.GetColor(stopList[i].stopColor));
					this._stopOffsetList.Add(offset);
				}
				else if (offset == this._stopOffsetList[this._stopOffsetList.Count - 1])
				{
					this._stopColorList[this._stopOffsetList.Count - 1] = this.GetColor(stopList[i].stopColor);
				}
			}
			if (this._stopOffsetList[this._stopOffsetList.Count - 1] != 100f)
			{
				this._stopColorList.Add(this._stopColorList[this._stopOffsetList.Count - 1]);
				this._stopOffsetList.Add(100f);
			}
		}

		// Token: 0x04000873 RID: 2163
		private SVGRadialGradientElement _radialGradElement;

		// Token: 0x04000874 RID: 2164
		private SVGLength _cx;

		// Token: 0x04000875 RID: 2165
		private SVGLength _cy;

		// Token: 0x04000876 RID: 2166
		private SVGLength _r;

		// Token: 0x04000877 RID: 2167
		private List<Color> _stopColorList;

		// Token: 0x04000878 RID: 2168
		private List<float> _stopOffsetList;

		// Token: 0x04000879 RID: 2169
		protected bool _alphaBlended;

		// Token: 0x0400087A RID: 2170
		protected SVGFill _fill;

		// Token: 0x0400087B RID: 2171
		protected SVGMatrix _gradientTransform;

		// Token: 0x0400087C RID: 2172
		protected SVGMatrix _transform;

		// Token: 0x0400087D RID: 2173
		protected Rect _viewport;
	}
}
