﻿using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000114 RID: 276
	[Serializable]
	public class CCGradient
	{
		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060008CB RID: 2251 RVA: 0x000397DC File Offset: 0x000379DC
		public string hash
		{
			get
			{
				string text = "G";
				if (this.colorKeys != null && this.colorKeys.Length != 0)
				{
					for (int i = 0; i < this.colorKeys.Length; i++)
					{
						text = text + "C" + Mathf.RoundToInt(this.colorKeys[i].time * 999f).ToString("000") + CCGradient.ColorToHex(this.colorKeys[i].color);
					}
				}
				if (this.alphaKeys != null && this.alphaKeys.Length != 0)
				{
					for (int j = 0; j < this.alphaKeys.Length; j++)
					{
						text = text + "A" + Mathf.RoundToInt(this.alphaKeys[j].time * 999f).ToString("000") + Mathf.RoundToInt(this.alphaKeys[j].alpha * 999f).ToString("000");
					}
				}
				return text;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060008CC RID: 2252 RVA: 0x000398E1 File Offset: 0x00037AE1
		public List<ISVGReference> references
		{
			get
			{
				return this._references;
			}
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x000398EC File Offset: 0x00037AEC
		public bool AddReference(ISVGReference reference)
		{
			if (this._references == null)
			{
				this._references = new List<ISVGReference>
				{
					reference
				};
				if (this.onReferenceAdded != null)
				{
					this.onReferenceAdded(reference);
				}
				return true;
			}
			if (!this._references.Contains(reference))
			{
				this._references.Add(reference);
				if (this.onReferenceAdded != null)
				{
					this.onReferenceAdded(reference);
				}
				return true;
			}
			return false;
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x0003995A File Offset: 0x00037B5A
		public bool RemoveReference(ISVGReference reference)
		{
			if (this._references != null)
			{
				bool flag = this._references.Remove(reference);
				if (flag && this.onReferenceRemoved != null)
				{
					this.onReferenceRemoved(reference);
				}
				return flag;
			}
			return false;
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x0003998C File Offset: 0x00037B8C
		public int CountReferences(ISVGReference reference)
		{
			int num = 0;
			if (this._references != null)
			{
				for (int i = 0; i < this._references.Count; i++)
				{
					if (this._references[i] == reference)
					{
						num++;
					}
				}
			}
			return num;
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060008D0 RID: 2256 RVA: 0x000399CD File Offset: 0x00037BCD
		public int referenceCount
		{
			get
			{
				if (this._references == null)
				{
					return 0;
				}
				return this._references.Count;
			}
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x000399E4 File Offset: 0x00037BE4
		public CCGradient(CCGradientColorKey[] colorKeys, CCGradientAlphaKey[] alphaKeys, bool sort = true)
		{
			this.SetKeys(colorKeys, alphaKeys, sort);
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x000399F8 File Offset: 0x00037BF8
		public void SetKeys(CCGradientColorKey[] colorKeys, CCGradientAlphaKey[] alphaKeys, bool sort = true)
		{
			this.colorKeys = (CCGradientColorKey[])colorKeys.Clone();
			this.alphaKeys = (CCGradientAlphaKey[])alphaKeys.Clone();
			if (sort)
			{
				Array.Sort<CCGradientColorKey>(this.colorKeys, (CCGradientColorKey x, CCGradientColorKey y) => y.time.CompareTo(x.time));
				Array.Sort<CCGradientAlphaKey>(this.alphaKeys, (CCGradientAlphaKey x, CCGradientAlphaKey y) => y.time.CompareTo(x.time));
			}
			if (this.alphaKeys == null || this.alphaKeys.Length == 0)
			{
				this.alphaKeys = new CCGradientAlphaKey[]
				{
					new CCGradientAlphaKey(1f, 0f),
					new CCGradientAlphaKey(1f, 1f)
				};
			}
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00039AC8 File Offset: 0x00037CC8
		public Color32 Evaluate(float time)
		{
			time = Mathf.Clamp01(time);
			Color32 result;
			if (this.colorKeys == null || this.colorKeys.Length == 0)
			{
				result = new Color32(0, 0, 0, byte.MaxValue);
			}
			else if (this.colorKeys.Length == 1)
			{
				result = this.colorKeys[0].color;
			}
			else
			{
				int num = this.colorKeys.Length;
				float num2 = float.MaxValue;
				int num3 = 0;
				int i = 0;
				while (i < num)
				{
					float num4 = Mathf.Abs(this.colorKeys[i].time - time);
					if (num4 < num2)
					{
						num2 = num4;
						num3 = i;
						i++;
					}
					else
					{
						if (num4 <= num2)
						{
							num3 = i;
							break;
						}
						break;
					}
				}
				if (this.colorKeys[num3].time > time)
				{
					int num5 = num3;
					int num6 = Mathf.Clamp(num3 + 1, 0, num - 1);
					result = Color32.Lerp(this.colorKeys[num5].color, this.colorKeys[num6].color, Mathf.InverseLerp(this.colorKeys[num5].time, this.colorKeys[num6].time, time));
				}
				else if (this.colorKeys[num3].time < time)
				{
					int num7 = Mathf.Clamp(num3 - 1, 0, num - 1);
					int num8 = num3;
					result = Color32.Lerp(this.colorKeys[num7].color, this.colorKeys[num8].color, Mathf.InverseLerp(this.colorKeys[num7].time, this.colorKeys[num8].time, time));
				}
				else
				{
					result = this.colorKeys[num3].color;
				}
			}
			if (this.alphaKeys == null || this.alphaKeys.Length == 0)
			{
				result.a = byte.MaxValue;
			}
			else if (this.alphaKeys.Length == 1)
			{
				result.a = (byte)Mathf.RoundToInt(this.alphaKeys[0].alpha * 255f);
			}
			else
			{
				int num9 = this.alphaKeys.Length;
				float num10 = float.MaxValue;
				int num11 = 0;
				int j = 0;
				while (j < num9)
				{
					float num12 = Mathf.Abs(this.alphaKeys[j].time - time);
					if (num12 < num10)
					{
						num10 = num12;
						num11 = j;
						j++;
					}
					else
					{
						if (num12 <= num10)
						{
							num11 = j;
							break;
						}
						break;
					}
				}
				if (this.alphaKeys[num11].time > time)
				{
					int num13 = num11;
					int num14 = Mathf.Clamp(num11 + 1, 0, num9 - 1);
					result.a = (byte)Mathf.RoundToInt(Mathf.Lerp(this.alphaKeys[num13].alpha, this.alphaKeys[num14].alpha, Mathf.InverseLerp(this.alphaKeys[num13].time, this.alphaKeys[num14].time, time)) * 255f);
				}
				else if (this.alphaKeys[num11].time < time)
				{
					int num15 = Mathf.Clamp(num11 - 1, 0, num9 - 1);
					int num16 = num11;
					result.a = (byte)Mathf.RoundToInt(Mathf.Lerp(this.alphaKeys[num15].alpha, this.alphaKeys[num16].alpha, Mathf.InverseLerp(this.alphaKeys[num15].time, this.alphaKeys[num16].time, time)) * 255f);
				}
				else
				{
					result.a = (byte)Mathf.RoundToInt(this.alphaKeys[num11].alpha * 255f);
				}
			}
			return result;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00039EA0 File Offset: 0x000380A0
		public Color32 ApproximateColor(int samples)
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			float num5 = (float)(samples - 1);
			for (float num6 = 0f; num6 < (float)samples; num6 += 1f)
			{
				Color32 color = this.Evaluate(num6 / num5);
				num += (int)color.r;
				num2 += (int)color.g;
				num3 += (int)color.b;
				num4 += (int)color.a;
			}
			num = Mathf.Clamp(Mathf.RoundToInt((float)num / (float)samples), 0, 255);
			num2 = Mathf.Clamp(Mathf.RoundToInt((float)num2 / (float)samples), 0, 255);
			num3 = Mathf.Clamp(Mathf.RoundToInt((float)num3 / (float)samples), 0, 255);
			num4 = Mathf.Clamp(Mathf.RoundToInt((float)num4 / (float)samples), 0, 255);
			return new Color32((byte)num, (byte)num2, (byte)num3, (byte)num4);
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060008D5 RID: 2261 RVA: 0x00039F6E File Offset: 0x0003816E
		public bool initialised
		{
			get
			{
				return this.colorKeys != null && this.alphaKeys != null && this.colorKeys.Length != 0 && this.alphaKeys.Length != 0;
			}
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x00039F98 File Offset: 0x00038198
		public CCGradient Clone()
		{
			if (this.colorKeys == null || this.alphaKeys == null)
			{
				return null;
			}
			return new CCGradient((CCGradientColorKey[])this.colorKeys.Clone(), (CCGradientAlphaKey[])this.alphaKeys.Clone(), false)
			{
				index = this.index,
				atlasIndex = this.atlasIndex
			};
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x00039FF8 File Offset: 0x000381F8
		public override string ToString()
		{
			string text = string.Format("[CCGradient: initialised={0}, index={1}, atlasIndex={2}]", new object[]
			{
				this.hash,
				this.initialised,
				this.index,
				this.atlasIndex
			});
			if (this.colorKeys != null && this.colorKeys.Length != 0)
			{
				text += "\nColorKeys:\n";
				for (int i = 0; i < this.colorKeys.Length; i++)
				{
					text = text + this.colorKeys[i].ToString() + "\n";
				}
			}
			if (this.alphaKeys != null && this.alphaKeys.Length != 0)
			{
				text += "\nAlphaKeys:\n";
				for (int j = 0; j < this.alphaKeys.Length; j++)
				{
					text = text + this.alphaKeys[j].ToString() + "\n";
				}
			}
			return text;
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x0003A0F0 File Offset: 0x000382F0
		public static string ColorToHex(Color32 color)
		{
			return color.r.ToString("X2") + color.g.ToString("X2") + color.b.ToString("X2");
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x0003A12C File Offset: 0x0003832C
		public static Color HexToColor(string hex)
		{
			byte r;
			byte.TryParse(hex.Substring(0, 2), NumberStyles.HexNumber, null, out r);
			byte g;
			byte.TryParse(hex.Substring(2, 2), NumberStyles.HexNumber, null, out g);
			byte b;
			byte.TryParse(hex.Substring(4, 2), NumberStyles.HexNumber, null, out b);
			return new Color32(r, g, b, byte.MaxValue);
		}

		// Token: 0x04000836 RID: 2102
		public const string DEFAULT_GRADIENT_HASH = "GC999FFFFFFC000FFFFFFA999999A000999";

		// Token: 0x04000837 RID: 2103
		public CCGradientColorKey[] colorKeys;

		// Token: 0x04000838 RID: 2104
		public CCGradientAlphaKey[] alphaKeys;

		// Token: 0x04000839 RID: 2105
		public int index;

		// Token: 0x0400083A RID: 2106
		[HideInInspector]
		[NonSerialized]
		public int atlasIndex;

		// Token: 0x0400083B RID: 2107
		[HideInInspector]
		[NonSerialized]
		protected List<ISVGReference> _references;

		// Token: 0x0400083C RID: 2108
		[NonSerialized]
		public Action<ISVGReference> onReferenceAdded;

		// Token: 0x0400083D RID: 2109
		[NonSerialized]
		public Action<ISVGReference> onReferenceRemoved;
	}
}
