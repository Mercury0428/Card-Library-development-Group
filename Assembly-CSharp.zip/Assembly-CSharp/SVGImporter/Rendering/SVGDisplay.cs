﻿using System;

namespace SVGImporter.Rendering
{
	// Token: 0x02000127 RID: 295
	public enum SVGDisplay
	{
		// Token: 0x040008B0 RID: 2224
		Inline,
		// Token: 0x040008B1 RID: 2225
		Block,
		// Token: 0x040008B2 RID: 2226
		Flex,
		// Token: 0x040008B3 RID: 2227
		InlineBlock,
		// Token: 0x040008B4 RID: 2228
		InlineFlex,
		// Token: 0x040008B5 RID: 2229
		InlineTable,
		// Token: 0x040008B6 RID: 2230
		ListItem,
		// Token: 0x040008B7 RID: 2231
		RunIn,
		// Token: 0x040008B8 RID: 2232
		Table,
		// Token: 0x040008B9 RID: 2233
		TableCaption,
		// Token: 0x040008BA RID: 2234
		TableColumnGroup,
		// Token: 0x040008BB RID: 2235
		TableHeaderGroup,
		// Token: 0x040008BC RID: 2236
		TableFooterGroup,
		// Token: 0x040008BD RID: 2237
		TableRowGroup,
		// Token: 0x040008BE RID: 2238
		TableCell,
		// Token: 0x040008BF RID: 2239
		TableColumn,
		// Token: 0x040008C0 RID: 2240
		TableRow,
		// Token: 0x040008C1 RID: 2241
		None
	}
}
