﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000144 RID: 324
	public class SVGPathSegCurvetoCubicAbs : SVGPathSegCurvetoCubic
	{
		// Token: 0x06000A1A RID: 2586 RVA: 0x00041314 File Offset: 0x0003F514
		public SVGPathSegCurvetoCubicAbs(float x1, float y1, float x2, float y2, float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Cubic_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
			this._controlPoint1 = new Vector2(x1, y1);
			this._controlPoint2 = new Vector2(x2, y2);
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000A1B RID: 2587 RVA: 0x0004137F File Offset: 0x0003F57F
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x06000A1C RID: 2588 RVA: 0x00041387 File Offset: 0x0003F587
		public override Vector2 controlPoint2
		{
			get
			{
				return this._controlPoint2;
			}
		}

		// Token: 0x04000952 RID: 2386
		protected Vector2 _controlPoint1 = Vector2.zero;

		// Token: 0x04000953 RID: 2387
		protected Vector2 _controlPoint2 = Vector2.zero;
	}
}
