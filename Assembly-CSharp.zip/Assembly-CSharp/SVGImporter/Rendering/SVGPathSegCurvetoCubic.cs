﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000143 RID: 323
	public abstract class SVGPathSegCurvetoCubic : SVGPathSeg
	{
		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000A17 RID: 2583
		public abstract Vector2 controlPoint1 { get; }

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000A18 RID: 2584
		public abstract Vector2 controlPoint2 { get; }
	}
}
