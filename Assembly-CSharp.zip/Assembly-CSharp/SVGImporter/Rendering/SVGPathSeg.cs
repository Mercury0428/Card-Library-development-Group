﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013F RID: 319
	public abstract class SVGPathSeg
	{
		// Token: 0x1700014E RID: 334
		// (get) Token: 0x06000A00 RID: 2560 RVA: 0x0004113F File Offset: 0x0003F33F
		public SVGPathSegTypes type
		{
			get
			{
				return this._type;
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x06000A01 RID: 2561 RVA: 0x00041147 File Offset: 0x0003F347
		public int index
		{
			get
			{
				return this._index;
			}
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x0004114F File Offset: 0x0003F34F
		public int SetIndex(int value)
		{
			this._index = value;
			return value;
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x00041159 File Offset: 0x0003F359
		public void SetPosition(Vector2 value)
		{
			this._currentPoint = value;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x00041162 File Offset: 0x0003F362
		public void SetPreviousSegment(SVGPathSeg prevSeg)
		{
			if (prevSeg == null)
			{
				return;
			}
			this._prevSeg = prevSeg;
			this._previousPoint = prevSeg.currentPoint;
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0004117B File Offset: 0x0003F37B
		internal void SetList(SVGPathSegList segList)
		{
			this._segList = segList;
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x06000A06 RID: 2566 RVA: 0x00041184 File Offset: 0x0003F384
		public SVGPathSeg previousSeg
		{
			get
			{
				return this._segList.GetPreviousSegment(this._index);
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x06000A07 RID: 2567 RVA: 0x00041197 File Offset: 0x0003F397
		public Vector2 currentPoint
		{
			get
			{
				return this._currentPoint;
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000A08 RID: 2568 RVA: 0x0004119F File Offset: 0x0003F39F
		public Vector2 previousPoint
		{
			get
			{
				return this._previousPoint;
			}
		}

		// Token: 0x04000942 RID: 2370
		protected SVGPathSegTypes _type;

		// Token: 0x04000943 RID: 2371
		protected int _index = -1;

		// Token: 0x04000944 RID: 2372
		protected SVGPathSeg _prevSeg;

		// Token: 0x04000945 RID: 2373
		protected Vector2 _currentPoint = Vector2.zero;

		// Token: 0x04000946 RID: 2374
		protected Vector2 _previousPoint = Vector2.zero;

		// Token: 0x04000947 RID: 2375
		protected SVGPathSegList _segList;
	}
}
