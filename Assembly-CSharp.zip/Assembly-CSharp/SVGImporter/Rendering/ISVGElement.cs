﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200013C RID: 316
	public interface ISVGElement
	{
		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060009F0 RID: 2544
		AttributeList attrList { get; }

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060009F1 RID: 2545
		SVGPaintable paintable { get; }

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060009F2 RID: 2546
		SVGMatrix transformMatrix { get; }

		// Token: 0x060009F3 RID: 2547
		List<List<Vector2>> GetPath();

		// Token: 0x060009F4 RID: 2548
		List<List<Vector2>> GetClipPath();
	}
}
