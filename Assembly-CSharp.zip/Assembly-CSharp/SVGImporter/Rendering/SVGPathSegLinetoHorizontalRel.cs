﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014F RID: 335
	public class SVGPathSegLinetoHorizontalRel : SVGPathSeg
	{
		// Token: 0x06000A32 RID: 2610 RVA: 0x000417D3 File Offset: 0x0003F9D3
		public SVGPathSegLinetoHorizontalRel(float x, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.LineTo_Horizontal_Rel;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = this._previousPoint + new Vector2(x, 0f);
		}
	}
}
