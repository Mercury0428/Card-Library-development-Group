﻿using System;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x0200014B RID: 331
	public class SVGPathSegCurvetoQuadraticSmoothAbs : SVGPathSegCurvetoQuadratic
	{
		// Token: 0x06000A2C RID: 2604 RVA: 0x00041660 File Offset: 0x0003F860
		public SVGPathSegCurvetoQuadraticSmoothAbs(float x, float y, SVGPathSeg segment)
		{
			this._type = SVGPathSegTypes.CurveTo_Quadratic_Smooth_Abs;
			if (segment != null)
			{
				this._previousPoint = segment.currentPoint;
			}
			this._currentPoint = new Vector2(x, y);
			SVGPathSegCurvetoQuadratic svgpathSegCurvetoQuadratic = segment as SVGPathSegCurvetoQuadratic;
			if (svgpathSegCurvetoQuadratic != null)
			{
				this._controlPoint1 = this._previousPoint + (this._previousPoint - svgpathSegCurvetoQuadratic.controlPoint1);
				return;
			}
			this._controlPoint1 = this._previousPoint;
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000A2D RID: 2605 RVA: 0x000416DB File Offset: 0x0003F8DB
		public override Vector2 controlPoint1
		{
			get
			{
				return this._controlPoint1;
			}
		}

		// Token: 0x0400095C RID: 2396
		protected Vector2 _controlPoint1 = Vector2.zero;
	}
}
