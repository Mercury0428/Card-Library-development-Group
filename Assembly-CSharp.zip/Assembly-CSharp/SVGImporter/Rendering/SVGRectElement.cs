﻿using System;
using System.Collections.Generic;
using SVGImporter.Document;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Rendering
{
	// Token: 0x02000122 RID: 290
	public class SVGRectElement : SVGParentable, ISVGDrawable, ISVGElement
	{
		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000948 RID: 2376 RVA: 0x0003CE37 File Offset: 0x0003B037
		public AttributeList attrList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000949 RID: 2377 RVA: 0x0003CE3F File Offset: 0x0003B03F
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600094A RID: 2378 RVA: 0x0003CE47 File Offset: 0x0003B047
		public SVGLength x
		{
			get
			{
				return this._x;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x0600094B RID: 2379 RVA: 0x0003CE4F File Offset: 0x0003B04F
		public SVGLength y
		{
			get
			{
				return this._y;
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x0600094C RID: 2380 RVA: 0x0003CE57 File Offset: 0x0003B057
		public SVGLength width
		{
			get
			{
				return this._width;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x0600094D RID: 2381 RVA: 0x0003CE5F File Offset: 0x0003B05F
		public SVGLength height
		{
			get
			{
				return this._height;
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x0600094E RID: 2382 RVA: 0x0003CE67 File Offset: 0x0003B067
		public SVGLength rx
		{
			get
			{
				return this._rx;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x0600094F RID: 2383 RVA: 0x0003CE6F File Offset: 0x0003B06F
		public SVGLength ry
		{
			get
			{
				return this._ry;
			}
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x0003CE78 File Offset: 0x0003B078
		public SVGRectElement(Node node, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable = null) : base(inheritTransformList)
		{
			this._attrList = node.attributes;
			this._paintable = new SVGPaintable(inheritPaintable, node);
			this._x = new SVGLength(this.attrList.GetValue("x"));
			this._y = new SVGLength(this.attrList.GetValue("y"));
			this._width = new SVGLength(this.attrList.GetValue("width"));
			this._height = new SVGLength(this.attrList.GetValue("height"));
			this._rx = new SVGLength(this.attrList.GetValue("rx"));
			this._ry = new SVGLength(this.attrList.GetValue("ry"));
			base.currentTransformList = new SVGTransformList(this.attrList.GetValue("transform"));
			Rect viewport = this._paintable.viewport;
			base.currentTransformList.AppendItem(new SVGTransform(SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, false)));
			this.paintable.SetViewport(viewport);
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x0003BF4F File Offset: 0x0003A14F
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x0003CFB0 File Offset: 0x0003B1B0
		public List<List<Vector2>> GetPath()
		{
			List<Vector2> list = new List<Vector2>();
			float value = this.width.value;
			float value2 = this.height.value;
			float value3 = this.x.value;
			float value4 = this.y.value;
			float value5 = this.rx.value;
			float value6 = this.ry.value;
			Vector2 vector = new Vector2(value3, value4);
			Vector2 vector2 = new Vector2(value3 + value, value4);
			Vector2 vector3 = new Vector2(value3 + value, value4 + value2);
			Vector2 vector4 = new Vector2(value3, value4 + value2);
			if (value5 == 0f && value6 == 0f)
			{
				list = new List<Vector2>(new Vector2[]
				{
					base.transformMatrix.Transform(vector),
					base.transformMatrix.Transform(vector2),
					base.transformMatrix.Transform(vector3),
					base.transformMatrix.Transform(vector4)
				});
			}
			else
			{
				float num = (value5 == 0f) ? value6 : value5;
				float num2 = (value6 == 0f) ? value5 : value6;
				num = ((num > value * 0.5f - 2f) ? (value * 0.5f - 2f) : num);
				num2 = ((num2 > value2 * 0.5f - 2f) ? (value2 * 0.5f - 2f) : num2);
				float transformAngle = base.transformAngle;
				Vector2 p = base.transformMatrix.Transform(new Vector2(vector.x + num, vector.y));
				Vector2 p2 = base.transformMatrix.Transform(new Vector2(vector2.x - num, vector2.y));
				Vector2 p3 = base.transformMatrix.Transform(new Vector2(vector2.x, vector2.y + num2));
				Vector2 p4 = base.transformMatrix.Transform(new Vector2(vector3.x, vector3.y - num2));
				Vector2 p5 = base.transformMatrix.Transform(new Vector2(vector3.x - num, vector3.y));
				Vector2 p6 = base.transformMatrix.Transform(new Vector2(vector4.x + num, vector4.y));
				Vector2 p7 = base.transformMatrix.Transform(new Vector2(vector4.x, vector4.y - num2));
				Vector2 p8 = base.transformMatrix.Transform(new Vector2(vector.x, vector.y + num2));
				list = SVGGeomUtils.RoundedRect(p, p2, p3, p4, p5, p6, p7, p8, num, num2, transformAngle);
			}
			list.Add(list[0]);
			return new List<List<Vector2>>
			{
				list
			};
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x0003D2B4 File Offset: 0x0003B4B4
		public List<List<Vector2>> GetClipPath()
		{
			List<List<Vector2>> path = this.GetPath();
			if (path == null || path.Count == 0 || path[0] == null || path[0].Count == 0)
			{
				return null;
			}
			List<List<Vector2>> list = new List<List<Vector2>>();
			if (this.paintable.IsFill())
			{
				list.Add(path[0]);
			}
			if (this.paintable.IsStroke())
			{
				List<List<Vector2>> list2 = SVGLineUtils.StrokeShape(new List<StrokeSegment[]>
				{
					SVGSimplePath.GetSegments(path[0])
				}, this.paintable.strokeWidth, Color.black, SVGSimplePath.GetStrokeLineJoin(this.paintable.strokeLineJoin), SVGSimplePath.GetStrokeLineCap(this.paintable.strokeLineCap), this.paintable.miterLimit, this.paintable.dashArray, this.paintable.dashOffset, ClosePathRule.ALWAYS, SVGGraphics.roundQuality);
				if (list2 != null && list2.Count > 0)
				{
					list.AddRange(list2);
				}
			}
			return list;
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x0003D3A9 File Offset: 0x0003B5A9
		public void Render()
		{
			SVGGraphics.Create(this, "Rectangle Element", ClosePathRule.ALWAYS);
		}

		// Token: 0x04000898 RID: 2200
		private SVGLength _x;

		// Token: 0x04000899 RID: 2201
		private SVGLength _y;

		// Token: 0x0400089A RID: 2202
		private SVGLength _width;

		// Token: 0x0400089B RID: 2203
		private SVGLength _height;

		// Token: 0x0400089C RID: 2204
		private SVGLength _rx;

		// Token: 0x0400089D RID: 2205
		private SVGLength _ry;

		// Token: 0x0400089E RID: 2206
		private AttributeList _attrList;

		// Token: 0x0400089F RID: 2207
		private SVGPaintable _paintable;
	}
}
