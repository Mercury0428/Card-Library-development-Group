﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000CD RID: 205
	[ExecuteInEditMode]
	[AddComponentMenu("Rendering/SVG Sorter", 20)]
	public class SVGSorter : MonoBehaviour
	{
		// Token: 0x060006C6 RID: 1734 RVA: 0x00027DE6 File Offset: 0x00025FE6
		public void Sort()
		{
			this.zOffsetStart = base.transform.position.z;
			this.SortRecursive(base.transform, ref this.zOffsetStart, ref this.layerIndexStart);
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00027E18 File Offset: 0x00026018
		private void SortRecursive(Transform transform, ref float zOffset, ref int layerIndex)
		{
			int childCount = transform.childCount;
			int i = 0;
			while (i < childCount)
			{
				Transform child = transform.GetChild(i);
				SVGRenderer component = child.GetComponent<SVGRenderer>();
				if (!(component != null))
				{
					goto IL_B2;
				}
				if (!component.overrideSorter)
				{
					SVGAsset vectorGraphics = component.vectorGraphics;
					if (vectorGraphics != null)
					{
						Bounds bounds = vectorGraphics.bounds;
						Vector3 position = component.transform.position;
						zOffset += bounds.size.z * Mathf.Sign(this.depthOffset);
						position.z = zOffset;
						component.transform.position = position;
						zOffset += this.depthOffset;
						SVGRenderer svgrenderer = component;
						int num = layerIndex;
						layerIndex = num + 1;
						svgrenderer.sortingOrder = num;
						goto IL_B2;
					}
					goto IL_B2;
				}
				else if (!component.overrideSorterChildren)
				{
					goto IL_B2;
				}
				IL_BB:
				i++;
				continue;
				IL_B2:
				this.SortRecursive(child, ref zOffset, ref layerIndex);
				goto IL_BB;
			}
		}

		// Token: 0x04000723 RID: 1827
		public float depthOffset = 0.01f;

		// Token: 0x04000724 RID: 1828
		public int layerIndex;

		// Token: 0x04000725 RID: 1829
		public bool sort = true;

		// Token: 0x04000726 RID: 1830
		private float zOffsetStart;

		// Token: 0x04000727 RID: 1831
		private int layerIndexStart;
	}
}
