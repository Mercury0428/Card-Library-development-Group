﻿using System;

namespace SVGImporter
{
	// Token: 0x020000B2 RID: 178
	public interface ISVGReference
	{
	}
}
