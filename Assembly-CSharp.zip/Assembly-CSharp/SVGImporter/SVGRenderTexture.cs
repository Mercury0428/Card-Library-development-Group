﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000CC RID: 204
	public class SVGRenderTexture
	{
		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060006BF RID: 1727 RVA: 0x00027B40 File Offset: 0x00025D40
		protected static Camera camera
		{
			get
			{
				if (SVGRenderTexture._camera == null)
				{
					SVGRenderTexture._camera = new GameObject("SVG Camera").AddComponent<Camera>();
					SVGRenderTexture._camera.cullingMask = int.MinValue;
					SVGRenderTexture._camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
					SVGRenderTexture._camera.clearFlags = CameraClearFlags.Color;
					SVGRenderTexture._camera.orthographic = true;
					SVGRenderTexture._camera.enabled = false;
				}
				return SVGRenderTexture._camera;
			}
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x00027BC6 File Offset: 0x00025DC6
		protected static void RemoveCamera()
		{
			if (SVGRenderTexture._camera != null)
			{
				SVGRenderTexture._camera.targetTexture = null;
				Object.Destroy(SVGRenderTexture._camera.gameObject);
				SVGRenderTexture._camera = null;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060006C1 RID: 1729 RVA: 0x00027BF5 File Offset: 0x00025DF5
		protected static SVGRenderer renderer
		{
			get
			{
				if (SVGRenderTexture._renderer == null)
				{
					SVGRenderTexture._renderer = new GameObject("editor SVG Renderer")
					{
						layer = 31
					}.AddComponent<SVGRenderer>();
				}
				return SVGRenderTexture._renderer;
			}
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00027C25 File Offset: 0x00025E25
		protected static void RemoveSVGRenderer()
		{
			if (SVGRenderTexture._renderer != null)
			{
				SVGRenderTexture._renderer.vectorGraphics = null;
				Object.Destroy(SVGRenderTexture._renderer.gameObject);
				SVGRenderTexture._renderer = null;
			}
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00027C54 File Offset: 0x00025E54
		protected static RenderTexture GetRenderTexture(SVGAsset svgAsset, Rect textureSize)
		{
			float num = 1f;
			if (svgAsset != null)
			{
				num = svgAsset.bounds.size.x / svgAsset.bounds.size.y;
			}
			int num2 = Mathf.CeilToInt(textureSize.width);
			RenderTexture renderTexture = new RenderTexture(num2, Mathf.CeilToInt((float)num2 / num), 24, RenderTextureFormat.Default, RenderTextureReadWrite.Default);
			renderTexture.antiAliasing = 8;
			renderTexture.Create();
			return renderTexture;
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00027CC4 File Offset: 0x00025EC4
		public static RenderTexture RenderSVG(SVGAsset svgAsset, Rect textureSize)
		{
			Bounds bounds = svgAsset.bounds;
			SVGRenderTexture.renderer.transform.position = SVGRenderTexture.camera.transform.forward * (SVGRenderTexture.camera.nearClipPlane + svgAsset.bounds.size.z + 1f) - svgAsset.bounds.center;
			SVGRenderTexture.renderer.vectorGraphics = svgAsset;
			if (bounds.size.x > bounds.size.y)
			{
				SVGRenderTexture.camera.orthographicSize = Mathf.Min(bounds.size.x, bounds.size.y) * 0.5f;
			}
			else
			{
				SVGRenderTexture.camera.orthographicSize = Mathf.Max(bounds.size.x, bounds.size.y) * 0.5f;
			}
			RenderTexture renderTexture = SVGRenderTexture.GetRenderTexture(svgAsset, textureSize);
			SVGRenderTexture.camera.targetTexture = renderTexture;
			SVGRenderTexture.camera.Render();
			SVGRenderTexture.camera.targetTexture = null;
			SVGRenderTexture.RemoveSVGRenderer();
			SVGRenderTexture.RemoveCamera();
			return renderTexture;
		}

		// Token: 0x04000720 RID: 1824
		private const int EMPTY_LAYER = 31;

		// Token: 0x04000721 RID: 1825
		protected static Camera _camera;

		// Token: 0x04000722 RID: 1826
		protected static SVGRenderer _renderer;
	}
}
