﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000AE RID: 174
	[ExecuteInEditMode]
	[AddComponentMenu("Miscellaneous/SVG Frame Animator", 20)]
	public class SVGFrameAnimator : MonoBehaviour
	{
		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600056F RID: 1391 RVA: 0x0001FED1 File Offset: 0x0001E0D1
		public SVGRenderer svgRenderer
		{
			get
			{
				if (this._svgRenderer == null)
				{
					this._svgRenderer = base.GetComponent<SVGRenderer>();
				}
				return this._svgRenderer;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x0001FEF3 File Offset: 0x0001E0F3
		public SVGImage svgImage
		{
			get
			{
				if (this._svgImage == null)
				{
					this._svgImage = base.GetComponent<SVGImage>();
				}
				return this._svgImage;
			}
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0001FF15 File Offset: 0x0001E115
		protected virtual void OnEnable()
		{
			this.UpdateMesh();
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0001FF20 File Offset: 0x0001E120
		protected virtual void UpdateMesh()
		{
			if (this.frames == null || this.frames.Length == 0)
			{
				return;
			}
			int num = (int)Mathf.Repeat(this.frameIndex, (float)this.frames.Length);
			if (this.svgRenderer != null && this.svgRenderer.vectorGraphics != this.frames[num])
			{
				this.svgRenderer.vectorGraphics = this.frames[num];
			}
			if (this.svgImage != null && this.svgImage.vectorGraphics != this.frames[num])
			{
				this.svgImage.vectorGraphics = this.frames[num];
			}
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0001FFCB File Offset: 0x0001E1CB
		private void LateUpdate()
		{
			if (this.frameIndex != this.lastFrameIndex)
			{
				this.UpdateMesh();
				this.lastFrameIndex = this.frameIndex;
			}
		}

		// Token: 0x04000619 RID: 1561
		public SVGAsset[] frames;

		// Token: 0x0400061A RID: 1562
		public float frameIndex;

		// Token: 0x0400061B RID: 1563
		private float lastFrameIndex;

		// Token: 0x0400061C RID: 1564
		protected SVGRenderer _svgRenderer;

		// Token: 0x0400061D RID: 1565
		protected SVGImage _svgImage;
	}
}
