﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace SVGImporter
{
	// Token: 0x020000CA RID: 202
	[ExecuteInEditMode]
	[AddComponentMenu("UI/SVG Image", 21)]
	public class SVGImage : MaskableGraphic, ILayoutElement, ICanvasRaycastFilter, ISVGRenderer, ISVGReference
	{
		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00025385 File Offset: 0x00023585
		// (set) Token: 0x06000651 RID: 1617 RVA: 0x0002538D File Offset: 0x0002358D
		public SVGAsset vectorGraphics
		{
			get
			{
				return this._vectorGraphics;
			}
			set
			{
				if (SVGPropertyUtility.SetClass<SVGAsset>(ref this._vectorGraphics, value))
				{
					this.Clear();
					this.UpdateMaterial();
					this.SetAllDirty();
				}
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x000253AF File Offset: 0x000235AF
		// (set) Token: 0x06000653 RID: 1619 RVA: 0x000253B7 File Offset: 0x000235B7
		public SVGImage.Type type
		{
			get
			{
				return this.m_Type;
			}
			set
			{
				if (SVGPropertyUtility.SetStruct<SVGImage.Type>(ref this.m_Type, value))
				{
					this.SetVerticesDirty();
				}
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x000253CD File Offset: 0x000235CD
		// (set) Token: 0x06000655 RID: 1621 RVA: 0x000253D5 File Offset: 0x000235D5
		public bool preserveAspect
		{
			get
			{
				return this.m_PreserveAspect;
			}
			set
			{
				if (SVGPropertyUtility.SetStruct<bool>(ref this.m_PreserveAspect, value))
				{
					this.SetVerticesDirty();
				}
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x000253EB File Offset: 0x000235EB
		// (set) Token: 0x06000657 RID: 1623 RVA: 0x000253F3 File Offset: 0x000235F3
		public bool usePivot
		{
			get
			{
				return this.m_UsePivot;
			}
			set
			{
				if (SVGPropertyUtility.SetStruct<bool>(ref this.m_UsePivot, value))
				{
					this.SetVerticesDirty();
				}
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000658 RID: 1624 RVA: 0x00025409 File Offset: 0x00023609
		// (set) Token: 0x06000659 RID: 1625 RVA: 0x00025411 File Offset: 0x00023611
		public float eventAlphaThreshold
		{
			get
			{
				return this.m_EventAlphaThreshold;
			}
			set
			{
				this.m_EventAlphaThreshold = value;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x0600065A RID: 1626 RVA: 0x0002541A File Offset: 0x0002361A
		public List<ISVGModify> modifiers
		{
			get
			{
				return this._modifiers;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600065B RID: 1627 RVA: 0x00025422 File Offset: 0x00023622
		public int lastFrameChanged
		{
			get
			{
				return this._lastFrameChanged;
			}
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x0002542A File Offset: 0x0002362A
		public void AddModifier(ISVGModify modifier)
		{
			if (this._modifiers.Contains(modifier))
			{
				return;
			}
			this._modifiers.Add(modifier);
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x00025447 File Offset: 0x00023647
		public void RemoveModifier(ISVGModify modifier)
		{
			if (!this._modifiers.Contains(modifier))
			{
				return;
			}
			this._modifiers.Remove(modifier);
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x00025465 File Offset: 0x00023665
		public void UpdateRenderer()
		{
			this.SetAllDirty();
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600065F RID: 1631 RVA: 0x0002546D File Offset: 0x0002366D
		// (set) Token: 0x06000660 RID: 1632 RVA: 0x00025475 File Offset: 0x00023675
		public virtual Action<SVGLayer[], SVGAsset, bool> OnPrepareForRendering
		{
			get
			{
				return this._OnPrepareForRendering;
			}
			set
			{
				this._OnPrepareForRendering = value;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000661 RID: 1633 RVA: 0x0002547E File Offset: 0x0002367E
		private bool useLayers
		{
			get
			{
				return this._vectorGraphics.useLayers;
			}
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x0002548B File Offset: 0x0002368B
		protected override void Awake()
		{
			this.Clear();
			this.UpdateMaterial();
			if (this._vectorGraphics != null)
			{
				this._vectorGraphics.AddReference(this);
			}
			base.Awake();
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x000254B9 File Offset: 0x000236B9
		protected override void OnDestroy()
		{
			if (this._vectorGraphics != null)
			{
				this._vectorGraphics.RemoveReference(this);
			}
			base.OnDestroy();
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000664 RID: 1636 RVA: 0x000254DC File Offset: 0x000236DC
		public bool hasBorder
		{
			get
			{
				return this._vectorGraphics != null && this._vectorGraphics.border.sqrMagnitude > 0f;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000665 RID: 1637 RVA: 0x00025513 File Offset: 0x00023713
		public float pixelsPerUnit
		{
			get
			{
				return 100f;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000666 RID: 1638 RVA: 0x0002551A File Offset: 0x0002371A
		protected Mesh sharedMesh
		{
			get
			{
				if (this._vectorGraphics == null)
				{
					return null;
				}
				return this._vectorGraphics.sharedMesh;
			}
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x00025538 File Offset: 0x00023738
		private Vector4 GetDrawingDimensions(bool shouldPreserveAspect)
		{
			Vector2 vector = (this.sharedMesh == null) ? Vector2.zero : this.sharedMesh.bounds.size;
			Rect pixelAdjustedRect = base.GetPixelAdjustedRect();
			if (shouldPreserveAspect && vector.sqrMagnitude > 0f)
			{
				float num = vector.x / vector.y;
				float num2 = pixelAdjustedRect.width / pixelAdjustedRect.height;
				if (num > num2)
				{
					float height = pixelAdjustedRect.height;
					pixelAdjustedRect.height = pixelAdjustedRect.width * (1f / num);
					pixelAdjustedRect.y += (height - pixelAdjustedRect.height) * base.rectTransform.pivot.y;
				}
				else
				{
					float width = pixelAdjustedRect.width;
					pixelAdjustedRect.width = pixelAdjustedRect.height * num;
					pixelAdjustedRect.x += (width - pixelAdjustedRect.width) * base.rectTransform.pivot.x;
				}
			}
			return new Vector4(pixelAdjustedRect.x, pixelAdjustedRect.y, pixelAdjustedRect.width, pixelAdjustedRect.height);
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x00025664 File Offset: 0x00023864
		public override void SetNativeSize()
		{
			if (this.sharedMesh != null)
			{
				Vector2 vector = this.sharedMesh.bounds.size * 1000f;
				float x = vector.x / this.pixelsPerUnit;
				float y = vector.y / this.pixelsPerUnit;
				base.rectTransform.anchorMax = base.rectTransform.anchorMin;
				base.rectTransform.sizeDelta = new Vector2(x, y);
				this.SetAllDirty();
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000669 RID: 1641 RVA: 0x000256EA File Offset: 0x000238EA
		public override Material defaultMaterial
		{
			get
			{
				this.GetDefaultMaterial();
				return this._defaultMaterial;
			}
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x000256F8 File Offset: 0x000238F8
		protected float InverseLerp(float from, float to, float value)
		{
			if (from < to)
			{
				value -= from;
				value /= to - from;
				return value;
			}
			return 1f - (value - to) / (from - to);
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x00025719 File Offset: 0x00023919
		protected float Lerp(float from, float to, float value)
		{
			return from + value * (to - from);
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x00003D07 File Offset: 0x00001F07
		public virtual void CalculateLayoutInputHorizontal()
		{
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x00003D07 File Offset: 0x00001F07
		public virtual void CalculateLayoutInputVertical()
		{
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600066E RID: 1646 RVA: 0x00025722 File Offset: 0x00023922
		public virtual float minWidth
		{
			get
			{
				return 0f;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600066F RID: 1647 RVA: 0x0002572C File Offset: 0x0002392C
		public virtual float preferredWidth
		{
			get
			{
				if (this.sharedMesh == null)
				{
					return 0f;
				}
				return this.sharedMesh.bounds.size.x / this.pixelsPerUnit;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000670 RID: 1648 RVA: 0x0002576C File Offset: 0x0002396C
		public virtual float flexibleWidth
		{
			get
			{
				return -1f;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000671 RID: 1649 RVA: 0x00025722 File Offset: 0x00023922
		public virtual float minHeight
		{
			get
			{
				return 0f;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000672 RID: 1650 RVA: 0x00025774 File Offset: 0x00023974
		public virtual float preferredHeight
		{
			get
			{
				if (this.sharedMesh == null)
				{
					return 0f;
				}
				return this.sharedMesh.bounds.size.y / this.pixelsPerUnit;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000673 RID: 1651 RVA: 0x0002576C File Offset: 0x0002396C
		public virtual float flexibleHeight
		{
			get
			{
				return -1f;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000674 RID: 1652 RVA: 0x0000821B File Offset: 0x0000641B
		public virtual int layoutPriority
		{
			get
			{
				return 0;
			}
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x000257B4 File Offset: 0x000239B4
		public virtual bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
		{
			if (this.m_EventAlphaThreshold >= 1f)
			{
				return true;
			}
			this.sharedMesh == null;
			return true;
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x000257D4 File Offset: 0x000239D4
		private Vector2 MapCoordinate(Vector2 local, Rect rect)
		{
			Bounds bounds = this.sharedMesh.bounds;
			return new Vector2(local.x * bounds.size.x / rect.width, local.y * bounds.size.y / rect.height);
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x00025828 File Offset: 0x00023A28
		public override void SetMaterialDirty()
		{
			if (this.IsActive())
			{
				SVGAtlas.Instance.UpdateMaterialProperties(this.m_Material);
			}
			base.SetMaterialDirty();
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00025848 File Offset: 0x00023A48
		protected float SafeDivide(float a, float b)
		{
			if (b == 0f)
			{
				return 0f;
			}
			return a / b;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x0002585C File Offset: 0x00023A5C
		protected string BorderToString(Vector4 border)
		{
			return string.Format("left: {0}, bottom: {1}, right: {2}, top: {3}", new object[]
			{
				border.x,
				border.y,
				border.z,
				border.w
			});
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x000258B4 File Offset: 0x00023AB4
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			if (this.sharedMesh == null)
			{
				base.OnPopulateMesh(vh);
				return;
			}
			vh.Clear();
			Mesh sharedMesh = this.sharedMesh;
			this.tempVBOLength = sharedMesh.vertexCount;
			this.vertices = sharedMesh.vertices;
			this.triangles = sharedMesh.triangles;
			this.uv = sharedMesh.uv;
			this.uv2 = sharedMesh.uv2;
			this.colors = sharedMesh.colors32;
			this.normals = sharedMesh.normals;
			if (this.vertexStream == null || this.vertexStream.Length != this.tempVBOLength)
			{
				this.vertexStream = new UIVertex[this.tempVBOLength];
			}
			if (this._vectorGraphics.antialiasing || this._vectorGraphics.generateNormals)
			{
				base.canvas.additionalShaderChannels = (AdditionalCanvasShaderChannels.TexCoord1 | AdditionalCanvasShaderChannels.TexCoord2 | AdditionalCanvasShaderChannels.Normal);
			}
			else
			{
				base.canvas.additionalShaderChannels = (AdditionalCanvasShaderChannels.TexCoord1 | AdditionalCanvasShaderChannels.TexCoord2);
			}
			Bounds bounds = this.sharedMesh.bounds;
			if (this.m_UsePivot)
			{
				bounds.center += new Vector3((-0.5f + this._vectorGraphics.pivotPoint.x) * bounds.size.x, (0.5f - this._vectorGraphics.pivotPoint.y) * bounds.size.y, 0f);
			}
			if (this.m_Type == SVGImage.Type.Simple)
			{
				Vector4 drawingDimensions = this.GetDrawingDimensions(this.preserveAspect);
				for (int i = 0; i < this.tempVBOLength; i++)
				{
					this.vertexStream[i].position.x = drawingDimensions.x + this.InverseLerp(bounds.min.x, bounds.max.x, this.vertices[i].x) * drawingDimensions.z;
					this.vertexStream[i].position.y = drawingDimensions.y + this.InverseLerp(bounds.min.y, bounds.max.y, this.vertices[i].y) * drawingDimensions.w;
					this.vertexStream[i].color = this.colors[i] * this.color;
				}
			}
			else
			{
				Vector4 drawingDimensions2 = this.GetDrawingDimensions(false);
				Vector4 border = this._vectorGraphics.border;
				Vector4 vector = new Vector4(border.x + 1E-07f, border.y + 1E-07f, 1f - border.z - 1E-07f, 1f - border.w - 1E-07f);
				float num = base.canvas.referencePixelsPerUnit * this.vectorGraphics.scale * 100f;
				Vector2 vector2 = new Vector2(bounds.size.x * num, bounds.size.y * num);
				Vector4 vector3 = new Vector4(drawingDimensions2.x, drawingDimensions2.y, drawingDimensions2.x + drawingDimensions2.z, drawingDimensions2.y + drawingDimensions2.w);
				Vector4 vector4 = new Vector4(vector2.x * border.x, vector2.y * border.y, vector2.x * border.z, vector2.y * border.w);
				Vector2 vector5 = new Vector2(this.SafeDivide(1f, 1f - (border.x + border.z)) * (drawingDimensions2.z - (vector4.x + vector4.z)), this.SafeDivide(1f, 1f - (border.y + border.w)) * (drawingDimensions2.w - (vector4.w + vector4.y)));
				float num2 = vector4.x + vector4.z;
				if (num2 != 0f)
				{
					num2 = Mathf.Clamp01(drawingDimensions2.z / num2);
					if (num2 != 1f)
					{
						vector5.x = 0f;
						vector2.x *= num2;
						vector4.x *= num2;
						vector4.z *= num2;
					}
				}
				float num3 = vector4.w + vector4.y;
				if (num3 != 0f)
				{
					num3 = Mathf.Clamp01(drawingDimensions2.w / num3);
					if (num3 != 1f)
					{
						vector5.y = 0f;
						vector2.y *= num3;
						vector4.w *= num3;
						vector4.y *= num3;
					}
				}
				float num4 = vector3.w - vector4.w;
				float num5 = vector3.x + vector4.x;
				for (int j = 0; j < this.tempVBOLength; j++)
				{
					this.vertexStream[j].color = this.colors[j] * this.color;
					Vector2 vector6;
					vector6.x = this.InverseLerp(bounds.min.x, bounds.max.x, this.vertices[j].x);
					vector6.y = this.InverseLerp(bounds.min.y, bounds.max.y, this.vertices[j].y);
					if (border.x != 0f && vector6.x <= vector.x)
					{
						this.vertexStream[j].position.x = vector3.x + vector6.x * vector2.x;
					}
					else if (border.z != 0f && vector6.x >= vector.z)
					{
						this.vertexStream[j].position.x = vector3.z - (1f - vector6.x) * vector2.x;
					}
					else
					{
						this.vertexStream[j].position.x = num5 + (vector6.x - border.x) * vector5.x;
					}
					if (border.w != 0f && vector6.y >= vector.w)
					{
						this.vertexStream[j].position.y = vector3.w - (1f - vector6.y) * vector2.y;
					}
					else if (border.y != 0f && vector6.y <= vector.y)
					{
						this.vertexStream[j].position.y = vector3.y + vector6.y * vector2.y;
					}
					else
					{
						this.vertexStream[j].position.y = num4 - (1f - vector6.y - border.w) * vector5.y;
					}
				}
			}
			if ((this._vectorGraphics.hasGradients || this._vectorGraphics.useGradients == SVGUseGradients.Always) && this.uv != null && this.uv2 != null && this.tempVBOLength == this.uv.Length && this.tempVBOLength == this.uv2.Length)
			{
				for (int k = 0; k < this.tempVBOLength; k++)
				{
					this.vertexStream[k].uv0 = this.uv[k];
					this.vertexStream[k].uv1 = this.uv2[k];
				}
			}
			if (this._vectorGraphics.antialiasing)
			{
				if (this._vectorGraphics.antialiasing && this.normals != null && this.tempVBOLength == this.normals.Length)
				{
					for (int l = 0; l < this.tempVBOLength; l++)
					{
						this.vertexStream[l].normal.x = this.normals[l].x;
						this.vertexStream[l].normal.y = this.normals[l].y;
					}
				}
			}
			else if (this._vectorGraphics.generateNormals && this.normals != null && this.normals.Length == this.tempVBOLength)
			{
				for (int m = 0; m < this.tempVBOLength; m++)
				{
					this.vertexStream[m].normal = this.normals[m];
				}
			}
			vh.AddUIVertexStream(new List<UIVertex>(this.vertexStream), new List<int>(this.triangles));
			this._lastFrameChanged = Time.frameCount;
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x000261CC File Offset: 0x000243CC
		protected void GetDefaultMaterial()
		{
			if (this._lastVectorGraphics != this._vectorGraphics)
			{
				if (this._lastVectorGraphics != null)
				{
					this._lastVectorGraphics.RemoveReference(this);
				}
				if (this._vectorGraphics != null)
				{
					this._vectorGraphics.AddReference(this);
				}
				this._lastVectorGraphics = this._vectorGraphics;
				this.Clear();
			}
			if (this._vectorGraphics != null && this._defaultMaterial == null)
			{
				this._defaultMaterial = this._vectorGraphics.sharedUIMaterial;
			}
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x0002625F File Offset: 0x0002445F
		protected void Clear()
		{
			this._defaultMaterial = null;
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x00026268 File Offset: 0x00024468
		protected override void UpdateMaterial()
		{
			this.GetDefaultMaterial();
			base.UpdateMaterial();
		}

		// Token: 0x040006E7 RID: 1767
		[FormerlySerializedAs("vectorGraphics")]
		[SerializeField]
		protected SVGAsset _vectorGraphics;

		// Token: 0x040006E8 RID: 1768
		protected SVGAsset _lastVectorGraphics;

		// Token: 0x040006E9 RID: 1769
		[SerializeField]
		private SVGImage.Type m_Type;

		// Token: 0x040006EA RID: 1770
		[SerializeField]
		private bool m_PreserveAspect;

		// Token: 0x040006EB RID: 1771
		[SerializeField]
		private bool m_UsePivot;

		// Token: 0x040006EC RID: 1772
		private float m_EventAlphaThreshold = 1f;

		// Token: 0x040006ED RID: 1773
		protected Material _defaultMaterial;

		// Token: 0x040006EE RID: 1774
		protected List<ISVGModify> _modifiers = new List<ISVGModify>();

		// Token: 0x040006EF RID: 1775
		protected int _lastFrameChanged;

		// Token: 0x040006F0 RID: 1776
		protected Action<SVGLayer[], SVGAsset, bool> _OnPrepareForRendering;

		// Token: 0x040006F1 RID: 1777
		private const float epsilon = 1E-07f;

		// Token: 0x040006F2 RID: 1778
		private int tempVBOLength;

		// Token: 0x040006F3 RID: 1779
		private UIVertex[] vertexStream;

		// Token: 0x040006F4 RID: 1780
		private Vector3[] vertices;

		// Token: 0x040006F5 RID: 1781
		private int[] triangles;

		// Token: 0x040006F6 RID: 1782
		private Vector2[] uv;

		// Token: 0x040006F7 RID: 1783
		private Vector2[] uv2;

		// Token: 0x040006F8 RID: 1784
		private Vector2[] uv3;

		// Token: 0x040006F9 RID: 1785
		private Color32[] colors;

		// Token: 0x040006FA RID: 1786
		private Vector3[] normals;

		// Token: 0x02000341 RID: 833
		public enum Type
		{
			// Token: 0x04001205 RID: 4613
			Simple,
			// Token: 0x04001206 RID: 4614
			Sliced
		}
	}
}
