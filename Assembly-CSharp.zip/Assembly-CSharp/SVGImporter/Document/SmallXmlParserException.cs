﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E7 RID: 231
	internal sealed class SmallXmlParserException : Exception
	{
		// Token: 0x06000782 RID: 1922 RVA: 0x0002DFCB File Offset: 0x0002C1CB
		public SmallXmlParserException(string msg, int line, int column) : base(string.Format("{0}. At ({1},{2})", msg, line, column))
		{
			this.line = line;
			this.column = column;
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000783 RID: 1923 RVA: 0x0002DFF8 File Offset: 0x0002C1F8
		public int Line
		{
			get
			{
				return this.line;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000784 RID: 1924 RVA: 0x0002E000 File Offset: 0x0002C200
		public int Column
		{
			get
			{
				return this.column;
			}
		}

		// Token: 0x0400079B RID: 1947
		private int line;

		// Token: 0x0400079C RID: 1948
		private int column;
	}
}
