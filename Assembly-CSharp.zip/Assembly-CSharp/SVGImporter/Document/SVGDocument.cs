﻿using System;
using SVGImporter.Rendering;

namespace SVGImporter.Document
{
	// Token: 0x020000DF RID: 223
	public class SVGDocument
	{
		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600074D RID: 1869 RVA: 0x0002D0FA File Offset: 0x0002B2FA
		public SVGElement rootElement
		{
			get
			{
				return this._rootElement;
			}
		}

		// Token: 0x0600074E RID: 1870 RVA: 0x0002D104 File Offset: 0x0002B304
		public SVGDocument(string originalDocument, SVGGraphics r)
		{
			this.parser = new SVGParser(originalDocument);
			while (!this.parser.isEOF && this.parser.node.name != SVGNodeName.SVG)
			{
				this.parser.Next();
			}
			this._rootElement = new SVGElement(this.parser, new SVGTransformList(), null, true);
		}

		// Token: 0x0600074F RID: 1871 RVA: 0x0002D169 File Offset: 0x0002B369
		public void Clear()
		{
			this._rootElement = null;
			this.parser = null;
		}

		// Token: 0x04000771 RID: 1905
		private SVGElement _rootElement;

		// Token: 0x04000772 RID: 1906
		private SVGParser parser;
	}
}
