﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SVGImporter.Document
{
	// Token: 0x020000E5 RID: 229
	public struct AttributeList
	{
		// Token: 0x06000764 RID: 1892 RVA: 0x0002D41A File Offset: 0x0002B61A
		public AttributeList(AttributeList a)
		{
			if (a.attrs != null)
			{
				this.attrs = new Dictionary<string, string>(a.attrs);
				return;
			}
			this.attrs = null;
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x0002D43D File Offset: 0x0002B63D
		public void Clear()
		{
			if (this.attrs != null)
			{
				this.attrs.Clear();
			}
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x0002D452 File Offset: 0x0002B652
		public void Add(string name, string value)
		{
			if (this.attrs == null)
			{
				this.attrs = new Dictionary<string, string>();
			}
			this.attrs[name] = value;
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x0002D474 File Offset: 0x0002B674
		public string GetValue(string name)
		{
			string result;
			if (this.attrs != null && this.attrs.TryGetValue(name, out result))
			{
				return result;
			}
			return "";
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x0002D4A0 File Offset: 0x0002B6A0
		public new string ToString()
		{
			if (this.attrs == null)
			{
				return "null";
			}
			bool flag = true;
			StringBuilder stringBuilder = new StringBuilder();
			foreach (KeyValuePair<string, string> keyValuePair in this.attrs)
			{
				if (!flag)
				{
					stringBuilder.Append(", ");
				}
				stringBuilder.Append(keyValuePair.Key).Append("=").Append(keyValuePair.Value);
				flag = false;
			}
			return stringBuilder.ToString();
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000769 RID: 1897 RVA: 0x0002D540 File Offset: 0x0002B740
		public int Count
		{
			get
			{
				return this.attrs.Count;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600076A RID: 1898 RVA: 0x0002D54D File Offset: 0x0002B74D
		public Dictionary<string, string> Get
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x170000BE RID: 190
		// (set) Token: 0x0600076B RID: 1899 RVA: 0x0002D555 File Offset: 0x0002B755
		public Dictionary<string, string> Set
		{
			set
			{
				this.attrs = value;
			}
		}

		// Token: 0x04000791 RID: 1937
		private Dictionary<string, string> attrs;
	}
}
