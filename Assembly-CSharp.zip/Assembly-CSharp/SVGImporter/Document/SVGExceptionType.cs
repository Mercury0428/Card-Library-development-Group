﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E3 RID: 227
	public enum SVGExceptionType
	{
		// Token: 0x0400078D RID: 1933
		WrongType,
		// Token: 0x0400078E RID: 1934
		InvalidValue,
		// Token: 0x0400078F RID: 1935
		MatrixNotInvertable
	}
}
