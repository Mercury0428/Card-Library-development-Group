﻿using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using SVGImporter.Utils;

namespace SVGImporter.Document
{
	// Token: 0x020000E6 RID: 230
	public class SmallXmlParser
	{
		// Token: 0x0600076C RID: 1900 RVA: 0x0002D55E File Offset: 0x0002B75E
		private Exception Error(string msg)
		{
			return new SmallXmlParserException(msg, this.line, this.column);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x0002D574 File Offset: 0x0002B774
		private Exception UnexpectedEndError()
		{
			string[] array = new string[this.elementNames.Count];
			(this.elementNames as ICollection).CopyTo(array, 0);
			return this.Error(string.Format("Unexpected end of stream. Element stack content is {0}", string.Join(",", array)));
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x0002D5C0 File Offset: 0x0002B7C0
		private bool IsNameChar(char c, bool start)
		{
			if (c <= '.')
			{
				if (c == '-' || c == '.')
				{
					return !start;
				}
			}
			else if (c == ':' || c == '_')
			{
				return true;
			}
			if (c > 'Ā')
			{
				if (c == 'ՙ' || c == 'ۥ' || c == 'ۦ')
				{
					return true;
				}
				if ('ʻ' <= c && c <= 'ˁ')
				{
					return true;
				}
			}
			switch (char.GetUnicodeCategory(c))
			{
			case UnicodeCategory.UppercaseLetter:
			case UnicodeCategory.LowercaseLetter:
			case UnicodeCategory.TitlecaseLetter:
			case UnicodeCategory.OtherLetter:
			case UnicodeCategory.LetterNumber:
				return true;
			case UnicodeCategory.ModifierLetter:
			case UnicodeCategory.NonSpacingMark:
			case UnicodeCategory.SpacingCombiningMark:
			case UnicodeCategory.EnclosingMark:
			case UnicodeCategory.DecimalDigitNumber:
				return !start;
			default:
				return false;
			}
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x0002D662 File Offset: 0x0002B862
		private bool IsWhitespace(int c)
		{
			return c - 9 <= 1 || c == 13 || c == 32;
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x0002D678 File Offset: 0x0002B878
		public void SkipWhitespaces()
		{
			this.SkipWhitespaces(false);
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x0002D681 File Offset: 0x0002B881
		private void HandleWhitespaces()
		{
			while (this.IsWhitespace(this.Peek()))
			{
				this.buffer.Append((char)this.Read());
			}
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x0002D6A8 File Offset: 0x0002B8A8
		public void SkipWhitespaces(bool expected)
		{
			for (;;)
			{
				int num = this.Peek();
				if (num - 9 > 1 && num != 13 && num != 32)
				{
					break;
				}
				this.Read();
				if (expected)
				{
					expected = false;
				}
			}
			if (expected)
			{
				throw this.Error("Whitespace is expected.");
			}
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x0002D6EB File Offset: 0x0002B8EB
		private int Peek()
		{
			return this.reader.Peek();
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0002D6F8 File Offset: 0x0002B8F8
		private int Read()
		{
			int num = this.reader.Read();
			if (num == 10)
			{
				this.resetColumn = true;
			}
			if (this.resetColumn)
			{
				this.line++;
				this.resetColumn = false;
				this.column = 1;
				return num;
			}
			this.column++;
			return num;
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x0002D750 File Offset: 0x0002B950
		public void Expect(int c)
		{
			int num = this.Read();
			if (num < 0)
			{
				throw this.UnexpectedEndError();
			}
			if (num != c)
			{
				throw this.Error(string.Format("Expected '{0}' but got {1}", (char)c, (char)num));
			}
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0002D794 File Offset: 0x0002B994
		private string ReadUntil(char until, bool handleReferences)
		{
			while (this.Peek() >= 0)
			{
				char c = (char)this.Read();
				if (c == until)
				{
					string result = this.buffer.ToString();
					this.buffer.Length = 0;
					return result;
				}
				if (handleReferences && c == '&')
				{
					this.ReadReference();
				}
				else
				{
					this.buffer.Append(c);
				}
			}
			throw this.UnexpectedEndError();
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x0002D7F4 File Offset: 0x0002B9F4
		public string ReadName()
		{
			int num = 0;
			if (this.Peek() < 0 || !this.IsNameChar((char)this.Peek(), true))
			{
				throw this.Error("XML name start character is expected.");
			}
			for (int i = this.Peek(); i >= 0; i = this.Peek())
			{
				char c = (char)i;
				if (!this.IsNameChar(c, false))
				{
					break;
				}
				if (num == this.nameBuffer.Length)
				{
					char[] destinationArray = new char[num * 2];
					Array.Copy(this.nameBuffer, 0, destinationArray, 0, num);
					this.nameBuffer = destinationArray;
				}
				this.nameBuffer[num++] = c;
				this.Read();
			}
			if (num == 0)
			{
				throw this.Error("Valid XML name is expected.");
			}
			return new string(this.nameBuffer, 0, num);
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x0002D8A4 File Offset: 0x0002BAA4
		public void Parse(TextReader input, SmallXmlParser.IContentHandler handler)
		{
			this.reader = input;
			this.handler = handler;
			handler.OnStartParsing(this);
			while (this.Peek() >= 0)
			{
				this.ReadContent();
			}
			this.buffer.Length = 0;
			if (this.elementNames.Count > 0)
			{
				throw this.Error(string.Format("Insufficient close tag: {0}", this.elementNames.Peek()));
			}
			this.Cleanup();
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x0002D913 File Offset: 0x0002BB13
		private void Cleanup()
		{
			this.line = 1;
			this.column = 0;
			this.handler = null;
			this.reader = null;
			this.elementNames.Clear();
			this.attributes.Clear();
			this.buffer.Length = 0;
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x0002D954 File Offset: 0x0002BB54
		public void ReadContent()
		{
			if (this.IsWhitespace(this.Peek()))
			{
				this.HandleWhitespaces();
			}
			if (this.Peek() != 60)
			{
				this.ReadCharacters();
				return;
			}
			this.Read();
			int num = this.Peek();
			if (num != 33)
			{
				if (num != 47)
				{
					string text;
					if (num == 63)
					{
						this.buffer.Length = 0;
						this.Read();
						text = this.ReadName();
						this.SkipWhitespaces();
						string str = string.Empty;
						if (this.Peek() != 63)
						{
							for (;;)
							{
								str += this.ReadUntil('?', false);
								if (this.Peek() == 62)
								{
									break;
								}
								str += "?";
							}
						}
						this.Expect(62);
						return;
					}
					this.buffer.Length = 0;
					text = this.ReadName();
					string a = text.ToLower();
					if (!(a == "style"))
					{
						while (this.Peek() != 62 && this.Peek() != 47)
						{
							this.ReadAttribute(ref this.attributes);
						}
						this.SkipWhitespaces();
						if (this.Peek() == 47)
						{
							this.handler.OnInlineElement(text, this.attributes);
							this.Read();
						}
						else
						{
							this.handler.OnStartElement(text, this.attributes);
							this.elementNames.Push(text);
						}
						this.attributes.Clear();
						this.Expect(62);
						return;
					}
					while (this.Peek() != 62 && this.Peek() != 47)
					{
						this.ReadAttribute(ref this.attributes);
					}
					this.SkipWhitespaces();
					if (this.Peek() == 47)
					{
						this.Read();
					}
					this.ReadUntil('>', false);
					string text2 = this.ReadUntil('<', false);
					text2 = CSSParser.CleanCSS(text2);
					if (string.IsNullOrEmpty(text2))
					{
						text2 = this.ReadUntil('<', false);
					}
					if (!string.IsNullOrEmpty(text2))
					{
						text2 = text2.Replace("![CDATA[", "");
						text2 = text2.Replace("]]>", "");
						text2 = CSSParser.CleanCSS(text2);
					}
					this.handler.OnStyleElement(text, this.attributes, text2);
					this.attributes.Clear();
					this.ReadUntil('>', false);
					return;
				}
				else
				{
					this.buffer.Length = 0;
					if (this.elementNames.Count == 0)
					{
						throw this.UnexpectedEndError();
					}
					this.Read();
					string text = this.ReadName();
					this.SkipWhitespaces();
					string text3 = (string)this.elementNames.Pop();
					if (text != text3)
					{
						throw this.Error(string.Format("End tag mismatch: expected {0} but found {1}", text3, text));
					}
					this.handler.OnEndElement(text);
					this.Expect(62);
					return;
				}
			}
			else
			{
				this.Read();
				if (this.Peek() == 91)
				{
					this.Read();
					if (this.ReadName() != "CDATA")
					{
						throw this.Error("Invalid declaration markup");
					}
					this.Expect(91);
					this.ReadCDATASection();
					return;
				}
				else
				{
					if (this.Peek() == 45)
					{
						this.ReadComment();
						return;
					}
					if (this.ReadName() != "DOCTYPE")
					{
						throw this.Error("Invalid declaration markup.");
					}
					this.ReadUntil('>', false);
					return;
				}
			}
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x0002DC7C File Offset: 0x0002BE7C
		private void ReadCharacters()
		{
			for (;;)
			{
				int num = this.Peek();
				if (num == -1)
				{
					break;
				}
				if (num != 38)
				{
					if (num == 60)
					{
						return;
					}
					this.buffer.Append((char)this.Read());
				}
				else
				{
					this.Read();
					this.ReadReference();
				}
			}
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x0002DCC8 File Offset: 0x0002BEC8
		private void ReadReference()
		{
			if (this.Peek() == 35)
			{
				this.Read();
				this.ReadCharacterReference();
				return;
			}
			string a = this.ReadName();
			this.Expect(59);
			if (a == "amp")
			{
				this.buffer.Append('&');
				return;
			}
			if (a == "quot")
			{
				this.buffer.Append('"');
				return;
			}
			if (a == "apos")
			{
				this.buffer.Append('\'');
				return;
			}
			if (a == "lt")
			{
				this.buffer.Append('<');
				return;
			}
			if (!(a == "gt"))
			{
				throw this.Error("General non-predefined entity reference is not supported in this parser.");
			}
			this.buffer.Append('>');
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x0002DD98 File Offset: 0x0002BF98
		private int ReadCharacterReference()
		{
			int num = 0;
			if (this.Peek() == 120)
			{
				this.Read();
				for (int i = this.Peek(); i >= 0; i = this.Peek())
				{
					if (48 <= i && i <= 57)
					{
						num <<= 4 + i - 48;
					}
					else if (65 <= i && i <= 70)
					{
						num <<= 4 + i - 65 + 10;
					}
					else
					{
						if (97 > i || i > 102)
						{
							break;
						}
						num <<= 4 + i - 97 + 10;
					}
					this.Read();
				}
			}
			else
			{
				int num2 = this.Peek();
				while (num2 >= 0 && 48 <= num2 && num2 <= 57)
				{
					num <<= 4 + num2 - 48;
					this.Read();
					num2 = this.Peek();
				}
			}
			return num;
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x0002DE54 File Offset: 0x0002C054
		private void ReadAttribute(ref AttributeList a)
		{
			this.SkipWhitespaces(true);
			if (this.Peek() == 47 || this.Peek() == 62)
			{
				return;
			}
			string name = this.ReadName();
			this.SkipWhitespaces();
			this.Expect(61);
			this.SkipWhitespaces();
			int num = this.Read();
			string value;
			if (num != 34)
			{
				if (num != 39)
				{
					throw this.Error("Invalid attribute value markup.");
				}
				value = this.ReadUntil('\'', true);
			}
			else
			{
				value = this.ReadUntil('"', true);
			}
			a.Add(name, value);
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x0002DED8 File Offset: 0x0002C0D8
		private void ReadCDATASection()
		{
			int num = 0;
			while (this.Peek() >= 0)
			{
				char c = (char)this.Read();
				if (c == ']')
				{
					num++;
				}
				else
				{
					if (c == '>' && num > 1)
					{
						for (int i = num; i > 2; i--)
						{
							this.buffer.Append(']');
						}
						return;
					}
					for (int j = 0; j < num; j++)
					{
						this.buffer.Append(']');
					}
					num = 0;
					this.buffer.Append(c);
				}
			}
			throw this.UnexpectedEndError();
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x0002DF58 File Offset: 0x0002C158
		private void ReadComment()
		{
			this.Expect(45);
			this.Expect(45);
			while (this.Read() != 45 || this.Read() != 45)
			{
			}
			if (this.Read() != 62)
			{
				throw this.Error("'--' is not allowed inside comment markup.");
			}
		}

		// Token: 0x04000792 RID: 1938
		private SmallXmlParser.IContentHandler handler;

		// Token: 0x04000793 RID: 1939
		private TextReader reader;

		// Token: 0x04000794 RID: 1940
		private LiteStack elementNames = new LiteStack();

		// Token: 0x04000795 RID: 1941
		private StringBuilder buffer = new StringBuilder(200);

		// Token: 0x04000796 RID: 1942
		private char[] nameBuffer = new char[30];

		// Token: 0x04000797 RID: 1943
		private AttributeList attributes;

		// Token: 0x04000798 RID: 1944
		private int line = 1;

		// Token: 0x04000799 RID: 1945
		private int column;

		// Token: 0x0400079A RID: 1946
		private bool resetColumn;

		// Token: 0x0200034E RID: 846
		public interface IContentHandler
		{
			// Token: 0x06001694 RID: 5780
			void OnStartParsing(SmallXmlParser parser);

			// Token: 0x06001695 RID: 5781
			void OnStartElement(string name, AttributeList attrs);

			// Token: 0x06001696 RID: 5782
			void OnEndElement(string name);

			// Token: 0x06001697 RID: 5783
			void OnInlineElement(string name, AttributeList attrs);

			// Token: 0x06001698 RID: 5784
			void OnStyleElement(string name, AttributeList attrs, string style);
		}
	}
}
