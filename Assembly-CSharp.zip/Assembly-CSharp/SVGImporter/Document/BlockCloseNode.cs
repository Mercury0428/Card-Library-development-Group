﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000EC RID: 236
	public class BlockCloseNode : Node
	{
		// Token: 0x0600078A RID: 1930 RVA: 0x0002E0C1 File Offset: 0x0002C2C1
		public BlockCloseNode(SVGNodeName name, AttributeList attributes, int depth) : base(name, attributes, depth)
		{
		}
	}
}
