﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E1 RID: 225
	public enum DOMExceptionType
	{
		// Token: 0x0400077C RID: 1916
		IndexSizeErr,
		// Token: 0x0400077D RID: 1917
		DomstringSizeErr,
		// Token: 0x0400077E RID: 1918
		HierarchyRequestErr,
		// Token: 0x0400077F RID: 1919
		WrongDocumentErr,
		// Token: 0x04000780 RID: 1920
		InvalidCharacterErr,
		// Token: 0x04000781 RID: 1921
		NoDataAllowedErr,
		// Token: 0x04000782 RID: 1922
		NoModificationAllowedErr,
		// Token: 0x04000783 RID: 1923
		NotFoundErr,
		// Token: 0x04000784 RID: 1924
		NotSupportedErr,
		// Token: 0x04000785 RID: 1925
		InuseAttributeErr,
		// Token: 0x04000786 RID: 1926
		InvalidStateErr,
		// Token: 0x04000787 RID: 1927
		SyntaxErr,
		// Token: 0x04000788 RID: 1928
		InvalidModificationErr,
		// Token: 0x04000789 RID: 1929
		NamespaceErr,
		// Token: 0x0400078A RID: 1930
		InvalidAccessErr
	}
}
