﻿using System;
using System.Collections.Generic;
using System.IO;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter.Document
{
	// Token: 0x020000ED RID: 237
	public class SVGParser : SmallXmlParser.IContentHandler
	{
		// Token: 0x0600078B RID: 1931 RVA: 0x0002E0CC File Offset: 0x0002C2CC
		public SVGParser()
		{
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x0002E0EA File Offset: 0x0002C2EA
		public static void Clear()
		{
			if (SVGParser._defs != null)
			{
				SVGParser._defs.Clear();
				SVGParser._defs = null;
			}
			if (SVGAssetImport.errors != null)
			{
				SVGAssetImport.errors.Clear();
				SVGAssetImport.errors = null;
			}
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x0002E11A File Offset: 0x0002C31A
		public static void Init()
		{
			if (SVGAssetImport.errors == null)
			{
				SVGAssetImport.errors = new List<SVGError>();
			}
			else
			{
				SVGAssetImport.errors.Clear();
			}
			if (SVGParser._defs == null)
			{
				SVGParser._defs = new Dictionary<string, Node>();
				return;
			}
			SVGParser._defs.Clear();
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x0002E155 File Offset: 0x0002C355
		public SVGParser(string text)
		{
			this._parser.Parse(new StringReader(text), this);
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x0002E185 File Offset: 0x0002C385
		public void AddNode(Node node)
		{
			this.nodes.Add(node);
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000790 RID: 1936 RVA: 0x0002E193 File Offset: 0x0002C393
		public Node node
		{
			get
			{
				return this.nodes[this.idx];
			}
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x0002E1A6 File Offset: 0x0002C3A6
		public bool Next()
		{
			this.idx++;
			return !this.isEOF;
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x0002E1BF File Offset: 0x0002C3BF
		public bool isEOF
		{
			get
			{
				return this.idx >= this.nodes.Count;
			}
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x0002E1D7 File Offset: 0x0002C3D7
		public void OnStartParsing(SmallXmlParser parser)
		{
			this.idx = 0;
			this._currentDepth = 0;
			this._lastParent = null;
			if (SVGParser.dontPutInNodes == null)
			{
				SVGParser.dontPutInNodes = new List<SVGNodeName>();
				return;
			}
			SVGParser.dontPutInNodes.Clear();
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x0002E20A File Offset: 0x0002C40A
		private void DontPutInNodesAdd(Node node)
		{
			if (node is InlineNode)
			{
				return;
			}
			SVGParser.dontPutInNodes.Add(node.name);
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x0002E225 File Offset: 0x0002C425
		private void DontPutInNodesRemove(Node node)
		{
			if (node is InlineNode)
			{
				return;
			}
			SVGParser.dontPutInNodes.RemoveAt(SVGParser.dontPutInNodes.Count - 1);
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x0002E248 File Offset: 0x0002C448
		public void OnNode(Node node)
		{
			string value = node.attributes.GetValue("id");
			if (!string.IsNullOrEmpty(value))
			{
				if (SVGParser._defs.ContainsKey(value))
				{
					SVGParser._defs[value] = node;
					Debug.LogWarning(string.Concat(new object[]
					{
						"Element: ",
						node.name,
						", ID: ",
						value,
						" already exists! Overwriting with new element!"
					}));
				}
				else
				{
					SVGParser._defs.Add(value, node);
				}
			}
			switch (node.name)
			{
			case SVGNodeName.LinearGradient:
			case SVGNodeName.RadialGradient:
			case SVGNodeName.ConicalGradient:
			case SVGNodeName.Stop:
				this.AddNode(node);
				return;
			case SVGNodeName.Defs:
				this.DontPutInNodesAdd(node);
				return;
			case SVGNodeName.Symbol:
				this.DontPutInNodesAdd(node);
				return;
			case SVGNodeName.ClipPath:
				this.DontPutInNodesAdd(node);
				return;
			case SVGNodeName.Mask:
				this.DontPutInNodesAdd(node);
				return;
			case SVGNodeName.Image:
				this.DontPutInNodesAdd(node);
				return;
			}
			if (SVGParser.dontPutInNodes.Count == 0)
			{
				this.AddNode(node);
			}
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x0002E350 File Offset: 0x0002C550
		public void OnInlineElement(string name, AttributeList attrs)
		{
			Node node = new InlineNode(SVGParser.Lookup(name), new AttributeList(attrs), this._currentDepth);
			node.parent = this._lastParent;
			if (this._lastParent != null)
			{
				this._lastParent.children.Add(node);
			}
			this.OnNode(node);
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x0002E3A4 File Offset: 0x0002C5A4
		public void OnStartElement(string name, AttributeList attrs)
		{
			SVGNodeName name2 = SVGParser.Lookup(name);
			AttributeList attributes = new AttributeList(attrs);
			int currentDepth = this._currentDepth;
			this._currentDepth = currentDepth + 1;
			Node node = new BlockOpenNode(name2, attributes, currentDepth);
			node.parent = this._lastParent;
			if (this._lastParent != null)
			{
				this._lastParent.children.Add(node);
			}
			this._lastParent = node;
			this.OnNode(node);
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x0002E408 File Offset: 0x0002C608
		public void OnEndElement(string name)
		{
			SVGNodeName name2 = SVGParser.Lookup(name);
			AttributeList attributes = default(AttributeList);
			int num = this._currentDepth - 1;
			this._currentDepth = num;
			Node node = new BlockCloseNode(name2, attributes, num);
			if (this._lastParent != null)
			{
				this._lastParent = this._lastParent.parent;
			}
			else
			{
				this._lastParent = null;
			}
			node.parent = this._lastParent;
			switch (node.name)
			{
			case SVGNodeName.LinearGradient:
			case SVGNodeName.RadialGradient:
			case SVGNodeName.ConicalGradient:
				this.AddNode(node);
				return;
			case SVGNodeName.Defs:
				this.DontPutInNodesRemove(node);
				return;
			case SVGNodeName.Symbol:
				this.DontPutInNodesRemove(node);
				return;
			case SVGNodeName.ClipPath:
				this.DontPutInNodesRemove(node);
				return;
			case SVGNodeName.Mask:
				this.DontPutInNodesRemove(node);
				return;
			case SVGNodeName.Image:
				this.DontPutInNodesRemove(node);
				return;
			}
			if (SVGParser.dontPutInNodes.Count == 0)
			{
				this.AddNode(node);
			}
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x0002E4EC File Offset: 0x0002C6EC
		public bool IsInlineElement(Node node)
		{
			SVGNodeName name = node.name;
			return name <= SVGNodeName.Path || name == SVGNodeName.Stop;
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x0002E50C File Offset: 0x0002C70C
		public void OnStyleElement(string name, AttributeList attrs, string style)
		{
			Node node = new InlineNode(SVGParser.Lookup(name), new AttributeList(attrs), this._currentDepth);
			node.content = style;
			node.parent = this._lastParent;
			if (this._lastParent != null)
			{
				this._lastParent.children.Add(node);
			}
			this.AddNode(node);
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x0002E564 File Offset: 0x0002C764
		public void GetElementList(List<object> elementList, SVGPaintable paintable, SVGTransformList summaryTransformList)
		{
			bool flag = false;
			while (!flag && this.Next())
			{
				if (this.node is BlockCloseNode)
				{
					flag = true;
				}
				else
				{
					switch (this.node.name)
					{
					case SVGNodeName.Rect:
						elementList.Add(new SVGRectElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.Line:
						elementList.Add(new SVGLineElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.Circle:
						elementList.Add(new SVGCircleElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.Ellipse:
						elementList.Add(new SVGEllipseElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.PolyLine:
						elementList.Add(new SVGPolylineElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.Polygon:
						elementList.Add(new SVGPolygonElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.Path:
						elementList.Add(new SVGPathElement(this.node, summaryTransformList, paintable));
						break;
					case SVGNodeName.SVG:
						if (!(this.node is InlineNode))
						{
							elementList.Add(new SVGElement(this, summaryTransformList, paintable, false));
						}
						break;
					case SVGNodeName.G:
						if (!(this.node is InlineNode))
						{
							elementList.Add(new SVGElement(this, summaryTransformList, paintable, false));
						}
						break;
					case SVGNodeName.LinearGradient:
						this.ResolveGradientLinks();
						paintable.AppendLinearGradient(new SVGLinearGradientElement(this, this.node));
						break;
					case SVGNodeName.RadialGradient:
						this.ResolveGradientLinks();
						paintable.AppendRadialGradient(new SVGRadialGradientElement(this, this.node));
						break;
					case SVGNodeName.ConicalGradient:
						this.ResolveGradientLinks();
						paintable.AppendConicalGradient(new SVGConicalGradientElement(this, this.node));
						break;
					case SVGNodeName.Defs:
						this.GetElementList(elementList, paintable, summaryTransformList);
						break;
					case SVGNodeName.Title:
						this.GetElementList(elementList, paintable, summaryTransformList);
						break;
					case SVGNodeName.Desc:
						this.GetElementList(elementList, paintable, summaryTransformList);
						break;
					case SVGNodeName.Symbol:
						if (!(this.node is InlineNode))
						{
							elementList.Add(new SVGElement(this, summaryTransformList, paintable, false));
						}
						break;
					case SVGNodeName.Use:
					{
						string text = this.node.attributes.GetValue("xlink:href");
						if (!string.IsNullOrEmpty(text))
						{
							if (text[0] == '#')
							{
								text = text.Remove(0, 1);
							}
							if (SVGParser._defs.ContainsKey(text))
							{
								Node node = SVGParser._defs[text];
								if (node != null && node != this.node)
								{
									List<Node> list = node.GetNodes();
									if (list != null && list.Count > 0)
									{
										this.nodes[this.idx] = new BlockOpenNode(SVGNodeName.Use, this.node.attributes, this.node.depth);
										list.Add(new BlockCloseNode(SVGNodeName.Use, default(AttributeList), this.node.depth));
										this.nodes.InsertRange(this.idx + 1, list);
										elementList.Add(new SVGElement(this, summaryTransformList, paintable, false));
									}
								}
							}
						}
						break;
					}
					case SVGNodeName.Style:
						paintable.AddCSS(this.node.content);
						break;
					}
				}
			}
		}

		// Token: 0x0600079D RID: 1949 RVA: 0x0002E8A4 File Offset: 0x0002CAA4
		protected void ResolveGradientLinks()
		{
			string text = this.node.attributes.GetValue("xlink:href");
			if (!string.IsNullOrEmpty(text))
			{
				if (text[0] == '#')
				{
					text = text.Remove(0, 1);
				}
				if (SVGParser._defs.ContainsKey(text))
				{
					Node node = SVGParser._defs[text];
					if (node != null && node != this.node)
					{
						SVGParser.MergeNodeAttributes(node, this.node);
						List<Node> list = node.GetNodes();
						if (list != null && list.Count > 0)
						{
							bool flag = this.nodes[this.idx] is InlineNode;
							if (flag)
							{
								this.nodes[this.idx] = new BlockOpenNode(this.nodes[this.idx].name, this.nodes[this.idx].attributes, this.nodes[this.idx].depth);
							}
							list.RemoveAt(0);
							if (list.Count > 0)
							{
								list.RemoveAt(list.Count - 1);
							}
							if (list.Count > 0)
							{
								this.nodes[this.idx].children = list;
								this.nodes.InsertRange(this.idx + 1, list);
							}
							if (flag)
							{
								this.nodes.Insert(this.idx + 1 + list.Count, new BlockCloseNode(this.node.name, default(AttributeList), this.node.depth));
							}
						}
					}
				}
			}
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x0002EA40 File Offset: 0x0002CC40
		private static void MergeNodeAttributes(Node source, Node target)
		{
			Dictionary<string, string> get = source.attributes.Get;
			Dictionary<string, string> get2 = target.attributes.Get;
			foreach (KeyValuePair<string, string> keyValuePair in get)
			{
				if (!(keyValuePair.Key == "id") && !(keyValuePair.Key == "xlink"))
				{
					if (get2.ContainsKey(keyValuePair.Key))
					{
						get2[keyValuePair.Key] = keyValuePair.Value;
					}
					else
					{
						get2.Add(keyValuePair.Key, keyValuePair.Value);
					}
				}
			}
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x0002EAFC File Offset: 0x0002CCFC
		private static SVGNodeName Lookup(string name)
		{
			string text = name.ToLower();
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
			if (num <= 2556802313U)
			{
				if (num <= 1227372726U)
				{
					if (num <= 400234023U)
					{
						if (num != 85768329U)
						{
							if (num == 400234023U)
							{
								if (text == "line")
								{
									return SVGNodeName.Line;
								}
							}
						}
						else if (text == "polygon")
						{
							return SVGNodeName.Polygon;
						}
					}
					else if (num != 408269525U)
					{
						if (num != 673280137U)
						{
							if (num == 1227372726U)
							{
								if (text == "conicalgradient")
								{
									return SVGNodeName.ConicalGradient;
								}
							}
						}
						else if (text == "circle")
						{
							return SVGNodeName.Circle;
						}
					}
					else if (text == "polyline")
					{
						return SVGNodeName.PolyLine;
					}
				}
				else if (num <= 2198011936U)
				{
					if (num != 1310351786U)
					{
						if (num != 1469170932U)
						{
							if (num == 2198011936U)
							{
								if (text == "desc")
								{
									return SVGNodeName.Desc;
								}
							}
						}
						else if (text == "use")
						{
							return SVGNodeName.Use;
						}
					}
					else if (text == "radialgradient")
					{
						return SVGNodeName.RadialGradient;
					}
				}
				else if (num != 2223459638U)
				{
					if (num != 2549250864U)
					{
						if (num == 2556802313U)
						{
							if (text == "title")
							{
								return SVGNodeName.Title;
							}
						}
					}
					else if (text == "lineargradient")
					{
						return SVGNodeName.LinearGradient;
					}
				}
				else if (text == "path")
				{
					return SVGNodeName.Path;
				}
			}
			else if (num <= 3140818508U)
			{
				if (num <= 2866998125U)
				{
					if (num != 2667997009U)
					{
						if (num == 2866998125U)
						{
							if (text == "defs")
							{
								return SVGNodeName.Defs;
							}
						}
					}
					else if (text == "ellipse")
					{
						return SVGNodeName.Ellipse;
					}
				}
				else if (num != 2888859350U)
				{
					if (num != 3008443898U)
					{
						if (num == 3140818508U)
						{
							if (text == "clippath")
							{
								return SVGNodeName.ClipPath;
							}
						}
					}
					else if (text == "image")
					{
						return SVGNodeName.Image;
					}
				}
				else if (text == "style")
				{
					return SVGNodeName.Style;
				}
			}
			else if (num <= 3880226465U)
			{
				if (num != 3411225317U)
				{
					if (num != 3792446982U)
					{
						if (num == 3880226465U)
						{
							if (text == "svg")
							{
								return SVGNodeName.SVG;
							}
						}
					}
					else if (text == "g")
					{
						return SVGNodeName.G;
					}
				}
				else if (text == "stop")
				{
					return SVGNodeName.Stop;
				}
			}
			else if (num != 3883353449U)
			{
				if (num != 3940830471U)
				{
					if (num == 4093333969U)
					{
						if (text == "symbol")
						{
							return SVGNodeName.Symbol;
						}
					}
				}
				else if (text == "rect")
				{
					return SVGNodeName.Rect;
				}
			}
			else if (text == "mask")
			{
				return SVGNodeName.Mask;
			}
			return SVGNodeName.G;
		}

		// Token: 0x040007BA RID: 1978
		public static Dictionary<string, Node> _defs;

		// Token: 0x040007BB RID: 1979
		private SmallXmlParser _parser = new SmallXmlParser();

		// Token: 0x040007BC RID: 1980
		private int _currentDepth;

		// Token: 0x040007BD RID: 1981
		private Node _lastParent;

		// Token: 0x040007BE RID: 1982
		private static string STYLE_BLOCK;

		// Token: 0x040007BF RID: 1983
		public List<Node> nodes = new List<Node>();

		// Token: 0x040007C0 RID: 1984
		private int idx;

		// Token: 0x040007C1 RID: 1985
		private static List<SVGNodeName> dontPutInNodes = new List<SVGNodeName>();
	}
}
