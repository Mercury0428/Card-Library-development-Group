﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E4 RID: 228
	public class SVGException : DOMException
	{
		// Token: 0x06000760 RID: 1888 RVA: 0x0002D3E7 File Offset: 0x0002B5E7
		public SVGException(SVGExceptionType errorCode) : this(errorCode, string.Empty, null)
		{
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x0002D3F6 File Offset: 0x0002B5F6
		public SVGException(SVGExceptionType errorCode, string message) : this(errorCode, message, null)
		{
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x0002D401 File Offset: 0x0002B601
		public SVGException(SVGExceptionType errorCode, string message, Exception innerException) : base(message, innerException)
		{
			this.code = errorCode;
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000763 RID: 1891 RVA: 0x0002D412 File Offset: 0x0002B612
		public new SVGExceptionType Code
		{
			get
			{
				return this.code;
			}
		}

		// Token: 0x04000790 RID: 1936
		private SVGExceptionType code;
	}
}
