﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter.Document
{
	// Token: 0x020000E0 RID: 224
	public class SVGElement : SVGParentable, ISVGDrawable
	{
		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x06000750 RID: 1872 RVA: 0x0002D179 File Offset: 0x0002B379
		public string name
		{
			get
			{
				return this._name;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000751 RID: 1873 RVA: 0x0002D181 File Offset: 0x0002B381
		public AttributeList attributeList
		{
			get
			{
				return this._attrList;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000752 RID: 1874 RVA: 0x0002D189 File Offset: 0x0002B389
		public List<object> elementList
		{
			get
			{
				return this._elementList;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x0002D191 File Offset: 0x0002B391
		public SVGPaintable paintable
		{
			get
			{
				return this._paintable;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000754 RID: 1876 RVA: 0x0002D199 File Offset: 0x0002B399
		public bool rootElement
		{
			get
			{
				return this._rootElement;
			}
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0002D1A4 File Offset: 0x0002B3A4
		public SVGElement(SVGParser xmlImp, SVGTransformList inheritTransformList, SVGPaintable inheritPaintable, bool root = false) : base(inheritTransformList)
		{
			this._rootElement = root;
			this._name = this._attrList.GetValue("id");
			this._xmlImp = xmlImp;
			this._attrList = this._xmlImp.node.attributes;
			if (inheritPaintable != null)
			{
				this._paintable = new SVGPaintable(inheritPaintable, this._xmlImp.node);
			}
			else
			{
				this._paintable = new SVGPaintable(this._xmlImp.node);
			}
			this.Init();
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x0002D238 File Offset: 0x0002B438
		protected void Init()
		{
			this._elementList = new List<object>();
			this.ViewBoxTransform();
			SVGTransform newItem = new SVGTransform(this._cachedViewBoxTransform);
			SVGTransformList svgtransformList = new SVGTransformList(this._attrList.GetValue("transform"));
			svgtransformList.AppendItem(newItem);
			base.currentTransformList = svgtransformList;
			bool rootElement = this._rootElement;
			this.GetElementList();
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0002D294 File Offset: 0x0002B494
		private void GetElementList()
		{
			this._xmlImp.GetElementList(this._elementList, this._paintable, base.summaryTransformList);
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x0002D2B4 File Offset: 0x0002B4B4
		public void BeforeRender(SVGTransformList transformList)
		{
			base.inheritTransformList = transformList;
			for (int i = 0; i < this._elementList.Count; i++)
			{
				ISVGDrawable isvgdrawable = this._elementList[i] as ISVGDrawable;
				if (isvgdrawable != null)
				{
					isvgdrawable.BeforeRender(base.summaryTransformList);
				}
			}
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0002D300 File Offset: 0x0002B500
		public void Render()
		{
			for (int i = 0; i < this._elementList.Count; i++)
			{
				ISVGDrawable isvgdrawable = this._elementList[i] as ISVGDrawable;
				if (isvgdrawable != null)
				{
					isvgdrawable.Render();
				}
			}
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x0002D340 File Offset: 0x0002B540
		public SVGMatrix ViewBoxTransform()
		{
			if (!this.cachedViewBox)
			{
				this.cachedViewBox = true;
				Rect viewport = this._paintable.viewport;
				if (this._rootElement)
				{
					this._cachedViewBoxTransform = SVGTransformable.GetRootViewBoxTransform(this._attrList, ref viewport);
				}
				else
				{
					this._cachedViewBoxTransform = SVGTransformable.GetViewBoxTransform(this._attrList, ref viewport, true);
				}
				this.paintable.SetViewport(viewport);
			}
			return this._cachedViewBoxTransform;
		}

		// Token: 0x04000773 RID: 1907
		protected string _name;

		// Token: 0x04000774 RID: 1908
		private AttributeList _attrList;

		// Token: 0x04000775 RID: 1909
		private List<object> _elementList;

		// Token: 0x04000776 RID: 1910
		private SVGParser _xmlImp;

		// Token: 0x04000777 RID: 1911
		private SVGPaintable _paintable;

		// Token: 0x04000778 RID: 1912
		protected bool _rootElement;

		// Token: 0x04000779 RID: 1913
		private SVGMatrix _cachedViewBoxTransform = SVGMatrix.identity;

		// Token: 0x0400077A RID: 1914
		private bool cachedViewBox;
	}
}
