﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E2 RID: 226
	[Serializable]
	public class DOMException : Exception
	{
		// Token: 0x0600075B RID: 1883 RVA: 0x0002D3AB File Offset: 0x0002B5AB
		protected DOMException(string msg, Exception innerException) : base(msg, innerException)
		{
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0002D3B5 File Offset: 0x0002B5B5
		public DOMException(DOMExceptionType code) : this(code, string.Empty)
		{
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x0002D3C3 File Offset: 0x0002B5C3
		public DOMException(DOMExceptionType code, string msg) : this(code, msg, null)
		{
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x0002D3CE File Offset: 0x0002B5CE
		public DOMException(DOMExceptionType code, string msg, Exception innerException) : base(msg, innerException)
		{
			this.code = code;
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x0002D3DF File Offset: 0x0002B5DF
		public DOMExceptionType Code
		{
			get
			{
				return this.code;
			}
		}

		// Token: 0x0400078B RID: 1931
		private DOMExceptionType code;
	}
}
