﻿using System;
using System.Collections.Generic;

namespace SVGImporter.Document
{
	// Token: 0x020000E9 RID: 233
	public class Node
	{
		// Token: 0x06000785 RID: 1925 RVA: 0x0002E008 File Offset: 0x0002C208
		public Node(SVGNodeName name, AttributeList attributes, int depth)
		{
			this.parent = null;
			this.children = new List<Node>();
			this.name = name;
			this.attributes = attributes;
			this.depth = depth;
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x0002E038 File Offset: 0x0002C238
		public List<Node> GetNodes()
		{
			List<Node> list = new List<Node>();
			this.GetNodesInternal(this, list);
			return list;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x0002E054 File Offset: 0x0002C254
		protected void GetNodesInternal(Node node, List<Node> nodes)
		{
			if (node == null)
			{
				return;
			}
			nodes.Add(node);
			int count = node.children.Count;
			for (int i = 0; i < count; i++)
			{
				this.GetNodesInternal(node.children[i], nodes);
			}
			if (node is BlockOpenNode)
			{
				Node item = new BlockCloseNode(node.name, default(AttributeList), node.depth);
				nodes.Add(item);
			}
		}

		// Token: 0x040007B4 RID: 1972
		public Node parent;

		// Token: 0x040007B5 RID: 1973
		public List<Node> children;

		// Token: 0x040007B6 RID: 1974
		public SVGNodeName name;

		// Token: 0x040007B7 RID: 1975
		public AttributeList attributes;

		// Token: 0x040007B8 RID: 1976
		public int depth;

		// Token: 0x040007B9 RID: 1977
		public string content;
	}
}
