﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000E8 RID: 232
	public enum SVGNodeName
	{
		// Token: 0x0400079E RID: 1950
		Rect,
		// Token: 0x0400079F RID: 1951
		Line,
		// Token: 0x040007A0 RID: 1952
		Circle,
		// Token: 0x040007A1 RID: 1953
		Ellipse,
		// Token: 0x040007A2 RID: 1954
		PolyLine,
		// Token: 0x040007A3 RID: 1955
		Polygon,
		// Token: 0x040007A4 RID: 1956
		Path,
		// Token: 0x040007A5 RID: 1957
		SVG,
		// Token: 0x040007A6 RID: 1958
		G,
		// Token: 0x040007A7 RID: 1959
		LinearGradient,
		// Token: 0x040007A8 RID: 1960
		RadialGradient,
		// Token: 0x040007A9 RID: 1961
		ConicalGradient,
		// Token: 0x040007AA RID: 1962
		Defs,
		// Token: 0x040007AB RID: 1963
		Title,
		// Token: 0x040007AC RID: 1964
		Desc,
		// Token: 0x040007AD RID: 1965
		Stop,
		// Token: 0x040007AE RID: 1966
		Symbol,
		// Token: 0x040007AF RID: 1967
		ClipPath,
		// Token: 0x040007B0 RID: 1968
		Mask,
		// Token: 0x040007B1 RID: 1969
		Image,
		// Token: 0x040007B2 RID: 1970
		Use,
		// Token: 0x040007B3 RID: 1971
		Style
	}
}
