﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000EA RID: 234
	public class InlineNode : Node
	{
		// Token: 0x06000788 RID: 1928 RVA: 0x0002E0C1 File Offset: 0x0002C2C1
		public InlineNode(SVGNodeName name, AttributeList attributes, int depth) : base(name, attributes, depth)
		{
		}
	}
}
