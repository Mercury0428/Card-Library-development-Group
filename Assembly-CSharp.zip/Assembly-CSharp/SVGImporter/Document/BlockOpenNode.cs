﻿using System;

namespace SVGImporter.Document
{
	// Token: 0x020000EB RID: 235
	public class BlockOpenNode : Node
	{
		// Token: 0x06000789 RID: 1929 RVA: 0x0002E0C1 File Offset: 0x0002C2C1
		public BlockOpenNode(SVGNodeName name, AttributeList attributes, int depth) : base(name, attributes, depth)
		{
		}
	}
}
