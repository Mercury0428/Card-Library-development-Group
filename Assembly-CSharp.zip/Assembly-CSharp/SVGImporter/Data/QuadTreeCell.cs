﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Data
{
	// Token: 0x0200010E RID: 270
	public class QuadTreeCell<T>
	{
		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060008A5 RID: 2213 RVA: 0x00038BB5 File Offset: 0x00036DB5
		public int depth
		{
			get
			{
				return this._depth;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060008A6 RID: 2214 RVA: 0x00038BBD File Offset: 0x00036DBD
		public QuadTreeCell<T> root
		{
			get
			{
				return this.quadTree._root;
			}
		}

		// Token: 0x060008A7 RID: 2215 RVA: 0x00038BCA File Offset: 0x00036DCA
		internal QuadTreeCell<T> FindRoot(QuadTreeCell<T> current)
		{
			if (current.parent != null)
			{
				return this.FindRoot(current.parent);
			}
			return current;
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x00038BE2 File Offset: 0x00036DE2
		public QuadTreeCell(SVGBounds bounds)
		{
			this.bounds = bounds;
			this.parent = null;
			this.quadTree = null;
			this.maxCapacity = 1;
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x00038C0D File Offset: 0x00036E0D
		public QuadTreeCell(SVGBounds bounds, int maxCapacity)
		{
			this.bounds = bounds;
			this.parent = null;
			this.quadTree = null;
			this.maxCapacity = maxCapacity;
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x00038C38 File Offset: 0x00036E38
		public QuadTreeCell(SVGBounds bounds, QuadTreeCell<T> parent, int maxCapacity)
		{
			this.bounds = bounds;
			this.parent = parent;
			this.quadTree = null;
			this.maxCapacity = maxCapacity;
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x00038C63 File Offset: 0x00036E63
		public QuadTreeCell(SVGBounds bounds, QuadTreeCell<T> parent, QuadTree<T> quadTree, int maxCapacity)
		{
			this.bounds = bounds;
			this.parent = parent;
			this.quadTree = quadTree;
			this.maxCapacity = maxCapacity;
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x00038C8F File Offset: 0x00036E8F
		public QuadTreeNode<T> Add(T data, SVGBounds bounds)
		{
			return this.Add(new QuadTreeNode<T>(data, bounds));
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x00038CA0 File Offset: 0x00036EA0
		public QuadTreeNode<T> Add(QuadTreeNode<T> node)
		{
			if (this.nodes == null)
			{
				this.nodes = new List<QuadTreeNode<T>>();
			}
			if (this.bounds.Contains(node.bounds))
			{
				bool flag = node.bounds.maxX <= this.bounds.center.x;
				bool flag2 = node.bounds.minY >= this.bounds.center.y;
				bool flag3 = node.bounds.minX < this.bounds.center.x;
				bool flag4 = node.bounds.maxX > this.bounds.center.x;
				bool flag5 = node.bounds.maxY > this.bounds.center.y;
				bool flag6 = node.bounds.minY < this.bounds.center.y;
				if ((flag3 && flag4) || (flag5 && flag6))
				{
					node.cell = this;
					node._depth = this._depth;
					this.nodes.Add(node);
				}
				else if (this.nodes.Count < this.maxCapacity)
				{
					node.cell = this;
					node._depth = this._depth;
					this.nodes.Add(node);
				}
				else if (flag2)
				{
					if (flag)
					{
						if (this.topLeft == null)
						{
							this.topLeft = new QuadTreeCell<T>(new SVGBounds(this.bounds.minX, this.bounds.center.y, this.bounds.center.x, this.bounds.maxY), this, this.quadTree, this.maxCapacity);
						}
						this.topLeft._depth = this._depth + 1;
						this.topLeft.Add(node);
					}
					else
					{
						if (this.topRight == null)
						{
							this.topRight = new QuadTreeCell<T>(new SVGBounds(this.bounds.center.x, this.bounds.center.y, this.bounds.maxX, this.bounds.maxY), this, this.quadTree, this.maxCapacity);
						}
						this.topRight._depth = this._depth + 1;
						this.topRight.Add(node);
					}
				}
				else if (flag)
				{
					if (this.bottomLeft == null)
					{
						this.bottomLeft = new QuadTreeCell<T>(new SVGBounds(this.bounds.minX, this.bounds.minY, this.bounds.center.x, this.bounds.center.y), this, this.quadTree, this.maxCapacity);
					}
					this.bottomLeft._depth = this._depth + 1;
					this.bottomLeft.Add(node);
				}
				else
				{
					if (this.bottomRight == null)
					{
						this.bottomRight = new QuadTreeCell<T>(new SVGBounds(this.bounds.center.x, this.bounds.minY, this.bounds.maxX, this.bounds.center.y), this, this.quadTree, this.maxCapacity);
					}
					this.bottomRight._depth = this._depth + 1;
					this.bottomRight.Add(node);
				}
			}
			else
			{
				node.cell = this;
				node._depth = this._depth;
				this.nodes.Add(node);
			}
			return node;
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00039024 File Offset: 0x00037224
		public List<QuadTreeNode<T>> Contains(Vector2 point)
		{
			if (!this.bounds.Contains(point))
			{
				return null;
			}
			List<QuadTreeNode<T>> list = null;
			if (this.nodes != null && this.nodes.Count > 0)
			{
				list = new List<QuadTreeNode<T>>();
				for (int i = 0; i < this.nodes.Count; i++)
				{
					if (this.nodes[i].bounds.Contains(point))
					{
						list.Add(this.nodes[i]);
					}
				}
				if (list.Count == 0)
				{
					list = null;
				}
			}
			if (this.topLeft != null)
			{
				List<QuadTreeNode<T>> list2 = this.topLeft.Contains(point);
				if (list2 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list2);
				}
			}
			if (this.topRight != null)
			{
				List<QuadTreeNode<T>> list3 = this.topRight.Contains(point);
				if (list3 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list3);
				}
			}
			if (this.bottomLeft != null)
			{
				List<QuadTreeNode<T>> list4 = this.bottomLeft.Contains(point);
				if (list4 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list4);
				}
			}
			if (this.bottomRight != null)
			{
				List<QuadTreeNode<T>> list5 = this.bottomRight.Contains(point);
				if (list5 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list5);
				}
			}
			return list;
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x00039154 File Offset: 0x00037354
		public List<QuadTreeNode<T>> Contains(SVGBounds bounds)
		{
			if (!this.bounds.Intersects(bounds))
			{
				return null;
			}
			List<QuadTreeNode<T>> list = null;
			if (this.nodes != null && this.nodes.Count > 0)
			{
				list = new List<QuadTreeNode<T>>();
				for (int i = 0; i < this.nodes.Count; i++)
				{
					if (bounds.Contains(this.nodes[i].bounds))
					{
						list.Add(this.nodes[i]);
					}
				}
				if (list.Count == 0)
				{
					list = null;
				}
			}
			if (this.topLeft != null)
			{
				List<QuadTreeNode<T>> list2 = this.topLeft.Contains(bounds);
				if (list2 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list2);
				}
			}
			if (this.topRight != null)
			{
				List<QuadTreeNode<T>> list3 = this.topRight.Contains(bounds);
				if (list3 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list3);
				}
			}
			if (this.bottomLeft != null)
			{
				List<QuadTreeNode<T>> list4 = this.bottomLeft.Contains(bounds);
				if (list4 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list4);
				}
			}
			if (this.bottomRight != null)
			{
				List<QuadTreeNode<T>> list5 = this.bottomRight.Contains(bounds);
				if (list5 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list5);
				}
			}
			return list;
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x00039284 File Offset: 0x00037484
		public List<QuadTreeNode<T>> Intersects(SVGBounds bounds)
		{
			if (!this.bounds.Intersects(bounds))
			{
				return null;
			}
			List<QuadTreeNode<T>> list = null;
			if (this.nodes != null && this.nodes.Count > 0)
			{
				list = new List<QuadTreeNode<T>>();
				for (int i = 0; i < this.nodes.Count; i++)
				{
					if (this.nodes[i].bounds.Intersects(bounds))
					{
						list.Add(this.nodes[i]);
					}
				}
				if (list.Count == 0)
				{
					list = null;
				}
			}
			if (this.topLeft != null)
			{
				List<QuadTreeNode<T>> list2 = this.topLeft.Intersects(bounds);
				if (list2 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list2);
				}
			}
			if (this.topRight != null)
			{
				List<QuadTreeNode<T>> list3 = this.topRight.Intersects(bounds);
				if (list3 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list3);
				}
			}
			if (this.bottomLeft != null)
			{
				List<QuadTreeNode<T>> list4 = this.bottomLeft.Intersects(bounds);
				if (list4 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list4);
				}
			}
			if (this.bottomRight != null)
			{
				List<QuadTreeNode<T>> list5 = this.bottomRight.Intersects(bounds);
				if (list5 != null)
				{
					if (list == null)
					{
						list = new List<QuadTreeNode<T>>();
					}
					list.AddRange(list5);
				}
			}
			return list;
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x000393B1 File Offset: 0x000375B1
		public List<QuadTreeNode<T>> NearestNeighbour(Vector2 point)
		{
			return null;
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x000393B4 File Offset: 0x000375B4
		public void Clear()
		{
			if (this.nodes != null)
			{
				this.nodes.Clear();
				this.nodes = null;
			}
			if (this.topLeft != null)
			{
				this.topLeft.Clear();
				this.topLeft = null;
			}
			if (this.topRight != null)
			{
				this.topRight.Clear();
				this.topRight = null;
			}
			if (this.bottomLeft != null)
			{
				this.bottomLeft.Clear();
				this.bottomLeft = null;
			}
			if (this.bottomRight != null)
			{
				this.bottomRight.Clear();
				this.bottomRight = null;
			}
			this._depth = 0;
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x0003944C File Offset: 0x0003764C
		public void Remove()
		{
			if (this.parent != null)
			{
				if (this.parent.topLeft != null && this.parent.topLeft == this)
				{
					this.parent.topLeft.Clear();
					this.parent.topLeft = null;
					return;
				}
				if (this.parent.topRight != null && this.parent.topRight == this)
				{
					this.parent.topRight.Clear();
					this.parent.topRight = null;
					return;
				}
				if (this.parent.bottomLeft != null && this.parent.bottomLeft == this)
				{
					this.parent.bottomLeft.Clear();
					this.parent.bottomLeft = null;
					return;
				}
				if (this.parent.bottomRight != null && this.parent.bottomRight == this)
				{
					this.parent.bottomRight.Clear();
					this.parent.bottomRight = null;
				}
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060008B4 RID: 2228 RVA: 0x00039543 File Offset: 0x00037743
		public bool isCellEmpty
		{
			get
			{
				return (this.nodes == null || this.nodes.Count == 0) && this.topLeft == null && this.topRight == null && this.bottomLeft == null && this.bottomRight == null;
			}
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x0003957D File Offset: 0x0003777D
		public void CleanUnusedCells()
		{
			QuadTreeCell<T>.CleanUnusedCells(this);
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00039585 File Offset: 0x00037785
		public static void CleanUnusedCells(QuadTreeCell<T> cell)
		{
			if (cell == null || !cell.isCellEmpty)
			{
				return;
			}
			cell.Remove();
			QuadTreeCell<T>.CleanUnusedCells(cell.parent);
		}

		// Token: 0x04000821 RID: 2081
		private const int DEFAULT_MAX_CAPACITY = 1;

		// Token: 0x04000822 RID: 2082
		public int maxCapacity = 1;

		// Token: 0x04000823 RID: 2083
		public SVGBounds bounds;

		// Token: 0x04000824 RID: 2084
		public QuadTreeCell<T> parent;

		// Token: 0x04000825 RID: 2085
		public QuadTreeCell<T> topLeft;

		// Token: 0x04000826 RID: 2086
		public QuadTreeCell<T> topRight;

		// Token: 0x04000827 RID: 2087
		public QuadTreeCell<T> bottomLeft;

		// Token: 0x04000828 RID: 2088
		public QuadTreeCell<T> bottomRight;

		// Token: 0x04000829 RID: 2089
		public List<QuadTreeNode<T>> nodes;

		// Token: 0x0400082A RID: 2090
		public QuadTree<T> quadTree;

		// Token: 0x0400082B RID: 2091
		protected internal int _depth;
	}
}
