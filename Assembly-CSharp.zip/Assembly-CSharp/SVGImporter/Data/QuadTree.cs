﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Data
{
	// Token: 0x0200010F RID: 271
	public class QuadTree<T>
	{
		// Token: 0x060008B7 RID: 2231 RVA: 0x000395A4 File Offset: 0x000377A4
		public QuadTree(SVGBounds bounds)
		{
			this._originalBounds = bounds;
			this._root = new QuadTreeCell<T>(bounds, null, this, this._originalMaxCapacity);
			this._root._depth = 0;
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x000395DA File Offset: 0x000377DA
		public QuadTree(SVGBounds bounds, int maxCapacity)
		{
			this._originalBounds = bounds;
			this._originalMaxCapacity = maxCapacity;
			this._root = new QuadTreeCell<T>(bounds, null, this, this._originalMaxCapacity);
			this._root._depth = 0;
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060008B9 RID: 2233 RVA: 0x00039617 File Offset: 0x00037817
		public QuadTreeCell<T> root
		{
			get
			{
				return this._root;
			}
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x0003961F File Offset: 0x0003781F
		public QuadTreeNode<T> Add(T data, SVGBounds bounds)
		{
			return this._root.Add(data, bounds);
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x0003962E File Offset: 0x0003782E
		public List<QuadTreeNode<T>> Contains(Vector2 point)
		{
			return this._root.Contains(point);
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x0003963C File Offset: 0x0003783C
		public List<QuadTreeNode<T>> Contains(SVGBounds bounds)
		{
			return this._root.Contains(bounds);
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x0003964A File Offset: 0x0003784A
		public List<QuadTreeNode<T>> Intersects(SVGBounds bounds)
		{
			return this._root.Intersects(bounds);
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00039658 File Offset: 0x00037858
		public void Clear()
		{
			this._root.Clear();
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x00039665 File Offset: 0x00037865
		public void Reset()
		{
			this._root.Clear();
			this._root = new QuadTreeCell<T>(this._originalBounds, null, this, this._originalMaxCapacity);
			this._root._depth = 0;
		}

		// Token: 0x0400082C RID: 2092
		protected internal QuadTreeCell<T> _root;

		// Token: 0x0400082D RID: 2093
		protected internal SVGBounds _originalBounds;

		// Token: 0x0400082E RID: 2094
		protected internal int _originalMaxCapacity = 1;
	}
}
