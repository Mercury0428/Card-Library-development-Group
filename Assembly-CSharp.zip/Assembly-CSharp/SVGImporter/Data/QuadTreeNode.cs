﻿using System;
using SVGImporter.Utils;

namespace SVGImporter.Data
{
	// Token: 0x0200010D RID: 269
	public class QuadTreeNode<T>
	{
		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x0600089F RID: 2207 RVA: 0x00038AE5 File Offset: 0x00036CE5
		public QuadTree<T> quadTree
		{
			get
			{
				return this.cell.quadTree;
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060008A0 RID: 2208 RVA: 0x00038AF2 File Offset: 0x00036CF2
		public int depth
		{
			get
			{
				return this._depth;
			}
		}

		// Token: 0x060008A1 RID: 2209 RVA: 0x00038AFA File Offset: 0x00036CFA
		public QuadTreeNode(T data, SVGBounds bounds)
		{
			this.data = data;
			this.bounds = bounds;
		}

		// Token: 0x060008A2 RID: 2210 RVA: 0x00038B10 File Offset: 0x00036D10
		public QuadTreeNode(T data, SVGBounds bounds, QuadTreeCell<T> cell)
		{
			this.data = data;
			this.bounds = bounds;
			this.cell = cell;
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x00038B30 File Offset: 0x00036D30
		public void Move(SVGBounds bounds)
		{
			if (this.bounds.Compare(bounds))
			{
				return;
			}
			this.bounds.ApplyBounds(bounds);
			if (this.cell.bounds.Contains(bounds))
			{
				return;
			}
			QuadTreeCell<T> root = this.cell.root;
			this.Remove();
			root.Add(this);
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x00038B84 File Offset: 0x00036D84
		public void Remove()
		{
			this.cell.nodes.Remove(this);
			if (this.cell.nodes.Count == 0)
			{
				this.cell.CleanUnusedCells();
			}
		}

		// Token: 0x0400081D RID: 2077
		public T data;

		// Token: 0x0400081E RID: 2078
		public SVGBounds bounds;

		// Token: 0x0400081F RID: 2079
		public QuadTreeCell<T> cell;

		// Token: 0x04000820 RID: 2080
		protected internal int _depth;
	}
}
