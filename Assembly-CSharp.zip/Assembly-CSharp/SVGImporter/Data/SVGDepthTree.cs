﻿using System;
using System.Collections.Generic;
using SVGImporter.Utils;
using UnityEngine;

namespace SVGImporter.Data
{
	// Token: 0x02000110 RID: 272
	public class SVGDepthTree
	{
		// Token: 0x060008C0 RID: 2240 RVA: 0x00039697 File Offset: 0x00037897
		public SVGDepthTree(SVGBounds bounds)
		{
			this.quadTree = new QuadTree<int>(new SVGBounds(bounds.center, bounds.size));
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x000396BD File Offset: 0x000378BD
		public SVGDepthTree(Rect bounds)
		{
			this.quadTree = new QuadTree<int>(new SVGBounds(bounds.center, bounds.size));
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x000396E4 File Offset: 0x000378E4
		public int[] TestDepthAdd(int node, SVGBounds bounds)
		{
			List<QuadTreeNode<int>> list = this.quadTree.Intersects(bounds);
			int[] array = null;
			if (list != null && list.Count > 0)
			{
				array = new int[list.Count];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = list[i].data;
				}
			}
			this.quadTree.Add(node, bounds);
			return array;
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x00039744 File Offset: 0x00037944
		public void Clear()
		{
			this.quadTree.Clear();
		}

		// Token: 0x0400082F RID: 2095
		protected QuadTree<int> quadTree;
	}
}
