﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B7 RID: 183
	[Serializable]
	public class LayerSelection
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000598 RID: 1432 RVA: 0x00020B56 File Offset: 0x0001ED56
		public List<int> layers
		{
			get
			{
				if (this._layers == null)
				{
					this._layers = new List<int>();
				}
				return this._layers;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000599 RID: 1433 RVA: 0x00020B71 File Offset: 0x0001ED71
		public HashSet<int> cache
		{
			get
			{
				this.UpdateCache();
				return this._cache;
			}
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x00020B7F File Offset: 0x0001ED7F
		public void Add(int index)
		{
			if (this.Contains(index))
			{
				return;
			}
			this.layers.Add(index);
			this.cache.Add(index);
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00020BA4 File Offset: 0x0001EDA4
		public void Remove(int index)
		{
			if (!this.Contains(index))
			{
				return;
			}
			this.layers.Remove(index);
			this.cache.Remove(index);
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00020BCA File Offset: 0x0001EDCA
		public bool Contains(int index)
		{
			return this.cache.Contains(index);
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00020BD8 File Offset: 0x0001EDD8
		public void UpdateCache()
		{
			if (this._cache == null)
			{
				this._cache = new HashSet<int>();
			}
			for (int i = 0; i < this.layers.Count; i++)
			{
				this._cache.Add(this.layers[i]);
			}
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00020C26 File Offset: 0x0001EE26
		public void ClearCache()
		{
			if (this._cache != null)
			{
				this._cache.Clear();
			}
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00020C3B File Offset: 0x0001EE3B
		public void Clear()
		{
			this.ClearCache();
			if (this._layers != null)
			{
				this._layers.Clear();
			}
		}

		// Token: 0x0400064A RID: 1610
		[HideInInspector]
		[SerializeField]
		protected List<int> _layers;

		// Token: 0x0400064B RID: 1611
		protected HashSet<int> _cache;
	}
}
