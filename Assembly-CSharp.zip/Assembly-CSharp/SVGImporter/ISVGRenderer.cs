﻿using System;
using System.Collections.Generic;

namespace SVGImporter
{
	// Token: 0x020000B3 RID: 179
	public interface ISVGRenderer
	{
		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000588 RID: 1416
		// (set) Token: 0x06000589 RID: 1417
		Action<SVGLayer[], SVGAsset, bool> OnPrepareForRendering { get; set; }

		// Token: 0x0600058A RID: 1418
		void UpdateRenderer();

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600058B RID: 1419
		SVGAsset vectorGraphics { get; }

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600058C RID: 1420
		int lastFrameChanged { get; }

		// Token: 0x0600058D RID: 1421
		void AddModifier(ISVGModify modifier);

		// Token: 0x0600058E RID: 1422
		void RemoveModifier(ISVGModify modifier);

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600058F RID: 1423
		List<ISVGModify> modifiers { get; }
	}
}
