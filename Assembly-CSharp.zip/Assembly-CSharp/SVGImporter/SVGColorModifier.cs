﻿using System;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B6 RID: 182
	[ExecuteInEditMode]
	[RequireComponent(typeof(ISVGRenderer))]
	[AddComponentMenu("Rendering/SVG Modifiers/Color Modifier", 22)]
	public class SVGColorModifier : SVGModifier
	{
		// Token: 0x06000596 RID: 1430 RVA: 0x00020A38 File Offset: 0x0001EC38
		protected override void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force)
		{
			if (layers == null)
			{
				return;
			}
			int num = layers.Length;
			if (!this.useSelection)
			{
				for (int i = 0; i < num; i++)
				{
					if (layers[i].shapes != null)
					{
						int num2 = layers[i].shapes.Length;
						for (int j = 0; j < num2; j++)
						{
							SVGFill fill = layers[i].shapes[j].fill;
							fill.color *= this.color;
						}
					}
				}
				return;
			}
			for (int k = 0; k < num; k++)
			{
				if (layers[k].shapes != null && this.layerSelection.Contains(k))
				{
					int num3 = layers[k].shapes.Length;
					for (int l = 0; l < num3; l++)
					{
						SVGFill fill2 = layers[k].shapes[l].fill;
						fill2.color *= this.color;
					}
				}
			}
		}

		// Token: 0x04000649 RID: 1609
		public Color color;
	}
}
