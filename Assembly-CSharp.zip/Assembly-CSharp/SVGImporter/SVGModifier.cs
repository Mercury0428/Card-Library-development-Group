﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B8 RID: 184
	public abstract class SVGModifier : MonoBehaviour, ISVGModify
	{
		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060005A1 RID: 1441 RVA: 0x00020C56 File Offset: 0x0001EE56
		public bool hasSelection
		{
			get
			{
				return this.useSelection && this.layerSelection != null && this.layerSelection.layers.Count != 0;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x00020C7F File Offset: 0x0001EE7F
		public ISVGRenderer svgRenderer
		{
			get
			{
				if (this._svgRenderer == null)
				{
					this._svgRenderer = base.GetComponent<ISVGRenderer>();
				}
				return this._svgRenderer;
			}
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00020C9B File Offset: 0x0001EE9B
		protected virtual void Init()
		{
			if (this.svgRenderer != null)
			{
				this.svgRenderer.AddModifier(this);
				ISVGRenderer svgRenderer = this.svgRenderer;
				svgRenderer.OnPrepareForRendering = (Action<SVGLayer[], SVGAsset, bool>)Delegate.Combine(svgRenderer.OnPrepareForRendering, new Action<SVGLayer[], SVGAsset, bool>(this.PrepareForRendering));
			}
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x00020CDC File Offset: 0x0001EEDC
		protected virtual void Clear()
		{
			if (this.svgRenderer != null)
			{
				ISVGRenderer svgRenderer = this.svgRenderer;
				svgRenderer.OnPrepareForRendering = (Action<SVGLayer[], SVGAsset, bool>)Delegate.Remove(svgRenderer.OnPrepareForRendering, new Action<SVGLayer[], SVGAsset, bool>(this.PrepareForRendering));
				this.svgRenderer.RemoveModifier(this);
				this._svgRenderer = null;
			}
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00020D2C File Offset: 0x0001EF2C
		protected virtual void OnEnable()
		{
			this.Init();
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00020D34 File Offset: 0x0001EF34
		protected virtual void OnDisable()
		{
			this.Clear();
			if (this.svgRenderer != null)
			{
				this.svgRenderer.UpdateRenderer();
			}
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00020D4F File Offset: 0x0001EF4F
		protected virtual void OnWillRenderObject()
		{
			if (this.svgRenderer == null || this.manualUpdate)
			{
				return;
			}
			if (Application.isPlaying && this.svgRenderer.lastFrameChanged == Time.frameCount)
			{
				return;
			}
			this.svgRenderer.UpdateRenderer();
		}

		// Token: 0x060005A8 RID: 1448
		protected abstract void PrepareForRendering(SVGLayer[] layers, SVGAsset svgAsset, bool force);

		// Token: 0x0400064C RID: 1612
		[HideInInspector]
		public bool manualUpdate;

		// Token: 0x0400064D RID: 1613
		[HideInInspector]
		public bool useSelection;

		// Token: 0x0400064E RID: 1614
		[HideInInspector]
		public LayerSelection layerSelection;

		// Token: 0x0400064F RID: 1615
		protected ISVGRenderer _svgRenderer;
	}
}
