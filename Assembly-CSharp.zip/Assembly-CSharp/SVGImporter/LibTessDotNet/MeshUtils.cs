﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D3 RID: 211
	internal static class MeshUtils
	{
		// Token: 0x060006F8 RID: 1784 RVA: 0x00028FF0 File Offset: 0x000271F0
		public static MeshUtils.Edge MakeEdge(MeshUtils.Edge eNext)
		{
			MeshUtils.EdgePair edgePair = MeshUtils.EdgePair.Create();
			MeshUtils.Edge e = edgePair._e;
			MeshUtils.Edge eSym = edgePair._eSym;
			MeshUtils.Edge.EnsureFirst(ref eNext);
			MeshUtils.Edge next = eNext._Sym._next;
			eSym._next = next;
			next._Sym._next = e;
			e._next = eNext;
			eNext._Sym._next = eSym;
			e._Sym = eSym;
			e._Onext = e;
			e._Lnext = eSym;
			e._Org = null;
			e._Lface = null;
			e._winding = 0;
			e._activeRegion = null;
			eSym._Sym = e;
			eSym._Onext = eSym;
			eSym._Lnext = e;
			eSym._Org = null;
			eSym._Lface = null;
			eSym._winding = 0;
			eSym._activeRegion = null;
			return e;
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x000290AC File Offset: 0x000272AC
		public static void Splice(MeshUtils.Edge a, MeshUtils.Edge b)
		{
			MeshUtils.Edge onext = a._Onext;
			MeshUtils.Edge onext2 = b._Onext;
			onext._Sym._Lnext = b;
			onext2._Sym._Lnext = a;
			a._Onext = onext2;
			b._Onext = onext;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x000290F0 File Offset: 0x000272F0
		public static void MakeVertex(MeshUtils.Vertex vNew, MeshUtils.Edge eOrig, MeshUtils.Vertex vNext)
		{
			MeshUtils.Vertex prev = vNext._prev;
			vNew._prev = prev;
			prev._next = vNew;
			vNew._next = vNext;
			vNext._prev = vNew;
			vNew._anEdge = eOrig;
			MeshUtils.Edge edge = eOrig;
			do
			{
				edge._Org = vNew;
				edge = edge._Onext;
			}
			while (edge != eOrig);
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x0002913C File Offset: 0x0002733C
		public static void MakeFace(MeshUtils.Face fNew, MeshUtils.Edge eOrig, MeshUtils.Face fNext)
		{
			MeshUtils.Face prev = fNext._prev;
			fNew._prev = prev;
			prev._next = fNew;
			fNew._next = fNext;
			fNext._prev = fNew;
			fNew._anEdge = eOrig;
			fNew._trail = null;
			fNew._marked = false;
			fNew._inside = fNext._inside;
			MeshUtils.Edge edge = eOrig;
			do
			{
				edge._Lface = fNew;
				edge = edge._Lnext;
			}
			while (edge != eOrig);
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x000291A4 File Offset: 0x000273A4
		public static void KillEdge(MeshUtils.Edge eDel)
		{
			MeshUtils.Edge.EnsureFirst(ref eDel);
			MeshUtils.Edge next = eDel._next;
			MeshUtils.Edge next2 = eDel._Sym._next;
			next._Sym._next = next2;
			next2._Sym._next = next;
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x000291E4 File Offset: 0x000273E4
		public static void KillVertex(MeshUtils.Vertex vDel, MeshUtils.Vertex newOrg)
		{
			MeshUtils.Edge anEdge = vDel._anEdge;
			MeshUtils.Edge edge = anEdge;
			do
			{
				edge._Org = newOrg;
				edge = edge._Onext;
			}
			while (edge != anEdge);
			MeshUtils.Vertex prev = vDel._prev;
			MeshUtils.Vertex next = vDel._next;
			next._prev = prev;
			prev._next = next;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x00029228 File Offset: 0x00027428
		public static void KillFace(MeshUtils.Face fDel, MeshUtils.Face newLFace)
		{
			MeshUtils.Edge anEdge = fDel._anEdge;
			MeshUtils.Edge edge = anEdge;
			do
			{
				edge._Lface = newLFace;
				edge = edge._Lnext;
			}
			while (edge != anEdge);
			MeshUtils.Face prev = fDel._prev;
			MeshUtils.Face next = fDel._next;
			next._prev = prev;
			prev._next = next;
		}

		// Token: 0x0400073D RID: 1853
		public const int Undef = -1;

		// Token: 0x02000345 RID: 837
		public class Vertex
		{
			// Token: 0x0400120D RID: 4621
			internal MeshUtils.Vertex _prev;

			// Token: 0x0400120E RID: 4622
			internal MeshUtils.Vertex _next;

			// Token: 0x0400120F RID: 4623
			internal MeshUtils.Edge _anEdge;

			// Token: 0x04001210 RID: 4624
			internal Vec3 _coords;

			// Token: 0x04001211 RID: 4625
			internal float _s;

			// Token: 0x04001212 RID: 4626
			internal float _t;

			// Token: 0x04001213 RID: 4627
			internal PQHandle _pqHandle;

			// Token: 0x04001214 RID: 4628
			internal int _n;

			// Token: 0x04001215 RID: 4629
			internal object _data;
		}

		// Token: 0x02000346 RID: 838
		public class Face
		{
			// Token: 0x1700043A RID: 1082
			// (get) Token: 0x06001670 RID: 5744 RVA: 0x00072AF4 File Offset: 0x00070CF4
			internal int VertsCount
			{
				get
				{
					int num = 0;
					MeshUtils.Edge edge = this._anEdge;
					do
					{
						num++;
						edge = edge._Lnext;
					}
					while (edge != this._anEdge);
					return num;
				}
			}

			// Token: 0x04001216 RID: 4630
			internal MeshUtils.Face _prev;

			// Token: 0x04001217 RID: 4631
			internal MeshUtils.Face _next;

			// Token: 0x04001218 RID: 4632
			internal MeshUtils.Edge _anEdge;

			// Token: 0x04001219 RID: 4633
			internal MeshUtils.Face _trail;

			// Token: 0x0400121A RID: 4634
			internal int _n;

			// Token: 0x0400121B RID: 4635
			internal bool _marked;

			// Token: 0x0400121C RID: 4636
			internal bool _inside;
		}

		// Token: 0x02000347 RID: 839
		public struct EdgePair
		{
			// Token: 0x06001672 RID: 5746 RVA: 0x00072B20 File Offset: 0x00070D20
			public static MeshUtils.EdgePair Create()
			{
				MeshUtils.EdgePair edgePair = default(MeshUtils.EdgePair);
				edgePair._e = new MeshUtils.Edge();
				edgePair._e._pair = edgePair;
				edgePair._eSym = new MeshUtils.Edge();
				edgePair._eSym._pair = edgePair;
				return edgePair;
			}

			// Token: 0x0400121D RID: 4637
			internal MeshUtils.Edge _e;

			// Token: 0x0400121E RID: 4638
			internal MeshUtils.Edge _eSym;
		}

		// Token: 0x02000348 RID: 840
		public class Edge
		{
			// Token: 0x1700043B RID: 1083
			// (get) Token: 0x06001673 RID: 5747 RVA: 0x00072B66 File Offset: 0x00070D66
			// (set) Token: 0x06001674 RID: 5748 RVA: 0x00072B73 File Offset: 0x00070D73
			internal MeshUtils.Face _Rface
			{
				get
				{
					return this._Sym._Lface;
				}
				set
				{
					this._Sym._Lface = value;
				}
			}

			// Token: 0x1700043C RID: 1084
			// (get) Token: 0x06001675 RID: 5749 RVA: 0x00072B81 File Offset: 0x00070D81
			// (set) Token: 0x06001676 RID: 5750 RVA: 0x00072B8E File Offset: 0x00070D8E
			internal MeshUtils.Vertex _Dst
			{
				get
				{
					return this._Sym._Org;
				}
				set
				{
					this._Sym._Org = value;
				}
			}

			// Token: 0x1700043D RID: 1085
			// (get) Token: 0x06001677 RID: 5751 RVA: 0x00072B9C File Offset: 0x00070D9C
			// (set) Token: 0x06001678 RID: 5752 RVA: 0x00072BA9 File Offset: 0x00070DA9
			internal MeshUtils.Edge _Oprev
			{
				get
				{
					return this._Sym._Lnext;
				}
				set
				{
					this._Sym._Lnext = value;
				}
			}

			// Token: 0x1700043E RID: 1086
			// (get) Token: 0x06001679 RID: 5753 RVA: 0x00072BB7 File Offset: 0x00070DB7
			// (set) Token: 0x0600167A RID: 5754 RVA: 0x00072BC4 File Offset: 0x00070DC4
			internal MeshUtils.Edge _Lprev
			{
				get
				{
					return this._Onext._Sym;
				}
				set
				{
					this._Onext._Sym = value;
				}
			}

			// Token: 0x1700043F RID: 1087
			// (get) Token: 0x0600167B RID: 5755 RVA: 0x00072BD2 File Offset: 0x00070DD2
			// (set) Token: 0x0600167C RID: 5756 RVA: 0x00072BDF File Offset: 0x00070DDF
			internal MeshUtils.Edge _Dprev
			{
				get
				{
					return this._Lnext._Sym;
				}
				set
				{
					this._Lnext._Sym = value;
				}
			}

			// Token: 0x17000440 RID: 1088
			// (get) Token: 0x0600167D RID: 5757 RVA: 0x00072BED File Offset: 0x00070DED
			// (set) Token: 0x0600167E RID: 5758 RVA: 0x00072BFA File Offset: 0x00070DFA
			internal MeshUtils.Edge _Rprev
			{
				get
				{
					return this._Sym._Onext;
				}
				set
				{
					this._Sym._Onext = value;
				}
			}

			// Token: 0x17000441 RID: 1089
			// (get) Token: 0x0600167F RID: 5759 RVA: 0x00072C08 File Offset: 0x00070E08
			// (set) Token: 0x06001680 RID: 5760 RVA: 0x00072C15 File Offset: 0x00070E15
			internal MeshUtils.Edge _Dnext
			{
				get
				{
					return this._Rprev._Sym;
				}
				set
				{
					this._Rprev._Sym = value;
				}
			}

			// Token: 0x17000442 RID: 1090
			// (get) Token: 0x06001681 RID: 5761 RVA: 0x00072C23 File Offset: 0x00070E23
			// (set) Token: 0x06001682 RID: 5762 RVA: 0x00072C30 File Offset: 0x00070E30
			internal MeshUtils.Edge _Rnext
			{
				get
				{
					return this._Oprev._Sym;
				}
				set
				{
					this._Oprev._Sym = value;
				}
			}

			// Token: 0x06001683 RID: 5763 RVA: 0x00002050 File Offset: 0x00000250
			internal Edge()
			{
			}

			// Token: 0x06001684 RID: 5764 RVA: 0x00072C3E File Offset: 0x00070E3E
			internal static void EnsureFirst(ref MeshUtils.Edge e)
			{
				if (e == e._pair._eSym)
				{
					e = e._Sym;
				}
			}

			// Token: 0x0400121F RID: 4639
			internal MeshUtils.EdgePair _pair;

			// Token: 0x04001220 RID: 4640
			internal MeshUtils.Edge _next;

			// Token: 0x04001221 RID: 4641
			internal MeshUtils.Edge _Sym;

			// Token: 0x04001222 RID: 4642
			internal MeshUtils.Edge _Onext;

			// Token: 0x04001223 RID: 4643
			internal MeshUtils.Edge _Lnext;

			// Token: 0x04001224 RID: 4644
			internal MeshUtils.Vertex _Org;

			// Token: 0x04001225 RID: 4645
			internal MeshUtils.Face _Lface;

			// Token: 0x04001226 RID: 4646
			internal Tess.ActiveRegion _activeRegion;

			// Token: 0x04001227 RID: 4647
			internal int _winding;
		}
	}
}
