﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000CF RID: 207
	public class Dict<TValue> where TValue : class
	{
		// Token: 0x060006D0 RID: 1744 RVA: 0x00028050 File Offset: 0x00026250
		public Dict(Dict<TValue>.LessOrEqual leq)
		{
			this._leq = leq;
			this._head = new Dict<TValue>.Node
			{
				_key = default(TValue)
			};
			this._head._prev = this._head;
			this._head._next = this._head;
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x000280A3 File Offset: 0x000262A3
		public Dict<TValue>.Node Insert(TValue key)
		{
			return this.InsertBefore(this._head, key);
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x000280B4 File Offset: 0x000262B4
		public Dict<TValue>.Node InsertBefore(Dict<TValue>.Node node, TValue key)
		{
			do
			{
				node = node._prev;
			}
			while (node._key != null && !this._leq(node._key, key));
			Dict<TValue>.Node node2 = new Dict<TValue>.Node
			{
				_key = key
			};
			node2._next = node._next;
			node._next._prev = node2;
			node2._prev = node;
			node._next = node2;
			return node2;
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x00028120 File Offset: 0x00026320
		public Dict<TValue>.Node Find(TValue key)
		{
			Dict<TValue>.Node node = this._head;
			do
			{
				node = node._next;
			}
			while (node._key != null && !this._leq(key, node._key));
			return node;
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x0002815D File Offset: 0x0002635D
		public Dict<TValue>.Node Min()
		{
			return this._head._next;
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x0002816A File Offset: 0x0002636A
		public void Remove(Dict<TValue>.Node node)
		{
			node._next._prev = node._prev;
			node._prev._next = node._next;
		}

		// Token: 0x04000733 RID: 1843
		private Dict<TValue>.LessOrEqual _leq;

		// Token: 0x04000734 RID: 1844
		private Dict<TValue>.Node _head;

		// Token: 0x02000343 RID: 835
		public class Node
		{
			// Token: 0x17000437 RID: 1079
			// (get) Token: 0x06001667 RID: 5735 RVA: 0x00072ADA File Offset: 0x00070CDA
			public TValue Key
			{
				get
				{
					return this._key;
				}
			}

			// Token: 0x17000438 RID: 1080
			// (get) Token: 0x06001668 RID: 5736 RVA: 0x00072AE2 File Offset: 0x00070CE2
			public Dict<TValue>.Node Prev
			{
				get
				{
					return this._prev;
				}
			}

			// Token: 0x17000439 RID: 1081
			// (get) Token: 0x06001669 RID: 5737 RVA: 0x00072AEA File Offset: 0x00070CEA
			public Dict<TValue>.Node Next
			{
				get
				{
					return this._next;
				}
			}

			// Token: 0x0400120A RID: 4618
			internal TValue _key;

			// Token: 0x0400120B RID: 4619
			internal Dict<TValue>.Node _prev;

			// Token: 0x0400120C RID: 4620
			internal Dict<TValue>.Node _next;
		}

		// Token: 0x02000344 RID: 836
		// (Invoke) Token: 0x0600166C RID: 5740
		public delegate bool LessOrEqual(TValue lhs, TValue rhs);
	}
}
