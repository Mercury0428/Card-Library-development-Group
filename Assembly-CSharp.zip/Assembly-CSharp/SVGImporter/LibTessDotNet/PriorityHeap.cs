﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D5 RID: 213
	public class PriorityHeap<TValue> where TValue : class
	{
		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000700 RID: 1792 RVA: 0x00029278 File Offset: 0x00027478
		public bool Empty
		{
			get
			{
				return this._size == 0;
			}
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00029284 File Offset: 0x00027484
		public PriorityHeap(int initialSize, PriorityHeap<TValue>.LessOrEqual leq)
		{
			this._leq = leq;
			this._nodes = new int[initialSize + 1];
			this._handles = new PriorityHeap<TValue>.HandleElem[initialSize + 1];
			this._size = 0;
			this._max = initialSize;
			this._freeList = 0;
			this._initialized = false;
			this._nodes[1] = 1;
			this._handles[1] = new PriorityHeap<TValue>.HandleElem
			{
				_key = default(TValue)
			};
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x000292F8 File Offset: 0x000274F8
		private void FloatDown(int curr)
		{
			int num = this._nodes[curr];
			for (;;)
			{
				int num2 = curr << 1;
				if (num2 < this._size && this._leq(this._handles[this._nodes[num2 + 1]]._key, this._handles[this._nodes[num2]]._key))
				{
					num2++;
				}
				int num3 = this._nodes[num2];
				if (num2 > this._size || this._leq(this._handles[num]._key, this._handles[num3]._key))
				{
					break;
				}
				this._nodes[curr] = num3;
				this._handles[num3]._node = curr;
				curr = num2;
			}
			this._nodes[curr] = num;
			this._handles[num]._node = curr;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x000293C8 File Offset: 0x000275C8
		private void FloatUp(int curr)
		{
			int num = this._nodes[curr];
			for (;;)
			{
				int num2 = curr >> 1;
				int num3 = this._nodes[num2];
				if (num2 == 0 || this._leq(this._handles[num3]._key, this._handles[num]._key))
				{
					break;
				}
				this._nodes[curr] = num3;
				this._handles[num3]._node = curr;
				curr = num2;
			}
			this._nodes[curr] = num;
			this._handles[num]._node = curr;
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00029448 File Offset: 0x00027648
		public void Init()
		{
			for (int i = this._size; i >= 1; i--)
			{
				this.FloatDown(i);
			}
			this._initialized = true;
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00029474 File Offset: 0x00027674
		public PQHandle Insert(TValue value)
		{
			int num = this._size + 1;
			this._size = num;
			int num2 = num;
			if (num2 * 2 > this._max)
			{
				this._max <<= 1;
				Array.Resize<int>(ref this._nodes, this._max + 1);
				Array.Resize<PriorityHeap<TValue>.HandleElem>(ref this._handles, this._max + 1);
			}
			int num3;
			if (this._freeList == 0)
			{
				num3 = num2;
			}
			else
			{
				num3 = this._freeList;
				this._freeList = this._handles[num3]._node;
			}
			this._nodes[num2] = num3;
			if (this._handles[num3] == null)
			{
				this._handles[num3] = new PriorityHeap<TValue>.HandleElem
				{
					_key = value,
					_node = num2
				};
			}
			else
			{
				this._handles[num3]._node = num2;
				this._handles[num3]._key = value;
			}
			if (this._initialized)
			{
				this.FloatUp(num2);
			}
			return new PQHandle
			{
				_handle = num3
			};
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x00029564 File Offset: 0x00027764
		public TValue ExtractMin()
		{
			int num = this._nodes[1];
			TValue key = this._handles[num]._key;
			if (this._size > 0)
			{
				this._nodes[1] = this._nodes[this._size];
				this._handles[this._nodes[1]]._node = 1;
				this._handles[num]._key = default(TValue);
				this._handles[num]._node = this._freeList;
				this._freeList = num;
				int num2 = this._size - 1;
				this._size = num2;
				if (num2 > 0)
				{
					this.FloatDown(1);
				}
			}
			return key;
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00029602 File Offset: 0x00027802
		public TValue Minimum()
		{
			return this._handles[this._nodes[1]]._key;
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00029618 File Offset: 0x00027818
		public void Remove(PQHandle handle)
		{
			int handle2 = handle._handle;
			int node = this._handles[handle2]._node;
			this._nodes[node] = this._nodes[this._size];
			this._handles[this._nodes[node]]._node = node;
			int num = node;
			int num2 = this._size - 1;
			this._size = num2;
			if (num <= num2)
			{
				if (node <= 1 || this._leq(this._handles[this._nodes[node >> 1]]._key, this._handles[this._nodes[node]]._key))
				{
					this.FloatDown(node);
				}
				else
				{
					this.FloatUp(node);
				}
			}
			this._handles[handle2]._key = default(TValue);
			this._handles[handle2]._node = this._freeList;
			this._freeList = handle2;
		}

		// Token: 0x04000740 RID: 1856
		private PriorityHeap<TValue>.LessOrEqual _leq;

		// Token: 0x04000741 RID: 1857
		private int[] _nodes;

		// Token: 0x04000742 RID: 1858
		private PriorityHeap<TValue>.HandleElem[] _handles;

		// Token: 0x04000743 RID: 1859
		private int _size;

		// Token: 0x04000744 RID: 1860
		private int _max;

		// Token: 0x04000745 RID: 1861
		private int _freeList;

		// Token: 0x04000746 RID: 1862
		private bool _initialized;

		// Token: 0x02000349 RID: 841
		// (Invoke) Token: 0x06001686 RID: 5766
		public delegate bool LessOrEqual(TValue lhs, TValue rhs);

		// Token: 0x0200034A RID: 842
		protected class HandleElem
		{
			// Token: 0x04001228 RID: 4648
			internal TValue _key;

			// Token: 0x04001229 RID: 4649
			internal int _node;
		}
	}
}
