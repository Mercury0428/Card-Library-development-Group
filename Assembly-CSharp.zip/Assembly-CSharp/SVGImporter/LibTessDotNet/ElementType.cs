﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D9 RID: 217
	public enum ElementType
	{
		// Token: 0x04000768 RID: 1896
		Polygons,
		// Token: 0x04000769 RID: 1897
		ConnectedPolygons,
		// Token: 0x0400076A RID: 1898
		BoundaryContours
	}
}
