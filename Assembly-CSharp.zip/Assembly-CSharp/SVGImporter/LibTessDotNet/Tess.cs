﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D7 RID: 215
	public class Tess
	{
		// Token: 0x06000711 RID: 1809 RVA: 0x00029BE1 File Offset: 0x00027DE1
		private Tess.ActiveRegion RegionBelow(Tess.ActiveRegion reg)
		{
			return reg._nodeUp._prev._key;
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00029BF3 File Offset: 0x00027DF3
		private Tess.ActiveRegion RegionAbove(Tess.ActiveRegion reg)
		{
			return reg._nodeUp._next._key;
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x00029C08 File Offset: 0x00027E08
		private bool EdgeLeq(Tess.ActiveRegion reg1, Tess.ActiveRegion reg2)
		{
			MeshUtils.Edge eUp = reg1._eUp;
			MeshUtils.Edge eUp2 = reg2._eUp;
			if (eUp._Dst == this._event)
			{
				if (eUp2._Dst != this._event)
				{
					return Geom.EdgeSign(eUp2._Dst, this._event, eUp2._Org) <= 0f;
				}
				if (Geom.VertLeq(eUp._Org, eUp2._Org))
				{
					return Geom.EdgeSign(eUp2._Dst, eUp._Org, eUp2._Org) <= 0f;
				}
				return Geom.EdgeSign(eUp._Dst, eUp2._Org, eUp._Org) >= 0f;
			}
			else
			{
				if (eUp2._Dst == this._event)
				{
					return Geom.EdgeSign(eUp._Dst, this._event, eUp._Org) >= 0f;
				}
				float num = Geom.EdgeEval(eUp._Dst, this._event, eUp._Org);
				float num2 = Geom.EdgeEval(eUp2._Dst, this._event, eUp2._Org);
				return num >= num2;
			}
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x00029D20 File Offset: 0x00027F20
		private void DeleteRegion(Tess.ActiveRegion reg)
		{
			bool fixUpperEdge = reg._fixUpperEdge;
			reg._eUp._activeRegion = null;
			this._dict.Remove(reg._nodeUp);
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x00029D46 File Offset: 0x00027F46
		private void FixUpperEdge(Tess.ActiveRegion reg, MeshUtils.Edge newEdge)
		{
			this._mesh.Delete(reg._eUp);
			reg._fixUpperEdge = false;
			reg._eUp = newEdge;
			newEdge._activeRegion = reg;
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x00029D70 File Offset: 0x00027F70
		private Tess.ActiveRegion TopLeftRegion(Tess.ActiveRegion reg)
		{
			MeshUtils.Vertex org = reg._eUp._Org;
			do
			{
				reg = this.RegionAbove(reg);
			}
			while (reg._eUp._Org == org);
			if (reg._fixUpperEdge)
			{
				MeshUtils.Edge newEdge = this._mesh.Connect(this.RegionBelow(reg)._eUp._Sym, reg._eUp._Lnext);
				this.FixUpperEdge(reg, newEdge);
				reg = this.RegionAbove(reg);
			}
			return reg;
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x00029DE4 File Offset: 0x00027FE4
		private Tess.ActiveRegion TopRightRegion(Tess.ActiveRegion reg)
		{
			MeshUtils.Vertex dst = reg._eUp._Dst;
			do
			{
				reg = this.RegionAbove(reg);
			}
			while (reg._eUp._Dst == dst);
			return reg;
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x00029E18 File Offset: 0x00028018
		private Tess.ActiveRegion AddRegionBelow(Tess.ActiveRegion regAbove, MeshUtils.Edge eNewUp)
		{
			Tess.ActiveRegion activeRegion = new Tess.ActiveRegion();
			activeRegion._eUp = eNewUp;
			activeRegion._nodeUp = this._dict.InsertBefore(regAbove._nodeUp, activeRegion);
			activeRegion._fixUpperEdge = false;
			activeRegion._sentinel = false;
			activeRegion._dirty = false;
			eNewUp._activeRegion = activeRegion;
			return activeRegion;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x00029E67 File Offset: 0x00028067
		private void ComputeWinding(Tess.ActiveRegion reg)
		{
			reg._windingNumber = this.RegionAbove(reg)._windingNumber + reg._eUp._winding;
			reg._inside = Geom.IsWindingInside(this._windingRule, reg._windingNumber);
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x00029EA0 File Offset: 0x000280A0
		private void FinishRegion(Tess.ActiveRegion reg)
		{
			MeshUtils.Edge eUp = reg._eUp;
			MeshUtils.Face lface = eUp._Lface;
			lface._inside = reg._inside;
			lface._anEdge = eUp;
			this.DeleteRegion(reg);
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x00029ED4 File Offset: 0x000280D4
		private MeshUtils.Edge FinishLeftRegions(Tess.ActiveRegion regFirst, Tess.ActiveRegion regLast)
		{
			Tess.ActiveRegion activeRegion = regFirst;
			MeshUtils.Edge eUp = regFirst._eUp;
			while (activeRegion != regLast)
			{
				activeRegion._fixUpperEdge = false;
				Tess.ActiveRegion activeRegion2 = this.RegionBelow(activeRegion);
				MeshUtils.Edge edge = activeRegion2._eUp;
				if (edge._Org != eUp._Org)
				{
					if (!activeRegion2._fixUpperEdge)
					{
						this.FinishRegion(activeRegion);
						break;
					}
					edge = this._mesh.Connect(eUp._Lprev, edge._Sym);
					this.FixUpperEdge(activeRegion2, edge);
				}
				if (eUp._Onext != edge)
				{
					this._mesh.Splice(edge._Oprev, edge);
					this._mesh.Splice(eUp, edge);
				}
				this.FinishRegion(activeRegion);
				eUp = activeRegion2._eUp;
				activeRegion = activeRegion2;
			}
			return eUp;
		}

		// Token: 0x0600071C RID: 1820 RVA: 0x00029F84 File Offset: 0x00028184
		private void AddRightEdges(Tess.ActiveRegion regUp, MeshUtils.Edge eFirst, MeshUtils.Edge eLast, MeshUtils.Edge eTopLeft, bool cleanUp)
		{
			bool flag = true;
			MeshUtils.Edge edge = eFirst;
			do
			{
				this.AddRegionBelow(regUp, edge._Sym);
				edge = edge._Onext;
			}
			while (edge != eLast);
			if (eTopLeft == null)
			{
				eTopLeft = this.RegionBelow(regUp)._eUp._Rprev;
			}
			Tess.ActiveRegion activeRegion = regUp;
			MeshUtils.Edge edge2 = eTopLeft;
			for (;;)
			{
				Tess.ActiveRegion activeRegion2 = this.RegionBelow(activeRegion);
				edge = activeRegion2._eUp._Sym;
				if (edge._Org != edge2._Org)
				{
					break;
				}
				if (edge._Onext != edge2)
				{
					this._mesh.Splice(edge._Oprev, edge);
					this._mesh.Splice(edge2._Oprev, edge);
				}
				activeRegion2._windingNumber = activeRegion._windingNumber - edge._winding;
				activeRegion2._inside = Geom.IsWindingInside(this._windingRule, activeRegion2._windingNumber);
				activeRegion._dirty = true;
				if (!flag && this.CheckForRightSplice(activeRegion))
				{
					Geom.AddWinding(edge, edge2);
					this.DeleteRegion(activeRegion);
					this._mesh.Delete(edge2);
				}
				flag = false;
				activeRegion = activeRegion2;
				edge2 = edge;
			}
			activeRegion._dirty = true;
			if (cleanUp)
			{
				this.WalkDirtyRegions(activeRegion);
			}
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x0002A097 File Offset: 0x00028297
		private void SpliceMergeVertices(MeshUtils.Edge e1, MeshUtils.Edge e2)
		{
			this._mesh.Splice(e1, e2);
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x0002A0A8 File Offset: 0x000282A8
		private void VertexWeights(MeshUtils.Vertex isect, MeshUtils.Vertex org, MeshUtils.Vertex dst, out float w0, out float w1)
		{
			float num = Geom.VertL1dist(org, isect);
			float num2 = Geom.VertL1dist(dst, isect);
			w0 = 0.5f * num2 / (num + num2);
			w1 = 0.5f * num / (num + num2);
			isect._coords.X = isect._coords.X + (w0 * org._coords.X + w1 * dst._coords.X);
			isect._coords.Y = isect._coords.Y + (w0 * org._coords.Y + w1 * dst._coords.Y);
			isect._coords.Z = isect._coords.Z + (w0 * org._coords.Z + w1 * dst._coords.Z);
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0002A16C File Offset: 0x0002836C
		private void GetIntersectData(MeshUtils.Vertex isect, MeshUtils.Vertex orgUp, MeshUtils.Vertex dstUp, MeshUtils.Vertex orgLo, MeshUtils.Vertex dstLo)
		{
			isect._coords = Vec3.Zero;
			float num;
			float num2;
			this.VertexWeights(isect, orgUp, dstUp, out num, out num2);
			float num3;
			float num4;
			this.VertexWeights(isect, orgLo, dstLo, out num3, out num4);
			if (this._combineCallback != null)
			{
				isect._data = this._combineCallback(isect._coords, new object[]
				{
					orgUp._data,
					dstUp._data,
					orgLo._data,
					dstLo._data
				}, new float[]
				{
					num,
					num2,
					num3,
					num4
				});
			}
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0002A204 File Offset: 0x00028404
		private bool CheckForRightSplice(Tess.ActiveRegion regUp)
		{
			Tess.ActiveRegion activeRegion = this.RegionBelow(regUp);
			MeshUtils.Edge eUp = regUp._eUp;
			MeshUtils.Edge eUp2 = activeRegion._eUp;
			if (Geom.VertLeq(eUp._Org, eUp2._Org))
			{
				if (Geom.EdgeSign(eUp2._Dst, eUp._Org, eUp2._Org) > 0f)
				{
					return false;
				}
				if (!Geom.VertEq(eUp._Org, eUp2._Org))
				{
					this._mesh.SplitEdge(eUp2._Sym);
					this._mesh.Splice(eUp, eUp2._Oprev);
					regUp._dirty = (activeRegion._dirty = true);
				}
				else if (eUp._Org != eUp2._Org)
				{
					this._pq.Remove(eUp._Org._pqHandle);
					this.SpliceMergeVertices(eUp2._Oprev, eUp);
				}
			}
			else
			{
				if (Geom.EdgeSign(eUp._Dst, eUp2._Org, eUp._Org) < 0f)
				{
					return false;
				}
				this.RegionAbove(regUp)._dirty = (regUp._dirty = true);
				this._mesh.SplitEdge(eUp._Sym);
				this._mesh.Splice(eUp2._Oprev, eUp);
			}
			return true;
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0002A338 File Offset: 0x00028538
		private bool CheckForLeftSplice(Tess.ActiveRegion regUp)
		{
			Tess.ActiveRegion activeRegion = this.RegionBelow(regUp);
			MeshUtils.Edge eUp = regUp._eUp;
			MeshUtils.Edge eUp2 = activeRegion._eUp;
			if (Geom.VertLeq(eUp._Dst, eUp2._Dst))
			{
				if (Geom.EdgeSign(eUp._Dst, eUp2._Dst, eUp._Org) < 0f)
				{
					return false;
				}
				this.RegionAbove(regUp)._dirty = (regUp._dirty = true);
				MeshUtils.Edge edge = this._mesh.SplitEdge(eUp);
				this._mesh.Splice(eUp2._Sym, edge);
				edge._Lface._inside = regUp._inside;
			}
			else
			{
				if (Geom.EdgeSign(eUp2._Dst, eUp._Dst, eUp2._Org) > 0f)
				{
					return false;
				}
				regUp._dirty = (activeRegion._dirty = true);
				MeshUtils.Edge edge2 = this._mesh.SplitEdge(eUp2);
				this._mesh.Splice(eUp._Lnext, eUp2._Sym);
				edge2._Rface._inside = regUp._inside;
			}
			return true;
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0002A440 File Offset: 0x00028640
		private bool CheckForIntersect(Tess.ActiveRegion regUp)
		{
			Tess.ActiveRegion activeRegion = this.RegionBelow(regUp);
			MeshUtils.Edge eUp = regUp._eUp;
			MeshUtils.Edge edge = activeRegion._eUp;
			MeshUtils.Vertex org = eUp._Org;
			MeshUtils.Vertex org2 = edge._Org;
			MeshUtils.Vertex dst = eUp._Dst;
			MeshUtils.Vertex dst2 = edge._Dst;
			if (org == org2)
			{
				return false;
			}
			float num = Math.Min(org._t, dst._t);
			float num2 = Math.Max(org2._t, dst2._t);
			if (num > num2)
			{
				return false;
			}
			if (Geom.VertLeq(org, org2))
			{
				if (Geom.EdgeSign(dst2, org, org2) > 0f)
				{
					return false;
				}
			}
			else if (Geom.EdgeSign(dst, org2, org) < 0f)
			{
				return false;
			}
			MeshUtils.Vertex vertex = new MeshUtils.Vertex();
			Geom.EdgeIntersect(dst, org, dst2, org2, vertex);
			if (Geom.VertLeq(vertex, this._event))
			{
				vertex._s = this._event._s;
				vertex._t = this._event._t;
			}
			MeshUtils.Vertex vertex2 = Geom.VertLeq(org, org2) ? org : org2;
			if (Geom.VertLeq(vertex2, vertex))
			{
				vertex._s = vertex2._s;
				vertex._t = vertex2._t;
			}
			if (Geom.VertEq(vertex, org) || Geom.VertEq(vertex, org2))
			{
				this.CheckForRightSplice(regUp);
				return false;
			}
			if ((!Geom.VertEq(dst, this._event) && Geom.EdgeSign(dst, this._event, vertex) >= 0f) || (!Geom.VertEq(dst2, this._event) && Geom.EdgeSign(dst2, this._event, vertex) <= 0f))
			{
				if (dst2 == this._event)
				{
					this._mesh.SplitEdge(eUp._Sym);
					this._mesh.Splice(edge._Sym, eUp);
					regUp = this.TopLeftRegion(regUp);
					eUp = this.RegionBelow(regUp)._eUp;
					this.FinishLeftRegions(this.RegionBelow(regUp), activeRegion);
					this.AddRightEdges(regUp, eUp._Oprev, eUp, eUp, true);
					return true;
				}
				if (dst == this._event)
				{
					this._mesh.SplitEdge(edge._Sym);
					this._mesh.Splice(eUp._Lnext, edge._Oprev);
					activeRegion = regUp;
					regUp = this.TopRightRegion(regUp);
					MeshUtils.Edge rprev = this.RegionBelow(regUp)._eUp._Rprev;
					activeRegion._eUp = edge._Oprev;
					edge = this.FinishLeftRegions(activeRegion, null);
					this.AddRightEdges(regUp, edge._Onext, eUp._Rprev, rprev, true);
					return true;
				}
				if (Geom.EdgeSign(dst, this._event, vertex) >= 0f)
				{
					this.RegionAbove(regUp)._dirty = (regUp._dirty = true);
					this._mesh.SplitEdge(eUp._Sym);
					eUp._Org._s = this._event._s;
					eUp._Org._t = this._event._t;
				}
				if (Geom.EdgeSign(dst2, this._event, vertex) <= 0f)
				{
					regUp._dirty = (activeRegion._dirty = true);
					this._mesh.SplitEdge(edge._Sym);
					edge._Org._s = this._event._s;
					edge._Org._t = this._event._t;
				}
				return false;
			}
			else
			{
				this._mesh.SplitEdge(eUp._Sym);
				this._mesh.SplitEdge(edge._Sym);
				this._mesh.Splice(edge._Oprev, eUp);
				eUp._Org._s = vertex._s;
				eUp._Org._t = vertex._t;
				eUp._Org._pqHandle = this._pq.Insert(eUp._Org);
				if (eUp._Org._pqHandle._handle == PQHandle.Invalid)
				{
					throw new InvalidOperationException("PQHandle should not be invalid");
				}
				this.GetIntersectData(eUp._Org, org, dst, org2, dst2);
				this.RegionAbove(regUp)._dirty = (regUp._dirty = (activeRegion._dirty = true));
				return false;
			}
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0002A85C File Offset: 0x00028A5C
		private void WalkDirtyRegions(Tess.ActiveRegion regUp)
		{
			Tess.ActiveRegion activeRegion = this.RegionBelow(regUp);
			for (;;)
			{
				if (!activeRegion._dirty)
				{
					if (!regUp._dirty)
					{
						activeRegion = regUp;
						regUp = this.RegionAbove(regUp);
						if (regUp == null || !regUp._dirty)
						{
							break;
						}
					}
					regUp._dirty = false;
					MeshUtils.Edge eUp = regUp._eUp;
					MeshUtils.Edge eUp2 = activeRegion._eUp;
					if (eUp._Dst != eUp2._Dst && this.CheckForLeftSplice(regUp))
					{
						if (activeRegion._fixUpperEdge)
						{
							this.DeleteRegion(activeRegion);
							this._mesh.Delete(eUp2);
							activeRegion = this.RegionBelow(regUp);
							eUp2 = activeRegion._eUp;
						}
						else if (regUp._fixUpperEdge)
						{
							this.DeleteRegion(regUp);
							this._mesh.Delete(eUp);
							regUp = this.RegionAbove(activeRegion);
							eUp = regUp._eUp;
						}
					}
					if (eUp._Org != eUp2._Org)
					{
						if (eUp._Dst != eUp2._Dst && !regUp._fixUpperEdge && !activeRegion._fixUpperEdge && (eUp._Dst == this._event || eUp2._Dst == this._event))
						{
							if (this.CheckForIntersect(regUp))
							{
								return;
							}
						}
						else
						{
							this.CheckForRightSplice(regUp);
						}
					}
					if (eUp._Org == eUp2._Org && eUp._Dst == eUp2._Dst)
					{
						Geom.AddWinding(eUp2, eUp);
						this.DeleteRegion(regUp);
						this._mesh.Delete(eUp);
						regUp = this.RegionAbove(activeRegion);
					}
				}
				else
				{
					regUp = activeRegion;
					activeRegion = this.RegionBelow(activeRegion);
				}
			}
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0002A9CC File Offset: 0x00028BCC
		private void ConnectRightVertex(Tess.ActiveRegion regUp, MeshUtils.Edge eBottomLeft)
		{
			MeshUtils.Edge edge = eBottomLeft._Onext;
			Tess.ActiveRegion activeRegion = this.RegionBelow(regUp);
			MeshUtils.Edge eUp = regUp._eUp;
			MeshUtils.Edge eUp2 = activeRegion._eUp;
			bool flag = false;
			if (eUp._Dst != eUp2._Dst)
			{
				this.CheckForIntersect(regUp);
			}
			if (Geom.VertEq(eUp._Org, this._event))
			{
				this._mesh.Splice(edge._Oprev, eUp);
				regUp = this.TopLeftRegion(regUp);
				edge = this.RegionBelow(regUp)._eUp;
				this.FinishLeftRegions(this.RegionBelow(regUp), activeRegion);
				flag = true;
			}
			if (Geom.VertEq(eUp2._Org, this._event))
			{
				this._mesh.Splice(eBottomLeft, eUp2._Oprev);
				eBottomLeft = this.FinishLeftRegions(activeRegion, null);
				flag = true;
			}
			if (flag)
			{
				this.AddRightEdges(regUp, eBottomLeft._Onext, edge, edge, true);
				return;
			}
			MeshUtils.Edge edge2;
			if (Geom.VertLeq(eUp2._Org, eUp._Org))
			{
				edge2 = eUp2._Oprev;
			}
			else
			{
				edge2 = eUp;
			}
			edge2 = this._mesh.Connect(eBottomLeft._Lprev, edge2);
			this.AddRightEdges(regUp, edge2, edge2._Onext, edge2._Onext, false);
			edge2._Sym._activeRegion._fixUpperEdge = true;
			this.WalkDirtyRegions(regUp);
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0002AB0C File Offset: 0x00028D0C
		private void ConnectLeftDegenerate(Tess.ActiveRegion regUp, MeshUtils.Vertex vEvent)
		{
			MeshUtils.Edge eUp = regUp._eUp;
			if (Geom.VertEq(eUp._Org, vEvent))
			{
				throw new InvalidOperationException("Vertices should have been merged before");
			}
			if (!Geom.VertEq(eUp._Dst, vEvent))
			{
				this._mesh.SplitEdge(eUp._Sym);
				if (regUp._fixUpperEdge)
				{
					this._mesh.Delete(eUp._Onext);
					regUp._fixUpperEdge = false;
				}
				this._mesh.Splice(vEvent._anEdge, eUp);
				this.SweepEvent(vEvent);
				return;
			}
			throw new InvalidOperationException("Vertices should have been merged before");
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x0002ABA0 File Offset: 0x00028DA0
		private void ConnectLeftVertex(MeshUtils.Vertex vEvent)
		{
			Tess.ActiveRegion activeRegion = new Tess.ActiveRegion();
			activeRegion._eUp = vEvent._anEdge._Sym;
			Tess.ActiveRegion key = this._dict.Find(activeRegion).Key;
			Tess.ActiveRegion activeRegion2 = this.RegionBelow(key);
			if (activeRegion2 == null)
			{
				return;
			}
			MeshUtils.Edge eUp = key._eUp;
			MeshUtils.Edge eUp2 = activeRegion2._eUp;
			if (Geom.EdgeSign(eUp._Dst, vEvent, eUp._Org) == 0f)
			{
				this.ConnectLeftDegenerate(key, vEvent);
				return;
			}
			Tess.ActiveRegion activeRegion3 = Geom.VertLeq(eUp2._Dst, eUp._Dst) ? key : activeRegion2;
			if (key._inside || activeRegion3._fixUpperEdge)
			{
				MeshUtils.Edge edge;
				if (activeRegion3 == key)
				{
					edge = this._mesh.Connect(vEvent._anEdge._Sym, eUp._Lnext);
				}
				else
				{
					edge = this._mesh.Connect(eUp2._Dnext, vEvent._anEdge)._Sym;
				}
				if (activeRegion3._fixUpperEdge)
				{
					this.FixUpperEdge(activeRegion3, edge);
				}
				else
				{
					this.ComputeWinding(this.AddRegionBelow(key, edge));
				}
				this.SweepEvent(vEvent);
				return;
			}
			this.AddRightEdges(key, vEvent._anEdge, vEvent._anEdge, null, true);
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x0002ACC4 File Offset: 0x00028EC4
		private void SweepEvent(MeshUtils.Vertex vEvent)
		{
			this._event = vEvent;
			MeshUtils.Edge edge = vEvent._anEdge;
			while (edge._activeRegion == null)
			{
				edge = edge._Onext;
				if (edge == vEvent._anEdge)
				{
					this.ConnectLeftVertex(vEvent);
					return;
				}
			}
			Tess.ActiveRegion activeRegion = this.TopLeftRegion(edge._activeRegion);
			Tess.ActiveRegion activeRegion2 = this.RegionBelow(activeRegion);
			MeshUtils.Edge eUp = activeRegion2._eUp;
			MeshUtils.Edge edge2 = this.FinishLeftRegions(activeRegion2, null);
			if (edge2._Onext == eUp)
			{
				this.ConnectRightVertex(activeRegion, edge2);
				return;
			}
			this.AddRightEdges(activeRegion, edge2._Onext, eUp, eUp, true);
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x0002AD4C File Offset: 0x00028F4C
		private void AddSentinel(float smin, float smax, float t)
		{
			MeshUtils.Edge edge = this._mesh.MakeEdge();
			edge._Org._s = smax;
			edge._Org._t = t;
			edge._Dst._s = smin;
			edge._Dst._t = t;
			this._event = edge._Dst;
			Tess.ActiveRegion activeRegion = new Tess.ActiveRegion();
			activeRegion._eUp = edge;
			activeRegion._windingNumber = 0;
			activeRegion._inside = false;
			activeRegion._fixUpperEdge = false;
			activeRegion._sentinel = true;
			activeRegion._dirty = false;
			activeRegion._nodeUp = this._dict.Insert(activeRegion);
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0002ADE4 File Offset: 0x00028FE4
		private void InitEdgeDict()
		{
			this._dict = new Dict<Tess.ActiveRegion>(new Dict<Tess.ActiveRegion>.LessOrEqual(this.EdgeLeq));
			float num = this._bmaxX - this._bminX;
			float num2 = this._bmaxY - this._bminY;
			float smin = this._bminX - num;
			float smax = this._bmaxX + num;
			float t = this._bminY - num2;
			float t2 = this._bmaxY + num2;
			this.AddSentinel(smin, smax, t);
			this.AddSentinel(smin, smax, t2);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x0002AE60 File Offset: 0x00029060
		private void DoneEdgeDict()
		{
			Tess.ActiveRegion key;
			while ((key = this._dict.Min().Key) != null)
			{
				bool sentinel = key._sentinel;
				this.DeleteRegion(key);
			}
			this._dict = null;
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0002AE98 File Offset: 0x00029098
		private void RemoveDegenerateEdges()
		{
			MeshUtils.Edge eHead = this._mesh._eHead;
			MeshUtils.Edge next;
			for (MeshUtils.Edge edge = eHead._next; edge != eHead; edge = next)
			{
				next = edge._next;
				MeshUtils.Edge lnext = edge._Lnext;
				if (Geom.VertEq(edge._Org, edge._Dst) && edge._Lnext._Lnext != edge)
				{
					this.SpliceMergeVertices(lnext, edge);
					this._mesh.Delete(edge);
					edge = lnext;
					lnext = edge._Lnext;
				}
				if (lnext._Lnext == edge)
				{
					if (lnext != edge)
					{
						if (lnext == next || lnext == next._Sym)
						{
							next = next._next;
						}
						this._mesh.Delete(lnext);
					}
					if (edge == next || edge == next._Sym)
					{
						next = next._next;
					}
					this._mesh.Delete(edge);
				}
			}
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x0002AF60 File Offset: 0x00029160
		private void InitPriorityQ()
		{
			MeshUtils.Vertex vHead = this._mesh._vHead;
			int num = 0;
			for (MeshUtils.Vertex next = vHead._next; next != vHead; next = next._next)
			{
				num++;
			}
			num += 8;
			this._pq = new PriorityQueue<MeshUtils.Vertex>(num, new PriorityHeap<MeshUtils.Vertex>.LessOrEqual(Geom.VertLeq));
			vHead = this._mesh._vHead;
			for (MeshUtils.Vertex next = vHead._next; next != vHead; next = next._next)
			{
				next._pqHandle = this._pq.Insert(next);
				if (next._pqHandle._handle == PQHandle.Invalid)
				{
					throw new InvalidOperationException("PQHandle should not be invalid");
				}
			}
			this._pq.Init();
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x0002B009 File Offset: 0x00029209
		private void DonePriorityQ()
		{
			this._pq = null;
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x0002B014 File Offset: 0x00029214
		private void RemoveDegenerateFaces()
		{
			MeshUtils.Face next;
			for (MeshUtils.Face face = this._mesh._fHead._next; face != this._mesh._fHead; face = next)
			{
				next = face._next;
				MeshUtils.Edge anEdge = face._anEdge;
				if (anEdge._Lnext._Lnext == anEdge)
				{
					Geom.AddWinding(anEdge._Onext, anEdge);
					this._mesh.Delete(anEdge);
				}
			}
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x0002B078 File Offset: 0x00029278
		protected void ComputeInterior()
		{
			this.RemoveDegenerateEdges();
			this.InitPriorityQ();
			this.RemoveDegenerateFaces();
			this.InitEdgeDict();
			MeshUtils.Vertex vertex;
			while ((vertex = this._pq.ExtractMin()) != null)
			{
				for (;;)
				{
					MeshUtils.Vertex vertex2 = this._pq.Minimum();
					if (vertex2 == null || !Geom.VertEq(vertex2, vertex))
					{
						break;
					}
					vertex2 = this._pq.ExtractMin();
					this.SpliceMergeVertices(vertex._anEdge, vertex2._anEdge);
				}
				this.SweepEvent(vertex);
			}
			this.DoneEdgeDict();
			this.DonePriorityQ();
			this.RemoveDegenerateFaces();
			this._mesh.Check();
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x0002B10A File Offset: 0x0002930A
		// (set) Token: 0x06000731 RID: 1841 RVA: 0x0002B112 File Offset: 0x00029312
		public Vec3 Normal
		{
			get
			{
				return this._normal;
			}
			set
			{
				this._normal = value;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x0002B11B File Offset: 0x0002931B
		public ContourVertex[] Vertices
		{
			get
			{
				return this._vertices;
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000733 RID: 1843 RVA: 0x0002B123 File Offset: 0x00029323
		public int VertexCount
		{
			get
			{
				return this._vertexCount;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000734 RID: 1844 RVA: 0x0002B12B File Offset: 0x0002932B
		public int[] Elements
		{
			get
			{
				return this._elements;
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x0002B133 File Offset: 0x00029333
		public int ElementCount
		{
			get
			{
				return this._elementCount;
			}
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x0002B13C File Offset: 0x0002933C
		public Tess()
		{
			this._normal = Vec3.Zero;
			this._bminX = (this._bminY = (this._bmaxX = (this._bmaxY = 0f)));
			this._windingRule = WindingRule.EvenOdd;
			this._mesh = null;
			this._vertices = null;
			this._vertexCount = 0;
			this._elements = null;
			this._elementCount = 0;
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x0002B1C0 File Offset: 0x000293C0
		private void ComputeNormal(ref Vec3 norm)
		{
			MeshUtils.Vertex next = this._mesh._vHead._next;
			float[] array = new float[]
			{
				next._coords.X,
				next._coords.Y,
				next._coords.Z
			};
			MeshUtils.Vertex[] array2 = new MeshUtils.Vertex[]
			{
				next,
				next,
				next
			};
			float[] array3 = new float[]
			{
				next._coords.X,
				next._coords.Y,
				next._coords.Z
			};
			MeshUtils.Vertex[] array4 = new MeshUtils.Vertex[]
			{
				next,
				next,
				next
			};
			while (next != this._mesh._vHead)
			{
				if (next._coords.X < array[0])
				{
					array[0] = next._coords.X;
					array2[0] = next;
				}
				if (next._coords.Y < array[1])
				{
					array[1] = next._coords.Y;
					array2[1] = next;
				}
				if (next._coords.Z < array[2])
				{
					array[2] = next._coords.Z;
					array2[2] = next;
				}
				if (next._coords.X > array3[0])
				{
					array3[0] = next._coords.X;
					array4[0] = next;
				}
				if (next._coords.Y > array3[1])
				{
					array3[1] = next._coords.Y;
					array4[1] = next;
				}
				if (next._coords.Z > array3[2])
				{
					array3[2] = next._coords.Z;
					array4[2] = next;
				}
				next = next._next;
			}
			int num = 0;
			if (array3[1] - array[1] > array3[0] - array[0])
			{
				num = 1;
			}
			if (array3[2] - array[2] > array3[num] - array[num])
			{
				num = 2;
			}
			if (array[num] >= array3[num])
			{
				norm = new Vec3
				{
					X = 0f,
					Y = 0f,
					Z = 1f
				};
				return;
			}
			float num2 = 0f;
			MeshUtils.Vertex vertex = array2[num];
			MeshUtils.Vertex vertex2 = array4[num];
			Vec3 vec;
			Vec3.Sub(ref vertex._coords, ref vertex2._coords, out vec);
			for (next = this._mesh._vHead._next; next != this._mesh._vHead; next = next._next)
			{
				Vec3 vec2;
				Vec3.Sub(ref next._coords, ref vertex2._coords, out vec2);
				Vec3 vec3;
				vec3.X = vec.Y * vec2.Z - vec.Z * vec2.Y;
				vec3.Y = vec.Z * vec2.X - vec.X * vec2.Z;
				vec3.Z = vec.X * vec2.Y - vec.Y * vec2.X;
				float num3 = vec3.X * vec3.X + vec3.Y * vec3.Y + vec3.Z * vec3.Z;
				if (num3 > num2)
				{
					num2 = num3;
					norm = vec3;
				}
			}
			if (num2 <= 0f)
			{
				norm = Vec3.Zero;
				num = Vec3.LongAxis(ref vec);
				norm[num] = 1f;
			}
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x0002B504 File Offset: 0x00029704
		private void CheckOrientation()
		{
			float num = 0f;
			for (MeshUtils.Face next = this._mesh._fHead._next; next != this._mesh._fHead; next = next._next)
			{
				MeshUtils.Edge edge = next._anEdge;
				if (edge._winding > 0)
				{
					do
					{
						num += (edge._Org._s - edge._Dst._s) * (edge._Org._t + edge._Dst._t);
						edge = edge._Lnext;
					}
					while (edge != next._anEdge);
				}
			}
			if (num < 0f)
			{
				for (MeshUtils.Vertex next2 = this._mesh._vHead._next; next2 != this._mesh._vHead; next2 = next2._next)
				{
					next2._t = -next2._t;
				}
				Vec3.Neg(ref this._tUnit);
			}
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x0002B5DC File Offset: 0x000297DC
		private void ProjectPolygon()
		{
			Vec3 normal = this._normal;
			bool flag = false;
			if (normal.X == 0f && normal.Y == 0f && normal.Z == 0f)
			{
				this.ComputeNormal(ref normal);
				flag = true;
			}
			int num = Vec3.LongAxis(ref normal);
			this._sUnit[num] = 0f;
			this._sUnit[(num + 1) % 3] = this.SUnitX;
			this._sUnit[(num + 2) % 3] = this.SUnitY;
			this._tUnit[num] = 0f;
			this._tUnit[(num + 1) % 3] = ((normal[num] > 0f) ? (-this.SUnitY) : this.SUnitY);
			this._tUnit[(num + 2) % 3] = ((normal[num] > 0f) ? this.SUnitX : (-this.SUnitX));
			for (MeshUtils.Vertex next = this._mesh._vHead._next; next != this._mesh._vHead; next = next._next)
			{
				Vec3.Dot(ref next._coords, ref this._sUnit, out next._s);
				Vec3.Dot(ref next._coords, ref this._tUnit, out next._t);
			}
			if (flag)
			{
				this.CheckOrientation();
			}
			bool flag2 = true;
			for (MeshUtils.Vertex next2 = this._mesh._vHead._next; next2 != this._mesh._vHead; next2 = next2._next)
			{
				if (flag2)
				{
					this._bminX = (this._bmaxX = next2._s);
					this._bminY = (this._bmaxY = next2._t);
					flag2 = false;
				}
				else
				{
					if (next2._s < this._bminX)
					{
						this._bminX = next2._s;
					}
					if (next2._s > this._bmaxX)
					{
						this._bmaxX = next2._s;
					}
					if (next2._t < this._bminY)
					{
						this._bminY = next2._t;
					}
					if (next2._t > this._bmaxY)
					{
						this._bmaxY = next2._t;
					}
				}
			}
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x0002B818 File Offset: 0x00029A18
		private void TessellateMonoRegion(MeshUtils.Face face)
		{
			MeshUtils.Edge edge = face._anEdge;
			while (Geom.VertLeq(edge._Dst, edge._Org))
			{
				edge = edge._Lprev;
			}
			while (Geom.VertLeq(edge._Org, edge._Dst))
			{
				edge = edge._Lnext;
			}
			MeshUtils.Edge edge2 = edge._Lprev;
			while (edge._Lnext != edge2)
			{
				if (Geom.VertLeq(edge._Dst, edge2._Org))
				{
					while (edge2._Lnext != edge && (Geom.EdgeGoesLeft(edge2._Lnext) || Geom.EdgeSign(edge2._Org, edge2._Dst, edge2._Lnext._Dst) <= 0f))
					{
						edge2 = this._mesh.Connect(edge2._Lnext, edge2)._Sym;
					}
					edge2 = edge2._Lprev;
				}
				else
				{
					while (edge2._Lnext != edge && (Geom.EdgeGoesRight(edge._Lprev) || Geom.EdgeSign(edge._Dst, edge._Org, edge._Lprev._Org) >= 0f))
					{
						edge = this._mesh.Connect(edge, edge._Lprev)._Sym;
					}
					edge = edge._Lnext;
				}
			}
			while (edge2._Lnext._Lnext != edge)
			{
				edge2 = this._mesh.Connect(edge2._Lnext, edge2)._Sym;
			}
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x0002B96C File Offset: 0x00029B6C
		private void TessellateInterior()
		{
			MeshUtils.Face next;
			for (MeshUtils.Face face = this._mesh._fHead._next; face != this._mesh._fHead; face = next)
			{
				next = face._next;
				if (face._inside)
				{
					this.TessellateMonoRegion(face);
				}
			}
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0002B9B4 File Offset: 0x00029BB4
		private void DiscardExterior()
		{
			MeshUtils.Face next;
			for (MeshUtils.Face face = this._mesh._fHead._next; face != this._mesh._fHead; face = next)
			{
				next = face._next;
				if (!face._inside)
				{
					this._mesh.ZapFace(face);
				}
			}
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x0002BA00 File Offset: 0x00029C00
		private void SetWindingNumber(int value, bool keepOnlyBoundary)
		{
			MeshUtils.Edge next;
			for (MeshUtils.Edge edge = this._mesh._eHead._next; edge != this._mesh._eHead; edge = next)
			{
				next = edge._next;
				if (edge._Rface._inside != edge._Lface._inside)
				{
					edge._winding = (edge._Lface._inside ? value : (-value));
				}
				else if (!keepOnlyBoundary)
				{
					edge._winding = 0;
				}
				else
				{
					this._mesh.Delete(edge);
				}
			}
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x0002BA81 File Offset: 0x00029C81
		private int GetNeighbourFace(MeshUtils.Edge edge)
		{
			if (edge._Rface == null)
			{
				return -1;
			}
			if (!edge._Rface._inside)
			{
				return -1;
			}
			return edge._Rface._n;
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x0002BAA8 File Offset: 0x00029CA8
		private void OutputPolymesh(ElementType elementType, int polySize)
		{
			int num = 0;
			int num2 = 0;
			if (polySize < 3)
			{
				polySize = 3;
			}
			if (polySize > 3)
			{
				this._mesh.MergeConvexFaces(polySize);
			}
			for (MeshUtils.Vertex vertex = this._mesh._vHead._next; vertex != this._mesh._vHead; vertex = vertex._next)
			{
				vertex._n = -1;
			}
			for (MeshUtils.Face next = this._mesh._fHead._next; next != this._mesh._fHead; next = next._next)
			{
				next._n = -1;
				if (next._inside)
				{
					MeshUtils.Edge edge = next._anEdge;
					int num3 = 0;
					do
					{
						MeshUtils.Vertex vertex = edge._Org;
						if (vertex._n == -1)
						{
							vertex._n = num2;
							num2++;
						}
						num3++;
						edge = edge._Lnext;
					}
					while (edge != next._anEdge);
					next._n = num;
					num++;
				}
			}
			this._elementCount = num;
			if (elementType == ElementType.ConnectedPolygons)
			{
				num *= 2;
			}
			this._elements = new int[num * polySize];
			this._vertexCount = num2;
			this._vertices = new ContourVertex[this._vertexCount];
			for (MeshUtils.Vertex vertex = this._mesh._vHead._next; vertex != this._mesh._vHead; vertex = vertex._next)
			{
				if (vertex._n != -1)
				{
					this._vertices[vertex._n].Position = vertex._coords;
					this._vertices[vertex._n].Data = vertex._data;
				}
			}
			int num4 = 0;
			for (MeshUtils.Face next = this._mesh._fHead._next; next != this._mesh._fHead; next = next._next)
			{
				if (next._inside)
				{
					MeshUtils.Edge edge = next._anEdge;
					int num3 = 0;
					do
					{
						MeshUtils.Vertex vertex = edge._Org;
						this._elements[num4++] = vertex._n;
						num3++;
						edge = edge._Lnext;
					}
					while (edge != next._anEdge);
					for (int i = num3; i < polySize; i++)
					{
						this._elements[num4++] = -1;
					}
					if (elementType == ElementType.ConnectedPolygons)
					{
						edge = next._anEdge;
						do
						{
							this._elements[num4++] = this.GetNeighbourFace(edge);
							edge = edge._Lnext;
						}
						while (edge != next._anEdge);
						for (int i = num3; i < polySize; i++)
						{
							this._elements[num4++] = -1;
						}
					}
				}
			}
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x0002BD08 File Offset: 0x00029F08
		private void OutputContours()
		{
			this._vertexCount = 0;
			this._elementCount = 0;
			for (MeshUtils.Face next = this._mesh._fHead._next; next != this._mesh._fHead; next = next._next)
			{
				if (next._inside)
				{
					MeshUtils.Edge anEdge;
					MeshUtils.Edge edge = anEdge = next._anEdge;
					do
					{
						this._vertexCount++;
						edge = edge._Lnext;
					}
					while (edge != anEdge);
					this._elementCount++;
				}
			}
			this._elements = new int[this._elementCount * 2];
			this._vertices = new ContourVertex[this._vertexCount];
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			for (MeshUtils.Face next = this._mesh._fHead._next; next != this._mesh._fHead; next = next._next)
			{
				if (next._inside)
				{
					int num4 = 0;
					MeshUtils.Edge anEdge;
					MeshUtils.Edge edge = anEdge = next._anEdge;
					do
					{
						this._vertices[num].Position = edge._Org._coords;
						this._vertices[num].Data = edge._Org._data;
						num++;
						num4++;
						edge = edge._Lnext;
					}
					while (edge != anEdge);
					this._elements[num2++] = num3;
					this._elements[num2++] = num4;
					num3 += num4;
				}
			}
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x0002BE70 File Offset: 0x0002A070
		private float SignedArea(ContourVertex[] vertices)
		{
			float num = 0f;
			for (int i = 0; i < vertices.Length; i++)
			{
				ContourVertex contourVertex = vertices[i];
				ContourVertex contourVertex2 = vertices[(i + 1) % vertices.Length];
				num += contourVertex.Position.X * contourVertex2.Position.Y;
				num -= contourVertex.Position.Y * contourVertex2.Position.X;
			}
			return num * 0.5f;
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x0002BEE2 File Offset: 0x0002A0E2
		public void AddContour(ContourVertex[] vertices)
		{
			this.AddContour(vertices, ContourOrientation.Original);
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x0002BEEC File Offset: 0x0002A0EC
		public void AddContour(ContourVertex[] vertices, ContourOrientation forceOrientation)
		{
			if (this._mesh == null)
			{
				this._mesh = new Mesh();
			}
			bool flag = false;
			if (forceOrientation != ContourOrientation.Original)
			{
				float num = this.SignedArea(vertices);
				flag = ((forceOrientation == ContourOrientation.Clockwise && num < 0f) || (forceOrientation == ContourOrientation.CounterClockwise && num > 0f));
			}
			MeshUtils.Edge edge = null;
			for (int i = 0; i < vertices.Length; i++)
			{
				if (edge == null)
				{
					edge = this._mesh.MakeEdge();
					this._mesh.Splice(edge, edge._Sym);
				}
				else
				{
					this._mesh.SplitEdge(edge);
					edge = edge._Lnext;
				}
				int num2 = flag ? (vertices.Length - 1 - i) : i;
				edge._Org._coords = vertices[num2].Position;
				edge._Org._data = vertices[num2].Data;
				edge._winding = 1;
				edge._Sym._winding = -1;
			}
		}

		// Token: 0x06000744 RID: 1860 RVA: 0x0002BFD7 File Offset: 0x0002A1D7
		public void Tessellate(WindingRule windingRule, ElementType elementType, int polySize)
		{
			this.Tessellate(windingRule, elementType, polySize, null);
		}

		// Token: 0x06000745 RID: 1861 RVA: 0x0002BFE4 File Offset: 0x0002A1E4
		public void Tessellate(WindingRule windingRule, ElementType elementType, int polySize, CombineCallback combineCallback)
		{
			this._vertices = null;
			this._elements = null;
			this._windingRule = windingRule;
			this._combineCallback = combineCallback;
			if (this._mesh == null)
			{
				return;
			}
			this.ProjectPolygon();
			this.ComputeInterior();
			if (elementType == ElementType.BoundaryContours)
			{
				this.SetWindingNumber(1, true);
			}
			else
			{
				this.TessellateInterior();
			}
			this._mesh.Check();
			if (elementType == ElementType.BoundaryContours)
			{
				this.OutputContours();
			}
			else
			{
				this.OutputPolymesh(elementType, polySize);
			}
			this._mesh = null;
		}

		// Token: 0x0400074E RID: 1870
		private Mesh _mesh;

		// Token: 0x0400074F RID: 1871
		private Vec3 _normal;

		// Token: 0x04000750 RID: 1872
		private Vec3 _sUnit;

		// Token: 0x04000751 RID: 1873
		private Vec3 _tUnit;

		// Token: 0x04000752 RID: 1874
		private float _bminX;

		// Token: 0x04000753 RID: 1875
		private float _bminY;

		// Token: 0x04000754 RID: 1876
		private float _bmaxX;

		// Token: 0x04000755 RID: 1877
		private float _bmaxY;

		// Token: 0x04000756 RID: 1878
		private WindingRule _windingRule;

		// Token: 0x04000757 RID: 1879
		private Dict<Tess.ActiveRegion> _dict;

		// Token: 0x04000758 RID: 1880
		private PriorityQueue<MeshUtils.Vertex> _pq;

		// Token: 0x04000759 RID: 1881
		private MeshUtils.Vertex _event;

		// Token: 0x0400075A RID: 1882
		private CombineCallback _combineCallback;

		// Token: 0x0400075B RID: 1883
		private ContourVertex[] _vertices;

		// Token: 0x0400075C RID: 1884
		private int _vertexCount;

		// Token: 0x0400075D RID: 1885
		private int[] _elements;

		// Token: 0x0400075E RID: 1886
		private int _elementCount;

		// Token: 0x0400075F RID: 1887
		public float SUnitX = 1f;

		// Token: 0x04000760 RID: 1888
		public float SUnitY = 1f;

		// Token: 0x0200034C RID: 844
		internal class ActiveRegion
		{
			// Token: 0x0400122C RID: 4652
			internal MeshUtils.Edge _eUp;

			// Token: 0x0400122D RID: 4653
			internal Dict<Tess.ActiveRegion>.Node _nodeUp;

			// Token: 0x0400122E RID: 4654
			internal int _windingNumber;

			// Token: 0x0400122F RID: 4655
			internal bool _inside;

			// Token: 0x04001230 RID: 4656
			internal bool _sentinel;

			// Token: 0x04001231 RID: 4657
			internal bool _dirty;

			// Token: 0x04001232 RID: 4658
			internal bool _fixUpperEdge;
		}
	}
}
