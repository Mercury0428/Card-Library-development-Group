﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000DC RID: 220
	// (Invoke) Token: 0x06000747 RID: 1863
	public delegate object CombineCallback(Vec3 position, object[] data, float[] weights);
}
