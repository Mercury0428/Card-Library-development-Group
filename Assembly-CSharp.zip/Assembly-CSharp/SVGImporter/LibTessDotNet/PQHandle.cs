﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D4 RID: 212
	public struct PQHandle
	{
		// Token: 0x0400073E RID: 1854
		public static readonly int Invalid = 268435455;

		// Token: 0x0400073F RID: 1855
		internal int _handle;
	}
}
