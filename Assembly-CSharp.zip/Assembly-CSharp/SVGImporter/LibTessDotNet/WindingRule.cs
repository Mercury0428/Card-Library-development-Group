﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000D8 RID: 216
	public enum WindingRule
	{
		// Token: 0x04000762 RID: 1890
		EvenOdd,
		// Token: 0x04000763 RID: 1891
		NonZero,
		// Token: 0x04000764 RID: 1892
		Positive,
		// Token: 0x04000765 RID: 1893
		Negative,
		// Token: 0x04000766 RID: 1894
		AbsGeqTwo
	}
}
