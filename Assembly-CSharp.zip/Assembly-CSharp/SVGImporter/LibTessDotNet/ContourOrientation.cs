﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000DA RID: 218
	public enum ContourOrientation
	{
		// Token: 0x0400076C RID: 1900
		Original,
		// Token: 0x0400076D RID: 1901
		Clockwise,
		// Token: 0x0400076E RID: 1902
		CounterClockwise
	}
}
