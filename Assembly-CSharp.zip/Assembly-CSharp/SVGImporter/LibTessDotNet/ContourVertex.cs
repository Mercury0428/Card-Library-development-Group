﻿using System;

namespace SVGImporter.LibTessDotNet
{
	// Token: 0x020000DB RID: 219
	public struct ContourVertex
	{
		// Token: 0x0400076F RID: 1903
		public Vec3 Position;

		// Token: 0x04000770 RID: 1904
		public object Data;
	}
}
