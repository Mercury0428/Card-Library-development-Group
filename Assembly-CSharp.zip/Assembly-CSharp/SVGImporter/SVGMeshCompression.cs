﻿using System;

namespace SVGImporter
{
	// Token: 0x020000C1 RID: 193
	public enum SVGMeshCompression
	{
		// Token: 0x0400067B RID: 1659
		Off,
		// Token: 0x0400067C RID: 1660
		Low,
		// Token: 0x0400067D RID: 1661
		Medium,
		// Token: 0x0400067E RID: 1662
		High
	}
}
