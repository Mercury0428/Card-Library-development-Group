﻿using System;

namespace SVGImporter
{
	// Token: 0x020000B4 RID: 180
	public interface ISVGShape
	{
		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000590 RID: 1424
		SVGPath[] shape { get; }
	}
}
