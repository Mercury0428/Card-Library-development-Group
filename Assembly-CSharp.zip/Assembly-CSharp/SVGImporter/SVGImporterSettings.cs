﻿using System;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000B0 RID: 176
	public class SVGImporterSettings : ScriptableObject
	{
		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000583 RID: 1411 RVA: 0x00020344 File Offset: 0x0001E544
		public static SVGImporterSettings Get
		{
			get
			{
				if (SVGImporterSettings._instance == null)
				{
					SVGImporterSettings._instance = Resources.Load<SVGImporterSettings>("svgImporterSettings");
					if (SVGImporterSettings._instance == null)
					{
						Debug.LogError("Cannot Load SVG Importer Settings! Please Move SVG Importer Settings in to Resource folder.");
						SVGImporterSettings._instance = ScriptableObject.CreateInstance<SVGImporterSettings>();
						SVGImporterSettings._instance.defaultSVGFormat = SVGAssetFormat.Transparent;
						SVGImporterSettings._instance.defaultUseGradients = SVGUseGradients.Never;
						SVGImporterSettings._instance.defaultAntialiasing = true;
						SVGImporterSettings._instance.defaultAntialiasingWidth = 2f;
						SVGImporterSettings._instance.defaultMeshCompression = SVGMeshCompression.High;
						SVGImporterSettings._instance.defaultVerticesPerMeter = 1000;
						SVGImporterSettings._instance.defaultScale = 0.001f;
						SVGImporterSettings._instance.defaultDepthOffset = 0.01f;
						SVGImporterSettings._instance.defaultCompressDepth = true;
						SVGImporterSettings._instance.defaultCustomPivotPoint = false;
						SVGImporterSettings._instance.defaultPivotPoint = new Vector2(0.5f, 0.5f);
						SVGImporterSettings._instance.defaultGenerateCollider = false;
						SVGImporterSettings._instance.defaultKeepSVGFile = false;
						SVGImporterSettings._instance.defaultUseLayers = false;
						SVGImporterSettings._instance.defaultIgnoreSVGCanvas = true;
						SVGImporterSettings._instance.defaultOptimizeMesh = true;
						SVGImporterSettings._instance.defaultGenerateNormals = false;
						SVGImporterSettings._instance.defaultGenerateTangents = false;
						SVGImporterSettings._instance.defaultSVGIcon = null;
						SVGImporterSettings._instance.ignoreImportExceptions = true;
					}
				}
				return SVGImporterSettings._instance;
			}
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x00020493 File Offset: 0x0001E693
		public static void UpdateAntialiasing()
		{
			Shader.SetGlobalFloat("SVG_ANTIALIASING_WIDTH", SVGImporterSettings.Get.defaultAntialiasingWidth);
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x000204A9 File Offset: 0x0001E6A9
		public static string version
		{
			get
			{
				return SVGImporterSettings._version;
			}
		}

		// Token: 0x0400062B RID: 1579
		protected static SVGImporterSettings _instance;

		// Token: 0x0400062C RID: 1580
		protected static string _version = "1.1.3";

		// Token: 0x0400062D RID: 1581
		public SVGAssetFormat defaultSVGFormat = SVGAssetFormat.Transparent;

		// Token: 0x0400062E RID: 1582
		public SVGUseGradients defaultUseGradients;

		// Token: 0x0400062F RID: 1583
		public bool defaultAntialiasing;

		// Token: 0x04000630 RID: 1584
		public float defaultAntialiasingWidth = 2f;

		// Token: 0x04000631 RID: 1585
		public SVGMeshCompression defaultMeshCompression;

		// Token: 0x04000632 RID: 1586
		public int defaultVerticesPerMeter = 1000;

		// Token: 0x04000633 RID: 1587
		public float defaultScale = 0.01f;

		// Token: 0x04000634 RID: 1588
		public float defaultDepthOffset = 0.01f;

		// Token: 0x04000635 RID: 1589
		public bool defaultCompressDepth = true;

		// Token: 0x04000636 RID: 1590
		public bool defaultCustomPivotPoint;

		// Token: 0x04000637 RID: 1591
		public Vector2 defaultPivotPoint = new Vector2(0.5f, 0.5f);

		// Token: 0x04000638 RID: 1592
		public bool defaultGenerateCollider;

		// Token: 0x04000639 RID: 1593
		public bool defaultKeepSVGFile = true;

		// Token: 0x0400063A RID: 1594
		public bool defaultUseLayers;

		// Token: 0x0400063B RID: 1595
		public bool defaultIgnoreSVGCanvas = true;

		// Token: 0x0400063C RID: 1596
		public bool defaultOptimizeMesh = true;

		// Token: 0x0400063D RID: 1597
		public bool defaultGenerateNormals;

		// Token: 0x0400063E RID: 1598
		public bool defaultGenerateTangents;

		// Token: 0x0400063F RID: 1599
		public Texture2D defaultSVGIcon;

		// Token: 0x04000640 RID: 1600
		public bool ignoreImportExceptions = true;
	}
}
