﻿using System;
using System.Collections.Generic;
using SVGImporter.Geometry;
using SVGImporter.Rendering;
using SVGImporter.Utils;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

namespace SVGImporter
{
	// Token: 0x020000CB RID: 203
	[ExecuteInEditMode]
	[AddComponentMenu("Rendering/SVG Renderer", 20)]
	public class SVGRenderer : UIBehaviour, ISVGShape, ISVGRenderer, ISVGReference
	{
		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600067F RID: 1663 RVA: 0x00026294 File Offset: 0x00024494
		// (set) Token: 0x06000680 RID: 1664 RVA: 0x0002629C File Offset: 0x0002449C
		public virtual Action<SVGLayer[], SVGAsset, bool> OnPrepareForRendering
		{
			get
			{
				return this._OnPrepareForRendering;
			}
			set
			{
				this._OnPrepareForRendering = value;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000681 RID: 1665 RVA: 0x000262A5 File Offset: 0x000244A5
		// (set) Token: 0x06000682 RID: 1666 RVA: 0x000262AD File Offset: 0x000244AD
		public SVGRenderer.Type type
		{
			get
			{
				return this._type;
			}
			set
			{
				this._type = value;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000683 RID: 1667 RVA: 0x000262B6 File Offset: 0x000244B6
		public int lastFrameChanged
		{
			get
			{
				return this._lastFrameChanged;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000684 RID: 1668 RVA: 0x000262BE File Offset: 0x000244BE
		// (set) Token: 0x06000685 RID: 1669 RVA: 0x000262C6 File Offset: 0x000244C6
		public SVGAsset vectorGraphics
		{
			get
			{
				return this._vectorGraphics;
			}
			set
			{
				this._vectorGraphics = value;
				if (!this.meshRenderer.isPartOfStaticBatch)
				{
					this.PrepareForRendering(true);
				}
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000686 RID: 1670 RVA: 0x000262E3 File Offset: 0x000244E3
		// (set) Token: 0x06000687 RID: 1671 RVA: 0x000262EB File Offset: 0x000244EB
		public Color color
		{
			get
			{
				return this._color;
			}
			set
			{
				this._color = value;
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000688 RID: 1672 RVA: 0x000262F4 File Offset: 0x000244F4
		// (set) Token: 0x06000689 RID: 1673 RVA: 0x000262FC File Offset: 0x000244FC
		public Material opaqueMaterial
		{
			get
			{
				return this._opaqueMaterial;
			}
			set
			{
				if (this._opaqueMaterial != value)
				{
					this._opaqueMaterial = value;
					this.UpdateMaterials();
				}
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x0600068A RID: 1674 RVA: 0x00026319 File Offset: 0x00024519
		// (set) Token: 0x0600068B RID: 1675 RVA: 0x00026321 File Offset: 0x00024521
		public Material transparentMaterial
		{
			get
			{
				return this._transparentMaterial;
			}
			set
			{
				if (this._transparentMaterial != value)
				{
					this._transparentMaterial = value;
					this.UpdateMaterials();
				}
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x0600068C RID: 1676 RVA: 0x0002633E File Offset: 0x0002453E
		public MeshFilter meshFilter
		{
			get
			{
				if (this._meshFilter == null)
				{
					base.GetComponent<MeshRenderer>();
				}
				return this._meshFilter;
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x0600068D RID: 1677 RVA: 0x0002635B File Offset: 0x0002455B
		public MeshRenderer meshRenderer
		{
			get
			{
				if (this._meshRenderer == null)
				{
					base.GetComponent<MeshRenderer>();
				}
				return this._meshRenderer;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x0600068E RID: 1678 RVA: 0x00026378 File Offset: 0x00024578
		public RectTransform rectTransform
		{
			get
			{
				return base.transform as RectTransform;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x0600068F RID: 1679 RVA: 0x00026385 File Offset: 0x00024585
		// (set) Token: 0x06000690 RID: 1680 RVA: 0x00026394 File Offset: 0x00024594
		public int sortingLayerID
		{
			get
			{
				return this.meshRenderer.sortingLayerID;
			}
			set
			{
				if (!SortingLayer.IsValid(value))
				{
					Debug.LogWarning(base.name + ": This renderer has an invalid layer-id, resetting to default.");
					this._sortingLayerID = SortingLayer.NameToID("Default");
				}
				else
				{
					this._sortingLayerID = value;
				}
				this.meshRenderer.sortingLayerID = this._sortingLayerID;
				this._sortingLayerName = this.meshRenderer.sortingLayerName;
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000691 RID: 1681 RVA: 0x000263F9 File Offset: 0x000245F9
		// (set) Token: 0x06000692 RID: 1682 RVA: 0x00026408 File Offset: 0x00024608
		public string sortingLayerName
		{
			get
			{
				return this.meshRenderer.sortingLayerName;
			}
			set
			{
				Renderer meshRenderer = this.meshRenderer;
				this._sortingLayerName = value;
				meshRenderer.sortingLayerName = value;
				this._lastSortingLayerID = (this._sortingLayerID = this.meshRenderer.sortingLayerID);
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000693 RID: 1683 RVA: 0x00026444 File Offset: 0x00024644
		// (set) Token: 0x06000694 RID: 1684 RVA: 0x00026454 File Offset: 0x00024654
		public int sortingOrder
		{
			get
			{
				return this.meshRenderer.sortingOrder;
			}
			set
			{
				Renderer meshRenderer = this.meshRenderer;
				this._sortingOrder = value;
				meshRenderer.sortingOrder = value;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000695 RID: 1685 RVA: 0x00026476 File Offset: 0x00024676
		// (set) Token: 0x06000696 RID: 1686 RVA: 0x0002647E File Offset: 0x0002467E
		public bool overrideSorter
		{
			get
			{
				return this._overrideSorter;
			}
			set
			{
				this._overrideSorter = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000697 RID: 1687 RVA: 0x00026487 File Offset: 0x00024687
		// (set) Token: 0x06000698 RID: 1688 RVA: 0x0002648F File Offset: 0x0002468F
		public bool overrideSorterChildren
		{
			get
			{
				return this._overrideSorterChildren;
			}
			set
			{
				this._overrideSorterChildren = value;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06000699 RID: 1689 RVA: 0x00026498 File Offset: 0x00024698
		public SVGPath[] shape
		{
			get
			{
				if (this._vectorGraphics == null)
				{
					return null;
				}
				return this._vectorGraphics.colliderShape;
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x000264B8 File Offset: 0x000246B8
		protected override void Awake()
		{
			base.Awake();
			this.CacheComponents();
			this.meshFilter.sharedMesh = null;
			if (this._vectorGraphics != null)
			{
				this._vectorGraphics.AddReference(this);
			}
			this.Clear();
			this.PrepareForRendering(true);
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00026504 File Offset: 0x00024704
		protected override void OnEnable()
		{
			base.OnEnable();
			this.EnableMeshRenderer(true);
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00026513 File Offset: 0x00024713
		private void OnWillRenderObject()
		{
			if (!this.meshRenderer.isPartOfStaticBatch)
			{
				this.PrepareForRendering(false);
			}
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00026529 File Offset: 0x00024729
		protected override void OnDisable()
		{
			this.EnableMeshRenderer(false);
			base.OnDisable();
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x00026538 File Offset: 0x00024738
		protected override void OnDestroy()
		{
			if (this._vectorGraphics != null)
			{
				this._vectorGraphics.RemoveReference(this);
			}
			base.OnDestroy();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0002655C File Offset: 0x0002475C
		private void CacheComponents()
		{
			if (this._meshFilter == null)
			{
				this._meshFilter = base.GetComponent<MeshFilter>();
				if (this._meshFilter == null)
				{
					this._meshFilter = base.gameObject.AddComponent<MeshFilter>();
				}
			}
			if (this._meshRenderer == null)
			{
				this._meshRenderer = base.GetComponent<MeshRenderer>();
				if (this._meshRenderer == null)
				{
					this._meshRenderer = base.gameObject.AddComponent<MeshRenderer>();
				}
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x000265DB File Offset: 0x000247DB
		public void UpdateRenderer()
		{
			this.PrepareForRendering(true);
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000265E4 File Offset: 0x000247E4
		protected void PrepareForRendering(bool force = false)
		{
			if (this._vectorGraphics == null)
			{
				if (this._lastVectorGraphics != null)
				{
					this._lastVectorGraphics.RemoveReference(this);
					this._lastVectorGraphics = null;
				}
				this.Clear();
				return;
			}
			bool flag = force || this._lastType != this._type || this.meshFilter.sharedMesh == null;
			bool flag2 = force || this._lastColor != this._color;
			bool flag3 = force || this._lastOpaqueMaterial != this._opaqueMaterial || this._lastTransparentMaterial != this._transparentMaterial;
			if (this._lastVectorGraphics != this._vectorGraphics)
			{
				flag = true;
				flag2 = true;
				if (this._lastVectorGraphics != null)
				{
					this._lastVectorGraphics.RemoveReference(this);
				}
				if (this._vectorGraphics != null)
				{
					this._vectorGraphics.AddReference(this);
				}
			}
			if (this.useLayers || !this.useSharedMesh)
			{
				if (this._lastUseSharedMesh)
				{
					flag = true;
				}
				if (!flag && this._type == SVGRenderer.Type.Sliced && this.rectTransform != null)
				{
					this._rectTransformRect = this.rectTransform.rect;
					if (this._rectTransformRect != this._lastRectTransformRect)
					{
						flag = true;
						this._lastRectTransformRect = this._rectTransformRect;
					}
				}
			}
			if (this.useLayers)
			{
				if (this._layers == null)
				{
					this._layers = this._vectorGraphics.layersClone;
				}
				if (flag || flag2)
				{
					this.InitMesh();
					if (this._type == SVGRenderer.Type.Sliced)
					{
						this.UpdateSlicedMesh();
					}
					this.UpdateColors(force);
					this._lastFrameChanged = Time.frameCount;
					flag3 = true;
					if (this._OnPrepareForRendering != null)
					{
						this._OnPrepareForRendering(this._layers, this._vectorGraphics, force);
					}
					this.GenerateMesh();
					if (this.meshFilter.sharedMesh != this._mesh)
					{
						this.meshFilter.sharedMesh = this._mesh;
					}
				}
			}
			else if (this.useSharedMesh)
			{
				this._sharedMesh = this._vectorGraphics.sharedMesh;
				this.meshFilter.sharedMesh = this._sharedMesh;
			}
			else
			{
				if (flag)
				{
					this.InitMesh();
					flag3 = true;
					if (this._type == SVGRenderer.Type.Sliced)
					{
						this.UpdateSlicedMesh();
					}
					if (this.onVectorGraphicsChanged != null)
					{
						this.onVectorGraphicsChanged(this._vectorGraphics);
					}
				}
				if (flag || flag2)
				{
					this.UpdateColors(force);
					this._lastFrameChanged = Time.frameCount;
					flag3 = true;
				}
				if (this.meshFilter.sharedMesh != this._mesh)
				{
					this.meshFilter.sharedMesh = this._mesh;
				}
			}
			if (flag3)
			{
				this.UpdateMaterials();
			}
			this._lastOpaqueMaterial = this._opaqueMaterial;
			this._lastTransparentMaterial = this._transparentMaterial;
			this._lastVectorGraphics = this._vectorGraphics;
			this._lastColor = this._color;
			this._lastType = this._type;
			this._lastUseSharedMesh = this.useSharedMesh;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x000268E4 File Offset: 0x00024AE4
		protected void GenerateMesh()
		{
			Shader[] array;
			SVGMesh.CombineMeshes(this._layers, this._mesh, out array, this._vectorGraphics.useGradients, this._vectorGraphics.format, this._vectorGraphics.compressDepth, this._vectorGraphics.antialiasing);
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00026934 File Offset: 0x00024B34
		protected void UpdateColors(bool force = false)
		{
			if (this._color == Color.white)
			{
				return;
			}
			if (this.useLayers)
			{
				Color32 color = this._color;
				bool flag = color.a != byte.MaxValue;
				int num = this._layers.Length;
				for (int i = 0; i < num; i++)
				{
					int num2 = this._layers[i].shapes.Length;
					for (int j = 0; j < num2; j++)
					{
						if (this._layers[i].shapes[j].fill != null)
						{
							Color32 color2 = this._layers[i].shapes[j].fill.color;
							color2.r = color2.r * color.r / byte.MaxValue;
							color2.g = color2.g * color.g / byte.MaxValue;
							color2.b = color2.b * color.b / byte.MaxValue;
							color2.a = color2.a * color.a / byte.MaxValue;
							this._layers[i].shapes[j].fill.color = color2;
							if (flag)
							{
								this._layers[i].shapes[j].fill.blend = FILL_BLEND.ALPHA_BLENDED;
							}
						}
					}
				}
				return;
			}
			if (this._sharedMesh != null)
			{
				if (this._cachedColors == null || this._cachedColors.Length != this._sharedMesh.vertexCount)
				{
					Color32[] colors = this._sharedMesh.colors32;
					if (colors == null || colors.Length == 0)
					{
						return;
					}
					this._finalColors = new Color32[colors.Length];
					this._cachedColors = (Color32[])colors.Clone();
				}
				int num3 = this._cachedColors.Length;
				Color32 color3 = this._color;
				for (int k = 0; k < num3; k++)
				{
					this._finalColors[k].r = this._cachedColors[k].r * color3.r / byte.MaxValue;
					this._finalColors[k].g = this._cachedColors[k].g * color3.g / byte.MaxValue;
					this._finalColors[k].b = this._cachedColors[k].b * color3.b / byte.MaxValue;
					this._finalColors[k].a = this._cachedColors[k].a * color3.a / byte.MaxValue;
				}
				this._mesh.colors32 = this._finalColors;
				this.meshFilter.sharedMesh = this._mesh;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060006A4 RID: 1700 RVA: 0x00026C50 File Offset: 0x00024E50
		public bool hasBorder
		{
			get
			{
				return this._vectorGraphics != null && this._vectorGraphics.border.sqrMagnitude > 0f;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060006A5 RID: 1701 RVA: 0x00025513 File Offset: 0x00023713
		protected float pixelsPerUnit
		{
			get
			{
				return 100f;
			}
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x000256F8 File Offset: 0x000238F8
		protected float InverseLerp(float from, float to, float value)
		{
			if (from < to)
			{
				value -= from;
				value /= to - from;
				return value;
			}
			return 1f - (value - to) / (from - to);
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x00025848 File Offset: 0x00023A48
		protected float SafeDivide(float a, float b)
		{
			if (b == 0f)
			{
				return 0f;
			}
			return a / b;
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x00026C88 File Offset: 0x00024E88
		protected string BorderToString(Vector4 border)
		{
			return string.Format("left: {0}, bottom: {1}, right: {2}, top: {3}", new object[]
			{
				border.x,
				border.y,
				border.z,
				border.w
			});
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00026CE0 File Offset: 0x00024EE0
		protected void UpdateSlicedMesh()
		{
			if (this.hasBorder && this.rectTransform != null)
			{
				Bounds bounds = this._vectorGraphics.bounds;
				Vector4 vector = new Vector4(this._rectTransformRect.x, this._rectTransformRect.y, this._rectTransformRect.width, this._rectTransformRect.height);
				Vector4 border = this._vectorGraphics.border;
				Vector4 vector2 = new Vector4(border.x + 1E-07f, border.y + 1E-07f, 1f - border.z - 1E-07f, 1f - border.w - 1E-07f);
				float num = this.vectorGraphics.scale * 100f;
				Vector2 vector3 = new Vector2(bounds.size.x * num, bounds.size.y * num);
				Vector4 vector4 = new Vector4(vector.x, vector.y, vector.x + vector.z, vector.y + vector.w);
				Vector4 vector5 = new Vector4(vector3.x * border.x, vector3.y * border.y, vector3.x * border.z, vector3.y * border.w);
				Vector2 vector6 = new Vector2(this.SafeDivide(1f, 1f - (border.x + border.z)) * (vector.z - (vector5.x + vector5.z)), this.SafeDivide(1f, 1f - (border.y + border.w)) * (vector.w - (vector5.w + vector5.y)));
				float num2 = vector5.x + vector5.z;
				if (num2 != 0f)
				{
					num2 = Mathf.Clamp01(vector.z / num2);
					if (num2 != 1f)
					{
						vector6.x = 0f;
						vector3.x *= num2;
						vector5.x *= num2;
						vector5.z *= num2;
					}
				}
				float num3 = vector5.w + vector5.y;
				if (num3 != 0f)
				{
					num3 = Mathf.Clamp01(vector.w / num3);
					if (num3 != 1f)
					{
						vector6.y = 0f;
						vector3.y *= num3;
						vector5.w *= num3;
						vector5.y *= num3;
					}
				}
				float num4 = vector4.w - vector5.w;
				float num5 = vector4.x + vector5.x;
				Vector2 vector7;
				if (this.useLayers)
				{
					int num6 = this._layers.Length;
					for (int i = 0; i < num6; i++)
					{
						int num7 = this._layers[i].shapes.Length;
						for (int j = 0; j < num7; j++)
						{
							int num8 = this._layers[i].shapes[j].vertices.Length;
							for (int k = 0; k < num8; k++)
							{
								vector7.x = this.InverseLerp(bounds.min.x, bounds.max.x, this._layers[i].shapes[j].vertices[k].x);
								vector7.y = this.InverseLerp(bounds.min.y, bounds.max.y, this._layers[i].shapes[j].vertices[k].y);
								if (border.x != 0f && vector7.x <= vector2.x)
								{
									this._layers[i].shapes[j].vertices[k].x = vector4.x + vector7.x * vector3.x;
								}
								else if (border.z != 0f && vector7.x >= vector2.z)
								{
									this._layers[i].shapes[j].vertices[k].x = vector4.z - (1f - vector7.x) * vector3.x;
								}
								else
								{
									this._layers[i].shapes[j].vertices[k].x = num5 + (vector7.x - border.x) * vector6.x;
								}
								if (border.w != 0f && vector7.y >= vector2.w)
								{
									this._layers[i].shapes[j].vertices[k].y = vector4.w - (1f - vector7.y) * vector3.y;
								}
								else if (border.y != 0f && vector7.y <= vector2.y)
								{
									this._layers[i].shapes[j].vertices[k].y = vector4.y + vector7.y * vector3.y;
								}
								else
								{
									this._layers[i].shapes[j].vertices[k].y = num4 - (1f - vector7.y - border.w) * vector6.y;
								}
							}
						}
					}
					return;
				}
				if (this._cachedVertices == null)
				{
					if (this._sharedMesh == null)
					{
						this._sharedMesh = this._vectorGraphics.sharedMesh;
					}
					Vector3[] vertices = this._sharedMesh.vertices;
					if (vertices == null || vertices.Length == 0)
					{
						return;
					}
					this._finalVertices = new Vector3[vertices.Length];
					this._cachedVertices = (Vector3[])vertices.Clone();
				}
				int num9 = this._cachedVertices.Length;
				for (int l = 0; l < num9; l++)
				{
					vector7.x = this.InverseLerp(bounds.min.x, bounds.max.x, this._cachedVertices[l].x);
					vector7.y = this.InverseLerp(bounds.min.y, bounds.max.y, this._cachedVertices[l].y);
					if (border.x != 0f && vector7.x <= vector2.x)
					{
						this._finalVertices[l].x = vector4.x + vector7.x * vector3.x;
					}
					else if (border.z != 0f && vector7.x >= vector2.z)
					{
						this._finalVertices[l].x = vector4.z - (1f - vector7.x) * vector3.x;
					}
					else
					{
						this._finalVertices[l].x = num5 + (vector7.x - border.x) * vector6.x;
					}
					if (border.w != 0f && vector7.y >= vector2.w)
					{
						this._finalVertices[l].y = vector4.w - (1f - vector7.y) * vector3.y;
					}
					else if (border.y != 0f && vector7.y <= vector2.y)
					{
						this._finalVertices[l].y = vector4.y + vector7.y * vector3.y;
					}
					else
					{
						this._finalVertices[l].y = num4 - (1f - vector7.y - border.w) * vector6.y;
					}
				}
				this._mesh.vertices = this._finalVertices;
				this.meshFilter.sharedMesh = this._mesh;
			}
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00027579 File Offset: 0x00025779
		internal bool AtlasContainsMaterial(Material material)
		{
			return SVGAtlas.Instance.ContainsMaterial(material);
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x00027588 File Offset: 0x00025788
		protected void SwapMaterials(bool transparent = true)
		{
			if (this._vectorGraphics == null)
			{
				this.CleanMaterials();
				return;
			}
			bool hasGradients = this._vectorGraphics.hasGradients || this._vectorGraphics.useGradients == SVGUseGradients.Always;
			Material opaqueMaterial = SVGAtlas.Instance.GetOpaqueMaterial(hasGradients);
			Material transparentMaterial = SVGAtlas.Instance.GetTransparentMaterial(this._vectorGraphics.antialiasing, hasGradients);
			int subMeshCount = 0;
			if (this.useLayers)
			{
				subMeshCount = this._mesh.subMeshCount;
			}
			else if (this._sharedMesh != null)
			{
				subMeshCount = this._sharedMesh.subMeshCount;
			}
			if (this._vectorGraphics.isOpaque)
			{
				if (transparent)
				{
					if (this._transparentMaterial != null)
					{
						this.SetSharedMaterials(subMeshCount, this._transparentMaterial, this._transparentMaterial);
						return;
					}
					this.SetSharedMaterials(subMeshCount, transparentMaterial, transparentMaterial);
					return;
				}
				else
				{
					if (this._opaqueMaterial == null && this._transparentMaterial == null)
					{
						this.SetSharedMaterials(subMeshCount, opaqueMaterial, transparentMaterial);
						return;
					}
					if (this._opaqueMaterial != null && this._transparentMaterial != null)
					{
						this.SetSharedMaterials(subMeshCount, this._opaqueMaterial, this._transparentMaterial);
						return;
					}
					if (this._transparentMaterial != null)
					{
						this.SetSharedMaterials(subMeshCount, opaqueMaterial, this._transparentMaterial);
						return;
					}
					if (this._opaqueMaterial != null)
					{
						this.SetSharedMaterials(subMeshCount, this._opaqueMaterial, transparentMaterial);
						return;
					}
				}
			}
			else
			{
				if (this._transparentMaterial == null)
				{
					this.SetSharedMaterials(subMeshCount, transparentMaterial, transparentMaterial);
					return;
				}
				this.SetSharedMaterials(subMeshCount, this._transparentMaterial, this._transparentMaterial);
			}
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00027718 File Offset: 0x00025918
		private void SetSharedMaterials(int subMeshCount, Material firstMaterial, Material secondMaterial)
		{
			if (subMeshCount < 2)
			{
				this.meshRenderer.sharedMaterials = new Material[]
				{
					firstMaterial
				};
				return;
			}
			this.meshRenderer.sharedMaterials = new Material[]
			{
				firstMaterial,
				secondMaterial
			};
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00027750 File Offset: 0x00025950
		public void UpdateMaterials()
		{
			if (this._opaqueMaterial != null)
			{
				SVGAtlas.Instance.UpdateMaterialProperties(this._opaqueMaterial);
			}
			if (this._transparentMaterial != null)
			{
				SVGAtlas.Instance.UpdateMaterialProperties(this._transparentMaterial);
			}
			this.SwapMaterials(this._color.a != 1f);
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x000277B4 File Offset: 0x000259B4
		public void SetAllDirty()
		{
			if (!this.meshRenderer.isPartOfStaticBatch)
			{
				this.PrepareForRendering(true);
			}
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x000277CA File Offset: 0x000259CA
		private void EnableMeshRenderer(bool value)
		{
			if (!this.meshRenderer.isPartOfStaticBatch)
			{
				this.meshRenderer.enabled = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060006B0 RID: 1712 RVA: 0x000277E5 File Offset: 0x000259E5
		private bool useLayers
		{
			get
			{
				return this._vectorGraphics.useLayers;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060006B1 RID: 1713 RVA: 0x000277F2 File Offset: 0x000259F2
		private bool useSharedMesh
		{
			get
			{
				return !this.useLayers && this._color == Color.white && this._type == SVGRenderer.Type.Simple;
			}
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x0002781C File Offset: 0x00025A1C
		private void InitMesh()
		{
			if (this._vectorGraphics == null)
			{
				this._lastVectorGraphics = null;
				this.Clear();
				return;
			}
			if (this.useLayers)
			{
				this._layers = this._vectorGraphics.layersClone;
				if (this._mesh == null)
				{
					this._mesh = new Mesh();
					this._mesh.hideFlags = HideFlags.DontSave;
				}
				else
				{
					this._mesh.Clear();
				}
				this._mesh.name = this._vectorGraphics.name + " Instance " + this._mesh.GetInstanceID();
				this.meshFilter.sharedMesh = this._mesh;
				return;
			}
			this.CleanMesh();
			if (this._sharedMesh != this._vectorGraphics.sharedMesh)
			{
				this._sharedMesh = this._vectorGraphics.sharedMesh;
			}
			if (this.useSharedMesh)
			{
				if (this.meshFilter.sharedMesh != this._sharedMesh)
				{
					this.meshFilter.sharedMesh = this._sharedMesh;
					return;
				}
			}
			else
			{
				if (this._mesh == null)
				{
					this._mesh = new Mesh();
					this._mesh.hideFlags = HideFlags.DontSave;
				}
				else
				{
					this._mesh.Clear();
				}
				SVGMeshUtils.Fill(this._vectorGraphics.sharedMesh, this._mesh);
				Mesh mesh = this._mesh;
				mesh.name = mesh.name + " Instance " + this._mesh.GetInstanceID();
				if (this.meshFilter.sharedMesh != this._mesh)
				{
					this.meshFilter.sharedMesh = this._mesh;
				}
			}
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x000279D7 File Offset: 0x00025BD7
		public void AddModifier(ISVGModify modifier)
		{
			if (this._modifiers.Contains(modifier))
			{
				return;
			}
			this._modifiers.Add(modifier);
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x000279F4 File Offset: 0x00025BF4
		public void RemoveModifier(ISVGModify modifier)
		{
			if (!this._modifiers.Contains(modifier))
			{
				return;
			}
			this._modifiers.Remove(modifier);
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060006B5 RID: 1717 RVA: 0x00027A12 File Offset: 0x00025C12
		public bool isVisible
		{
			get
			{
				return this._meshRenderer.isVisible;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060006B6 RID: 1718 RVA: 0x00027A1F File Offset: 0x00025C1F
		public List<ISVGModify> modifiers
		{
			get
			{
				return this._modifiers;
			}
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x00027A27 File Offset: 0x00025C27
		protected void Clear()
		{
			this.CleanMaterials();
			this.CleanMesh();
			this.CleanLayers();
			this.CleanCache();
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x00027A41 File Offset: 0x00025C41
		private void CleanMaterials()
		{
			this.meshRenderer.sharedMaterials = new Material[0];
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00027A54 File Offset: 0x00025C54
		private void CleanMesh()
		{
			if (this._mesh != null)
			{
				this._mesh.Clear();
			}
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00027A6F File Offset: 0x00025C6F
		private void CleanLayers()
		{
			if (this._layers != null)
			{
				this._layers = null;
			}
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x00027A80 File Offset: 0x00025C80
		private void CleanCache()
		{
			if (this._cachedColors != null)
			{
				this._cachedColors = null;
			}
			if (this._finalColors != null)
			{
				this._finalColors = null;
			}
			if (this._cachedVertices != null)
			{
				this._cachedVertices = null;
			}
			if (this._finalVertices != null)
			{
				this._finalVertices = null;
			}
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00027AC0 File Offset: 0x00025CC0
		private void DestroyArray<T>(T[] array) where T : Object
		{
			if (array == null)
			{
				return;
			}
			foreach (T t in array)
			{
				if (!(t == null))
				{
					this.DestroyObjectInternal(t);
				}
			}
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00027B03 File Offset: 0x00025D03
		private void DestroyObjectInternal(Object obj)
		{
			if (obj == null)
			{
				return;
			}
			Object.Destroy(obj);
		}

		// Token: 0x040006FB RID: 1787
		public Action<SVGAsset> onVectorGraphicsChanged;

		// Token: 0x040006FC RID: 1788
		protected Action<SVGLayer[], SVGAsset, bool> _OnPrepareForRendering;

		// Token: 0x040006FD RID: 1789
		protected SVGRenderer.Type _lastType;

		// Token: 0x040006FE RID: 1790
		[FormerlySerializedAs("type")]
		[SerializeField]
		private SVGRenderer.Type _type;

		// Token: 0x040006FF RID: 1791
		[FormerlySerializedAs("lastTimeModified")]
		[SerializeField]
		protected long _lastTimeModified;

		// Token: 0x04000700 RID: 1792
		protected Rect _rectTransformRect;

		// Token: 0x04000701 RID: 1793
		protected Rect _lastRectTransformRect;

		// Token: 0x04000702 RID: 1794
		protected int _lastFrameChanged;

		// Token: 0x04000703 RID: 1795
		[FormerlySerializedAs("vectorGraphics")]
		[SerializeField]
		protected SVGAsset _vectorGraphics;

		// Token: 0x04000704 RID: 1796
		protected SVGAsset _lastVectorGraphics;

		// Token: 0x04000705 RID: 1797
		[FormerlySerializedAs("color")]
		[SerializeField]
		protected Color _color = Color.white;

		// Token: 0x04000706 RID: 1798
		protected Color _lastColor = Color.white;

		// Token: 0x04000707 RID: 1799
		protected Color32[] _cachedColors;

		// Token: 0x04000708 RID: 1800
		protected Vector3[] _cachedVertices;

		// Token: 0x04000709 RID: 1801
		[FormerlySerializedAs("opaqueMaterial")]
		[SerializeField]
		protected Material _opaqueMaterial;

		// Token: 0x0400070A RID: 1802
		protected Material _lastOpaqueMaterial;

		// Token: 0x0400070B RID: 1803
		[FormerlySerializedAs("transparentMaterial")]
		[SerializeField]
		protected Material _transparentMaterial;

		// Token: 0x0400070C RID: 1804
		protected Material _lastTransparentMaterial;

		// Token: 0x0400070D RID: 1805
		protected MeshFilter _meshFilter;

		// Token: 0x0400070E RID: 1806
		protected MeshRenderer _meshRenderer;

		// Token: 0x0400070F RID: 1807
		protected SVGLayer[] _layers;

		// Token: 0x04000710 RID: 1808
		protected Mesh _sharedMesh;

		// Token: 0x04000711 RID: 1809
		protected Mesh _mesh;

		// Token: 0x04000712 RID: 1810
		[FormerlySerializedAs("sortingLayerID")]
		[SerializeField]
		protected int _sortingLayerID;

		// Token: 0x04000713 RID: 1811
		protected int _lastSortingLayerID;

		// Token: 0x04000714 RID: 1812
		[FormerlySerializedAs("sortingLayerName")]
		[SerializeField]
		protected string _sortingLayerName;

		// Token: 0x04000715 RID: 1813
		[FormerlySerializedAs("sortingOrder")]
		[SerializeField]
		protected int _sortingOrder;

		// Token: 0x04000716 RID: 1814
		protected int _lastSortingOrder;

		// Token: 0x04000717 RID: 1815
		[FormerlySerializedAs("overrideSorter")]
		[SerializeField]
		protected bool _overrideSorter;

		// Token: 0x04000718 RID: 1816
		protected bool _lastOverrideSorter;

		// Token: 0x04000719 RID: 1817
		[FormerlySerializedAs("overrideSorterChildren")]
		[SerializeField]
		protected bool _overrideSorterChildren;

		// Token: 0x0400071A RID: 1818
		protected bool _lastOverrideSorterChildren;

		// Token: 0x0400071B RID: 1819
		protected Color32[] _finalColors;

		// Token: 0x0400071C RID: 1820
		private const float epsilon = 1E-07f;

		// Token: 0x0400071D RID: 1821
		protected Vector3[] _finalVertices;

		// Token: 0x0400071E RID: 1822
		protected bool _lastUseSharedMesh;

		// Token: 0x0400071F RID: 1823
		protected List<ISVGModify> _modifiers = new List<ISVGModify>();

		// Token: 0x02000342 RID: 834
		public enum Type
		{
			// Token: 0x04001208 RID: 4616
			Simple,
			// Token: 0x04001209 RID: 4617
			Sliced
		}
	}
}
