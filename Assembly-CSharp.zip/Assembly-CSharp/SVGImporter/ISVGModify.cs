﻿using System;

namespace SVGImporter
{
	// Token: 0x020000B1 RID: 177
	public interface ISVGModify
	{
	}
}
