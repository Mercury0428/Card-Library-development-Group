﻿using System;
using System.Collections.Generic;
using SVGImporter.Rendering;
using UnityEngine;

namespace SVGImporter
{
	// Token: 0x020000C5 RID: 197
	public class SVGAtlasData
	{
		// Token: 0x060005F3 RID: 1523 RVA: 0x0002390D File Offset: 0x00021B0D
		public void Init(int length)
		{
			this.gradients = new CCGradient[length];
			this.gradientCache = new Dictionary<string, CCGradient>();
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00023926 File Offset: 0x00021B26
		public void ClearGradientCache()
		{
			if (this.gradientCache != null)
			{
				this.gradientCache.Clear();
			}
			this.gradientCache = null;
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00023944 File Offset: 0x00021B44
		public void InitGradientCache()
		{
			if (this.gradientCache == null)
			{
				this.gradientCache = new Dictionary<string, CCGradient>();
				int num = this.gradients.Length;
				for (int i = 0; i < num; i++)
				{
					if (this.gradients[i] != null)
					{
						string hash = this.gradients[i].hash;
						if (!this.gradientCache.ContainsKey(hash))
						{
							this.gradientCache.Add(hash, this.gradients[i]);
						}
					}
				}
			}
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x000239B3 File Offset: 0x00021BB3
		public void RebuildGradientCache()
		{
			this.ClearGradientCache();
			this.InitGradientCache();
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x000239C4 File Offset: 0x00021BC4
		public static CCGradient GetDefaultGradient()
		{
			CCGradientColorKey[] colorKeys = new CCGradientColorKey[]
			{
				new CCGradientColorKey(Color.white, 0f),
				new CCGradientColorKey(Color.white, 1f)
			};
			CCGradientAlphaKey[] alphaKeys = new CCGradientAlphaKey[]
			{
				new CCGradientAlphaKey(1f, 0f),
				new CCGradientAlphaKey(1f, 1f)
			};
			return new CCGradient(colorKeys, alphaKeys, true);
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00023A4C File Offset: 0x00021C4C
		public CCGradient AddGradient(CCGradient gradient)
		{
			bool flag;
			return this.AddGradient(gradient, out flag);
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x00023A64 File Offset: 0x00021C64
		public CCGradient AddGradient(CCGradient gradient, out bool gradientExist)
		{
			gradientExist = false;
			if (gradient == null || !gradient.initialised)
			{
				return null;
			}
			if (this.gradientCache == null || this.gradientCache.Count == 0)
			{
				this.RebuildGradientCache();
			}
			string hash = gradient.hash;
			if (this.gradientCache.ContainsKey(hash))
			{
				gradient = this.gradientCache[hash];
				gradientExist = true;
			}
			else
			{
				int num = this.gradients.Length;
				for (int i = 0; i < num; i++)
				{
					if (this.gradients[i] == null)
					{
						gradient.index = i;
						this.gradients[i] = gradient;
						this.gradientCache.Add(hash, gradient);
						break;
					}
				}
				gradientExist = false;
			}
			return gradient;
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00023B08 File Offset: 0x00021D08
		public bool RemoveGradient(CCGradient gradient)
		{
			if (gradient == null || !gradient.initialised)
			{
				return false;
			}
			if (this.gradientCache == null || this.gradientCache.Count == 0)
			{
				return false;
			}
			string hash = gradient.hash;
			if (this.gradientCache.ContainsKey(hash))
			{
				this.gradientCache.Remove(hash);
				this.gradients[gradient.index] = null;
				return true;
			}
			return false;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00023B6C File Offset: 0x00021D6C
		public CCGradient GetGradient(int index)
		{
			index = Mathf.Clamp(index, 0, this.gradients.Length - 1);
			return this.gradients[index];
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x00023B89 File Offset: 0x00021D89
		public SVGFill GetGradient(SVGFill gradient)
		{
			gradient.gradientColors = this.GetGradient(gradient.gradientColors);
			return gradient;
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00023BA0 File Offset: 0x00021DA0
		public CCGradient GetGradient(CCGradient gradient)
		{
			if (gradient == null || !gradient.initialised || this.gradientCache == null)
			{
				return null;
			}
			string hash = gradient.hash;
			if (this.gradientCache.ContainsKey(hash))
			{
				return this.gradientCache[hash];
			}
			return null;
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00023BE8 File Offset: 0x00021DE8
		public bool HasGradient(CCGradient gradient)
		{
			if (gradient == null || !gradient.initialised || this.gradientCache == null)
			{
				return false;
			}
			string hash = gradient.hash;
			if (this.gradientCache.ContainsKey(hash))
			{
				gradient = this.gradientCache[hash];
				return true;
			}
			return false;
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00023C30 File Offset: 0x00021E30
		public void Clear()
		{
			if (this.gradients != null)
			{
				this.gradients = null;
			}
			if (this.gradientCache != null)
			{
				this.gradientCache.Clear();
				this.gradientCache = null;
			}
		}

		// Token: 0x040006B4 RID: 1716
		public CCGradient[] gradients;

		// Token: 0x040006B5 RID: 1717
		public Dictionary<string, CCGradient> gradientCache;
	}
}
