﻿using System;

namespace SVGImporter
{
	// Token: 0x020000C2 RID: 194
	public enum SVGAssetFormat
	{
		// Token: 0x04000680 RID: 1664
		Opaque,
		// Token: 0x04000681 RID: 1665
		Transparent,
		// Token: 0x04000682 RID: 1666
		uGUI
	}
}
