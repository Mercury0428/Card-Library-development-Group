﻿using System;

namespace SVGImporter
{
	// Token: 0x020000C8 RID: 200
	public enum SVGError
	{
		// Token: 0x040006DB RID: 1755
		None,
		// Token: 0x040006DC RID: 1756
		Syntax,
		// Token: 0x040006DD RID: 1757
		CorruptedFile,
		// Token: 0x040006DE RID: 1758
		ClipPath,
		// Token: 0x040006DF RID: 1759
		Symbol,
		// Token: 0x040006E0 RID: 1760
		Image,
		// Token: 0x040006E1 RID: 1761
		Mask,
		// Token: 0x040006E2 RID: 1762
		Unknown
	}
}
