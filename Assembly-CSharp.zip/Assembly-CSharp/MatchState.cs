﻿using System;

// Token: 0x02000038 RID: 56
internal enum MatchState
{
	// Token: 0x040001E4 RID: 484
	HasSymbol = 1,
	// Token: 0x040001E5 RID: 485
	HasMatch,
	// Token: 0x040001E6 RID: 486
	HasSymbolAndMatch
}
