﻿using System;

// Token: 0x02000074 RID: 116
public enum Genres
{
	// Token: 0x040004D0 RID: 1232
	univ,
	// Token: 0x040004D1 RID: 1233
	mona,
	// Token: 0x040004D2 RID: 1234
	self,
	// Token: 0x040004D3 RID: 1235
	all,
	// Token: 0x040004D4 RID: 1236
	none
}
