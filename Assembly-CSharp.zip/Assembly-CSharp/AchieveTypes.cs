﻿using System;

// Token: 0x02000062 RID: 98
public enum AchieveTypes
{
	// Token: 0x0400045B RID: 1115
	endcard,
	// Token: 0x0400045C RID: 1116
	card,
	// Token: 0x0400045D RID: 1117
	character,
	// Token: 0x0400045E RID: 1118
	objective,
	// Token: 0x0400045F RID: 1119
	highscore,
	// Token: 0x04000460 RID: 1120
	none
}
