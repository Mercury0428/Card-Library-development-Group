﻿using System;
using System.Collections;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000018 RID: 24
public class AnimBut : MonoBehaviour
{
	// Token: 0x060000AC RID: 172 RVA: 0x00004854 File Offset: 0x00002A54
	private void Awake()
	{
		this.but = base.transform.parent.GetComponentInChildren<Button>();
		this.trans = base.GetComponent<RectTransform>();
		this.patrans = base.transform.parent.GetComponent<RectTransform>();
		this.img = base.GetComponent<SVGImage>();
		this.scImg = base.GetComponent<AutoText>();
		this.scTxt = this.txt.GetComponent<AutoText>();
	}

	// Token: 0x060000AD RID: 173 RVA: 0x000048C2 File Offset: 0x00002AC2
	public void ResetLock(bool withlastmode = true)
	{
		if (!withlastmode)
		{
			this.lastmode = this.mode;
		}
		if (this.lastmode == ControlModes.none)
		{
			this.Lock(false);
			return;
		}
		this.UnLock(this.lastmode, false, withlastmode);
	}

	// Token: 0x060000AE RID: 174 RVA: 0x000048F4 File Offset: 0x00002AF4
	public void UnLock(ControlModes nmode, bool withoutbut = false, bool withlastmode = true)
	{
		if (!withoutbut)
		{
			this.but.gameObject.SetActive(true);
		}
		this.scTxt.AnteMove();
		this.scImg.AnteMove();
		this.sc2Img.AnteMove();
		this.sc2Txt.AnteMove();
		if (nmode != this.mode || !withlastmode)
		{
			Inputs curInput = InputAct.diff.curInput;
			if ((nmode == ControlModes.multichoice || nmode == ControlModes.selectback) && !InputAct.diff.NavigationMode())
			{
				this.Lock(false);
				return;
			}
			if (withlastmode)
			{
				this.lastmode = this.mode;
			}
			this.mode = nmode;
			this.UpdateControl(curInput);
		}
	}

	// Token: 0x060000AF RID: 175 RVA: 0x00004994 File Offset: 0x00002B94
	public void Lock(bool direct = false)
	{
		this.but.gameObject.SetActive(false);
		if (direct)
		{
			this.scTxt.MoveDirect();
			this.scImg.MoveDirect();
			this.sc2Txt.MoveDirect();
			this.sc2Img.MoveDirect();
			this.sc2Txt.StopAllCoroutines();
			this.sc2Img.StopAllCoroutines();
		}
		else
		{
			this.scTxt.Move();
			this.scImg.Move();
			this.sc2Txt.Move();
			this.sc2Img.Move();
		}
		this.lastmode = this.mode;
		this.mode = ControlModes.none;
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x00004A38 File Offset: 0x00002C38
	private void OnEnable()
	{
		AnimBut.diff = this;
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x00004A40 File Offset: 0x00002C40
	public void SwitchSize(bool tall)
	{
		this.but.GetComponent<RectTransform>().sizeDelta = (tall ? new Vector2(10000f, 950f) : new Vector2(10000f, 140f));
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x00004A78 File Offset: 0x00002C78
	private void SetGraphics(SVGAsset sel, SVGAsset back, SVGAsset menu, SVGAsset inventory)
	{
		string text = (this.typeCont == Inputs.leap) ? "action_leap" : "action_next";
		switch (this.mode)
		{
		case ControlModes.next:
			this.ApplySingle(sel, text);
			return;
		case ControlModes.nextmenu:
			this.ApplyBoth(sel, menu, text, "action_menu");
			return;
		case ControlModes.selectback:
			this.ApplyBoth(sel, back, "action_select", "action_back");
			return;
		case ControlModes.resetmenu:
			this.ApplyBoth(sel, menu, "action_reset", "action_menu");
			return;
		case ControlModes.multichoice:
			this.ApplySingle(sel, "action_select");
			return;
		default:
			return;
		}
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x00004B08 File Offset: 0x00002D08
	private void ApplySingle(SVGAsset but1, string txt1)
	{
		this.sc2Txt.Move();
		this.sc2Img.Move();
		this.img2.enabled = (this.txt2.enabled = false);
		this.img.enabled = (this.txt.enabled = true);
		this.img.vectorGraphics = but1;
		this.txt.text = ((this.typeCont == Inputs.touch) ? "" : SpeechAct.diff.GetSceneText(txt1));
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x00004B94 File Offset: 0x00002D94
	private void ApplyBoth(SVGAsset but1, SVGAsset but2, string text1, string text2)
	{
		if (but2 == null)
		{
			this.ApplySingle(but1, text1);
			return;
		}
		this.img2.enabled = (this.txt2.enabled = (this.img.enabled = (this.txt.enabled = true)));
		this.img.vectorGraphics = but1;
		this.img2.vectorGraphics = but2;
		this.txt.text = SpeechAct.diff.GetSceneText(text1);
		this.txt2.text = SpeechAct.diff.GetSceneText(text2);
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x00004C30 File Offset: 0x00002E30
	public void UpdateControl(Inputs type)
	{
		this.typeCont = type;
		if (this.typeCont == Inputs.touch)
		{
			this.patrans.anchoredPosition = new Vector2(184f, 0f);
		}
		else
		{
			this.patrans.anchoredPosition = new Vector2(0f, 0f);
		}
		switch (type)
		{
		case Inputs.xbox:
			this.SetGraphics(this.xboxBut, this.xboxBackBut, this.xboxMenuBut, this.xboxInventoryBut);
			return;
		case Inputs.ps:
			this.SetGraphics(this.psBut, this.psBackBut, this.psMenuBut, this.psInventoryBut);
			return;
		case Inputs.tv:
			this.SetGraphics(this.defaultBut, this.tvInventoryBut, this.tvMenuBut, this.tvInventoryBut);
			return;
		}
		this.SetGraphics(this.defaultBut, null, null, null);
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x00004D17 File Offset: 0x00002F17
	private void OnDisable()
	{
		AnimBut.diff = null;
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00004D1F File Offset: 0x00002F1F
	private IEnumerator DoAnimate()
	{
		for (;;)
		{
			float t = 0f;
			while (t < 1f)
			{
				this.amo = Mathf.Lerp(this.amo, 1.1f, Time.deltaTime);
				this.trans.sizeDelta = Vector2.LerpUnclamped(this.osize, this.osize * this.amo, Easing.ElasticEaseInOut(Mathf.PingPong(t * 0.8f * this.amo, 1f), 0f, 1f, 1f));
				t += Time.deltaTime * 3f;
				yield return null;
			}
			t = 0f;
			while (t < 1f)
			{
				this.amo = Mathf.Lerp(this.amo, 1.1f, Time.deltaTime);
				this.trans.sizeDelta = Vector2.Lerp(this.osize * this.amo, this.osize, t);
				t += Time.deltaTime * 4f;
				yield return null;
			}
			yield return null;
		}
		yield break;
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x00004D2E File Offset: 0x00002F2E
	public void Tap()
	{
		this.amo = 1.5f;
		if (JukeBox.diff)
		{
			JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
		}
	}

	// Token: 0x04000086 RID: 134
	public SVGAsset psBut;

	// Token: 0x04000087 RID: 135
	public SVGAsset psBackBut;

	// Token: 0x04000088 RID: 136
	public SVGAsset psMenuBut;

	// Token: 0x04000089 RID: 137
	public SVGAsset psInventoryBut;

	// Token: 0x0400008A RID: 138
	public SVGAsset xboxBut;

	// Token: 0x0400008B RID: 139
	public SVGAsset xboxBackBut;

	// Token: 0x0400008C RID: 140
	public SVGAsset xboxMenuBut;

	// Token: 0x0400008D RID: 141
	public SVGAsset xboxInventoryBut;

	// Token: 0x0400008E RID: 142
	public SVGAsset tvMenuBut;

	// Token: 0x0400008F RID: 143
	public SVGAsset tvInventoryBut;

	// Token: 0x04000090 RID: 144
	public SVGAsset defaultBut;

	// Token: 0x04000091 RID: 145
	private float amo = 1.1f;

	// Token: 0x04000092 RID: 146
	private RectTransform trans;

	// Token: 0x04000093 RID: 147
	private Vector2 osize = new Vector2(40f, 40f);

	// Token: 0x04000094 RID: 148
	public static AnimBut diff;

	// Token: 0x04000095 RID: 149
	public bool startLocked;

	// Token: 0x04000096 RID: 150
	private Button but;

	// Token: 0x04000097 RID: 151
	public Text txt;

	// Token: 0x04000098 RID: 152
	private AutoText scTxt;

	// Token: 0x04000099 RID: 153
	private AutoText scImg;

	// Token: 0x0400009A RID: 154
	public Text txt2;

	// Token: 0x0400009B RID: 155
	public AutoText sc2Txt;

	// Token: 0x0400009C RID: 156
	public AutoText sc2Img;

	// Token: 0x0400009D RID: 157
	private SVGImage img;

	// Token: 0x0400009E RID: 158
	public SVGImage img2;

	// Token: 0x0400009F RID: 159
	public ControlModes mode = ControlModes.none;

	// Token: 0x040000A0 RID: 160
	private ControlModes lastmode = ControlModes.none;

	// Token: 0x040000A1 RID: 161
	private Inputs typeCont = Inputs.none;

	// Token: 0x040000A2 RID: 162
	private RectTransform patrans;
}
