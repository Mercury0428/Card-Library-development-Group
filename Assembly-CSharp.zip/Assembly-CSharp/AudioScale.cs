﻿using System;
using UnityEngine;

// Token: 0x02000089 RID: 137
public class AudioScale : MonoBehaviour
{
	// Token: 0x06000479 RID: 1145 RVA: 0x0001C2D5 File Offset: 0x0001A4D5
	public void VelocityMultiplierIntensity(float value)
	{
		this._velocityMultiplierIntensity = value;
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x0001C2DE File Offset: 0x0001A4DE
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x0001C2E7 File Offset: 0x0001A4E7
	public void RandomIntensity(float value)
	{
		this._randomIntensity = value;
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x0001C2F0 File Offset: 0x0001A4F0
	public void OnAudio(float audioVelocity)
	{
		float num = audioVelocity * this.velocityMultiplier * this._velocityMultiplierIntensity;
		if (this.random && this._randomIntensity >= 0.5f)
		{
			this.destination.x = 1f + Mathf.PerlinNoise(Time.realtimeSinceStartup * 1.5f, Time.realtimeSinceStartup * 3f) * this.velocity.x * num;
			this.destination.y = 1f + Mathf.PerlinNoise(Time.realtimeSinceStartup * 0.5f, Time.realtimeSinceStartup) * this.velocity.y * num;
			this.destination.z = 1f + Mathf.PerlinNoise(Time.realtimeSinceStartup * 0.3f, Time.realtimeSinceStartup * 2f) * this.velocity.z * num;
		}
		else
		{
			this.destination.x = 1f + this.velocity.x * num;
			this.destination.y = 1f + this.velocity.y * num;
			this.destination.z = 1f + this.velocity.z * num;
		}
		this.target.localScale = Vector3.Lerp(this.target.localScale, this.destination, Time.deltaTime * this.speed * this._speedIntensity);
	}

	// Token: 0x04000531 RID: 1329
	public Transform target;

	// Token: 0x04000532 RID: 1330
	public Vector3 velocity;

	// Token: 0x04000533 RID: 1331
	public float velocityMultiplier = 1f;

	// Token: 0x04000534 RID: 1332
	protected float _velocityMultiplierIntensity = 1f;

	// Token: 0x04000535 RID: 1333
	public float speed = 1f;

	// Token: 0x04000536 RID: 1334
	protected float _speedIntensity = 1f;

	// Token: 0x04000537 RID: 1335
	public bool random = true;

	// Token: 0x04000538 RID: 1336
	protected float _randomIntensity = 1f;

	// Token: 0x04000539 RID: 1337
	private Vector3 destination;
}
