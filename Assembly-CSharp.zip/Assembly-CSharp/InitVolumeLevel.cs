﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000055 RID: 85
public class InitVolumeLevel : MonoBehaviour
{
	// Token: 0x0600030A RID: 778 RVA: 0x00013A9C File Offset: 0x00011C9C
	private void OnEnable()
	{
		this.slide.value = PlayerPrefs.GetFloat(this.id);
	}

	// Token: 0x0600030B RID: 779 RVA: 0x00013AB4 File Offset: 0x00011CB4
	public void PlaySample()
	{
		JukeBox.diff.PlaySound(SFXTypes.ui_high_score_menu, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0600030C RID: 780 RVA: 0x00013AD7 File Offset: 0x00011CD7
	public void StopSample()
	{
		JukeBox.diff.FadeStopSound(SFXTypes.ui_high_score_menu, 2f, false, 2.5f);
	}

	// Token: 0x040003D2 RID: 978
	public Slider slide;

	// Token: 0x040003D3 RID: 979
	public string sample;

	// Token: 0x040003D4 RID: 980
	public string id;
}
