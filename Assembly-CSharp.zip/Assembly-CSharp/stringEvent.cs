﻿using System;
using UnityEngine.Events;

// Token: 0x0200009E RID: 158
[Serializable]
public class stringEvent : UnityEvent<string>
{
}
