﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200003F RID: 63
public class DialogAct : MonoBehaviour
{
	// Token: 0x060001FC RID: 508 RVA: 0x0000C80C File Offset: 0x0000AA0C
	public void Init(string labelId, string actionId, Action onvalid, string overridetext = null)
	{
		base.transform.SetAsLastSibling();
		this.time = Time.realtimeSinceStartup;
		this.OnValidate = onvalid;
		this.actionTxt.text = SpeechAct.diff.GetSceneText(actionId).ToUpper();
		this.labelTxt.text = (string.IsNullOrEmpty(overridetext) ? SpeechAct.diff.GetSceneText(labelId) : overridetext);
		if (CardReader.diff)
		{
			CardReader.diff.GetComponent<KingdomAct>().CloseWindows();
		}
		InputAct.diff.MenuNav(true);
	}

	// Token: 0x060001FD RID: 509 RVA: 0x0000C89A File Offset: 0x0000AA9A
	private void OnEnable()
	{
		this.time = Time.realtimeSinceStartup;
	}

	// Token: 0x060001FE RID: 510 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
	public void ActionDo()
	{
		if (this.OnValidate != null)
		{
			this.OnValidate();
		}
		this.Cancel();
	}

	// Token: 0x060001FF RID: 511 RVA: 0x0000C8C2 File Offset: 0x0000AAC2
	public void Cancel()
	{
		if (Time.realtimeSinceStartup - this.time < 0.2f)
		{
			return;
		}
		base.gameObject.SetActive(false);
		InputAct.diff.DisableMenuNav(true);
	}

	// Token: 0x04000225 RID: 549
	public Text actionTxt;

	// Token: 0x04000226 RID: 550
	public Text labelTxt;

	// Token: 0x04000227 RID: 551
	private Action OnValidate;

	// Token: 0x04000228 RID: 552
	private float time;
}
