﻿using System;
using System.Runtime.Serialization;

namespace Unity.IO.Compression
{
	// Token: 0x02000189 RID: 393
	[Serializable]
	public sealed class InvalidDataException : SystemException
	{
		// Token: 0x06000C17 RID: 3095 RVA: 0x000500B6 File Offset: 0x0004E2B6
		public InvalidDataException() : base(SR.GetString("Invalid data"))
		{
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x000500C8 File Offset: 0x0004E2C8
		public InvalidDataException(string message) : base(message)
		{
		}

		// Token: 0x06000C19 RID: 3097 RVA: 0x000500D1 File Offset: 0x0004E2D1
		public InvalidDataException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x000500DB File Offset: 0x0004E2DB
		internal InvalidDataException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}
	}
}
