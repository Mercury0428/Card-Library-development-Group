﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000174 RID: 372
	public enum CompressionMode
	{
		// Token: 0x040009F9 RID: 2553
		Decompress,
		// Token: 0x040009FA RID: 2554
		Compress
	}
}
