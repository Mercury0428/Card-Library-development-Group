﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200017B RID: 379
	internal class FastEncoder
	{
		// Token: 0x06000BA7 RID: 2983 RVA: 0x0004DD67 File Offset: 0x0004BF67
		public FastEncoder()
		{
			this.inputWindow = new FastEncoderWindow();
			this.currentMatch = new Match();
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x0004DD85 File Offset: 0x0004BF85
		internal int BytesInHistory
		{
			get
			{
				return this.inputWindow.BytesAvailable;
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x0004DD92 File Offset: 0x0004BF92
		internal DeflateInput UnprocessedInput
		{
			get
			{
				return this.inputWindow.UnprocessedInput;
			}
		}

		// Token: 0x06000BAA RID: 2986 RVA: 0x0004DD9F File Offset: 0x0004BF9F
		internal void FlushInput()
		{
			this.inputWindow.FlushWindow();
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000BAB RID: 2987 RVA: 0x0004DDAC File Offset: 0x0004BFAC
		internal double LastCompressionRatio
		{
			get
			{
				return this.lastCompressionRatio;
			}
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x0004DDB4 File Offset: 0x0004BFB4
		internal void GetBlock(DeflateInput input, OutputBuffer output, int maxBytesToCopy)
		{
			FastEncoder.WriteDeflatePreamble(output);
			this.GetCompressedOutput(input, output, maxBytesToCopy);
			this.WriteEndOfBlock(output);
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x0004DDCC File Offset: 0x0004BFCC
		internal void GetCompressedData(DeflateInput input, OutputBuffer output)
		{
			this.GetCompressedOutput(input, output, -1);
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x0004DDD7 File Offset: 0x0004BFD7
		internal void GetBlockHeader(OutputBuffer output)
		{
			FastEncoder.WriteDeflatePreamble(output);
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x0004DDDF File Offset: 0x0004BFDF
		internal void GetBlockFooter(OutputBuffer output)
		{
			this.WriteEndOfBlock(output);
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x0004DDE8 File Offset: 0x0004BFE8
		private void GetCompressedOutput(DeflateInput input, OutputBuffer output, int maxBytesToCopy)
		{
			int bytesWritten = output.BytesWritten;
			int num = 0;
			int num2 = this.BytesInHistory + input.Count;
			do
			{
				int num3 = (input.Count < this.inputWindow.FreeWindowSpace) ? input.Count : this.inputWindow.FreeWindowSpace;
				if (maxBytesToCopy >= 1)
				{
					num3 = Math.Min(num3, maxBytesToCopy - num);
				}
				if (num3 > 0)
				{
					this.inputWindow.CopyBytes(input.Buffer, input.StartIndex, num3);
					input.ConsumeBytes(num3);
					num += num3;
				}
				this.GetCompressedOutput(output);
			}
			while (this.SafeToWriteTo(output) && this.InputAvailable(input) && (maxBytesToCopy < 1 || num < maxBytesToCopy));
			int num4 = output.BytesWritten - bytesWritten;
			int num5 = this.BytesInHistory + input.Count;
			int num6 = num2 - num5;
			if (num4 != 0)
			{
				this.lastCompressionRatio = (double)num4 / (double)num6;
			}
		}

		// Token: 0x06000BB1 RID: 2993 RVA: 0x0004DEC0 File Offset: 0x0004C0C0
		private void GetCompressedOutput(OutputBuffer output)
		{
			while (this.inputWindow.BytesAvailable > 0 && this.SafeToWriteTo(output))
			{
				this.inputWindow.GetNextSymbolOrMatch(this.currentMatch);
				if (this.currentMatch.State == MatchState.HasSymbol)
				{
					FastEncoder.WriteChar(this.currentMatch.Symbol, output);
				}
				else if (this.currentMatch.State == MatchState.HasMatch)
				{
					FastEncoder.WriteMatch(this.currentMatch.Length, this.currentMatch.Position, output);
				}
				else
				{
					FastEncoder.WriteChar(this.currentMatch.Symbol, output);
					FastEncoder.WriteMatch(this.currentMatch.Length, this.currentMatch.Position, output);
				}
			}
		}

		// Token: 0x06000BB2 RID: 2994 RVA: 0x0004DF78 File Offset: 0x0004C178
		private bool InputAvailable(DeflateInput input)
		{
			return input.Count > 0 || this.BytesInHistory > 0;
		}

		// Token: 0x06000BB3 RID: 2995 RVA: 0x0004DF8E File Offset: 0x0004C18E
		private bool SafeToWriteTo(OutputBuffer output)
		{
			return output.FreeBytes > 16;
		}

		// Token: 0x06000BB4 RID: 2996 RVA: 0x0004DF9C File Offset: 0x0004C19C
		private void WriteEndOfBlock(OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[256];
			int n = (int)(num & 31U);
			output.WriteBits(n, num >> 5);
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x0004DFC4 File Offset: 0x0004C1C4
		internal static void WriteMatch(int matchLen, int matchPos, OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[254 + matchLen];
			int num2 = (int)(num & 31U);
			if (num2 <= 16)
			{
				output.WriteBits(num2, num >> 5);
			}
			else
			{
				output.WriteBits(16, num >> 5 & 65535U);
				output.WriteBits(num2 - 16, num >> 21);
			}
			num = FastEncoderStatics.FastEncoderDistanceCodeInfo[FastEncoderStatics.GetSlot(matchPos)];
			output.WriteBits((int)(num & 15U), num >> 8);
			int num3 = (int)(num >> 4 & 15U);
			if (num3 != 0)
			{
				output.WriteBits(num3, (uint)(matchPos & (int)FastEncoderStatics.BitMask[num3]));
			}
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x0004E048 File Offset: 0x0004C248
		internal static void WriteChar(byte b, OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[(int)b];
			output.WriteBits((int)(num & 31U), num >> 5);
		}

		// Token: 0x06000BB7 RID: 2999 RVA: 0x0004E06A File Offset: 0x0004C26A
		internal static void WriteDeflatePreamble(OutputBuffer output)
		{
			output.WriteBytes(FastEncoderStatics.FastEncoderTreeStructureData, 0, FastEncoderStatics.FastEncoderTreeStructureData.Length);
			output.WriteBits(9, 34U);
		}

		// Token: 0x04000A24 RID: 2596
		private FastEncoderWindow inputWindow;

		// Token: 0x04000A25 RID: 2597
		private Match currentMatch;

		// Token: 0x04000A26 RID: 2598
		private double lastCompressionRatio;
	}
}
