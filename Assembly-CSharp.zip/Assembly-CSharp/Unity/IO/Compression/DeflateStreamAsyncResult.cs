﻿using System;
using System.Threading;

namespace Unity.IO.Compression
{
	// Token: 0x0200017A RID: 378
	internal class DeflateStreamAsyncResult : IAsyncResult
	{
		// Token: 0x06000B9C RID: 2972 RVA: 0x0004DC1C File Offset: 0x0004BE1C
		public DeflateStreamAsyncResult(object asyncObject, object asyncState, AsyncCallback asyncCallback, byte[] buffer, int offset, int count)
		{
			this.buffer = buffer;
			this.offset = offset;
			this.count = count;
			this.m_CompletedSynchronously = true;
			this.m_AsyncObject = asyncObject;
			this.m_AsyncState = asyncState;
			this.m_AsyncCallback = asyncCallback;
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000B9D RID: 2973 RVA: 0x0004DC58 File Offset: 0x0004BE58
		public object AsyncState
		{
			get
			{
				return this.m_AsyncState;
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000B9E RID: 2974 RVA: 0x0004DC60 File Offset: 0x0004BE60
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				int completed = this.m_Completed;
				if (this.m_Event == null)
				{
					Interlocked.CompareExchange(ref this.m_Event, new ManualResetEvent(completed != 0), null);
				}
				ManualResetEvent manualResetEvent = (ManualResetEvent)this.m_Event;
				if (completed == 0 && this.m_Completed != 0)
				{
					manualResetEvent.Set();
				}
				return manualResetEvent;
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x0004DCB1 File Offset: 0x0004BEB1
		public bool CompletedSynchronously
		{
			get
			{
				return this.m_CompletedSynchronously;
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000BA0 RID: 2976 RVA: 0x0004DCB9 File Offset: 0x0004BEB9
		public bool IsCompleted
		{
			get
			{
				return this.m_Completed != 0;
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x0004DCC4 File Offset: 0x0004BEC4
		internal object Result
		{
			get
			{
				return this.m_Result;
			}
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x0004DCCC File Offset: 0x0004BECC
		internal void Close()
		{
			if (this.m_Event != null)
			{
				((ManualResetEvent)this.m_Event).Close();
			}
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x0004DCE6 File Offset: 0x0004BEE6
		internal void InvokeCallback(bool completedSynchronously, object result)
		{
			this.Complete(completedSynchronously, result);
		}

		// Token: 0x06000BA4 RID: 2980 RVA: 0x0004DCF0 File Offset: 0x0004BEF0
		internal void InvokeCallback(object result)
		{
			this.Complete(result);
		}

		// Token: 0x06000BA5 RID: 2981 RVA: 0x0004DCF9 File Offset: 0x0004BEF9
		private void Complete(bool completedSynchronously, object result)
		{
			this.m_CompletedSynchronously = completedSynchronously;
			this.Complete(result);
		}

		// Token: 0x06000BA6 RID: 2982 RVA: 0x0004DD0C File Offset: 0x0004BF0C
		private void Complete(object result)
		{
			this.m_Result = result;
			Interlocked.Increment(ref this.m_Completed);
			if (this.m_Event != null)
			{
				((ManualResetEvent)this.m_Event).Set();
			}
			if (Interlocked.Increment(ref this.m_InvokedCallback) == 1 && this.m_AsyncCallback != null)
			{
				this.m_AsyncCallback(this);
			}
		}

		// Token: 0x04000A18 RID: 2584
		public byte[] buffer;

		// Token: 0x04000A19 RID: 2585
		public int offset;

		// Token: 0x04000A1A RID: 2586
		public int count;

		// Token: 0x04000A1B RID: 2587
		public bool isWrite;

		// Token: 0x04000A1C RID: 2588
		private object m_AsyncObject;

		// Token: 0x04000A1D RID: 2589
		private object m_AsyncState;

		// Token: 0x04000A1E RID: 2590
		private AsyncCallback m_AsyncCallback;

		// Token: 0x04000A1F RID: 2591
		private object m_Result;

		// Token: 0x04000A20 RID: 2592
		internal bool m_CompletedSynchronously;

		// Token: 0x04000A21 RID: 2593
		private int m_InvokedCallback;

		// Token: 0x04000A22 RID: 2594
		private int m_Completed;

		// Token: 0x04000A23 RID: 2595
		private object m_Event;
	}
}
