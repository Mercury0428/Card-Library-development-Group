﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000173 RID: 371
	internal enum BlockType
	{
		// Token: 0x040009F5 RID: 2549
		Uncompressed,
		// Token: 0x040009F6 RID: 2550
		Static,
		// Token: 0x040009F7 RID: 2551
		Dynamic
	}
}
