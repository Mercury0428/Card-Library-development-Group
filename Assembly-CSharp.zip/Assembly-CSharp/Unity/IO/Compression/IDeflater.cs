﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000185 RID: 389
	internal interface IDeflater : IDisposable
	{
		// Token: 0x06000BFA RID: 3066
		bool NeedsInput();

		// Token: 0x06000BFB RID: 3067
		void SetInput(byte[] inputBuffer, int startIndex, int count);

		// Token: 0x06000BFC RID: 3068
		int GetDeflateOutput(byte[] outputBuffer);

		// Token: 0x06000BFD RID: 3069
		bool Finish(byte[] outputBuffer, out int bytesRead);
	}
}
