﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000177 RID: 375
	internal class DeflateInput
	{
		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000B63 RID: 2915 RVA: 0x0004CEB7 File Offset: 0x0004B0B7
		// (set) Token: 0x06000B64 RID: 2916 RVA: 0x0004CEBF File Offset: 0x0004B0BF
		internal byte[] Buffer
		{
			get
			{
				return this.buffer;
			}
			set
			{
				this.buffer = value;
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000B65 RID: 2917 RVA: 0x0004CEC8 File Offset: 0x0004B0C8
		// (set) Token: 0x06000B66 RID: 2918 RVA: 0x0004CED0 File Offset: 0x0004B0D0
		internal int Count
		{
			get
			{
				return this.count;
			}
			set
			{
				this.count = value;
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000B67 RID: 2919 RVA: 0x0004CED9 File Offset: 0x0004B0D9
		// (set) Token: 0x06000B68 RID: 2920 RVA: 0x0004CEE1 File Offset: 0x0004B0E1
		internal int StartIndex
		{
			get
			{
				return this.startIndex;
			}
			set
			{
				this.startIndex = value;
			}
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x0004CEEA File Offset: 0x0004B0EA
		internal void ConsumeBytes(int n)
		{
			this.startIndex += n;
			this.count -= n;
		}

		// Token: 0x06000B6A RID: 2922 RVA: 0x0004CF08 File Offset: 0x0004B108
		internal DeflateInput.InputState DumpState()
		{
			DeflateInput.InputState result;
			result.count = this.count;
			result.startIndex = this.startIndex;
			return result;
		}

		// Token: 0x06000B6B RID: 2923 RVA: 0x0004CF30 File Offset: 0x0004B130
		internal void RestoreState(DeflateInput.InputState state)
		{
			this.count = state.count;
			this.startIndex = state.startIndex;
		}

		// Token: 0x040009FE RID: 2558
		private byte[] buffer;

		// Token: 0x040009FF RID: 2559
		private int count;

		// Token: 0x04000A00 RID: 2560
		private int startIndex;

		// Token: 0x02000358 RID: 856
		internal struct InputState
		{
			// Token: 0x0400125D RID: 4701
			internal int count;

			// Token: 0x0400125E RID: 4702
			internal int startIndex;
		}
	}
}
