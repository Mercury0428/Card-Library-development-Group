﻿using System;
using System.Diagnostics;

namespace Unity.IO.Compression
{
	// Token: 0x0200017D RID: 381
	internal class FastEncoderWindow
	{
		// Token: 0x06000BBB RID: 3003 RVA: 0x0004E202 File Offset: 0x0004C402
		public FastEncoderWindow()
		{
			this.ResetWindow();
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000BBC RID: 3004 RVA: 0x0004E210 File Offset: 0x0004C410
		public int BytesAvailable
		{
			get
			{
				return this.bufEnd - this.bufPos;
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000BBD RID: 3005 RVA: 0x0004E21F File Offset: 0x0004C41F
		public DeflateInput UnprocessedInput
		{
			get
			{
				return new DeflateInput
				{
					Buffer = this.window,
					StartIndex = this.bufPos,
					Count = this.bufEnd - this.bufPos
				};
			}
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x0004E251 File Offset: 0x0004C451
		public void FlushWindow()
		{
			this.ResetWindow();
		}

		// Token: 0x06000BBF RID: 3007 RVA: 0x0004E25C File Offset: 0x0004C45C
		private void ResetWindow()
		{
			this.window = new byte[16646];
			this.prev = new ushort[8450];
			this.lookup = new ushort[2048];
			this.bufPos = 8192;
			this.bufEnd = this.bufPos;
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000BC0 RID: 3008 RVA: 0x0004E2B0 File Offset: 0x0004C4B0
		public int FreeWindowSpace
		{
			get
			{
				return 16384 - this.bufEnd;
			}
		}

		// Token: 0x06000BC1 RID: 3009 RVA: 0x0004E2BE File Offset: 0x0004C4BE
		public void CopyBytes(byte[] inputBuffer, int startIndex, int count)
		{
			Array.Copy(inputBuffer, startIndex, this.window, this.bufEnd, count);
			this.bufEnd += count;
		}

		// Token: 0x06000BC2 RID: 3010 RVA: 0x0004E2E4 File Offset: 0x0004C4E4
		public void MoveWindows()
		{
			Array.Copy(this.window, this.bufPos - 8192, this.window, 0, 8192);
			for (int i = 0; i < 2048; i++)
			{
				int num = (int)(this.lookup[i] - 8192);
				if (num <= 0)
				{
					this.lookup[i] = 0;
				}
				else
				{
					this.lookup[i] = (ushort)num;
				}
			}
			for (int i = 0; i < 8192; i++)
			{
				long num2 = (long)((ulong)this.prev[i] - 8192UL);
				if (num2 <= 0L)
				{
					this.prev[i] = 0;
				}
				else
				{
					this.prev[i] = (ushort)num2;
				}
			}
			this.bufPos = 8192;
			this.bufEnd = this.bufPos;
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x0004E39E File Offset: 0x0004C59E
		private uint HashValue(uint hash, byte b)
		{
			return hash << 4 ^ (uint)b;
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x0004E3A8 File Offset: 0x0004C5A8
		private uint InsertString(ref uint hash)
		{
			hash = this.HashValue(hash, this.window[this.bufPos + 2]);
			uint num = (uint)this.lookup[(int)(hash & 2047U)];
			this.lookup[(int)(hash & 2047U)] = (ushort)this.bufPos;
			this.prev[this.bufPos & 8191] = (ushort)num;
			return num;
		}

		// Token: 0x06000BC5 RID: 3013 RVA: 0x0004E40C File Offset: 0x0004C60C
		private void InsertStrings(ref uint hash, int matchLen)
		{
			if (this.bufEnd - this.bufPos <= matchLen)
			{
				this.bufPos += matchLen - 1;
				return;
			}
			while (--matchLen > 0)
			{
				this.InsertString(ref hash);
				this.bufPos++;
			}
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x0004E45C File Offset: 0x0004C65C
		internal bool GetNextSymbolOrMatch(Match match)
		{
			uint hash = this.HashValue(0U, this.window[this.bufPos]);
			hash = this.HashValue(hash, this.window[this.bufPos + 1]);
			int position = 0;
			int num;
			if (this.bufEnd - this.bufPos <= 3)
			{
				num = 0;
			}
			else
			{
				int num2 = (int)this.InsertString(ref hash);
				if (num2 != 0)
				{
					num = this.FindMatch(num2, out position, 32, 32);
					if (this.bufPos + num > this.bufEnd)
					{
						num = this.bufEnd - this.bufPos;
					}
				}
				else
				{
					num = 0;
				}
			}
			if (num < 3)
			{
				match.State = MatchState.HasSymbol;
				match.Symbol = this.window[this.bufPos];
				this.bufPos++;
			}
			else
			{
				this.bufPos++;
				if (num <= 6)
				{
					int position2 = 0;
					int num3 = (int)this.InsertString(ref hash);
					int num4;
					if (num3 != 0)
					{
						num4 = this.FindMatch(num3, out position2, (num < 4) ? 32 : 8, 32);
						if (this.bufPos + num4 > this.bufEnd)
						{
							num4 = this.bufEnd - this.bufPos;
						}
					}
					else
					{
						num4 = 0;
					}
					if (num4 > num)
					{
						match.State = MatchState.HasSymbolAndMatch;
						match.Symbol = this.window[this.bufPos - 1];
						match.Position = position2;
						match.Length = num4;
						this.bufPos++;
						num = num4;
						this.InsertStrings(ref hash, num);
					}
					else
					{
						match.State = MatchState.HasMatch;
						match.Position = position;
						match.Length = num;
						num--;
						this.bufPos++;
						this.InsertStrings(ref hash, num);
					}
				}
				else
				{
					match.State = MatchState.HasMatch;
					match.Position = position;
					match.Length = num;
					this.InsertStrings(ref hash, num);
				}
			}
			if (this.bufPos == 16384)
			{
				this.MoveWindows();
			}
			return true;
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x0004E62C File Offset: 0x0004C82C
		private int FindMatch(int search, out int matchPos, int searchDepth, int niceLength)
		{
			int num = 0;
			int num2 = 0;
			int num3 = this.bufPos - 8192;
			byte b = this.window[this.bufPos];
			while (search > num3)
			{
				if (this.window[search + num] == b)
				{
					int num4 = 0;
					while (num4 < 258 && this.window[this.bufPos + num4] == this.window[search + num4])
					{
						num4++;
					}
					if (num4 > num)
					{
						num = num4;
						num2 = search;
						if (num4 > 32)
						{
							break;
						}
						b = this.window[this.bufPos + num4];
					}
				}
				if (--searchDepth == 0)
				{
					break;
				}
				search = (int)this.prev[search & 8191];
			}
			matchPos = this.bufPos - num2 - 1;
			if (num == 3 && matchPos >= 16384)
			{
				return 0;
			}
			return num;
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x0004E6F4 File Offset: 0x0004C8F4
		[Conditional("DEBUG")]
		private void VerifyHashes()
		{
			for (int i = 0; i < 2048; i++)
			{
				ushort num = this.lookup[i];
				while (num != 0 && this.bufPos - (int)num < 8192)
				{
					ushort num2 = this.prev[(int)(num & 8191)];
					if (this.bufPos - (int)num2 >= 8192)
					{
						break;
					}
					num = num2;
				}
			}
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x0004E74E File Offset: 0x0004C94E
		private uint RecalculateHash(int position)
		{
			return (uint)(((int)this.window[position] << 8 ^ (int)this.window[position + 1] << 4 ^ (int)this.window[position + 2]) & 2047);
		}

		// Token: 0x04000A39 RID: 2617
		private byte[] window;

		// Token: 0x04000A3A RID: 2618
		private int bufPos;

		// Token: 0x04000A3B RID: 2619
		private int bufEnd;

		// Token: 0x04000A3C RID: 2620
		private const int FastEncoderHashShift = 4;

		// Token: 0x04000A3D RID: 2621
		private const int FastEncoderHashtableSize = 2048;

		// Token: 0x04000A3E RID: 2622
		private const int FastEncoderHashMask = 2047;

		// Token: 0x04000A3F RID: 2623
		private const int FastEncoderWindowSize = 8192;

		// Token: 0x04000A40 RID: 2624
		private const int FastEncoderWindowMask = 8191;

		// Token: 0x04000A41 RID: 2625
		private const int FastEncoderMatch3DistThreshold = 16384;

		// Token: 0x04000A42 RID: 2626
		internal const int MaxMatch = 258;

		// Token: 0x04000A43 RID: 2627
		internal const int MinMatch = 3;

		// Token: 0x04000A44 RID: 2628
		private const int SearchDepth = 32;

		// Token: 0x04000A45 RID: 2629
		private const int GoodLength = 4;

		// Token: 0x04000A46 RID: 2630
		private const int NiceLength = 32;

		// Token: 0x04000A47 RID: 2631
		private const int LazyMatchThreshold = 6;

		// Token: 0x04000A48 RID: 2632
		private ushort[] prev;

		// Token: 0x04000A49 RID: 2633
		private ushort[] lookup;
	}
}
