﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200017E RID: 382
	internal interface IFileFormatWriter
	{
		// Token: 0x06000BCA RID: 3018
		byte[] GetHeader();

		// Token: 0x06000BCB RID: 3019
		void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy);

		// Token: 0x06000BCC RID: 3020
		byte[] GetFooter();
	}
}
