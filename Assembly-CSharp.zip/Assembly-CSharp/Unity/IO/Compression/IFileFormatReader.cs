﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200017F RID: 383
	internal interface IFileFormatReader
	{
		// Token: 0x06000BCD RID: 3021
		bool ReadHeader(InputBuffer input);

		// Token: 0x06000BCE RID: 3022
		bool ReadFooter(InputBuffer input);

		// Token: 0x06000BCF RID: 3023
		void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy);

		// Token: 0x06000BD0 RID: 3024
		void Validate();
	}
}
