﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200018D RID: 397
	internal class SR
	{
		// Token: 0x06000C38 RID: 3128 RVA: 0x00002050 File Offset: 0x00000250
		private SR()
		{
		}

		// Token: 0x06000C39 RID: 3129 RVA: 0x00050610 File Offset: 0x0004E810
		internal static string GetString(string p)
		{
			return p;
		}

		// Token: 0x04000AB2 RID: 2738
		public const string ArgumentOutOfRange_Enum = "Argument out of range";

		// Token: 0x04000AB3 RID: 2739
		public const string CorruptedGZipHeader = "Corrupted gzip header";

		// Token: 0x04000AB4 RID: 2740
		public const string CannotReadFromDeflateStream = "Cannot read from deflate stream";

		// Token: 0x04000AB5 RID: 2741
		public const string CannotWriteToDeflateStream = "Cannot write to deflate stream";

		// Token: 0x04000AB6 RID: 2742
		public const string GenericInvalidData = "Invalid data";

		// Token: 0x04000AB7 RID: 2743
		public const string InvalidCRC = "Invalid CRC";

		// Token: 0x04000AB8 RID: 2744
		public const string InvalidStreamSize = "Invalid stream size";

		// Token: 0x04000AB9 RID: 2745
		public const string InvalidHuffmanData = "Invalid Huffman data";

		// Token: 0x04000ABA RID: 2746
		public const string InvalidBeginCall = "Invalid begin call";

		// Token: 0x04000ABB RID: 2747
		public const string InvalidEndCall = "Invalid end call";

		// Token: 0x04000ABC RID: 2748
		public const string InvalidBlockLength = "Invalid block length";

		// Token: 0x04000ABD RID: 2749
		public const string InvalidArgumentOffsetCount = "Invalid argument offset count";

		// Token: 0x04000ABE RID: 2750
		public const string NotSupported = "Not supported";

		// Token: 0x04000ABF RID: 2751
		public const string NotWriteableStream = "Not a writeable stream";

		// Token: 0x04000AC0 RID: 2752
		public const string NotReadableStream = "Not a readable stream";

		// Token: 0x04000AC1 RID: 2753
		public const string ObjectDisposed_StreamClosed = "Object disposed";

		// Token: 0x04000AC2 RID: 2754
		public const string UnknownState = "Unknown state";

		// Token: 0x04000AC3 RID: 2755
		public const string UnknownCompressionMode = "Unknown compression mode";

		// Token: 0x04000AC4 RID: 2756
		public const string UnknownBlockType = "Unknown block type";
	}
}
