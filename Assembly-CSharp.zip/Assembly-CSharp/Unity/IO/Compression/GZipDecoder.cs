﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000180 RID: 384
	internal class GZipDecoder : IFileFormatReader
	{
		// Token: 0x06000BD1 RID: 3025 RVA: 0x0004E778 File Offset: 0x0004C978
		public GZipDecoder()
		{
			this.Reset();
		}

		// Token: 0x06000BD2 RID: 3026 RVA: 0x0004E786 File Offset: 0x0004C986
		public void Reset()
		{
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingID1;
			this.gzipFooterSubstate = GZipDecoder.GzipHeaderState.ReadingCRC;
			this.expectedCrc32 = 0U;
			this.expectedOutputStreamSizeModulo = 0U;
		}

		// Token: 0x06000BD3 RID: 3027 RVA: 0x0004E7A8 File Offset: 0x0004C9A8
		public bool ReadHeader(InputBuffer input)
		{
			int bits;
			switch (this.gzipHeaderSubstate)
			{
			case GZipDecoder.GzipHeaderState.ReadingID1:
				bits = input.GetBits(8);
				if (bits < 0)
				{
					return false;
				}
				if (bits != 31)
				{
					throw new InvalidDataException(SR.GetString("Corrupted gzip header"));
				}
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingID2;
				break;
			case GZipDecoder.GzipHeaderState.ReadingID2:
				break;
			case GZipDecoder.GzipHeaderState.ReadingCM:
				goto IL_A5;
			case GZipDecoder.GzipHeaderState.ReadingFLG:
				goto IL_CE;
			case GZipDecoder.GzipHeaderState.ReadingMMTime:
				goto IL_F1;
			case GZipDecoder.GzipHeaderState.ReadingXFL:
				goto IL_128;
			case GZipDecoder.GzipHeaderState.ReadingOS:
				goto IL_13D;
			case GZipDecoder.GzipHeaderState.ReadingXLen1:
				goto IL_152;
			case GZipDecoder.GzipHeaderState.ReadingXLen2:
				goto IL_17B;
			case GZipDecoder.GzipHeaderState.ReadingXLenData:
				goto IL_1A8;
			case GZipDecoder.GzipHeaderState.ReadingFileName:
				goto IL_1E5;
			case GZipDecoder.GzipHeaderState.ReadingComment:
				goto IL_212;
			case GZipDecoder.GzipHeaderState.ReadingCRC16Part1:
				goto IL_240;
			case GZipDecoder.GzipHeaderState.ReadingCRC16Part2:
				goto IL_26A;
			case GZipDecoder.GzipHeaderState.Done:
				return true;
			default:
				throw new InvalidDataException(SR.GetString("Unknown state"));
			}
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			if (bits != 139)
			{
				throw new InvalidDataException(SR.GetString("Corrupted gzip header"));
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCM;
			IL_A5:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			if (bits != 8)
			{
				throw new InvalidDataException(SR.GetString("Unknown compression mode"));
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingFLG;
			IL_CE:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzip_header_flag = bits;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingMMTime;
			this.loopCounter = 0;
			IL_F1:
			while (this.loopCounter < 4)
			{
				bits = input.GetBits(8);
				if (bits < 0)
				{
					return false;
				}
				this.loopCounter++;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXFL;
			this.loopCounter = 0;
			IL_128:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingOS;
			IL_13D:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLen1;
			IL_152:
			if ((this.gzip_header_flag & 4) == 0)
			{
				goto IL_1E5;
			}
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzip_header_xlen = bits;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLen2;
			IL_17B:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzip_header_xlen |= bits << 8;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLenData;
			this.loopCounter = 0;
			IL_1A8:
			while (this.loopCounter < this.gzip_header_xlen)
			{
				bits = input.GetBits(8);
				if (bits < 0)
				{
					return false;
				}
				this.loopCounter++;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingFileName;
			this.loopCounter = 0;
			IL_1E5:
			if ((this.gzip_header_flag & 8) == 0)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingComment;
			}
			else
			{
				for (;;)
				{
					bits = input.GetBits(8);
					if (bits < 0)
					{
						break;
					}
					if (bits == 0)
					{
						goto Block_20;
					}
				}
				return false;
				Block_20:
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingComment;
			}
			IL_212:
			if ((this.gzip_header_flag & 16) == 0)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part1;
			}
			else
			{
				for (;;)
				{
					bits = input.GetBits(8);
					if (bits < 0)
					{
						break;
					}
					if (bits == 0)
					{
						goto Block_23;
					}
				}
				return false;
				Block_23:
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part1;
			}
			IL_240:
			if ((this.gzip_header_flag & 2) == 0)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.Done;
				return true;
			}
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part2;
			IL_26A:
			bits = input.GetBits(8);
			if (bits < 0)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.Done;
			return true;
		}

		// Token: 0x06000BD4 RID: 3028 RVA: 0x0004EA48 File Offset: 0x0004CC48
		public bool ReadFooter(InputBuffer input)
		{
			input.SkipToByteBoundary();
			if (this.gzipFooterSubstate == GZipDecoder.GzipHeaderState.ReadingCRC)
			{
				while (this.loopCounter < 4)
				{
					int bits = input.GetBits(8);
					if (bits < 0)
					{
						return false;
					}
					this.expectedCrc32 |= (uint)((uint)bits << 8 * this.loopCounter);
					this.loopCounter++;
				}
				this.gzipFooterSubstate = GZipDecoder.GzipHeaderState.ReadingFileSize;
				this.loopCounter = 0;
			}
			if (this.gzipFooterSubstate == GZipDecoder.GzipHeaderState.ReadingFileSize)
			{
				if (this.loopCounter == 0)
				{
					this.expectedOutputStreamSizeModulo = 0U;
				}
				while (this.loopCounter < 4)
				{
					int bits2 = input.GetBits(8);
					if (bits2 < 0)
					{
						return false;
					}
					this.expectedOutputStreamSizeModulo |= (uint)((uint)bits2 << 8 * this.loopCounter);
					this.loopCounter++;
				}
			}
			return true;
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x0004EB10 File Offset: 0x0004CD10
		public void UpdateWithBytesRead(byte[] buffer, int offset, int copied)
		{
			this.actualCrc32 = Crc32Helper.UpdateCrc32(this.actualCrc32, buffer, offset, copied);
			long num = this.actualStreamSizeModulo + (long)((ulong)copied);
			if (num >= 4294967296L)
			{
				num %= 4294967296L;
			}
			this.actualStreamSizeModulo = num;
		}

		// Token: 0x06000BD6 RID: 3030 RVA: 0x0004EB5A File Offset: 0x0004CD5A
		public void Validate()
		{
			if (this.expectedCrc32 != this.actualCrc32)
			{
				throw new InvalidDataException(SR.GetString("Invalid CRC"));
			}
			if (this.actualStreamSizeModulo != (long)((ulong)this.expectedOutputStreamSizeModulo))
			{
				throw new InvalidDataException(SR.GetString("Invalid stream size"));
			}
		}

		// Token: 0x04000A4A RID: 2634
		private GZipDecoder.GzipHeaderState gzipHeaderSubstate;

		// Token: 0x04000A4B RID: 2635
		private GZipDecoder.GzipHeaderState gzipFooterSubstate;

		// Token: 0x04000A4C RID: 2636
		private int gzip_header_flag;

		// Token: 0x04000A4D RID: 2637
		private int gzip_header_xlen;

		// Token: 0x04000A4E RID: 2638
		private uint expectedCrc32;

		// Token: 0x04000A4F RID: 2639
		private uint expectedOutputStreamSizeModulo;

		// Token: 0x04000A50 RID: 2640
		private int loopCounter;

		// Token: 0x04000A51 RID: 2641
		private uint actualCrc32;

		// Token: 0x04000A52 RID: 2642
		private long actualStreamSizeModulo;

		// Token: 0x0200035C RID: 860
		internal enum GzipHeaderState
		{
			// Token: 0x0400126B RID: 4715
			ReadingID1,
			// Token: 0x0400126C RID: 4716
			ReadingID2,
			// Token: 0x0400126D RID: 4717
			ReadingCM,
			// Token: 0x0400126E RID: 4718
			ReadingFLG,
			// Token: 0x0400126F RID: 4719
			ReadingMMTime,
			// Token: 0x04001270 RID: 4720
			ReadingXFL,
			// Token: 0x04001271 RID: 4721
			ReadingOS,
			// Token: 0x04001272 RID: 4722
			ReadingXLen1,
			// Token: 0x04001273 RID: 4723
			ReadingXLen2,
			// Token: 0x04001274 RID: 4724
			ReadingXLenData,
			// Token: 0x04001275 RID: 4725
			ReadingFileName,
			// Token: 0x04001276 RID: 4726
			ReadingComment,
			// Token: 0x04001277 RID: 4727
			ReadingCRC16Part1,
			// Token: 0x04001278 RID: 4728
			ReadingCRC16Part2,
			// Token: 0x04001279 RID: 4729
			Done,
			// Token: 0x0400127A RID: 4730
			ReadingCRC,
			// Token: 0x0400127B RID: 4731
			ReadingFileSize
		}

		// Token: 0x0200035D RID: 861
		[Flags]
		internal enum GZipOptionalHeaderFlags
		{
			// Token: 0x0400127D RID: 4733
			CRCFlag = 2,
			// Token: 0x0400127E RID: 4734
			ExtraFieldsFlag = 4,
			// Token: 0x0400127F RID: 4735
			FileNameFlag = 8,
			// Token: 0x04001280 RID: 4736
			CommentFlag = 16
		}
	}
}
