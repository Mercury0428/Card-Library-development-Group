﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000188 RID: 392
	internal class InputBuffer
	{
		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000C0B RID: 3083 RVA: 0x0004FD84 File Offset: 0x0004DF84
		public int AvailableBits
		{
			get
			{
				return this.bitsInBuffer;
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000C0C RID: 3084 RVA: 0x0004FD8C File Offset: 0x0004DF8C
		public int AvailableBytes
		{
			get
			{
				return this.end - this.start + this.bitsInBuffer / 8;
			}
		}

		// Token: 0x06000C0D RID: 3085 RVA: 0x0004FDA4 File Offset: 0x0004DFA4
		public bool EnsureBitsAvailable(int count)
		{
			if (this.bitsInBuffer < count)
			{
				if (this.NeedsInput())
				{
					return false;
				}
				uint num = this.bitBuffer;
				byte[] array = this.buffer;
				int num2 = this.start;
				this.start = num2 + 1;
				this.bitBuffer = (num | array[num2] << (this.bitsInBuffer & 31));
				this.bitsInBuffer += 8;
				if (this.bitsInBuffer < count)
				{
					if (this.NeedsInput())
					{
						return false;
					}
					uint num3 = this.bitBuffer;
					byte[] array2 = this.buffer;
					num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num3 | array2[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
			}
			return true;
		}

		// Token: 0x06000C0E RID: 3086 RVA: 0x0004FE58 File Offset: 0x0004E058
		public uint TryLoad16Bits()
		{
			if (this.bitsInBuffer < 8)
			{
				if (this.start < this.end)
				{
					uint num = this.bitBuffer;
					byte[] array = this.buffer;
					int num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num | array[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
				if (this.start < this.end)
				{
					uint num3 = this.bitBuffer;
					byte[] array2 = this.buffer;
					int num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num3 | array2[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
			}
			else if (this.bitsInBuffer < 16 && this.start < this.end)
			{
				uint num4 = this.bitBuffer;
				byte[] array3 = this.buffer;
				int num2 = this.start;
				this.start = num2 + 1;
				this.bitBuffer = (num4 | array3[num2] << (this.bitsInBuffer & 31));
				this.bitsInBuffer += 8;
			}
			return this.bitBuffer;
		}

		// Token: 0x06000C0F RID: 3087 RVA: 0x0004FF67 File Offset: 0x0004E167
		private uint GetBitMask(int count)
		{
			return (1U << count) - 1U;
		}

		// Token: 0x06000C10 RID: 3088 RVA: 0x0004FF71 File Offset: 0x0004E171
		public int GetBits(int count)
		{
			if (!this.EnsureBitsAvailable(count))
			{
				return -1;
			}
			int result = (int)(this.bitBuffer & this.GetBitMask(count));
			this.bitBuffer >>= count;
			this.bitsInBuffer -= count;
			return result;
		}

		// Token: 0x06000C11 RID: 3089 RVA: 0x0004FFAC File Offset: 0x0004E1AC
		public int CopyTo(byte[] output, int offset, int length)
		{
			int num = 0;
			while (this.bitsInBuffer > 0 && length > 0)
			{
				output[offset++] = (byte)this.bitBuffer;
				this.bitBuffer >>= 8;
				this.bitsInBuffer -= 8;
				length--;
				num++;
			}
			if (length == 0)
			{
				return num;
			}
			int num2 = this.end - this.start;
			if (length > num2)
			{
				length = num2;
			}
			Array.Copy(this.buffer, this.start, output, offset, length);
			this.start += length;
			return num + length;
		}

		// Token: 0x06000C12 RID: 3090 RVA: 0x0005003D File Offset: 0x0004E23D
		public bool NeedsInput()
		{
			return this.start == this.end;
		}

		// Token: 0x06000C13 RID: 3091 RVA: 0x0005004D File Offset: 0x0004E24D
		public void SetInput(byte[] buffer, int offset, int length)
		{
			this.buffer = buffer;
			this.start = offset;
			this.end = offset + length;
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x00050066 File Offset: 0x0004E266
		public void SkipBits(int n)
		{
			this.bitBuffer >>= n;
			this.bitsInBuffer -= n;
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x00050087 File Offset: 0x0004E287
		public void SkipToByteBoundary()
		{
			this.bitBuffer >>= this.bitsInBuffer % 8;
			this.bitsInBuffer -= this.bitsInBuffer % 8;
		}

		// Token: 0x04000AA0 RID: 2720
		private byte[] buffer;

		// Token: 0x04000AA1 RID: 2721
		private int start;

		// Token: 0x04000AA2 RID: 2722
		private int end;

		// Token: 0x04000AA3 RID: 2723
		private uint bitBuffer;

		// Token: 0x04000AA4 RID: 2724
		private int bitsInBuffer;
	}
}
