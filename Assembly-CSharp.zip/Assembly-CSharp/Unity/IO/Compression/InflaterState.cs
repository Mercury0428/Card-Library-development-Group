﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000187 RID: 391
	internal enum InflaterState
	{
		// Token: 0x04000A89 RID: 2697
		ReadingHeader,
		// Token: 0x04000A8A RID: 2698
		ReadingBFinal = 2,
		// Token: 0x04000A8B RID: 2699
		ReadingBType,
		// Token: 0x04000A8C RID: 2700
		ReadingNumLitCodes,
		// Token: 0x04000A8D RID: 2701
		ReadingNumDistCodes,
		// Token: 0x04000A8E RID: 2702
		ReadingNumCodeLengthCodes,
		// Token: 0x04000A8F RID: 2703
		ReadingCodeLengthCodes,
		// Token: 0x04000A90 RID: 2704
		ReadingTreeCodesBefore,
		// Token: 0x04000A91 RID: 2705
		ReadingTreeCodesAfter,
		// Token: 0x04000A92 RID: 2706
		DecodeTop,
		// Token: 0x04000A93 RID: 2707
		HaveInitialLength,
		// Token: 0x04000A94 RID: 2708
		HaveFullLength,
		// Token: 0x04000A95 RID: 2709
		HaveDistCode,
		// Token: 0x04000A96 RID: 2710
		UncompressedAligning = 15,
		// Token: 0x04000A97 RID: 2711
		UncompressedByte1,
		// Token: 0x04000A98 RID: 2712
		UncompressedByte2,
		// Token: 0x04000A99 RID: 2713
		UncompressedByte3,
		// Token: 0x04000A9A RID: 2714
		UncompressedByte4,
		// Token: 0x04000A9B RID: 2715
		DecodingUncompressed,
		// Token: 0x04000A9C RID: 2716
		StartReadingFooter,
		// Token: 0x04000A9D RID: 2717
		ReadingFooter,
		// Token: 0x04000A9E RID: 2718
		VerifyingFooter,
		// Token: 0x04000A9F RID: 2719
		Done
	}
}
