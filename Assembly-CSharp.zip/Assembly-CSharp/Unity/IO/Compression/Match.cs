﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200018A RID: 394
	internal class Match
	{
		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000C1B RID: 3099 RVA: 0x000500E5 File Offset: 0x0004E2E5
		// (set) Token: 0x06000C1C RID: 3100 RVA: 0x000500ED File Offset: 0x0004E2ED
		internal MatchState State
		{
			get
			{
				return this.state;
			}
			set
			{
				this.state = value;
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000C1D RID: 3101 RVA: 0x000500F6 File Offset: 0x0004E2F6
		// (set) Token: 0x06000C1E RID: 3102 RVA: 0x000500FE File Offset: 0x0004E2FE
		internal int Position
		{
			get
			{
				return this.pos;
			}
			set
			{
				this.pos = value;
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000C1F RID: 3103 RVA: 0x00050107 File Offset: 0x0004E307
		// (set) Token: 0x06000C20 RID: 3104 RVA: 0x0005010F File Offset: 0x0004E30F
		internal int Length
		{
			get
			{
				return this.len;
			}
			set
			{
				this.len = value;
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000C21 RID: 3105 RVA: 0x00050118 File Offset: 0x0004E318
		// (set) Token: 0x06000C22 RID: 3106 RVA: 0x00050120 File Offset: 0x0004E320
		internal byte Symbol
		{
			get
			{
				return this.symbol;
			}
			set
			{
				this.symbol = value;
			}
		}

		// Token: 0x04000AA5 RID: 2725
		private MatchState state;

		// Token: 0x04000AA6 RID: 2726
		private int pos;

		// Token: 0x04000AA7 RID: 2727
		private int len;

		// Token: 0x04000AA8 RID: 2728
		private byte symbol;
	}
}
