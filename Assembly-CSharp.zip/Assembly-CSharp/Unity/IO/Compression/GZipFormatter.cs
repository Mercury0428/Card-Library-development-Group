﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000183 RID: 387
	internal class GZipFormatter : IFileFormatWriter
	{
		// Token: 0x06000BEB RID: 3051 RVA: 0x0004EDB7 File Offset: 0x0004CFB7
		internal GZipFormatter() : this(3)
		{
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x0004EDC0 File Offset: 0x0004CFC0
		internal GZipFormatter(int compressionLevel)
		{
			if (compressionLevel == 10)
			{
				this.headerBytes[8] = 2;
			}
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x0004EDEE File Offset: 0x0004CFEE
		public byte[] GetHeader()
		{
			return this.headerBytes;
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x0004EDF8 File Offset: 0x0004CFF8
		public void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy)
		{
			this._crc32 = Crc32Helper.UpdateCrc32(this._crc32, buffer, offset, bytesToCopy);
			long num = this._inputStreamSizeModulo + (long)((ulong)bytesToCopy);
			if (num >= 4294967296L)
			{
				num %= 4294967296L;
			}
			this._inputStreamSizeModulo = num;
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x0004EE44 File Offset: 0x0004D044
		public byte[] GetFooter()
		{
			byte[] array = new byte[8];
			this.WriteUInt32(array, this._crc32, 0);
			this.WriteUInt32(array, (uint)this._inputStreamSizeModulo, 4);
			return array;
		}

		// Token: 0x06000BF0 RID: 3056 RVA: 0x0004EE76 File Offset: 0x0004D076
		internal void WriteUInt32(byte[] b, uint value, int startIndex)
		{
			b[startIndex] = (byte)value;
			b[startIndex + 1] = (byte)(value >> 8);
			b[startIndex + 2] = (byte)(value >> 16);
			b[startIndex + 3] = (byte)(value >> 24);
		}

		// Token: 0x04000A5D RID: 2653
		private byte[] headerBytes = new byte[]
		{
			31,
			139,
			8,
			0,
			0,
			0,
			0,
			0,
			4,
			0
		};

		// Token: 0x04000A5E RID: 2654
		private uint _crc32;

		// Token: 0x04000A5F RID: 2655
		private long _inputStreamSizeModulo;
	}
}
