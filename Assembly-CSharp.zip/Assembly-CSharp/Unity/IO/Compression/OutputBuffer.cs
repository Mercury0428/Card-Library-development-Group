﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200018B RID: 395
	internal class OutputBuffer
	{
		// Token: 0x06000C24 RID: 3108 RVA: 0x00050129 File Offset: 0x0004E329
		internal void UpdateBuffer(byte[] output)
		{
			this.byteBuffer = output;
			this.pos = 0;
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000C25 RID: 3109 RVA: 0x00050139 File Offset: 0x0004E339
		internal int BytesWritten
		{
			get
			{
				return this.pos;
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000C26 RID: 3110 RVA: 0x00050141 File Offset: 0x0004E341
		internal int FreeBytes
		{
			get
			{
				return this.byteBuffer.Length - this.pos;
			}
		}

		// Token: 0x06000C27 RID: 3111 RVA: 0x00050154 File Offset: 0x0004E354
		internal void WriteUInt16(ushort value)
		{
			byte[] array = this.byteBuffer;
			int num = this.pos;
			this.pos = num + 1;
			array[num] = (byte)value;
			byte[] array2 = this.byteBuffer;
			num = this.pos;
			this.pos = num + 1;
			array2[num] = (byte)(value >> 8);
		}

		// Token: 0x06000C28 RID: 3112 RVA: 0x00050198 File Offset: 0x0004E398
		internal void WriteBits(int n, uint bits)
		{
			this.bitBuf |= bits << this.bitCount;
			this.bitCount += n;
			if (this.bitCount >= 16)
			{
				byte[] array = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array[num] = (byte)this.bitBuf;
				byte[] array2 = this.byteBuffer;
				num = this.pos;
				this.pos = num + 1;
				array2[num] = (byte)(this.bitBuf >> 8);
				this.bitCount -= 16;
				this.bitBuf >>= 16;
			}
		}

		// Token: 0x06000C29 RID: 3113 RVA: 0x00050234 File Offset: 0x0004E434
		internal void FlushBits()
		{
			while (this.bitCount >= 8)
			{
				byte[] array = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array[num] = (byte)this.bitBuf;
				this.bitCount -= 8;
				this.bitBuf >>= 8;
			}
			if (this.bitCount > 0)
			{
				byte[] array2 = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array2[num] = (byte)this.bitBuf;
				this.bitBuf = 0U;
				this.bitCount = 0;
			}
		}

		// Token: 0x06000C2A RID: 3114 RVA: 0x000502BD File Offset: 0x0004E4BD
		internal void WriteBytes(byte[] byteArray, int offset, int count)
		{
			if (this.bitCount == 0)
			{
				Array.Copy(byteArray, offset, this.byteBuffer, this.pos, count);
				this.pos += count;
				return;
			}
			this.WriteBytesUnaligned(byteArray, offset, count);
		}

		// Token: 0x06000C2B RID: 3115 RVA: 0x000502F4 File Offset: 0x0004E4F4
		private void WriteBytesUnaligned(byte[] byteArray, int offset, int count)
		{
			for (int i = 0; i < count; i++)
			{
				byte b = byteArray[offset + i];
				this.WriteByteUnaligned(b);
			}
		}

		// Token: 0x06000C2C RID: 3116 RVA: 0x0005031A File Offset: 0x0004E51A
		private void WriteByteUnaligned(byte b)
		{
			this.WriteBits(8, (uint)b);
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000C2D RID: 3117 RVA: 0x00050324 File Offset: 0x0004E524
		internal int BitsInBuffer
		{
			get
			{
				return this.bitCount / 8 + 1;
			}
		}

		// Token: 0x06000C2E RID: 3118 RVA: 0x00050330 File Offset: 0x0004E530
		internal OutputBuffer.BufferState DumpState()
		{
			OutputBuffer.BufferState result;
			result.pos = this.pos;
			result.bitBuf = this.bitBuf;
			result.bitCount = this.bitCount;
			return result;
		}

		// Token: 0x06000C2F RID: 3119 RVA: 0x00050365 File Offset: 0x0004E565
		internal void RestoreState(OutputBuffer.BufferState state)
		{
			this.pos = state.pos;
			this.bitBuf = state.bitBuf;
			this.bitCount = state.bitCount;
		}

		// Token: 0x04000AA9 RID: 2729
		private byte[] byteBuffer;

		// Token: 0x04000AAA RID: 2730
		private int pos;

		// Token: 0x04000AAB RID: 2731
		private uint bitBuf;

		// Token: 0x04000AAC RID: 2732
		private int bitCount;

		// Token: 0x0200035E RID: 862
		internal struct BufferState
		{
			// Token: 0x04001281 RID: 4737
			internal int pos;

			// Token: 0x04001282 RID: 4738
			internal uint bitBuf;

			// Token: 0x04001283 RID: 4739
			internal int bitCount;
		}
	}
}
