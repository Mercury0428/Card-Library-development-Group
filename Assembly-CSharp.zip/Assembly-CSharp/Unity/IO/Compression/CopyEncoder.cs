﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000175 RID: 373
	internal class CopyEncoder
	{
		// Token: 0x06000B5E RID: 2910 RVA: 0x0004CDC8 File Offset: 0x0004AFC8
		public void GetBlock(DeflateInput input, OutputBuffer output, bool isFinal)
		{
			int num = 0;
			if (input != null)
			{
				num = Math.Min(input.Count, output.FreeBytes - 5 - output.BitsInBuffer);
				if (num > 65531)
				{
					num = 65531;
				}
			}
			if (isFinal)
			{
				output.WriteBits(3, 1U);
			}
			else
			{
				output.WriteBits(3, 0U);
			}
			output.FlushBits();
			this.WriteLenNLen((ushort)num, output);
			if (input != null && num > 0)
			{
				output.WriteBytes(input.Buffer, input.StartIndex, num);
				input.ConsumeBytes(num);
			}
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x0004CE48 File Offset: 0x0004B048
		private void WriteLenNLen(ushort len, OutputBuffer output)
		{
			output.WriteUInt16(len);
			ushort value = ~len;
			output.WriteUInt16(value);
		}

		// Token: 0x040009FB RID: 2555
		private const int PaddingSize = 5;

		// Token: 0x040009FC RID: 2556
		private const int MaxUncompressedBlockSize = 65536;
	}
}
