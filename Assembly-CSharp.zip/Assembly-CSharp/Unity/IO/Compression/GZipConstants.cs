﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000182 RID: 386
	internal static class GZipConstants
	{
		// Token: 0x04000A54 RID: 2644
		internal const int CompressionLevel_3 = 3;

		// Token: 0x04000A55 RID: 2645
		internal const int CompressionLevel_10 = 10;

		// Token: 0x04000A56 RID: 2646
		internal const long FileLengthModulo = 4294967296L;

		// Token: 0x04000A57 RID: 2647
		internal const byte ID1 = 31;

		// Token: 0x04000A58 RID: 2648
		internal const byte ID2 = 139;

		// Token: 0x04000A59 RID: 2649
		internal const byte Deflate = 8;

		// Token: 0x04000A5A RID: 2650
		internal const int Xfl_HeaderPos = 8;

		// Token: 0x04000A5B RID: 2651
		internal const byte Xfl_FastestAlgorithm = 4;

		// Token: 0x04000A5C RID: 2652
		internal const byte Xfl_MaxCompressionSlowestAlgorithm = 2;
	}
}
