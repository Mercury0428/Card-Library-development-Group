﻿using System;
using System.IO;
using System.Security;
using System.Threading;

namespace Unity.IO.Compression
{
	// Token: 0x02000179 RID: 377
	public class DeflateStream : Stream
	{
		// Token: 0x06000B78 RID: 2936 RVA: 0x0004D2F9 File Offset: 0x0004B4F9
		public DeflateStream(Stream stream, CompressionMode mode) : this(stream, mode, false)
		{
		}

		// Token: 0x06000B79 RID: 2937 RVA: 0x0004D304 File Offset: 0x0004B504
		public DeflateStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (CompressionMode.Compress != mode && mode != CompressionMode.Decompress)
			{
				throw new ArgumentException(SR.GetString("Argument out of range"), "mode");
			}
			this._stream = stream;
			this._mode = mode;
			this._leaveOpen = leaveOpen;
			CompressionMode mode2 = this._mode;
			if (mode2 != CompressionMode.Decompress)
			{
				if (mode2 == CompressionMode.Compress)
				{
					if (!this._stream.CanWrite)
					{
						throw new ArgumentException(SR.GetString("Not a writeable stream"), "stream");
					}
					this.deflater = DeflateStream.CreateDeflater();
					this.m_AsyncWriterDelegate = new DeflateStream.AsyncWriteDelegate(this.InternalWrite);
					this.m_CallBack = new AsyncCallback(this.WriteCallback);
				}
			}
			else
			{
				if (!this._stream.CanRead)
				{
					throw new ArgumentException(SR.GetString("Not a readable stream"), "stream");
				}
				this.inflater = new Inflater();
				this.m_CallBack = new AsyncCallback(this.ReadCallback);
			}
			this.buffer = new byte[8192];
		}

		// Token: 0x06000B7A RID: 2938 RVA: 0x0004D40C File Offset: 0x0004B60C
		private static IDeflater CreateDeflater()
		{
			if (DeflateStream.GetDeflaterType() == DeflateStream.WorkerType.Managed)
			{
				return new DeflaterManaged();
			}
			throw new SystemException("Program entered an unexpected state.");
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x0000821B File Offset: 0x0000641B
		[SecuritySafeCritical]
		private static DeflateStream.WorkerType GetDeflaterType()
		{
			return DeflateStream.WorkerType.Managed;
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x0004D432 File Offset: 0x0004B632
		internal void SetFileFormatReader(IFileFormatReader reader)
		{
			if (reader != null)
			{
				this.inflater.SetFileFormatReader(reader);
			}
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x0004D443 File Offset: 0x0004B643
		internal void SetFileFormatWriter(IFileFormatWriter writer)
		{
			if (writer != null)
			{
				this.formatWriter = writer;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000B7E RID: 2942 RVA: 0x0004D44F File Offset: 0x0004B64F
		public Stream BaseStream
		{
			get
			{
				return this._stream;
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000B7F RID: 2943 RVA: 0x0004D457 File Offset: 0x0004B657
		public override bool CanRead
		{
			get
			{
				return this._stream != null && this._mode == CompressionMode.Decompress && this._stream.CanRead;
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000B80 RID: 2944 RVA: 0x0004D478 File Offset: 0x0004B678
		public override bool CanWrite
		{
			get
			{
				return this._stream != null && this._mode == CompressionMode.Compress && this._stream.CanWrite;
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000B81 RID: 2945 RVA: 0x0000821B File Offset: 0x0000641B
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000B82 RID: 2946 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Length
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000B83 RID: 2947 RVA: 0x0004D49A File Offset: 0x0004B69A
		// (set) Token: 0x06000B84 RID: 2948 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Position
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
			set
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x0004D4AB File Offset: 0x0004B6AB
		public override void Flush()
		{
			this.EnsureNotDisposed();
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override void SetLength(long value)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x0004D4B4 File Offset: 0x0004B6B4
		public override int Read(byte[] array, int offset, int count)
		{
			this.EnsureDecompressionMode();
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			int num = offset;
			int num2 = count;
			for (;;)
			{
				int num3 = this.inflater.Inflate(array, num, num2);
				num += num3;
				num2 -= num3;
				if (num2 == 0 || this.inflater.Finished())
				{
					break;
				}
				int num4 = this._stream.Read(this.buffer, 0, this.buffer.Length);
				if (num4 == 0)
				{
					break;
				}
				this.inflater.SetInput(this.buffer, 0, num4);
			}
			return count - num2;
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x0004D538 File Offset: 0x0004B738
		private void ValidateParameters(byte[] array, int offset, int count)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (array.Length - offset < count)
			{
				throw new ArgumentException(SR.GetString("Invalid argument offset count"));
			}
		}

		// Token: 0x06000B8A RID: 2954 RVA: 0x0004D589 File Offset: 0x0004B789
		private void EnsureNotDisposed()
		{
			if (this._stream == null)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x0004D5A4 File Offset: 0x0004B7A4
		private void EnsureDecompressionMode()
		{
			if (this._mode != CompressionMode.Decompress)
			{
				throw new InvalidOperationException(SR.GetString("Cannot read from deflate stream"));
			}
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x0004D5BE File Offset: 0x0004B7BE
		private void EnsureCompressionMode()
		{
			if (this._mode != CompressionMode.Compress)
			{
				throw new InvalidOperationException(SR.GetString("Cannot write to deflate stream"));
			}
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x0004D5DC File Offset: 0x0004B7DC
		public override IAsyncResult BeginRead(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			this.EnsureDecompressionMode();
			if (this.asyncOperations != 0)
			{
				throw new InvalidOperationException(SR.GetString("Invalid begin call"));
			}
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			Interlocked.Increment(ref this.asyncOperations);
			IAsyncResult result;
			try
			{
				DeflateStreamAsyncResult deflateStreamAsyncResult = new DeflateStreamAsyncResult(this, asyncState, asyncCallback, array, offset, count);
				deflateStreamAsyncResult.isWrite = false;
				int num = this.inflater.Inflate(array, offset, count);
				if (num != 0)
				{
					deflateStreamAsyncResult.InvokeCallback(true, num);
					result = deflateStreamAsyncResult;
				}
				else if (this.inflater.Finished())
				{
					deflateStreamAsyncResult.InvokeCallback(true, 0);
					result = deflateStreamAsyncResult;
				}
				else
				{
					this._stream.BeginRead(this.buffer, 0, this.buffer.Length, this.m_CallBack, deflateStreamAsyncResult);
					deflateStreamAsyncResult.m_CompletedSynchronously &= deflateStreamAsyncResult.IsCompleted;
					result = deflateStreamAsyncResult;
				}
			}
			catch
			{
				Interlocked.Decrement(ref this.asyncOperations);
				throw;
			}
			return result;
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x0004D6D4 File Offset: 0x0004B8D4
		private void ReadCallback(IAsyncResult baseStreamResult)
		{
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)baseStreamResult.AsyncState;
			deflateStreamAsyncResult.m_CompletedSynchronously &= baseStreamResult.CompletedSynchronously;
			try
			{
				this.EnsureNotDisposed();
				int num = this._stream.EndRead(baseStreamResult);
				if (num <= 0)
				{
					deflateStreamAsyncResult.InvokeCallback(0);
				}
				else
				{
					this.inflater.SetInput(this.buffer, 0, num);
					num = this.inflater.Inflate(deflateStreamAsyncResult.buffer, deflateStreamAsyncResult.offset, deflateStreamAsyncResult.count);
					if (num == 0 && !this.inflater.Finished())
					{
						this._stream.BeginRead(this.buffer, 0, this.buffer.Length, this.m_CallBack, deflateStreamAsyncResult);
					}
					else
					{
						deflateStreamAsyncResult.InvokeCallback(num);
					}
				}
			}
			catch (Exception result)
			{
				deflateStreamAsyncResult.InvokeCallback(result);
			}
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x0004D7B4 File Offset: 0x0004B9B4
		public override int EndRead(IAsyncResult asyncResult)
		{
			this.EnsureDecompressionMode();
			this.CheckEndXxxxLegalStateAndParams(asyncResult);
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult;
			this.AwaitAsyncResultCompletion(deflateStreamAsyncResult);
			Exception ex = deflateStreamAsyncResult.Result as Exception;
			if (ex != null)
			{
				throw ex;
			}
			return (int)deflateStreamAsyncResult.Result;
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0004D7F8 File Offset: 0x0004B9F8
		public override void Write(byte[] array, int offset, int count)
		{
			this.EnsureCompressionMode();
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			this.InternalWrite(array, offset, count, false);
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x0004D819 File Offset: 0x0004BA19
		internal void InternalWrite(byte[] array, int offset, int count, bool isAsync)
		{
			this.DoMaintenance(array, offset, count);
			this.WriteDeflaterOutput(isAsync);
			this.deflater.SetInput(array, offset, count);
			this.WriteDeflaterOutput(isAsync);
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x0004D844 File Offset: 0x0004BA44
		private void WriteDeflaterOutput(bool isAsync)
		{
			while (!this.deflater.NeedsInput())
			{
				int deflateOutput = this.deflater.GetDeflateOutput(this.buffer);
				if (deflateOutput > 0)
				{
					this.DoWrite(this.buffer, 0, deflateOutput, isAsync);
				}
			}
		}

		// Token: 0x06000B93 RID: 2963 RVA: 0x0004D888 File Offset: 0x0004BA88
		private void DoWrite(byte[] array, int offset, int count, bool isAsync)
		{
			if (isAsync)
			{
				IAsyncResult asyncResult = this._stream.BeginWrite(array, offset, count, null, null);
				this._stream.EndWrite(asyncResult);
				return;
			}
			this._stream.Write(array, offset, count);
		}

		// Token: 0x06000B94 RID: 2964 RVA: 0x0004D8C8 File Offset: 0x0004BAC8
		private void DoMaintenance(byte[] array, int offset, int count)
		{
			if (count <= 0)
			{
				return;
			}
			this.wroteBytes = true;
			if (this.formatWriter == null)
			{
				return;
			}
			if (!this.wroteHeader)
			{
				byte[] header = this.formatWriter.GetHeader();
				this._stream.Write(header, 0, header.Length);
				this.wroteHeader = true;
			}
			this.formatWriter.UpdateWithBytesRead(array, offset, count);
		}

		// Token: 0x06000B95 RID: 2965 RVA: 0x0004D924 File Offset: 0x0004BB24
		private void PurgeBuffers(bool disposing)
		{
			if (!disposing)
			{
				return;
			}
			if (this._stream == null)
			{
				return;
			}
			this.Flush();
			if (this._mode != CompressionMode.Compress)
			{
				return;
			}
			if (this.wroteBytes)
			{
				this.WriteDeflaterOutput(false);
				bool flag;
				do
				{
					int num;
					flag = this.deflater.Finish(this.buffer, out num);
					if (num > 0)
					{
						this.DoWrite(this.buffer, 0, num, false);
					}
				}
				while (!flag);
			}
			if (this.formatWriter != null && this.wroteHeader)
			{
				byte[] footer = this.formatWriter.GetFooter();
				this._stream.Write(footer, 0, footer.Length);
			}
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x0004D9B4 File Offset: 0x0004BBB4
		protected override void Dispose(bool disposing)
		{
			try
			{
				this.PurgeBuffers(disposing);
			}
			finally
			{
				try
				{
					if (disposing && !this._leaveOpen && this._stream != null)
					{
						this._stream.Dispose();
					}
				}
				finally
				{
					this._stream = null;
					try
					{
						if (this.deflater != null)
						{
							this.deflater.Dispose();
						}
					}
					finally
					{
						this.deflater = null;
						base.Dispose(disposing);
					}
				}
			}
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x0004DA40 File Offset: 0x0004BC40
		public override IAsyncResult BeginWrite(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			this.EnsureCompressionMode();
			if (this.asyncOperations != 0)
			{
				throw new InvalidOperationException(SR.GetString("Invalid begin call"));
			}
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			Interlocked.Increment(ref this.asyncOperations);
			IAsyncResult result;
			try
			{
				DeflateStreamAsyncResult deflateStreamAsyncResult = new DeflateStreamAsyncResult(this, asyncState, asyncCallback, array, offset, count);
				deflateStreamAsyncResult.isWrite = true;
				this.m_AsyncWriterDelegate.BeginInvoke(array, offset, count, true, this.m_CallBack, deflateStreamAsyncResult);
				deflateStreamAsyncResult.m_CompletedSynchronously &= deflateStreamAsyncResult.IsCompleted;
				result = deflateStreamAsyncResult;
			}
			catch
			{
				Interlocked.Decrement(ref this.asyncOperations);
				throw;
			}
			return result;
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x0004DAEC File Offset: 0x0004BCEC
		private void WriteCallback(IAsyncResult asyncResult)
		{
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult.AsyncState;
			deflateStreamAsyncResult.m_CompletedSynchronously &= asyncResult.CompletedSynchronously;
			try
			{
				this.m_AsyncWriterDelegate.EndInvoke(asyncResult);
			}
			catch (Exception result)
			{
				deflateStreamAsyncResult.InvokeCallback(result);
				return;
			}
			deflateStreamAsyncResult.InvokeCallback(null);
		}

		// Token: 0x06000B99 RID: 2969 RVA: 0x0004DB48 File Offset: 0x0004BD48
		public override void EndWrite(IAsyncResult asyncResult)
		{
			this.EnsureCompressionMode();
			this.CheckEndXxxxLegalStateAndParams(asyncResult);
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult;
			this.AwaitAsyncResultCompletion(deflateStreamAsyncResult);
			Exception ex = deflateStreamAsyncResult.Result as Exception;
			if (ex != null)
			{
				throw ex;
			}
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x0004DB84 File Offset: 0x0004BD84
		private void CheckEndXxxxLegalStateAndParams(IAsyncResult asyncResult)
		{
			if (this.asyncOperations != 1)
			{
				throw new InvalidOperationException(SR.GetString("Invalid end call"));
			}
			if (asyncResult == null)
			{
				throw new ArgumentNullException("asyncResult");
			}
			this.EnsureNotDisposed();
			if (!(asyncResult is DeflateStreamAsyncResult))
			{
				throw new ArgumentNullException("asyncResult");
			}
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x0004DBD4 File Offset: 0x0004BDD4
		private void AwaitAsyncResultCompletion(DeflateStreamAsyncResult asyncResult)
		{
			try
			{
				if (!asyncResult.IsCompleted)
				{
					asyncResult.AsyncWaitHandle.WaitOne();
				}
			}
			finally
			{
				Interlocked.Decrement(ref this.asyncOperations);
				asyncResult.Close();
			}
		}

		// Token: 0x04000A0B RID: 2571
		internal const int DefaultBufferSize = 8192;

		// Token: 0x04000A0C RID: 2572
		private Stream _stream;

		// Token: 0x04000A0D RID: 2573
		private CompressionMode _mode;

		// Token: 0x04000A0E RID: 2574
		private bool _leaveOpen;

		// Token: 0x04000A0F RID: 2575
		private Inflater inflater;

		// Token: 0x04000A10 RID: 2576
		private IDeflater deflater;

		// Token: 0x04000A11 RID: 2577
		private byte[] buffer;

		// Token: 0x04000A12 RID: 2578
		private int asyncOperations;

		// Token: 0x04000A13 RID: 2579
		private readonly AsyncCallback m_CallBack;

		// Token: 0x04000A14 RID: 2580
		private readonly DeflateStream.AsyncWriteDelegate m_AsyncWriterDelegate;

		// Token: 0x04000A15 RID: 2581
		private IFileFormatWriter formatWriter;

		// Token: 0x04000A16 RID: 2582
		private bool wroteHeader;

		// Token: 0x04000A17 RID: 2583
		private bool wroteBytes;

		// Token: 0x0200035A RID: 858
		// (Invoke) Token: 0x060016A5 RID: 5797
		internal delegate void AsyncWriteDelegate(byte[] array, int offset, int count, bool isAsync);

		// Token: 0x0200035B RID: 859
		private enum WorkerType : byte
		{
			// Token: 0x04001268 RID: 4712
			Managed,
			// Token: 0x04001269 RID: 4713
			Unknown
		}
	}
}
