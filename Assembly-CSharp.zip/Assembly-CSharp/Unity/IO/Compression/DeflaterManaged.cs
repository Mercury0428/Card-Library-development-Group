﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000178 RID: 376
	internal class DeflaterManaged : IDeflater, IDisposable
	{
		// Token: 0x06000B6D RID: 2925 RVA: 0x0004CF4A File Offset: 0x0004B14A
		internal DeflaterManaged()
		{
			this.deflateEncoder = new FastEncoder();
			this.copyEncoder = new CopyEncoder();
			this.input = new DeflateInput();
			this.output = new OutputBuffer();
			this.processingState = DeflaterManaged.DeflaterState.NotStarted;
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x0004CF85 File Offset: 0x0004B185
		private bool NeedsInput()
		{
			return ((IDeflater)this).NeedsInput();
		}

		// Token: 0x06000B6F RID: 2927 RVA: 0x0004CF8D File Offset: 0x0004B18D
		bool IDeflater.NeedsInput()
		{
			return this.input.Count == 0 && this.deflateEncoder.BytesInHistory == 0;
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x0004CFAC File Offset: 0x0004B1AC
		void IDeflater.SetInput(byte[] inputBuffer, int startIndex, int count)
		{
			this.input.Buffer = inputBuffer;
			this.input.Count = count;
			this.input.StartIndex = startIndex;
			if (count > 0 && count < 256)
			{
				DeflaterManaged.DeflaterState deflaterState = this.processingState;
				if (deflaterState != DeflaterManaged.DeflaterState.NotStarted)
				{
					if (deflaterState == DeflaterManaged.DeflaterState.CompressThenCheck)
					{
						this.processingState = DeflaterManaged.DeflaterState.HandlingSmallData;
						return;
					}
					if (deflaterState != DeflaterManaged.DeflaterState.CheckingForIncompressible)
					{
						return;
					}
				}
				this.processingState = DeflaterManaged.DeflaterState.StartingSmallData;
				return;
			}
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x0004D00C File Offset: 0x0004B20C
		int IDeflater.GetDeflateOutput(byte[] outputBuffer)
		{
			this.output.UpdateBuffer(outputBuffer);
			switch (this.processingState)
			{
			case DeflaterManaged.DeflaterState.NotStarted:
			{
				DeflateInput.InputState state = this.input.DumpState();
				OutputBuffer.BufferState state2 = this.output.DumpState();
				this.deflateEncoder.GetBlockHeader(this.output);
				this.deflateEncoder.GetCompressedData(this.input, this.output);
				if (!this.UseCompressed(this.deflateEncoder.LastCompressionRatio))
				{
					this.input.RestoreState(state);
					this.output.RestoreState(state2);
					this.copyEncoder.GetBlock(this.input, this.output, false);
					this.FlushInputWindows();
					this.processingState = DeflaterManaged.DeflaterState.CheckingForIncompressible;
					goto IL_23A;
				}
				this.processingState = DeflaterManaged.DeflaterState.CompressThenCheck;
				goto IL_23A;
			}
			case DeflaterManaged.DeflaterState.SlowDownForIncompressible1:
				this.deflateEncoder.GetBlockFooter(this.output);
				this.processingState = DeflaterManaged.DeflaterState.SlowDownForIncompressible2;
				break;
			case DeflaterManaged.DeflaterState.SlowDownForIncompressible2:
				break;
			case DeflaterManaged.DeflaterState.StartingSmallData:
				this.deflateEncoder.GetBlockHeader(this.output);
				this.processingState = DeflaterManaged.DeflaterState.HandlingSmallData;
				goto IL_223;
			case DeflaterManaged.DeflaterState.CompressThenCheck:
				this.deflateEncoder.GetCompressedData(this.input, this.output);
				if (!this.UseCompressed(this.deflateEncoder.LastCompressionRatio))
				{
					this.processingState = DeflaterManaged.DeflaterState.SlowDownForIncompressible1;
					this.inputFromHistory = this.deflateEncoder.UnprocessedInput;
					goto IL_23A;
				}
				goto IL_23A;
			case DeflaterManaged.DeflaterState.CheckingForIncompressible:
			{
				DeflateInput.InputState state3 = this.input.DumpState();
				OutputBuffer.BufferState state4 = this.output.DumpState();
				this.deflateEncoder.GetBlock(this.input, this.output, 8072);
				if (!this.UseCompressed(this.deflateEncoder.LastCompressionRatio))
				{
					this.input.RestoreState(state3);
					this.output.RestoreState(state4);
					this.copyEncoder.GetBlock(this.input, this.output, false);
					this.FlushInputWindows();
					goto IL_23A;
				}
				goto IL_23A;
			}
			case DeflaterManaged.DeflaterState.HandlingSmallData:
				goto IL_223;
			default:
				goto IL_23A;
			}
			if (this.inputFromHistory.Count > 0)
			{
				this.copyEncoder.GetBlock(this.inputFromHistory, this.output, false);
			}
			if (this.inputFromHistory.Count == 0)
			{
				this.deflateEncoder.FlushInput();
				this.processingState = DeflaterManaged.DeflaterState.CheckingForIncompressible;
				goto IL_23A;
			}
			goto IL_23A;
			IL_223:
			this.deflateEncoder.GetCompressedData(this.input, this.output);
			IL_23A:
			return this.output.BytesWritten;
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x0004D260 File Offset: 0x0004B460
		bool IDeflater.Finish(byte[] outputBuffer, out int bytesRead)
		{
			if (this.processingState == DeflaterManaged.DeflaterState.NotStarted)
			{
				bytesRead = 0;
				return true;
			}
			this.output.UpdateBuffer(outputBuffer);
			if (this.processingState == DeflaterManaged.DeflaterState.CompressThenCheck || this.processingState == DeflaterManaged.DeflaterState.HandlingSmallData || this.processingState == DeflaterManaged.DeflaterState.SlowDownForIncompressible1)
			{
				this.deflateEncoder.GetBlockFooter(this.output);
			}
			this.WriteFinal();
			bytesRead = this.output.BytesWritten;
			return true;
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x00003D07 File Offset: 0x00001F07
		void IDisposable.Dispose()
		{
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00003D07 File Offset: 0x00001F07
		protected void Dispose(bool disposing)
		{
		}

		// Token: 0x06000B75 RID: 2933 RVA: 0x0004D2C6 File Offset: 0x0004B4C6
		private bool UseCompressed(double ratio)
		{
			return ratio <= 1.0;
		}

		// Token: 0x06000B76 RID: 2934 RVA: 0x0004D2D7 File Offset: 0x0004B4D7
		private void FlushInputWindows()
		{
			this.deflateEncoder.FlushInput();
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x0004D2E4 File Offset: 0x0004B4E4
		private void WriteFinal()
		{
			this.copyEncoder.GetBlock(null, this.output, true);
		}

		// Token: 0x04000A01 RID: 2561
		private const int MinBlockSize = 256;

		// Token: 0x04000A02 RID: 2562
		private const int MaxHeaderFooterGoo = 120;

		// Token: 0x04000A03 RID: 2563
		private const int CleanCopySize = 8072;

		// Token: 0x04000A04 RID: 2564
		private const double BadCompressionThreshold = 1.0;

		// Token: 0x04000A05 RID: 2565
		private FastEncoder deflateEncoder;

		// Token: 0x04000A06 RID: 2566
		private CopyEncoder copyEncoder;

		// Token: 0x04000A07 RID: 2567
		private DeflateInput input;

		// Token: 0x04000A08 RID: 2568
		private OutputBuffer output;

		// Token: 0x04000A09 RID: 2569
		private DeflaterManaged.DeflaterState processingState;

		// Token: 0x04000A0A RID: 2570
		private DeflateInput inputFromHistory;

		// Token: 0x02000359 RID: 857
		private enum DeflaterState
		{
			// Token: 0x04001260 RID: 4704
			NotStarted,
			// Token: 0x04001261 RID: 4705
			SlowDownForIncompressible1,
			// Token: 0x04001262 RID: 4706
			SlowDownForIncompressible2,
			// Token: 0x04001263 RID: 4707
			StartingSmallData,
			// Token: 0x04001264 RID: 4708
			CompressThenCheck,
			// Token: 0x04001265 RID: 4709
			CheckingForIncompressible,
			// Token: 0x04001266 RID: 4710
			HandlingSmallData
		}
	}
}
