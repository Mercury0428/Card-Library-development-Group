﻿using System;
using System.IO;

namespace Unity.IO.Compression
{
	// Token: 0x02000181 RID: 385
	public class GZipStream : Stream
	{
		// Token: 0x06000BD7 RID: 3031 RVA: 0x0004EB99 File Offset: 0x0004CD99
		public GZipStream(Stream stream, CompressionMode mode) : this(stream, mode, false)
		{
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x0004EBA4 File Offset: 0x0004CDA4
		public GZipStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			this.deflateStream = new DeflateStream(stream, mode, leaveOpen);
			this.SetDeflateStreamFileFormatter(mode);
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x0004EBC4 File Offset: 0x0004CDC4
		private void SetDeflateStreamFileFormatter(CompressionMode mode)
		{
			if (mode == CompressionMode.Compress)
			{
				IFileFormatWriter fileFormatWriter = new GZipFormatter();
				this.deflateStream.SetFileFormatWriter(fileFormatWriter);
				return;
			}
			IFileFormatReader fileFormatReader = new GZipDecoder();
			this.deflateStream.SetFileFormatReader(fileFormatReader);
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000BDA RID: 3034 RVA: 0x0004EBFA File Offset: 0x0004CDFA
		public override bool CanRead
		{
			get
			{
				return this.deflateStream != null && this.deflateStream.CanRead;
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000BDB RID: 3035 RVA: 0x0004EC11 File Offset: 0x0004CE11
		public override bool CanWrite
		{
			get
			{
				return this.deflateStream != null && this.deflateStream.CanWrite;
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000BDC RID: 3036 RVA: 0x0004EC28 File Offset: 0x0004CE28
		public override bool CanSeek
		{
			get
			{
				return this.deflateStream != null && this.deflateStream.CanSeek;
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000BDD RID: 3037 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Length
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000BDE RID: 3038 RVA: 0x0004D49A File Offset: 0x0004B69A
		// (set) Token: 0x06000BDF RID: 3039 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Position
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
			set
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x0004EC3F File Offset: 0x0004CE3F
		public override void Flush()
		{
			if (this.deflateStream == null)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			this.deflateStream.Flush();
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x0004D49A File Offset: 0x0004B69A
		public override void SetLength(long value)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000BE3 RID: 3043 RVA: 0x0004EC65 File Offset: 0x0004CE65
		public override IAsyncResult BeginRead(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			if (this.deflateStream == null)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.BeginRead(array, offset, count, asyncCallback, asyncState);
		}

		// Token: 0x06000BE4 RID: 3044 RVA: 0x0004EC91 File Offset: 0x0004CE91
		public override int EndRead(IAsyncResult asyncResult)
		{
			if (this.deflateStream == null)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.EndRead(asyncResult);
		}

		// Token: 0x06000BE5 RID: 3045 RVA: 0x0004ECB7 File Offset: 0x0004CEB7
		public override IAsyncResult BeginWrite(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			if (this.deflateStream == null)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.BeginWrite(array, offset, count, asyncCallback, asyncState);
		}

		// Token: 0x06000BE6 RID: 3046 RVA: 0x0004ECE3 File Offset: 0x0004CEE3
		public override void EndWrite(IAsyncResult asyncResult)
		{
			if (this.deflateStream == null)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			this.deflateStream.EndWrite(asyncResult);
		}

		// Token: 0x06000BE7 RID: 3047 RVA: 0x0004ED09 File Offset: 0x0004CF09
		public override int Read(byte[] array, int offset, int count)
		{
			if (this.deflateStream == null)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			return this.deflateStream.Read(array, offset, count);
		}

		// Token: 0x06000BE8 RID: 3048 RVA: 0x0004ED32 File Offset: 0x0004CF32
		public override void Write(byte[] array, int offset, int count)
		{
			if (this.deflateStream == null)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			this.deflateStream.Write(array, offset, count);
		}

		// Token: 0x06000BE9 RID: 3049 RVA: 0x0004ED5C File Offset: 0x0004CF5C
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.deflateStream != null)
				{
					this.deflateStream.Dispose();
				}
				this.deflateStream = null;
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000BEA RID: 3050 RVA: 0x0004EDA0 File Offset: 0x0004CFA0
		public Stream BaseStream
		{
			get
			{
				if (this.deflateStream != null)
				{
					return this.deflateStream.BaseStream;
				}
				return null;
			}
		}

		// Token: 0x04000A53 RID: 2643
		private DeflateStream deflateStream;
	}
}
