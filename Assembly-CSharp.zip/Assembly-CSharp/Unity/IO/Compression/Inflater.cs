﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000186 RID: 390
	internal class Inflater
	{
		// Token: 0x06000BFE RID: 3070 RVA: 0x0004F2A0 File Offset: 0x0004D4A0
		public Inflater()
		{
			this.output = new OutputWindow();
			this.input = new InputBuffer();
			this.codeList = new byte[320];
			this.codeLengthTreeCodeLength = new byte[19];
			this.Reset();
		}

		// Token: 0x06000BFF RID: 3071 RVA: 0x0004F2F8 File Offset: 0x0004D4F8
		internal void SetFileFormatReader(IFileFormatReader reader)
		{
			this.formatReader = reader;
			this.hasFormatReader = true;
			this.Reset();
		}

		// Token: 0x06000C00 RID: 3072 RVA: 0x0004F30E File Offset: 0x0004D50E
		private void Reset()
		{
			if (this.hasFormatReader)
			{
				this.state = InflaterState.ReadingHeader;
				return;
			}
			this.state = InflaterState.ReadingBFinal;
		}

		// Token: 0x06000C01 RID: 3073 RVA: 0x0004F327 File Offset: 0x0004D527
		public void SetInput(byte[] inputBytes, int offset, int length)
		{
			this.input.SetInput(inputBytes, offset, length);
		}

		// Token: 0x06000C02 RID: 3074 RVA: 0x0004F337 File Offset: 0x0004D537
		public bool Finished()
		{
			return this.state == InflaterState.Done || this.state == InflaterState.VerifyingFooter;
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000C03 RID: 3075 RVA: 0x0004F34F File Offset: 0x0004D54F
		public int AvailableOutput
		{
			get
			{
				return this.output.AvailableBytes;
			}
		}

		// Token: 0x06000C04 RID: 3076 RVA: 0x0004F35C File Offset: 0x0004D55C
		public bool NeedsInput()
		{
			return this.input.NeedsInput();
		}

		// Token: 0x06000C05 RID: 3077 RVA: 0x0004F36C File Offset: 0x0004D56C
		public int Inflate(byte[] bytes, int offset, int length)
		{
			int num = 0;
			do
			{
				int num2 = this.output.CopyTo(bytes, offset, length);
				if (num2 > 0)
				{
					if (this.hasFormatReader)
					{
						this.formatReader.UpdateWithBytesRead(bytes, offset, num2);
					}
					offset += num2;
					num += num2;
					length -= num2;
				}
			}
			while (length != 0 && !this.Finished() && this.Decode());
			if (this.state == InflaterState.VerifyingFooter && this.output.AvailableBytes == 0)
			{
				this.formatReader.Validate();
			}
			return num;
		}

		// Token: 0x06000C06 RID: 3078 RVA: 0x0004F3E8 File Offset: 0x0004D5E8
		private bool Decode()
		{
			bool flag = false;
			if (this.Finished())
			{
				return true;
			}
			if (this.hasFormatReader)
			{
				if (this.state == InflaterState.ReadingHeader)
				{
					if (!this.formatReader.ReadHeader(this.input))
					{
						return false;
					}
					this.state = InflaterState.ReadingBFinal;
				}
				else if (this.state == InflaterState.StartReadingFooter || this.state == InflaterState.ReadingFooter)
				{
					if (!this.formatReader.ReadFooter(this.input))
					{
						return false;
					}
					this.state = InflaterState.VerifyingFooter;
					return true;
				}
			}
			if (this.state == InflaterState.ReadingBFinal)
			{
				if (!this.input.EnsureBitsAvailable(1))
				{
					return false;
				}
				this.bfinal = this.input.GetBits(1);
				this.state = InflaterState.ReadingBType;
			}
			if (this.state == InflaterState.ReadingBType)
			{
				if (!this.input.EnsureBitsAvailable(2))
				{
					this.state = InflaterState.ReadingBType;
					return false;
				}
				this.blockType = (BlockType)this.input.GetBits(2);
				if (this.blockType == BlockType.Dynamic)
				{
					this.state = InflaterState.ReadingNumLitCodes;
				}
				else if (this.blockType == BlockType.Static)
				{
					this.literalLengthTree = HuffmanTree.StaticLiteralLengthTree;
					this.distanceTree = HuffmanTree.StaticDistanceTree;
					this.state = InflaterState.DecodeTop;
				}
				else
				{
					if (this.blockType != BlockType.Uncompressed)
					{
						throw new InvalidDataException(SR.GetString("Unknown block type"));
					}
					this.state = InflaterState.UncompressedAligning;
				}
			}
			bool result;
			if (this.blockType == BlockType.Dynamic)
			{
				if (this.state < InflaterState.DecodeTop)
				{
					result = this.DecodeDynamicBlockHeader();
				}
				else
				{
					result = this.DecodeBlock(out flag);
				}
			}
			else if (this.blockType == BlockType.Static)
			{
				result = this.DecodeBlock(out flag);
			}
			else
			{
				if (this.blockType != BlockType.Uncompressed)
				{
					throw new InvalidDataException(SR.GetString("Unknown block type"));
				}
				result = this.DecodeUncompressedBlock(out flag);
			}
			if (flag && this.bfinal != 0)
			{
				if (this.hasFormatReader)
				{
					this.state = InflaterState.StartReadingFooter;
				}
				else
				{
					this.state = InflaterState.Done;
				}
			}
			return result;
		}

		// Token: 0x06000C07 RID: 3079 RVA: 0x0004F5AC File Offset: 0x0004D7AC
		private bool DecodeUncompressedBlock(out bool end_of_block)
		{
			end_of_block = false;
			for (;;)
			{
				switch (this.state)
				{
				case InflaterState.UncompressedAligning:
					this.input.SkipToByteBoundary();
					this.state = InflaterState.UncompressedByte1;
					goto IL_43;
				case InflaterState.UncompressedByte1:
				case InflaterState.UncompressedByte2:
				case InflaterState.UncompressedByte3:
				case InflaterState.UncompressedByte4:
					goto IL_43;
				case InflaterState.DecodingUncompressed:
					goto IL_D6;
				}
				break;
				IL_43:
				int bits = this.input.GetBits(8);
				if (bits < 0)
				{
					return false;
				}
				this.blockLengthBuffer[this.state - InflaterState.UncompressedByte1] = (byte)bits;
				if (this.state == InflaterState.UncompressedByte4)
				{
					this.blockLength = (int)this.blockLengthBuffer[0] + (int)this.blockLengthBuffer[1] * 256;
					int num = (int)this.blockLengthBuffer[2] + (int)this.blockLengthBuffer[3] * 256;
					if ((ushort)this.blockLength != (ushort)(~(ushort)num))
					{
						goto Block_4;
					}
				}
				this.state++;
			}
			throw new InvalidDataException(SR.GetString("Unknown state"));
			Block_4:
			throw new InvalidDataException(SR.GetString("Invalid block length"));
			IL_D6:
			int num2 = this.output.CopyFrom(this.input, this.blockLength);
			this.blockLength -= num2;
			if (this.blockLength == 0)
			{
				this.state = InflaterState.ReadingBFinal;
				end_of_block = true;
				return true;
			}
			return this.output.FreeBytes == 0;
		}

		// Token: 0x06000C08 RID: 3080 RVA: 0x0004F6EC File Offset: 0x0004D8EC
		private bool DecodeBlock(out bool end_of_block_code_seen)
		{
			end_of_block_code_seen = false;
			int i = this.output.FreeBytes;
			while (i > 258)
			{
				switch (this.state)
				{
				case InflaterState.DecodeTop:
				{
					int num = this.literalLengthTree.GetNextSymbol(this.input);
					if (num < 0)
					{
						return false;
					}
					if (num < 256)
					{
						this.output.Write((byte)num);
						i--;
						continue;
					}
					if (num == 256)
					{
						end_of_block_code_seen = true;
						this.state = InflaterState.ReadingBFinal;
						return true;
					}
					num -= 257;
					if (num < 8)
					{
						num += 3;
						this.extraBits = 0;
					}
					else if (num == 28)
					{
						num = 258;
						this.extraBits = 0;
					}
					else
					{
						if (num < 0 || num >= Inflater.extraLengthBits.Length)
						{
							throw new InvalidDataException(SR.GetString("Invalid data"));
						}
						this.extraBits = (int)Inflater.extraLengthBits[num];
					}
					this.length = num;
					goto IL_E2;
				}
				case InflaterState.HaveInitialLength:
					goto IL_E2;
				case InflaterState.HaveFullLength:
					goto IL_152;
				case InflaterState.HaveDistCode:
					break;
				default:
					throw new InvalidDataException(SR.GetString("Unknown state"));
				}
				IL_1B4:
				int distance;
				if (this.distanceCode > 3)
				{
					this.extraBits = this.distanceCode - 2 >> 1;
					int bits = this.input.GetBits(this.extraBits);
					if (bits < 0)
					{
						return false;
					}
					distance = Inflater.distanceBasePosition[this.distanceCode] + bits;
				}
				else
				{
					distance = this.distanceCode + 1;
				}
				this.output.WriteLengthDistance(this.length, distance);
				i -= this.length;
				this.state = InflaterState.DecodeTop;
				continue;
				IL_152:
				if (this.blockType == BlockType.Dynamic)
				{
					this.distanceCode = this.distanceTree.GetNextSymbol(this.input);
				}
				else
				{
					this.distanceCode = this.input.GetBits(5);
					if (this.distanceCode >= 0)
					{
						this.distanceCode = (int)Inflater.staticDistanceTreeTable[this.distanceCode];
					}
				}
				if (this.distanceCode < 0)
				{
					return false;
				}
				this.state = InflaterState.HaveDistCode;
				goto IL_1B4;
				IL_E2:
				if (this.extraBits > 0)
				{
					this.state = InflaterState.HaveInitialLength;
					int bits2 = this.input.GetBits(this.extraBits);
					if (bits2 < 0)
					{
						return false;
					}
					if (this.length < 0 || this.length >= Inflater.lengthBase.Length)
					{
						throw new InvalidDataException(SR.GetString("Invalid data"));
					}
					this.length = Inflater.lengthBase[this.length] + bits2;
				}
				this.state = InflaterState.HaveFullLength;
				goto IL_152;
			}
			return true;
		}

		// Token: 0x06000C09 RID: 3081 RVA: 0x0004F93C File Offset: 0x0004DB3C
		private bool DecodeDynamicBlockHeader()
		{
			switch (this.state)
			{
			case InflaterState.ReadingNumLitCodes:
				this.literalLengthCodeCount = this.input.GetBits(5);
				if (this.literalLengthCodeCount < 0)
				{
					return false;
				}
				this.literalLengthCodeCount += 257;
				this.state = InflaterState.ReadingNumDistCodes;
				goto IL_62;
			case InflaterState.ReadingNumDistCodes:
				goto IL_62;
			case InflaterState.ReadingNumCodeLengthCodes:
				goto IL_94;
			case InflaterState.ReadingCodeLengthCodes:
				break;
			case InflaterState.ReadingTreeCodesBefore:
			case InflaterState.ReadingTreeCodesAfter:
				goto IL_327;
			default:
				throw new InvalidDataException(SR.GetString("Unknown state"));
			}
			IL_105:
			while (this.loopCounter < this.codeLengthCodeCount)
			{
				int bits = this.input.GetBits(3);
				if (bits < 0)
				{
					return false;
				}
				this.codeLengthTreeCodeLength[(int)Inflater.codeOrder[this.loopCounter]] = (byte)bits;
				this.loopCounter++;
			}
			for (int i = this.codeLengthCodeCount; i < Inflater.codeOrder.Length; i++)
			{
				this.codeLengthTreeCodeLength[(int)Inflater.codeOrder[i]] = 0;
			}
			this.codeLengthTree = new HuffmanTree(this.codeLengthTreeCodeLength);
			this.codeArraySize = this.literalLengthCodeCount + this.distanceCodeCount;
			this.loopCounter = 0;
			this.state = InflaterState.ReadingTreeCodesBefore;
			IL_327:
			while (this.loopCounter < this.codeArraySize)
			{
				if (this.state == InflaterState.ReadingTreeCodesBefore && (this.lengthCode = this.codeLengthTree.GetNextSymbol(this.input)) < 0)
				{
					return false;
				}
				if (this.lengthCode <= 15)
				{
					byte[] array = this.codeList;
					int num = this.loopCounter;
					this.loopCounter = num + 1;
					array[num] = (byte)this.lengthCode;
				}
				else
				{
					if (!this.input.EnsureBitsAvailable(7))
					{
						this.state = InflaterState.ReadingTreeCodesAfter;
						return false;
					}
					if (this.lengthCode == 16)
					{
						if (this.loopCounter == 0)
						{
							throw new InvalidDataException();
						}
						byte b = this.codeList[this.loopCounter - 1];
						int num2 = this.input.GetBits(2) + 3;
						if (this.loopCounter + num2 > this.codeArraySize)
						{
							throw new InvalidDataException();
						}
						for (int j = 0; j < num2; j++)
						{
							byte[] array2 = this.codeList;
							int num = this.loopCounter;
							this.loopCounter = num + 1;
							array2[num] = b;
						}
					}
					else if (this.lengthCode == 17)
					{
						int num2 = this.input.GetBits(3) + 3;
						if (this.loopCounter + num2 > this.codeArraySize)
						{
							throw new InvalidDataException();
						}
						for (int k = 0; k < num2; k++)
						{
							byte[] array3 = this.codeList;
							int num = this.loopCounter;
							this.loopCounter = num + 1;
							array3[num] = 0;
						}
					}
					else
					{
						int num2 = this.input.GetBits(7) + 11;
						if (this.loopCounter + num2 > this.codeArraySize)
						{
							throw new InvalidDataException();
						}
						for (int l = 0; l < num2; l++)
						{
							byte[] array4 = this.codeList;
							int num = this.loopCounter;
							this.loopCounter = num + 1;
							array4[num] = 0;
						}
					}
				}
				this.state = InflaterState.ReadingTreeCodesBefore;
			}
			byte[] array5 = new byte[288];
			byte[] array6 = new byte[32];
			Array.Copy(this.codeList, array5, this.literalLengthCodeCount);
			Array.Copy(this.codeList, this.literalLengthCodeCount, array6, 0, this.distanceCodeCount);
			if (array5[256] == 0)
			{
				throw new InvalidDataException();
			}
			this.literalLengthTree = new HuffmanTree(array5);
			this.distanceTree = new HuffmanTree(array6);
			this.state = InflaterState.DecodeTop;
			return true;
			IL_62:
			this.distanceCodeCount = this.input.GetBits(5);
			if (this.distanceCodeCount < 0)
			{
				return false;
			}
			this.distanceCodeCount++;
			this.state = InflaterState.ReadingNumCodeLengthCodes;
			IL_94:
			this.codeLengthCodeCount = this.input.GetBits(4);
			if (this.codeLengthCodeCount < 0)
			{
				return false;
			}
			this.codeLengthCodeCount += 4;
			this.loopCounter = 0;
			this.state = InflaterState.ReadingCodeLengthCodes;
			goto IL_105;
		}

		// Token: 0x04000A6C RID: 2668
		private static readonly byte[] extraLengthBits = new byte[]
		{
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			1,
			1,
			1,
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			4,
			4,
			4,
			4,
			5,
			5,
			5,
			5,
			0
		};

		// Token: 0x04000A6D RID: 2669
		private static readonly int[] lengthBase = new int[]
		{
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			13,
			15,
			17,
			19,
			23,
			27,
			31,
			35,
			43,
			51,
			59,
			67,
			83,
			99,
			115,
			131,
			163,
			195,
			227,
			258
		};

		// Token: 0x04000A6E RID: 2670
		private static readonly int[] distanceBasePosition = new int[]
		{
			1,
			2,
			3,
			4,
			5,
			7,
			9,
			13,
			17,
			25,
			33,
			49,
			65,
			97,
			129,
			193,
			257,
			385,
			513,
			769,
			1025,
			1537,
			2049,
			3073,
			4097,
			6145,
			8193,
			12289,
			16385,
			24577,
			0,
			0
		};

		// Token: 0x04000A6F RID: 2671
		private static readonly byte[] codeOrder = new byte[]
		{
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		};

		// Token: 0x04000A70 RID: 2672
		private static readonly byte[] staticDistanceTreeTable = new byte[]
		{
			0,
			16,
			8,
			24,
			4,
			20,
			12,
			28,
			2,
			18,
			10,
			26,
			6,
			22,
			14,
			30,
			1,
			17,
			9,
			25,
			5,
			21,
			13,
			29,
			3,
			19,
			11,
			27,
			7,
			23,
			15,
			31
		};

		// Token: 0x04000A71 RID: 2673
		private OutputWindow output;

		// Token: 0x04000A72 RID: 2674
		private InputBuffer input;

		// Token: 0x04000A73 RID: 2675
		private HuffmanTree literalLengthTree;

		// Token: 0x04000A74 RID: 2676
		private HuffmanTree distanceTree;

		// Token: 0x04000A75 RID: 2677
		private InflaterState state;

		// Token: 0x04000A76 RID: 2678
		private bool hasFormatReader;

		// Token: 0x04000A77 RID: 2679
		private int bfinal;

		// Token: 0x04000A78 RID: 2680
		private BlockType blockType;

		// Token: 0x04000A79 RID: 2681
		private byte[] blockLengthBuffer = new byte[4];

		// Token: 0x04000A7A RID: 2682
		private int blockLength;

		// Token: 0x04000A7B RID: 2683
		private int length;

		// Token: 0x04000A7C RID: 2684
		private int distanceCode;

		// Token: 0x04000A7D RID: 2685
		private int extraBits;

		// Token: 0x04000A7E RID: 2686
		private int loopCounter;

		// Token: 0x04000A7F RID: 2687
		private int literalLengthCodeCount;

		// Token: 0x04000A80 RID: 2688
		private int distanceCodeCount;

		// Token: 0x04000A81 RID: 2689
		private int codeLengthCodeCount;

		// Token: 0x04000A82 RID: 2690
		private int codeArraySize;

		// Token: 0x04000A83 RID: 2691
		private int lengthCode;

		// Token: 0x04000A84 RID: 2692
		private byte[] codeList;

		// Token: 0x04000A85 RID: 2693
		private byte[] codeLengthTreeCodeLength;

		// Token: 0x04000A86 RID: 2694
		private HuffmanTree codeLengthTree;

		// Token: 0x04000A87 RID: 2695
		private IFileFormatReader formatReader;
	}
}
