﻿using System;

// Token: 0x02000039 RID: 57
public enum DataDisplay
{
	// Token: 0x040001E8 RID: 488
	none,
	// Token: 0x040001E9 RID: 489
	hidden,
	// Token: 0x040001EA RID: 490
	moving,
	// Token: 0x040001EB RID: 491
	locked,
	// Token: 0x040001EC RID: 492
	fullamount,
	// Token: 0x040001ED RID: 493
	towards
}
