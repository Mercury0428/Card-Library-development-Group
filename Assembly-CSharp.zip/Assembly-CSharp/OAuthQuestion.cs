﻿using System;
using UnityEngine;

// Token: 0x020000A0 RID: 160
public class OAuthQuestion : MonoBehaviour
{
	// Token: 0x060004EA RID: 1258 RVA: 0x0001E025 File Offset: 0x0001C225
	public void Click()
	{
		Debug.Log("Clicked");
		Application.OpenURL("http://www.twitchapps.com/tmi");
	}
}
