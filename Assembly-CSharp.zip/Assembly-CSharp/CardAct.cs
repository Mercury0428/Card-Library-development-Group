﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000032 RID: 50
public class CardAct : MonoBehaviour
{
	// Token: 0x06000158 RID: 344 RVA: 0x00009574 File Offset: 0x00007774
	protected void _Awake()
	{
		this.defaultImage = this.sprite.vectorGraphics;
		this.cardGraphics = this.sprite.gameObject;
		if (this.yesSign)
		{
			this.oriCol = (this.clCol = this.yesSign.color);
		}
		this.clCol.a = 0f;
		this.thistrans = base.GetComponent<RectTransform>();
		this.thistrans.localScale = new Vector3(1f, 1f, 1f);
		this.GoToPos(new Vector2(0f, -1000f));
		this.cardGraphics.SetActive(false);
	}

	// Token: 0x06000159 RID: 345 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void Init(Bearer bear)
	{
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void ReactToItem(Transform item)
	{
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void StopReacting()
	{
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00009628 File Offset: 0x00007828
	public virtual void InitCard(string yesText = "", string noText = "", string otherText = "", int decision = 0, bool withanim = true)
	{
		this.cardGraphics.SetActive(true);
		this.UpdateCard(yesText, noText, "");
		this.timeSinceGrab = Time.realtimeSinceStartup;
		if (!withanim)
		{
			return;
		}
		this.fond.enabled = true;
		if (decision == -1)
		{
			this.anima.Play("turnright");
			return;
		}
		this.anima.Play("turnleft");
	}

	// Token: 0x0600015D RID: 349 RVA: 0x00009690 File Offset: 0x00007890
	public virtual void UpdateCard(string yesText, string noText, string question = "")
	{
		if (this.fondyesno)
		{
			this.StopCorout();
			this.fondyesno.anchoredPosition = (this.fondyesno2.anchoredPosition = new Vector3(0f, 0f, 0f));
			this.fondyesno.rotation = (this.fondyesno2.rotation = Quaternion.Euler(0f, 0f, 0f));
			Text text = this.yesSign;
			this.yesSign2.text = yesText;
			text.text = yesText;
			Text text2 = this.noSign;
			this.noSign2.text = noText;
			text2.text = noText;
			this.yesSign.color = (this.noSign.color = (this.yesSign2.color = (this.noSign2.color = this.clCol)));
		}
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00009788 File Offset: 0x00007988
	public virtual void CustomImage(string source, string folder = "bearers")
	{
		if (!base.gameObject.activeInHierarchy)
		{
			return;
		}
		if (string.IsNullOrEmpty(source))
		{
			return;
		}
		this.cardAnimSet = 0;
		if (source.Contains("&"))
		{
			string[] array = source.Split(new char[]
			{
				'&'
			}, StringSplitOptions.RemoveEmptyEntries);
			source = array[0];
			this.GetAnimation(source, folder);
			string a = array[1];
			if (a == "yes")
			{
				this.cardAnimSet = 1;
				return;
			}
			if (a == "no")
			{
				this.cardAnimSet = -1;
				return;
			}
			if (a == "delay")
			{
				this.AnimSprite(false, 1f);
			}
		}
		else
		{
			this.GetAnimation(source, folder);
		}
		this.AnimSprite(false, 0f);
		this.hasCustomImage = true;
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00009844 File Offset: 0x00007A44
	private void AnimSprite(bool reverse = false, float delay = 0f)
	{
		if (this.animsprite != null)
		{
			base.StopCoroutine(this.animsprite);
		}
		this.animsprite = base.StartCoroutine(this.DoAnimSprite(this.cardAnimation, delay, reverse));
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00009874 File Offset: 0x00007A74
	private IEnumerator DoAnimSprite(SVGAsset[] sprites, float delay, bool reverse)
	{
		yield return new WaitForSeconds(delay);
		if (reverse)
		{
			int num;
			for (int i = sprites.Length - 1; i > -1; i = num - 1)
			{
				SVGAsset svgasset = sprites[i];
				if (this.sprite.vectorGraphics != svgasset)
				{
					this.sprite.vectorGraphics = svgasset;
					yield return new WaitForSeconds(0.2f);
				}
				num = i;
			}
		}
		else
		{
			foreach (SVGAsset svgasset2 in sprites)
			{
				if (this.sprite.vectorGraphics != svgasset2)
				{
					this.sprite.vectorGraphics = svgasset2;
					yield return new WaitForSeconds(0.2f);
				}
			}
			SVGAsset[] array = null;
		}
		yield break;
	}

	// Token: 0x06000161 RID: 353 RVA: 0x00009898 File Offset: 0x00007A98
	private void GetAnimation(string source, string folder)
	{
		List<SVGAsset> list = new List<SVGAsset>();
		string str;
		if (this.defaultImage == null)
		{
			str = folder + "/";
		}
		else
		{
			str = folder + "/" + this.defaultImage.name + "-";
			list.Add(this.defaultImage);
		}
		SVGAsset svgasset = (SVGAsset)Resources.Load(str + source, typeof(SVGAsset));
		int num = 1;
		while (svgasset != null)
		{
			list.Add(svgasset);
			svgasset = (SVGAsset)Resources.Load(str + source + num.ToString(), typeof(SVGAsset));
			num++;
		}
		this.cardAnimation = list.ToArray();
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00009952 File Offset: 0x00007B52
	public virtual void DefaultImage()
	{
		this.sprite.vectorGraphics = this.defaultImage;
		this.hasCustomImage = false;
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00003D07 File Offset: 0x00001F07
	public virtual void HideCard()
	{
	}

	// Token: 0x06000164 RID: 356 RVA: 0x0000996C File Offset: 0x00007B6C
	public virtual void HideFond()
	{
		this.fond.enabled = false;
	}

	// Token: 0x06000165 RID: 357 RVA: 0x0000997A File Offset: 0x00007B7A
	private void StopCorout()
	{
		base.StopCoroutine("MoveFond");
		base.StopCoroutine("ChangeYes");
		base.StopCoroutine("ChangeNo");
		base.StopCoroutine("RotateFond");
	}

	// Token: 0x06000166 RID: 358 RVA: 0x000099A8 File Offset: 0x00007BA8
	public virtual void ShowDecision(int dec)
	{
		int num = this.decision;
		if (this.decision == dec)
		{
			return;
		}
		this.decision = dec;
		this.StopCorout();
		if (!this.fondyesno)
		{
			return;
		}
		switch (this.decision)
		{
		case -1:
			base.StartCoroutine("MoveFond", this.tpos);
			base.StartCoroutine("ChangeYes", this.clCol);
			base.StartCoroutine("ChangeNo", this.oriCol);
			this.timeSinceGrab = Time.realtimeSinceStartup;
			if (this.cardAnimSet == -1)
			{
				this.AnimSprite(false, 0f);
			}
			if (this.cardAnimSet == 1 && num == 1)
			{
				this.AnimSprite(true, 0f);
				return;
			}
			break;
		case 0:
			base.StartCoroutine("MoveFond", this.opos);
			base.StartCoroutine("ChangeYes", this.clCol);
			base.StartCoroutine("ChangeNo", this.clCol);
			if (this.cardAnimSet == 1 && num == 1)
			{
				this.AnimSprite(true, 0f);
			}
			if (this.cardAnimSet == -1 && num == -1)
			{
				this.AnimSprite(true, 0f);
				return;
			}
			break;
		case 1:
			base.StartCoroutine("MoveFond", this.tpos);
			base.StartCoroutine("ChangeYes", this.oriCol);
			base.StartCoroutine("ChangeNo", this.clCol);
			this.timeSinceGrab = Time.realtimeSinceStartup;
			if (this.cardAnimSet == 1)
			{
				this.AnimSprite(false, 0f);
			}
			if (this.cardAnimSet == -1 && num == -1)
			{
				this.AnimSprite(true, 0f);
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00009B7E File Offset: 0x00007D7E
	private IEnumerator MoveFond(Vector3 targ)
	{
		float t = 0f;
		while (t < 0.5f)
		{
			this.fondyesno.anchoredPosition = Vector3.Lerp(this.fondyesno.anchoredPosition, targ, Time.deltaTime * 10f);
			if (this.destroy2Sides)
			{
				this.fondyesno2.anchoredPosition = Vector3.Lerp(this.fondyesno2.anchoredPosition, targ, Time.deltaTime * 10f);
			}
			t += Time.deltaTime;
			yield return null;
		}
		this.fondyesno.anchoredPosition = targ;
		if (this.destroy2Sides)
		{
			this.fondyesno2.anchoredPosition = targ;
		}
		yield break;
	}

	// Token: 0x06000168 RID: 360 RVA: 0x00009B94 File Offset: 0x00007D94
	private IEnumerator RotateFond(float dir)
	{
		float t = 0f;
		while (t < 0.5f)
		{
			this.fondyesno.rotation = Quaternion.Slerp(this.fondyesno.rotation, Quaternion.Euler(0f, 0f, dir), Time.deltaTime * 20f);
			if (this.destroy2Sides)
			{
				this.fondyesno2.rotation = Quaternion.Slerp(this.fondyesno2.rotation, Quaternion.Euler(0f, 0f, dir), Time.deltaTime * 20f);
			}
			t += Time.deltaTime;
			yield return null;
		}
		this.fondyesno.rotation = Quaternion.Euler(0f, 0f, dir);
		if (this.destroy2Sides)
		{
			this.fondyesno2.rotation = Quaternion.Euler(0f, 0f, dir);
		}
		yield break;
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00009BAA File Offset: 0x00007DAA
	private IEnumerator ChangeYes(Color targ)
	{
		float t = 0f;
		while (t < 0.5f)
		{
			Color color = Color.Lerp(this.yesSign.color, targ, Time.deltaTime * 20f);
			this.yesSign.color = color;
			if (this.destroy2Sides)
			{
				this.yesSign2.color = color;
			}
			t += Time.deltaTime;
			yield return null;
		}
		this.yesSign.color = targ;
		if (this.destroy2Sides)
		{
			this.yesSign2.color = targ;
		}
		yield break;
	}

	// Token: 0x0600016A RID: 362 RVA: 0x00009BC0 File Offset: 0x00007DC0
	private IEnumerator ChangeNo(Color targ)
	{
		float t = 0f;
		while (t < 0.5f)
		{
			Color color = Color.Lerp(this.noSign.color, targ, Time.deltaTime * 20f);
			this.noSign.color = color;
			if (this.destroy2Sides)
			{
				this.noSign2.color = color;
			}
			t += Time.deltaTime;
			yield return null;
		}
		this.noSign.color = targ;
		if (this.destroy2Sides)
		{
			this.noSign2.color = targ;
		}
		yield break;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00009BD8 File Offset: 0x00007DD8
	public void GoToPos(Vector2 target)
	{
		if (this.mytrans == null)
		{
			return;
		}
		if (this.destroy2Sides)
		{
			this.mytrans.anchoredPosition = target - this.half;
			this.mytrans2.anchoredPosition = target + this.half;
		}
		else
		{
			this.mytrans.anchoredPosition = target;
		}
		if (this.lockedRect != null)
		{
			this.lockedRect.anchoredPosition = target;
		}
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00009C54 File Offset: 0x00007E54
	public virtual void LerpToPos(Vector2 target, float amount)
	{
		if (this.mytrans == null)
		{
			return;
		}
		if (this.destroy2Sides)
		{
			float d = (target.x < 0f) ? 1.2f : 1f;
			float d2 = (target.x < 0f) ? 1f : 1.2f;
			this.mytrans.anchoredPosition = Vector2.Lerp(this.mytrans.anchoredPosition, target * d - this.half, amount);
			this.mytrans2.anchoredPosition = Vector2.Lerp(this.mytrans2.anchoredPosition, target * d2 + this.half, amount);
			return;
		}
		this.mytrans.anchoredPosition = Vector2.Lerp(this.mytrans.anchoredPosition, target, amount);
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00009D2C File Offset: 0x00007F2C
	public virtual void SlerpToPos(float xp, float yp)
	{
		if (this.mytrans == null)
		{
			return;
		}
		if (this.fondyesno)
		{
			this.fondyesno.rotation = Quaternion.Euler(0f, 0f, 0f);
		}
		if (this.destroy2Sides)
		{
			float num = (xp < 0f) ? (xp * 0.0012f) : (xp * 0.003f);
			float num2 = (xp < 0f) ? (xp * 0.003f) : (xp * 0.0012f);
			this.mytrans.rotation = Quaternion.Slerp(this.mytrans.rotation, Quaternion.AngleAxis(-yp * num2, Vector3.forward), Time.deltaTime * 12f);
			this.mytrans2.rotation = Quaternion.Slerp(this.mytrans2.rotation, Quaternion.AngleAxis(-yp * num, Vector3.forward), Time.deltaTime * 12f);
			this.fondyesno2.rotation = Quaternion.Euler(0f, 0f, 0f);
			return;
		}
		this.mytrans.rotation = Quaternion.Slerp(this.mytrans.rotation, Quaternion.AngleAxis(-yp * xp * 0.0012f, Vector3.forward), Time.deltaTime * 12f);
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00009E74 File Offset: 0x00008074
	public virtual void Disappear(Vector2 vec, bool nodecision)
	{
		if (this.mytrans == null)
		{
			return;
		}
		float num = nodecision ? 0.3f : (Mathf.Clamp(Time.realtimeSinceStartup - this.timeSinceGrab - 0.3f, 0.2f, 4f) * 10f);
		vec.y -= (nodecision ? (num * 10f * Time.deltaTime) : (num * Mathf.Pow(this.mytrans.anchoredPosition.x, 2f) * Time.deltaTime * 0.01f));
		vec *= 3f / num;
		this.AddToPos(vec);
		float num2 = vec.x * 10f / (10f + num);
		this.mytrans.Rotate(new Vector3(0f, 0f, -num2 * 0.4f));
		if (this.destroy2Sides)
		{
			this.mytrans2.Rotate(new Vector3(0f, 0f, -num2 * 0.4f));
		}
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00009F80 File Offset: 0x00008180
	private void AddToPos(Vector2 amount)
	{
		if (this.mytrans == null)
		{
			return;
		}
		this.mytrans.anchoredPosition += amount;
		if (this.destroy2Sides)
		{
			this.mytrans2.anchoredPosition += amount;
		}
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00009FD4 File Offset: 0x000081D4
	public void RotateTo(float ang)
	{
		if (this.mytrans == null)
		{
			return;
		}
		this.mytrans.rotation = Quaternion.AngleAxis(ang, Vector3.forward);
		if (this.destroy2Sides)
		{
			this.mytrans2.rotation = Quaternion.AngleAxis(ang, Vector3.forward);
		}
	}

	// Token: 0x06000171 RID: 369 RVA: 0x0000A024 File Offset: 0x00008224
	public virtual void Unset()
	{
		if (this.cardGraphics == null)
		{
			return;
		}
		this.cardGraphics.SetActive(false);
	}

	// Token: 0x0400018F RID: 399
	public RectTransform mytrans;

	// Token: 0x04000190 RID: 400
	public RectTransform mytrans2;

	// Token: 0x04000191 RID: 401
	protected RectTransform thistrans;

	// Token: 0x04000192 RID: 402
	public Animator anima;

	// Token: 0x04000193 RID: 403
	public SVGImage sprite;

	// Token: 0x04000194 RID: 404
	public SVGImage fond;

	// Token: 0x04000195 RID: 405
	public Text yesSign;

	// Token: 0x04000196 RID: 406
	public Text noSign;

	// Token: 0x04000197 RID: 407
	public Text yesSign2;

	// Token: 0x04000198 RID: 408
	public Text noSign2;

	// Token: 0x04000199 RID: 409
	public RectTransform fondyesno;

	// Token: 0x0400019A RID: 410
	public RectTransform fondyesno2;

	// Token: 0x0400019B RID: 411
	public int decision;

	// Token: 0x0400019C RID: 412
	protected Color oriCol;

	// Token: 0x0400019D RID: 413
	protected Color clCol;

	// Token: 0x0400019E RID: 414
	protected AudioSource audioCard;

	// Token: 0x0400019F RID: 415
	protected bool hasCustomImage;

	// Token: 0x040001A0 RID: 416
	protected SVGAsset defaultImage;

	// Token: 0x040001A1 RID: 417
	protected Vector3 tpos = new Vector3(0f, -85f, 0f);

	// Token: 0x040001A2 RID: 418
	protected Vector3 opos = new Vector3(0f, 40f, 0f);

	// Token: 0x040001A3 RID: 419
	protected float timeSinceGrab;

	// Token: 0x040001A4 RID: 420
	protected GameObject cardGraphics;

	// Token: 0x040001A5 RID: 421
	public SVGAsset[] cardAnimation;

	// Token: 0x040001A6 RID: 422
	private int cardAnimSet;

	// Token: 0x040001A7 RID: 423
	public bool destroy2Sides;

	// Token: 0x040001A8 RID: 424
	protected RectTransform lockedRect;

	// Token: 0x040001A9 RID: 425
	private Coroutine animsprite;

	// Token: 0x040001AA RID: 426
	private Vector2 half = new Vector2(70f, 0f);
}
