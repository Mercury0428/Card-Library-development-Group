﻿using System;
using System.Collections;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000015 RID: 21
public class RoadAct : MonoBehaviour
{
	// Token: 0x0600009D RID: 157 RVA: 0x000044CC File Offset: 0x000026CC
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnRefresh = (Action<Card>)Delegate.Combine(diff.OnRefresh, new Action<Card>(this.CheckBattle));
		this.selfT = base.GetComponent<RectTransform>();
		this.rulerImg = this.ruler.GetComponent<SVGImage>();
	}

	// Token: 0x0600009E RID: 158 RVA: 0x0000451C File Offset: 0x0000271C
	private void CheckBattle(Card card)
	{
		int @int = GameAct.diff.GetInt("inc_road");
		if (@int > 0 && !this.ontheroad)
		{
			this.StartRoad();
		}
		else if (this.ontheroad && (@int == 0 || card.bearer == Bearers.end))
		{
			this.StopRoad();
		}
		if (this.ontheroad)
		{
			this.RefreshRoad();
		}
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00004578 File Offset: 0x00002778
	private void StartRoad()
	{
		this.ontheroad = true;
		this.Enable();
		BackgroundAct.diff.SwitchWithTop(this.selfT, true);
		this.stepid = 0;
		this.ruler.anchoredPosition = new Vector2(this.steps[0].rectTransform.anchoredPosition.x, -63.5f);
		SVGImage[] array = this.steps;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].vectorGraphics = this.emptyDot;
		}
		this.steps[0].vectorGraphics = this.fullDot;
		this.rulerImg.vectorGraphics = this.start;
		this.rulerImg.SetNativeSize();
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00004628 File Offset: 0x00002828
	private void StopRoad()
	{
		this.ontheroad = false;
		BackgroundAct.diff.SwitchWithTop(this.selfT, false);
		base.StopCoroutine("DoRefresh");
		JukeBox.diff.PlaySound(SFXTypes.sfx_travel_arrival_horn, false, false, 2.5f, -1, 1.5f, 1f);
		base.StartCoroutine("DoDisable");
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00004685 File Offset: 0x00002885
	private IEnumerator DoDisable()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(false);
		}
		base.StopAllCoroutines();
		yield break;
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00004694 File Offset: 0x00002894
	private void Enable()
	{
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(true);
		}
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x000046F0 File Offset: 0x000028F0
	private void RefreshRoad()
	{
		int num = Mathf.Clamp(GameAct.diff.GetInt("inc_road") - 2, 0, 5);
		if (this.stepid != num)
		{
			this.steps[this.stepid].vectorGraphics = this.emptyDot;
			this.stepid = num;
			this.steps[this.stepid].vectorGraphics = this.fullDot;
			base.StopCoroutine("GoTo");
			base.StartCoroutine("GoTo", this.steps[this.stepid].rectTransform.anchoredPosition.x);
			JukeBox.diff.PlaySound(SFXTypes.sfx_travel_carriage_move, false, false, 2.5f, -1, 1.5f, 1f);
		}
		if (Util.Rand(0f, 1f) > 0.9f)
		{
			JukeBox.diff.PlaySound(SFXTypes.sfx_travel_distant_scream, false, false, 2.5f, -1, 1.5f, 1f);
		}
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x000047E9 File Offset: 0x000029E9
	private IEnumerator GoTo(float xp)
	{
		float t = 0f;
		Vector2 tpo = new Vector2(xp, -63.5f);
		this.rulerImg.vectorGraphics = this.run0;
		this.rulerImg.SetNativeSize();
		Vector2 opo = this.ruler.anchoredPosition;
		int oldi = 0;
		while (t < 1f)
		{
			this.ruler.anchoredPosition = Vector2.LerpUnclamped(opo, tpo, t);
			t += Time.deltaTime * 0.6f;
			int num = (int)(t * 6f);
			if (num != oldi)
			{
				oldi = num;
				this.rulerImg.vectorGraphics = ((num % 2 == 0) ? this.run1 : this.run0);
				this.rulerImg.SetNativeSize();
			}
			yield return 0;
		}
		this.rulerImg.vectorGraphics = this.stop;
		this.rulerImg.SetNativeSize();
		yield break;
	}

	// Token: 0x0400006F RID: 111
	public SVGAsset fullDot;

	// Token: 0x04000070 RID: 112
	public SVGAsset emptyDot;

	// Token: 0x04000071 RID: 113
	public SVGAsset start;

	// Token: 0x04000072 RID: 114
	public SVGAsset stop;

	// Token: 0x04000073 RID: 115
	public SVGAsset run0;

	// Token: 0x04000074 RID: 116
	public SVGAsset run1;

	// Token: 0x04000075 RID: 117
	private bool ontheroad;

	// Token: 0x04000076 RID: 118
	private RectTransform selfT;

	// Token: 0x04000077 RID: 119
	public SVGImage[] steps;

	// Token: 0x04000078 RID: 120
	public Text origin;

	// Token: 0x04000079 RID: 121
	public Text destination;

	// Token: 0x0400007A RID: 122
	public RectTransform ruler;

	// Token: 0x0400007B RID: 123
	private SVGImage rulerImg;

	// Token: 0x0400007C RID: 124
	private int stepid;
}
