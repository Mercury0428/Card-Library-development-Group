﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class DreamAct : MonoBehaviour
{
	// Token: 0x0600002C RID: 44 RVA: 0x00002F00 File Offset: 0x00001100
	private void Start()
	{
		this.flame = base.GetComponent<SVGImage>();
		EffectAct effectAct = this.scEff;
		effectAct.OnOpenEffect = (Action<Effect>)Delegate.Combine(effectAct.OnOpenEffect, new Action<Effect>(this.CheckDream));
		EffectAct effectAct2 = this.scEff;
		effectAct2.OnCloseEffect = (Action<Effect>)Delegate.Combine(effectAct2.OnCloseEffect, new Action<Effect>(this.CheckNoDream));
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00002F68 File Offset: 0x00001168
	private void CheckDream(Effect effect)
	{
		if (effect.tag != "dreamloop" || this.hasDream)
		{
			return;
		}
		this.hasDream = true;
		BackgroundAct.diff.FadeToBlack();
		BackgroundAct.diff.TurnLight(true);
		BackgroundAct.diff.HideTop(false);
		BackgroundAct.diff.HideBottom(false);
		this.NewFlame();
		this.flame.enabled = true;
		GameAct diff = GameAct.diff;
		diff.OnChoice = (Action<int>)Delegate.Combine(diff.OnChoice, new Action<int>(this.SwitchFlame));
		JukeBox.diff.PlaySound(SFXTypes.sfx_dream_start, false, false, 2.5f, -1, 1.5f, 1f);
		JukeBox.diff.PlaySound(SFXTypes.env_death_melisandre, false, false, 2.5f, -1, 1.5f, 1f);
		JukeBox.diff.StopMusic(false);
	}

	// Token: 0x0600002E RID: 46 RVA: 0x00003044 File Offset: 0x00001244
	private void CheckNoDream(Effect effect)
	{
		if (effect.tag != "dreamloop" || !this.hasDream)
		{
			return;
		}
		this.hasDream = false;
		BackgroundAct.diff.FadeToLight(GameStates.none);
		BackgroundAct.diff.ShowTop(false);
		BackgroundAct.diff.ShowBottom(false);
		BackgroundAct.diff.TurnLight(false);
		this.flame.enabled = false;
		GameAct diff = GameAct.diff;
		diff.OnChoice = (Action<int>)Delegate.Remove(diff.OnChoice, new Action<int>(this.SwitchFlame));
		JukeBox.diff.RestartMusic();
	}

	// Token: 0x0600002F RID: 47 RVA: 0x000030DB File Offset: 0x000012DB
	private void SwitchFlame(int dec)
	{
		if (dec != 0)
		{
			this.NewFlame();
		}
	}

	// Token: 0x06000030 RID: 48 RVA: 0x000030E8 File Offset: 0x000012E8
	private void NewFlame()
	{
		List<SVGAsset> list = new List<SVGAsset>(this.flames);
		if (this.asset != null)
		{
			list.Remove(this.asset);
		}
		this.asset = list[Util.RandInt(0, list.Count)];
		this.flame.vectorGraphics = this.asset;
	}

	// Token: 0x04000035 RID: 53
	public EffectAct scEff;

	// Token: 0x04000036 RID: 54
	private SVGAsset asset;

	// Token: 0x04000037 RID: 55
	public List<SVGAsset> flames;

	// Token: 0x04000038 RID: 56
	private bool hasDream;

	// Token: 0x04000039 RID: 57
	private SVGImage flame;
}
