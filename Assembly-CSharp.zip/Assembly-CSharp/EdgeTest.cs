﻿using System;
using UnityEngine;

// Token: 0x02000093 RID: 147
public class EdgeTest : MonoBehaviour
{
}
