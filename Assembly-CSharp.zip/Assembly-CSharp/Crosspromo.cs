﻿using System;
using UnityEngine;

// Token: 0x02000004 RID: 4
[Serializable]
public class Crosspromo
{
	// Token: 0x04000019 RID: 25
	public string name;

	// Token: 0x0400001A RID: 26
	public string iosCode;

	// Token: 0x0400001B RID: 27
	public string andCode;

	// Token: 0x0400001C RID: 28
	public string steamCode;

	// Token: 0x0400001D RID: 29
	public string amaCode;

	// Token: 0x0400001E RID: 30
	public string taptapCode;

	// Token: 0x0400001F RID: 31
	public string mainUrl;

	// Token: 0x04000020 RID: 32
	public string fullPromoText;

	// Token: 0x04000021 RID: 33
	public int start;

	// Token: 0x04000022 RID: 34
	public int recurrence;

	// Token: 0x04000023 RID: 35
	public Sprite promoSprite;
}
