﻿using System;
using System.Collections;

// Token: 0x0200007B RID: 123
public class IntroScreen : TitleScreen
{
	// Token: 0x06000432 RID: 1074 RVA: 0x0001ADF5 File Offset: 0x00018FF5
	public override IEnumerator Open()
	{
		yield return null;
		yield break;
	}
}
