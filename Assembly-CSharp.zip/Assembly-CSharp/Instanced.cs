﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

// Token: 0x0200008C RID: 140
public class Instanced : MonoBehaviour
{
	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000485 RID: 1157 RVA: 0x0001C5A6 File Offset: 0x0001A7A6
	// (set) Token: 0x06000486 RID: 1158 RVA: 0x0001C5AE File Offset: 0x0001A7AE
	public Instanced.TriggerEvent onUpdate
	{
		get
		{
			return this.m_onUpdate;
		}
		set
		{
			this.m_onUpdate = value;
		}
	}

	// Token: 0x04000541 RID: 1345
	[FormerlySerializedAs("onUpdate")]
	[SerializeField]
	protected Instanced.TriggerEvent m_onUpdate = new Instanced.TriggerEvent();

	// Token: 0x02000320 RID: 800
	[Serializable]
	public class TriggerEvent : UnityEvent<float>
	{
	}
}
