﻿using System;
using UnityEngine;

// Token: 0x0200009A RID: 154
public class MoveTheBall : MonoBehaviour
{
	// Token: 0x060004CE RID: 1230 RVA: 0x0001D73C File Offset: 0x0001B93C
	public void MoveLeft(string s, string all)
	{
		int num = 0;
		int.TryParse(s, out num);
		this.bX -= num;
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0001D764 File Offset: 0x0001B964
	public void MoveRight(string s, string all)
	{
		int num = 0;
		int.TryParse(s, out num);
		this.bX += num;
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x0001D78C File Offset: 0x0001B98C
	public void MoveUp(string s, string all)
	{
		int num = 0;
		int.TryParse(s, out num);
		this.bY += num;
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x0001D7B4 File Offset: 0x0001B9B4
	public void MoveDown(string s, string all)
	{
		int num = 0;
		int.TryParse(s, out num);
		this.bY -= num;
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x0001D7DC File Offset: 0x0001B9DC
	private void LateUpdate()
	{
		this.bX = Mathf.Max(Mathf.Min(this.Width, this.bX), 0);
		this.bY = Mathf.Max(Mathf.Min(this.Height, this.bY), 0);
		this.Ball.transform.position = new Vector3((float)(this.bX - this.Width / 2), 1f, (float)(this.bY - this.Height / 2));
	}

	// Token: 0x04000585 RID: 1413
	public int Width;

	// Token: 0x04000586 RID: 1414
	public int Height;

	// Token: 0x04000587 RID: 1415
	public Transform Ball;

	// Token: 0x04000588 RID: 1416
	public int bX;

	// Token: 0x04000589 RID: 1417
	public int bY;
}
