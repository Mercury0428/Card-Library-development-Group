﻿using System;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class AudioSpectrum : MonoBehaviour
{
	// Token: 0x17000011 RID: 17
	// (get) Token: 0x0600047E RID: 1150 RVA: 0x0001C4B1 File Offset: 0x0001A6B1
	public static AudioSpectrum Instance
	{
		get
		{
			return AudioSpectrum._Instance;
		}
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x0001C4B8 File Offset: 0x0001A6B8
	private void Awake()
	{
		AudioSpectrum._Instance = this;
		this.leftChannel = new float[this.resolution];
		this.rightChannel = new float[this.resolution];
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x0001C4E4 File Offset: 0x0001A6E4
	private void Update()
	{
		if (this.leftChannel == null || this.leftChannel.Length != this.resolution)
		{
			this.leftChannel = new float[this.resolution];
		}
		if (this.rightChannel == null || this.rightChannel.Length != this.resolution)
		{
			this.rightChannel = new float[this.resolution];
		}
		this.audioSource.GetSpectrumData(this.leftChannel, 0, FFTWindow.BlackmanHarris);
		this.audioSource.GetSpectrumData(this.rightChannel, 1, FFTWindow.BlackmanHarris);
	}

	// Token: 0x0400053A RID: 1338
	protected static AudioSpectrum _Instance;

	// Token: 0x0400053B RID: 1339
	public AudioSource audioSource;

	// Token: 0x0400053C RID: 1340
	public int resolution = 32;

	// Token: 0x0400053D RID: 1341
	[HideInInspector]
	public float[] leftChannel;

	// Token: 0x0400053E RID: 1342
	[HideInInspector]
	public float[] rightChannel;
}
