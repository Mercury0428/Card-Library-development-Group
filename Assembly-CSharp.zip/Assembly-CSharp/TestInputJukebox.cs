﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200007A RID: 122
public class TestInputJukebox : MonoBehaviour
{
	// Token: 0x0600042F RID: 1071 RVA: 0x0001ADA6 File Offset: 0x00018FA6
	private void Start()
	{
		base.GetComponent<JukeBox>().LinkVar(this.newvar);
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x0001ADB9 File Offset: 0x00018FB9
	private void Update()
	{
		if (global::Input.GetKeyDown(KeyCode.S))
		{
			global::Input.GetKeyDown(KeyCode.M);
		}
	}

	// Token: 0x040004EB RID: 1259
	[Range(10f, 300f)]
	public float voPitch = 100f;

	// Token: 0x040004EC RID: 1260
	[Range(20f, 20000f)]
	public float voCenterFrequ = 2900f;

	// Token: 0x040004ED RID: 1261
	[Range(0f, 3f)]
	public float voFrequGain = 1.5f;

	// Token: 0x040004EE RID: 1262
	public List<DataVariable> newvar;
}
