﻿using System;

// Token: 0x020000A5 RID: 165
public class UniRateDebug
{
	// Token: 0x06000549 RID: 1353 RVA: 0x00003D07 File Offset: 0x00001F07
	public static void Log(object message)
	{
	}
}
