﻿using System;

// Token: 0x0200004C RID: 76
[Serializable]
public class DataVariable
{
	// Token: 0x06000265 RID: 613 RVA: 0x00002050 File Offset: 0x00000250
	public DataVariable()
	{
	}

	// Token: 0x06000266 RID: 614 RVA: 0x0000E718 File Offset: 0x0000C918
	public DataVariable(Variables variable, int value)
	{
		this.var = variable;
		this.val = value;
	}

	// Token: 0x04000345 RID: 837
	public Variables var;

	// Token: 0x04000346 RID: 838
	public int val;
}
