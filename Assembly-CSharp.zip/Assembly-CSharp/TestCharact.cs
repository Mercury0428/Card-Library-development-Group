﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000097 RID: 151
public class TestCharact : MonoBehaviour
{
	// Token: 0x060004B8 RID: 1208 RVA: 0x0001D170 File Offset: 0x0001B370
	private void Start()
	{
		foreach (object obj in base.transform)
		{
			Transform transform = (Transform)obj;
			this.cards.Add(transform.GetComponent<CharacterCard>());
		}
		this.model = CardReader.diff.bearerGenModels.Find((BearerGen it) => it.bearer == this.curBearer);
		this.UpdateCards();
	}

	// Token: 0x060004B9 RID: 1209 RVA: 0x0001D1FC File Offset: 0x0001B3FC
	private void Update()
	{
		if (global::Input.GetKeyUp(KeyCode.R))
		{
			this.UpdateCards();
		}
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x0001D210 File Offset: 0x0001B410
	private void UpdateCards()
	{
		foreach (CharacterCard characterCard in this.cards)
		{
			characterCard.SetGenerated(this.model);
		}
	}

	// Token: 0x0400056C RID: 1388
	public Bearers curBearer;

	// Token: 0x0400056D RID: 1389
	private List<CharacterCard> cards = new List<CharacterCard>();

	// Token: 0x0400056E RID: 1390
	private BearerGen model;
}
