﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEngine;

// Token: 0x0200003C RID: 60
public class DataStore : MonoBehaviour
{
	// Token: 0x060001EA RID: 490 RVA: 0x0000BE68 File Offset: 0x0000A068
	private void Awake()
	{
		Environment.SetEnvironmentVariable("MONO_REFLECTION_SERIALIZER", "yes");
	}

	// Token: 0x060001EB RID: 491 RVA: 0x0000BE7C File Offset: 0x0000A07C
	public static void Reset(bool all = false, bool nosave = false)
	{
		string text = ".dat";
		if (GameAct.diff)
		{
			text = "_" + GameAct.diff.gamename + text;
		}
		else if (!all)
		{
			text = "_default" + text;
		}
		int length = text.Length;
		foreach (string text2 in Directory.GetFiles(Application.persistentDataPath + "/"))
		{
			if (text2.Substring(text2.Length - length, length) == text)
			{
				DataStore.RemoveFile(text2.Substring(Application.persistentDataPath.Length + 1, text2.Length - Application.persistentDataPath.Length + 1 - 4), false);
			}
		}
		DataStore.RemoveFile("stat_save", true);
		DataStore.RemoveFile("game_save", true);
		DataStore.RemoveFile("achievetodisplay_save", true);
		DataStore.RemoveFile("reigns_save", true);
	}

	// Token: 0x060001EC RID: 492 RVA: 0x0000BF68 File Offset: 0x0000A168
	public static void RemoveFile(string name, bool withdat = false)
	{
		string path = Application.persistentDataPath + "/" + name + ".dat";
		if (File.Exists(path))
		{
			File.Delete(path);
		}
		SuperPrefs.DeleteKey(name);
	}

	// Token: 0x060001ED RID: 493 RVA: 0x0000BFA0 File Offset: 0x0000A1A0
	public static void Save<T>(string name, T instance, bool playpref = false, bool nocloud = false)
	{
		if (!nocloud)
		{
			DataStore.SaveToCloud<T>(name, instance, playpref);
		}
		BinaryFormatter binaryFormatter = new BinaryFormatter();
		if (!playpref)
		{
			FileStream fileStream = new FileStream(Application.persistentDataPath + "/" + name + ".dat", FileMode.OpenOrCreate);
			binaryFormatter.Serialize(fileStream, instance);
			fileStream.Close();
			return;
		}
		using (MemoryStream memoryStream = new MemoryStream())
		{
			binaryFormatter.Serialize(memoryStream, instance);
			string @string = Encoding.UTF8.GetString(memoryStream.ToArray());
			SuperPrefs.SetString(name, @string);
		}
	}

	// Token: 0x060001EE RID: 494 RVA: 0x0000C03C File Offset: 0x0000A23C
	public static bool HasFile(string name)
	{
		return File.Exists(Application.persistentDataPath + "/" + name + ".dat");
	}

	// Token: 0x060001EF RID: 495 RVA: 0x0000C058 File Offset: 0x0000A258
	public static void Load<T>(string name, Action<T> completedCallback, bool playpref = false, bool nocloud = false)
	{
		BinaryFormatter binaryFormatter = new BinaryFormatter();
		if (!nocloud && DataStore.LoadFromCloud<T>(name, completedCallback, playpref))
		{
			return;
		}
		if (!playpref)
		{
			string path = Application.persistentDataPath + "/" + name + ".dat";
			if (File.Exists(path))
			{
				FileStream fileStream = File.Open(path, FileMode.Open);
				T obj = (T)((object)binaryFormatter.Deserialize(fileStream));
				fileStream.Close();
				completedCallback(obj);
				return;
			}
		}
		else if (SuperPrefs.HasKey(name))
		{
			T obj;
			using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(SuperPrefs.GetString(name))))
			{
				obj = (T)((object)binaryFormatter.Deserialize(memoryStream));
			}
			completedCallback(obj);
		}
		completedCallback(default(T));
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x0000C120 File Offset: 0x0000A320
	public static T LoadOld<T>(string name, bool playpref = false)
	{
		BinaryFormatter binaryFormatter = new BinaryFormatter();
		if (!playpref)
		{
			string path = Application.persistentDataPath + "/" + name + ".dat";
			if (File.Exists(path))
			{
				FileStream fileStream = File.Open(path, FileMode.Open);
				T result = (T)((object)binaryFormatter.Deserialize(fileStream));
				fileStream.Close();
				return result;
			}
		}
		else if (SuperPrefs.HasKey(name))
		{
			T result;
			using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(SuperPrefs.GetString(name))))
			{
				result = (T)((object)binaryFormatter.Deserialize(memoryStream));
			}
			return result;
		}
		return default(T);
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x0000821B File Offset: 0x0000641B
	public static bool SaveToCloud<T>(string filename, T instance, bool playpref = false)
	{
		return false;
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x0000821B File Offset: 0x0000641B
	public static bool LoadFromCloud<T>(string filename, Action<T> completedCallback, bool playpref = false)
	{
		return false;
	}
}
