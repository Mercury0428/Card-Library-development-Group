﻿using System;
using System.Collections.Generic;

// Token: 0x02000049 RID: 73
[Serializable]
public class Game
{
	// Token: 0x0400032B RID: 811
	public List<Card> cards = new List<Card>();

	// Token: 0x0400032C RID: 812
	public List<Card> hiddencards = new List<Card>();

	// Token: 0x0400032D RID: 813
	public List<Card> inventorycards = new List<Card>();

	// Token: 0x0400032E RID: 814
	public List<DataVariable> variables = new List<DataVariable>();

	// Token: 0x0400032F RID: 815
	public List<DataCustom> custom = new List<DataCustom>();

	// Token: 0x04000330 RID: 816
	public List<Bearers> bearers = new List<Bearers>();

	// Token: 0x04000331 RID: 817
	public List<PostponeEvent> postponeevents = new List<PostponeEvent>();

	// Token: 0x04000332 RID: 818
	public List<Bearers> seenbearers;

	// Token: 0x04000333 RID: 819
	public List<Bearers> metbearers;

	// Token: 0x04000334 RID: 820
	public string title;

	// Token: 0x04000335 RID: 821
	public string nick;

	// Token: 0x04000336 RID: 822
	public GameStates state;

	// Token: 0x04000337 RID: 823
	public string nextcard;

	// Token: 0x04000338 RID: 824
	public int lastage;

	// Token: 0x04000339 RID: 825
	public int turns;

	// Token: 0x0400033A RID: 826
	public List<string> endcards = new List<string>();

	// Token: 0x0400033B RID: 827
	public int maxage;

	// Token: 0x0400033C RID: 828
	public List<Effect> effects = new List<Effect>();

	// Token: 0x0400033D RID: 829
	public List<Objective> objectives = new List<Objective>();

	// Token: 0x0400033E RID: 830
	public List<Reign> reigns = new List<Reign>();

	// Token: 0x0400033F RID: 831
	public string language = "";
}
