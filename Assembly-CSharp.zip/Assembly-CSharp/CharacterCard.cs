﻿using System;
using System.Collections;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000033 RID: 51
public class CharacterCard : CardAct
{
	// Token: 0x06000173 RID: 371 RVA: 0x0000A0A0 File Offset: 0x000082A0
	private void SpecialDecision(int decision)
	{
		string curCardName = GameAct.diff.GetCurCardName();
		if (curCardName == "ratereigns")
		{
			if (decision == 1)
			{
				UniRate.Instance.RateIfNetworkAvailable();
			}
			return;
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x0000A0D4 File Offset: 0x000082D4
	private void Awake()
	{
		this.lockedRect = this.lockedCard.GetComponent<RectTransform>();
		this.selectable = this.choiceBut.GetComponent<Selectable>();
	}

	// Token: 0x06000175 RID: 373 RVA: 0x0000A0F8 File Offset: 0x000082F8
	public override void Init(Bearer newbear)
	{
		this.bear = newbear;
		MonoBehaviour.print(this.bear);
		if (newbear.type == BearerTypes.generated)
		{
			this.SetGenerated(CardReader.diff.bearerGenModels.Find((BearerGen it) => it.bearer == newbear.bearer));
		}
		else
		{
			this.sprite.vectorGraphics = this.bear.sprite;
			MonoBehaviour.print(this.bear.sprite);
			SVGAsset svgasset = (SVGAsset)Resources.Load("masks/" + this.bear.bearer.ToString());
			if (svgasset != null)
			{
				this.cloth.vectorGraphics = svgasset;
			}
			if (this.bear.hasEyes)
			{
				this.eyesIm.vectorGraphics = this.bear.eyes;
			}
			else
			{
				this.eyesIm.enabled = false;
			}
			this.epos = this.eyes.anchoredPosition;
			this.blinkIm.rectTransform.anchoredPosition = new Vector2(0f, (float)this.bear.eyesPos);
			this.blinkIm.vectorGraphics = this.blink;
		}
		this.hasEyes = this.bear.hasEyes;
		this.curEye = this.eyesIm.vectorGraphics;
		base._Awake();
		this.blueim = (SVGAsset)Resources.Load("bearers/" + this.bear.bearer.ToString() + "-blue");
		this.mute = false;
		this.voForceVO = false;
		Bearers bearer = newbear.bearer;
		if (bearer <= Bearers.dungeon)
		{
			if (bearer <= Bearers.three_eyed_raven)
			{
				if (bearer - Bearers.throne <= 1)
				{
					goto IL_205;
				}
				if (bearer != Bearers.three_eyed_raven)
				{
					return;
				}
			}
			else if (bearer != Bearers.wolf)
			{
				if (bearer != Bearers.scorpion && bearer != Bearers.dungeon)
				{
					return;
				}
				goto IL_205;
			}
		}
		else if (bearer <= Bearers.walker)
		{
			if (bearer == Bearers.crowd)
			{
				goto IL_205;
			}
			if (bearer - Bearers.raven > 1 && bearer != Bearers.walker)
			{
				return;
			}
		}
		else if (bearer != Bearers.cat)
		{
			if (bearer - Bearers.rhaegal > 2 && bearer != Bearers.wall)
			{
				return;
			}
			goto IL_205;
		}
		this.voForceVO = true;
		return;
		IL_205:
		this.mute = true;
	}

	// Token: 0x06000176 RID: 374 RVA: 0x0000A311 File Offset: 0x00008511
	private IEnumerator DelayUnlock(float delay)
	{
		yield return new WaitForSeconds(delay);
		base.transform.SetAsLastSibling();
		this.DefaultImage();
		this.lockedGraphic.vectorGraphics = this.blueim;
		this.lockedCard.SetActive(true);
		this.lockedCard.GetComponent<Animator>().Play("glass_break");
		JukeBox.diff.PlaySound(SFXTypes.ui_character_reveal, false, false, 2.5f, -1, 1.5f, 1f);
		if (this.hasEyes)
		{
			this.eyes.gameObject.SetActive(true);
			base.StartCoroutine("MoveEyes");
			this.NormalEyes();
		}
		this.ActivateButton(false);
		string text = this.curCard.question.Get();
		if (text.Contains("€") || text.Contains("$"))
		{
			text = text.Split(new char[]
			{
				'€',
				'$'
			})[0] + "...";
		}
		else
		{
			text = this.bear.generated.Get();
		}
		yield return new WaitForSeconds(0.6f);
		yield break;
	}

	// Token: 0x06000177 RID: 375 RVA: 0x0000A327 File Offset: 0x00008527
	public void UnlockBlue()
	{
		base.StopCoroutine("DelayUnlock");
		base.StartCoroutine("DelayUnlock", 0);
	}

	// Token: 0x06000178 RID: 376 RVA: 0x0000A348 File Offset: 0x00008548
	public void UpdateChoiceCard(Card card, bool isHidden, bool showSubtitle, DataDisplay display, bool first = false)
	{
		if (card == null || this.fond == null)
		{
			return;
		}
		this.curCard = card;
		if (display != DataDisplay.fullamount)
		{
			this.CustomImage("blue", "bearers");
			base.InitCard("", "", "", 0, true);
			this.eyes.gameObject.SetActive(false);
			if (display == DataDisplay.moving)
			{
				base.StartCoroutine("DelayUnlock", 0.5f);
			}
			return;
		}
		this.isHiddenChoice = isHidden;
		string text = card.question.Get();
		if (text.Contains("€") || text.Contains("$"))
		{
			text = text.Split(new char[]
			{
				'€',
				'$'
			})[0] + "...";
		}
		else
		{
			text = this.bear.generated.Get();
		}
		this.ActivateButton(first);
		if (isHidden)
		{
			base.InitCard("", "", "", 0, false);
			this.fond.enabled = true;
		}
		else
		{
			if (showSubtitle)
			{
				this.choiceText.enabled = true;
				this.choiceText.text = text;
			}
			base.InitCard("", "", "", 0, true);
		}
		if (this.hasEyes)
		{
			this.eyes.gameObject.SetActive(true);
			base.StartCoroutine("MoveEyes");
			this.NormalEyes();
		}
		else
		{
			this.eyes.gameObject.SetActive(false);
		}
		if (card.bearerVariation != "")
		{
			this.CustomImage(card.bearerVariation, "bearers");
			return;
		}
		this.DefaultImage();
	}

	// Token: 0x06000179 RID: 377 RVA: 0x0000A4F7 File Offset: 0x000086F7
	public void ActivateButton(bool first)
	{
		base.StopCoroutine("DoActivateButton");
		base.StartCoroutine("DoActivateButton", first);
	}

	// Token: 0x0600017A RID: 378 RVA: 0x0000A516 File Offset: 0x00008716
	private IEnumerator DoActivateButton(bool first)
	{
		while (GameAct.diff.state != GameStates.interaction)
		{
			yield return 0;
		}
		this.choiceBut.SetActive(true);
		if (!first)
		{
			yield break;
		}
		if (InputAct.diff && !InputAct.diff.NavigationMode())
		{
			yield break;
		}
		InputAct.diff.SetSelect(this.choiceBut);
		this.choiceBut.GetComponent<AutoSelectMe>().enabled = true;
		yield break;
	}

	// Token: 0x0600017B RID: 379 RVA: 0x0000A52C File Offset: 0x0000872C
	private void DeactivateButton()
	{
		base.StopCoroutine("DoActivateButton");
		this.choiceBut.SetActive(false);
		this.choiceBut.GetComponent<AutoSelectMe>().enabled = false;
	}

	// Token: 0x0600017C RID: 380 RVA: 0x0000A556 File Offset: 0x00008756
	public void AddButToNav(bool ison)
	{
		if (!ison)
		{
			this.wasSelected = this.isSelected;
		}
		this.selectable.enabled = ison;
		if (ison && this.wasSelected)
		{
			this.ActivateButton(true);
		}
	}

	// Token: 0x0600017D RID: 381 RVA: 0x0000A588 File Offset: 0x00008788
	public void UpdateWinterChoiceCard(Card card, int id, DataDisplay display, bool winterdone, bool first)
	{
		this.curCard = card;
		this.eyes.gameObject.SetActive(false);
		if (display == DataDisplay.hidden)
		{
			this.DefaultImage();
			base.InitCard("", "", "", 0, true);
			this.DeactivateButton();
			base.StartCoroutine("DelayUnlockWinter", id);
			if (winterdone)
			{
				this.isWinterDone = true;
				this.ActivateButton(first);
				MonoBehaviour.print("winter done, first" + first.ToString());
			}
			return;
		}
		this.DefaultImage();
		base.InitCard("", "", "", 0, true);
		this.ActivateButton(first);
	}

	// Token: 0x0600017E RID: 382 RVA: 0x0000A635 File Offset: 0x00008835
	private IEnumerator DelayUnlockWinter(int id)
	{
		yield return new WaitForSeconds(0.5f);
		this.sprite.vectorGraphics = (SVGAsset)Resources.Load("bearers/weirwood/weirwood_" + (id + 1), typeof(SVGAsset));
		this.lockedGraphic.vectorGraphics = this.defaultImage;
		this.lockedCard.SetActive(true);
		JukeBox.diff.PlaySound(SFXTypes.ui_character_reveal, false, false, 2.5f, -1, 1.5f, 1f);
		this.lockedCard.GetComponent<Animator>().Play("glass_break");
		yield break;
	}

	// Token: 0x0600017F RID: 383 RVA: 0x0000A64C File Offset: 0x0000884C
	public void UpdateCharacCard(Card card, int decision, bool withanim = true)
	{
		string question = card.question.Get();
		string text = (!card.override_yes.isEmpty) ? GameAct.diff.TreatText(card.override_yes, false) : SpeechAct.diff.GetSceneText("yes");
		string text2 = (!card.override_no.isEmpty) ? GameAct.diff.TreatText(card.override_no, false) : SpeechAct.diff.GetSceneText("no");
		if (!this.yesnodeactivate && (text == "..." || text2 == "..."))
		{
			this.fondyesno.gameObject.SetActive(false);
			this.fondyesno2.gameObject.SetActive(false);
			this.yesnodeactivate = true;
		}
		else if (this.yesnodeactivate && text != "..." && text2 != "...")
		{
			this.fondyesno.gameObject.SetActive(true);
			this.fondyesno2.gameObject.SetActive(true);
			this.yesnodeactivate = false;
		}
		if (this.OnInit != null)
		{
			this.OnInit();
		}
		this.destroyEffect = -10;
		Outcome outcome = card.yes_outcomes.Find((Outcome it) => it.variable == Variables.destroy && (it.bearer == Bearers.anyone || it.bearer == card.bearer));
		Outcome outcome2 = card.no_outcomes.Find((Outcome it) => it.variable == Variables.destroy && (it.bearer == Bearers.anyone || it.bearer == card.bearer));
		if (outcome != null && outcome2 != null)
		{
			this.destroyEffect = 2;
			this.PrepareDeath();
		}
		else if (outcome != null)
		{
			this.destroyEffect = 1;
			this.PrepareDeath();
		}
		else if (outcome2 != null)
		{
			this.destroyEffect = -1;
			this.PrepareDeath();
		}
		else if (this.hasEyes)
		{
			this.eyes.gameObject.SetActive(true);
			base.StartCoroutine("MoveEyes");
			this.NormalEyes();
		}
		else
		{
			this.eyes.gameObject.SetActive(false);
		}
		base.InitCard(text, text2, "", decision, withanim);
		this.Speak(question);
		if (!withanim)
		{
			return;
		}
		this.DefaultImage();
		if (card.bearerVariation != "")
		{
			this.CustomImage(card.bearerVariation, "bearers");
		}
	}

	// Token: 0x06000180 RID: 384 RVA: 0x0000A8A2 File Offset: 0x00008AA2
	public void AddPin()
	{
		this.handpin.SetActive(true);
	}

	// Token: 0x06000181 RID: 385 RVA: 0x0000A8B0 File Offset: 0x00008AB0
	public void RemovePin()
	{
		this.handpin.SetActive(false);
	}

	// Token: 0x06000182 RID: 386 RVA: 0x0000A8C0 File Offset: 0x00008AC0
	private void Speak(string question)
	{
		if (this.mute)
		{
			return;
		}
		if (!this.voForceVO && question.Length > 3 && question.Substring(0, 3) == "<i>" && question.Substring(question.Length - 4, 4) == "</i>")
		{
			return;
		}
		Bearers type = (this.bear.bearer == Bearers.jailor) ? Bearers.jon : ((this.bear.bearer == Bearers.wight) ? Bearers.walker : this.bear.bearer);
		JukeBox.diff.Speak(question, type, this.voPitch * 0.01f, this.voCenterFrequ, this.voFrequGain, this.voVolume);
	}

	// Token: 0x06000183 RID: 387 RVA: 0x0000A973 File Offset: 0x00008B73
	public override void UpdateCard(string yesText, string noText, string question = "")
	{
		if (!string.IsNullOrEmpty(question))
		{
			this.Speak(question);
		}
		base.UpdateCard(yesText, noText, question);
	}

	// Token: 0x06000184 RID: 388 RVA: 0x0000A990 File Offset: 0x00008B90
	public override void CustomImage(string source, string folder = "bearers")
	{
		if (this.hasEyes && (!this.keepEyes || source.Contains("noeyes")))
		{
			this.StopEyes();
			this.eyes.gameObject.SetActive(false);
		}
		if (source == "helmet")
		{
			this.cloth.enabled = true;
		}
		else
		{
			base.CustomImage(source, folder);
		}
		this.MeliFire();
	}

	// Token: 0x06000185 RID: 389 RVA: 0x0000A9FC File Offset: 0x00008BFC
	public override void DefaultImage()
	{
		if (this.hasCustomImage)
		{
			this.cloth.enabled = false;
		}
		if (this.hasEyes && this.hasCustomImage && !this.keepEyes)
		{
			this.eyes.gameObject.SetActive(true);
			base.StartCoroutine("MoveEyes");
		}
		base.DefaultImage();
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0000AA58 File Offset: 0x00008C58
	public void HellEyes()
	{
		if (!this.hasEyes)
		{
			return;
		}
		this.hasEvil = true;
	}

	// Token: 0x06000187 RID: 391 RVA: 0x0000AA6A File Offset: 0x00008C6A
	public void NormalEyes()
	{
		if (!this.hasEyes || !this.hasEvil)
		{
			return;
		}
		this.hasEvil = false;
	}

	// Token: 0x06000188 RID: 392 RVA: 0x0000AA84 File Offset: 0x00008C84
	private void StopEyes()
	{
		base.StopCoroutine("MoveEyes");
		base.StopCoroutine("Blink");
		this.eyesIm.vectorGraphics = this.curEye;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0000AAB0 File Offset: 0x00008CB0
	public override void HideCard()
	{
		this.StopEyes();
		if (this.OnChoice != null)
		{
			this.OnChoice(this.sprite.vectorGraphics.name);
		}
		if (this.OnDecisionMade != null)
		{
			this.OnDecisionMade(this.decision);
		}
		this.SpecialDecision(this.decision);
		this.DisableDeath();
		base.HideCard();
	}

	// Token: 0x0600018A RID: 394 RVA: 0x0000AB17 File Offset: 0x00008D17
	public override void HideFond()
	{
		if (this.OnHideFond != null)
		{
			this.OnHideFond();
		}
		base.HideFond();
	}

	// Token: 0x0600018B RID: 395 RVA: 0x0000AB34 File Offset: 0x00008D34
	public override void ShowDecision(int dec)
	{
		if (!this.destroy2Sides && (this.destroyEffect == dec || this.destroyEffect == 2))
		{
			if (this.hasEyes)
			{
				base.StopCoroutine("MoveEyes");
				this.blinkIm.vectorGraphics = (this.blinkIm2.vectorGraphics = this.death);
				this.blinkIm.enabled = (this.blinkIm2.enabled = true);
				this.eyesIm.enabled = (this.eyesIm2.enabled = false);
			}
			this.SwitchDeath(true);
		}
		else if (this.destroy2Sides && dec != 0 && this.destroyEffect != 2 && dec != this.destroyEffect)
		{
			if (this.hasEyes)
			{
				this.eyesIm.vectorGraphics = (this.eyes2.vectorGraphics = this.curEye);
				this.blinkIm.vectorGraphics = (this.blinkIm2.vectorGraphics = this.blink);
				this.blinkIm.enabled = (this.blinkIm2.enabled = false);
				this.eyesIm.enabled = (this.eyesIm2.enabled = true);
			}
			this.SwitchDeath(false);
		}
		base.ShowDecision(dec);
		if (dec != 0)
		{
			this.MeliFire();
		}
	}

	// Token: 0x0600018C RID: 396 RVA: 0x0000AC8C File Offset: 0x00008E8C
	private void MeliFire()
	{
		if (this.bear.bearer == Bearers.melisandre)
		{
			if (this.hasCustomImage)
			{
				int num = Util.RandInt(0, 5);
				num = (this.meliId = ((this.meliId == num) ? ((num == 4) ? 0 : (num + 1)) : num));
				if (!this.cloth.enabled)
				{
					this.cloth.enabled = true;
				}
				this.cloth.vectorGraphics = (SVGAsset)Resources.Load("masks/melisandre" + num, typeof(SVGAsset));
				return;
			}
			if (this.cloth.enabled)
			{
				this.cloth.enabled = false;
			}
		}
	}

	// Token: 0x0600018D RID: 397 RVA: 0x0000AD3D File Offset: 0x00008F3D
	private IEnumerator MoveEyes()
	{
		base.StartCoroutine("Blink");
		float t = 0f;
		this.eyes.gameObject.SetActive(true);
		this.eyesIm.enabled = true;
		this.blinkIm.enabled = false;
		this.eyes.anchoredPosition = Vector2.zero + this.epos;
		yield return new WaitForSeconds(0.4f);
		this.eyes.anchoredPosition = Vector2.zero + this.epos;
		for (;;)
		{
			t = 0f;
			float trust = Mathf.Sign(this.bear.vote);
			Vector2 fpos = FaceAct.diff.GetFacePos(trust) * 40f;
			Vector2 wpos = this.mytrans.transform.position;
			while (t < 1f)
			{
				Vector2 b = new Vector2(Mathf.Clamp(fpos.x - wpos.x * 0.25f + this.epos.x, -6f, 6f), Mathf.Clamp(fpos.y - (wpos.y + 10f) * 0.25f + this.epos.y, -6f, 6f));
				this.eyes.anchoredPosition = Vector2.Lerp(this.eyes.anchoredPosition, b, t);
				yield return 0;
				t += Time.deltaTime * 3f;
				yield return 0;
			}
			yield return new WaitForSeconds(Util.Rand(0.5f, 1f));
			fpos = default(Vector2);
			wpos = default(Vector2);
		}
		yield break;
	}

	// Token: 0x0600018E RID: 398 RVA: 0x0000AD4C File Offset: 0x00008F4C
	private IEnumerator Blink()
	{
		while (!this.hasEvil)
		{
			float num = (float)((this.bear.vote < 0f) ? 2 : 12);
			yield return new WaitForSeconds(num + Util.Rand(0.4f, 0.9f));
			this.eyesIm.enabled = false;
			this.blinkIm.enabled = true;
			yield return new WaitForSeconds(Util.Rand(0.3f, 0.5f));
			this.eyesIm.enabled = true;
			this.blinkIm.enabled = false;
		}
		yield break;
	}

	// Token: 0x0600018F RID: 399 RVA: 0x0000AD5C File Offset: 0x00008F5C
	public void SetGenerated(BearerGen model)
	{
		int generated = CardReader.diff.GetGenerated();
		this.body.enabled = (this.hair.enabled = (this.cloth.enabled = true));
		this.body.vectorGraphics = model.bodies[(generated + 123) % model.bodies.Count];
		this.hair.vectorGraphics = model.hairs[(generated + 91) % model.hairs.Count];
		this.cloth.vectorGraphics = model.clothes[(generated + 17) % model.clothes.Count];
		this.sprite.vectorGraphics = model.backs[(generated + 53) % model.backs.Count];
		this.eyesIm.vectorGraphics = model.eyes[(generated + 81) % model.eyes.Count];
	}

	// Token: 0x06000190 RID: 400 RVA: 0x0000AE5C File Offset: 0x0000905C
	public void PrepareDeath()
	{
		this.sprite2.vectorGraphics = this.sprite.vectorGraphics;
		if (this.body.enabled)
		{
			this.body2.enabled = (this.hair2.enabled = true);
			this.body2.vectorGraphics = this.body.vectorGraphics;
			this.hair2.vectorGraphics = this.hair.vectorGraphics;
		}
		if (this.cloth.enabled)
		{
			this.cloth2.enabled = true;
			this.cloth2.vectorGraphics = this.cloth.vectorGraphics;
		}
		this.sprite2.vectorGraphics = this.sprite.vectorGraphics;
	}

	// Token: 0x06000191 RID: 401 RVA: 0x0000AF18 File Offset: 0x00009118
	private void SwitchDeath(bool showdeath)
	{
		if (showdeath)
		{
			this.mytrans.anchoredPosition = new Vector2(-70f, 90f);
			this.mytrans.sizeDelta = new Vector2(140f, 380f);
			this.sprite.rectTransform.anchoredPosition = new Vector2(70f, 0f);
			this.destroy2Sides = true;
			this.mytrans2.anchoredPosition = new Vector2(70f, 90f);
			this.mytrans2.rotation = Quaternion.identity;
			this.mytrans2.gameObject.SetActive(true);
			return;
		}
		this.mytrans.anchoredPosition = new Vector2(0f, 90f);
		this.mytrans.sizeDelta = new Vector2(280f, 380f);
		this.sprite.rectTransform.anchoredPosition = new Vector2(0f, 0f);
		this.destroy2Sides = false;
		this.mytrans2.gameObject.SetActive(false);
	}

	// Token: 0x06000192 RID: 402 RVA: 0x0000B02C File Offset: 0x0000922C
	private void DisableDeath()
	{
		this.body2.enabled = (this.hair2.enabled = (this.cloth2.enabled = false));
		this.mytrans2.gameObject.SetActive(false);
		this.destroy2Sides = false;
	}

	// Token: 0x06000193 RID: 403 RVA: 0x0000B079 File Offset: 0x00009279
	public void SelectChoice()
	{
		this.isSelecting = true;
		this.isSelected = true;
		base.StopCoroutine("LargeCard");
		base.StopCoroutine("NormalCard");
		base.StartCoroutine("LargeCard");
	}

	// Token: 0x06000194 RID: 404 RVA: 0x0000B0AB File Offset: 0x000092AB
	public void UnSelectChoice()
	{
		this.isSelecting = false;
		this.isSelected = false;
		base.StopCoroutine("LargeCard");
		base.StopCoroutine("NormalCard");
		base.StartCoroutine("NormalCard");
	}

	// Token: 0x06000195 RID: 405 RVA: 0x0000B0DD File Offset: 0x000092DD
	private IEnumerator LargeCard()
	{
		RectTransform trans = this.mytrans;
		Vector2 osize = trans.localScale;
		Vector2 tsize = new Vector2(1.1f, 1.1f);
		float t = 0f;
		while (t < 1f)
		{
			trans.localScale = Vector2.LerpUnclamped(osize, tsize, Easing.BackEaseIn(t, 0f, 1f, 1f));
			if (this.isSelecting && t > 0.6f)
			{
				this.isSelecting = false;
			}
			t += Time.deltaTime * 3f;
			yield return 0;
		}
		trans.localScale = tsize;
		yield break;
	}

	// Token: 0x06000196 RID: 406 RVA: 0x0000B0EC File Offset: 0x000092EC
	private IEnumerator NormalCard()
	{
		RectTransform trans = this.mytrans;
		Vector2 osize = trans.localScale;
		Vector2 tsize = new Vector2(1f, 1f);
		float t = 0f;
		while (t < 1f)
		{
			trans.localScale = Vector2.Lerp(osize, tsize, t);
			t += Time.deltaTime * 5f;
			yield return 0;
		}
		trans.localScale = tsize;
		yield break;
	}

	// Token: 0x06000197 RID: 407 RVA: 0x0000B0FB File Offset: 0x000092FB
	public override void Unset()
	{
		base.Unset();
	}

	// Token: 0x06000198 RID: 408 RVA: 0x0000B103 File Offset: 0x00009303
	public void ValidChoice()
	{
		if (InputAct.diff.isInMenu)
		{
			return;
		}
		if (this.isSelecting)
		{
			base.StopCoroutine("YieldValid");
			base.StartCoroutine("YieldValid");
			return;
		}
		this.DoValid();
	}

	// Token: 0x06000199 RID: 409 RVA: 0x0000B138 File Offset: 0x00009338
	private IEnumerator YieldValid()
	{
		while (this.isSelecting)
		{
			yield return 0;
		}
		this.DoValid();
		yield break;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x0000B148 File Offset: 0x00009348
	private void DoValid()
	{
		if (this.isWinterDone)
		{
			GameAct.diff.ValidSelectionDirect("_endofends");
			return;
		}
		GameAct.diff.ValidSelection(this, this.bear, this.curCard);
		this.UpdateCharacCard(this.curCard, 0, this.isHiddenChoice);
		this.DisableChoice(false);
		base.StopCoroutine("LargeCard");
		base.StopCoroutine("NormalCard");
		base.StartCoroutine("NormalCard");
	}

	// Token: 0x0600019B RID: 411 RVA: 0x0000B1C0 File Offset: 0x000093C0
	public void DisableChoice(bool andremove = true)
	{
		if (this.choiceBut == null)
		{
			return;
		}
		this.DeactivateButton();
		this.choiceText.enabled = false;
		this.isHiddenChoice = false;
		if (andremove && !GameAct.diff.bearers.Contains(this.bear))
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x040001AB RID: 427
	[Range(10f, 300f)]
	public float voPitch = 100f;

	// Token: 0x040001AC RID: 428
	[Range(20f, 20000f)]
	public float voCenterFrequ = 2900f;

	// Token: 0x040001AD RID: 429
	[Range(0f, 3f)]
	public float voFrequGain = 1.5f;

	// Token: 0x040001AE RID: 430
	[Range(0f, 1f)]
	public float voVolume = 1f;

	// Token: 0x040001AF RID: 431
	private bool voForceVO;

	// Token: 0x040001B0 RID: 432
	private bool mute;

	// Token: 0x040001B1 RID: 433
	public SVGImage blinkIm;

	// Token: 0x040001B2 RID: 434
	public bool hasEyes;

	// Token: 0x040001B3 RID: 435
	public bool keepEyes;

	// Token: 0x040001B4 RID: 436
	public SVGAsset blink;

	// Token: 0x040001B5 RID: 437
	public SVGImage blinkIm2;

	// Token: 0x040001B6 RID: 438
	public SVGAsset death;

	// Token: 0x040001B7 RID: 439
	public RectTransform eyes;

	// Token: 0x040001B8 RID: 440
	private Bearer bear;

	// Token: 0x040001B9 RID: 441
	public float eyesUpMove = 0.5f;

	// Token: 0x040001BA RID: 442
	public float eyesLatMove = 0.5f;

	// Token: 0x040001BB RID: 443
	public Action OnInit;

	// Token: 0x040001BC RID: 444
	public Action OnHideFond;

	// Token: 0x040001BD RID: 445
	public Action<string> OnChoice;

	// Token: 0x040001BE RID: 446
	public Action<int> OnDecisionMade;

	// Token: 0x040001BF RID: 447
	public SVGImage body;

	// Token: 0x040001C0 RID: 448
	public SVGImage hair;

	// Token: 0x040001C1 RID: 449
	public SVGImage cloth;

	// Token: 0x040001C2 RID: 450
	public SVGImage sprite2;

	// Token: 0x040001C3 RID: 451
	public SVGImage body2;

	// Token: 0x040001C4 RID: 452
	public SVGImage hair2;

	// Token: 0x040001C5 RID: 453
	public SVGImage cloth2;

	// Token: 0x040001C6 RID: 454
	public SVGImage eyes2;

	// Token: 0x040001C7 RID: 455
	public GameObject handpin;

	// Token: 0x040001C8 RID: 456
	private int destroyEffect = -10;

	// Token: 0x040001C9 RID: 457
	private Card curCard;

	// Token: 0x040001CA RID: 458
	public GameObject lockedCard;

	// Token: 0x040001CB RID: 459
	public SVGImage lockedGraphic;

	// Token: 0x040001CC RID: 460
	private SVGAsset blueim;

	// Token: 0x040001CD RID: 461
	public Text choiceText;

	// Token: 0x040001CE RID: 462
	public GameObject choiceBut;

	// Token: 0x040001CF RID: 463
	private bool isHiddenChoice;

	// Token: 0x040001D0 RID: 464
	private int meliId;

	// Token: 0x040001D1 RID: 465
	private bool isWinterDone;

	// Token: 0x040001D2 RID: 466
	private Selectable selectable;

	// Token: 0x040001D3 RID: 467
	private bool wasSelected;

	// Token: 0x040001D4 RID: 468
	private bool yesnodeactivate;

	// Token: 0x040001D5 RID: 469
	private bool hasEvil = true;

	// Token: 0x040001D6 RID: 470
	private Vector2 epos;

	// Token: 0x040001D7 RID: 471
	private SVGAsset curEye;

	// Token: 0x040001D8 RID: 472
	public SVGImage eyesIm;

	// Token: 0x040001D9 RID: 473
	public SVGImage eyesIm2;

	// Token: 0x040001DA RID: 474
	private bool isSelecting;

	// Token: 0x040001DB RID: 475
	private bool isSelected;
}
