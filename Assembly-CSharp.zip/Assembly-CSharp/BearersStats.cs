﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200001F RID: 31
public class BearersStats : MonoBehaviour
{
	// Token: 0x06000104 RID: 260 RVA: 0x00005F72 File Offset: 0x00004172
	private void OnDisable()
	{
		this.Dismantle();
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00005F7C File Offset: 0x0000417C
	private void Dismantle()
	{
		if (this.objs.Count > 0)
		{
			foreach (GameObject obj in this.objs)
			{
				Object.Destroy(obj);
			}
		}
		this.objs = new List<GameObject>();
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00005FE8 File Offset: 0x000041E8
	private void OnEnable()
	{
		this.Dismantle();
		this.seenB = GameAct.diff.metBearers;
		this.allB = GameAct.diff.GetRegularBearers();
		int num = 0;
		int num2 = 0;
		int num3 = -80;
		int num4 = -180;
		int num5 = 0;
		List<Achievement> achieves = CardReader.diff.GetComponent<KingdomAct>().GetAchieves(AchieveTypes.character);
		for (int i = 0; i < this.allB.Count; i++)
		{
			Bearer bearer = this.allB[i];
			GameObject gameObject = Object.Instantiate<GameObject>(this.portraitPrefab);
			this.objs.Add(gameObject);
			gameObject.transform.SetParent(base.transform, false);
			SVGImage component = gameObject.GetComponent<SVGImage>();
			num5 = num3 + num4 * num;
			component.rectTransform.anchoredPosition = new Vector2((float)(-66 + num2 * 136), (float)num5);
			if (this.seenB.Contains(bearer.bearer))
			{
				string bname = bearer.bearer.ToString();
				component.vectorGraphics = (SVGAsset)Resources.Load("bearers/" + bname, typeof(SVGAsset));
				if (bearer.hasEyes)
				{
					SVGImage component2 = component.transform.Find("eyes").GetComponent<SVGImage>();
					component2.vectorGraphics = (SVGAsset)Resources.Load("eyes/" + bname, typeof(SVGAsset));
					component2.enabled = true;
				}
				component.transform.Find("text").GetComponent<Text>().text = bearer.name;
				if (achieves.Find((Achievement it) => it.name == bname) != null)
				{
					component.transform.Find("star").GetComponent<SVGImage>().enabled = true;
				}
			}
			num2++;
			if (num2 > 1)
			{
				num++;
				num2 = 0;
			}
		}
		base.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, (float)(-(float)num5 - num4));
	}

	// Token: 0x040000E3 RID: 227
	public GameObject portraitPrefab;

	// Token: 0x040000E4 RID: 228
	private List<Bearers> seenB;

	// Token: 0x040000E5 RID: 229
	private List<Bearer> allB;

	// Token: 0x040000E6 RID: 230
	private List<GameObject> objs = new List<GameObject>();
}
