﻿using System;
using System.Text;
using Steamworks;
using UnityEngine;

// Token: 0x02000079 RID: 121
[DisallowMultipleComponent]
public class SteamManager : MonoBehaviour
{
	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000427 RID: 1063 RVA: 0x0001AC14 File Offset: 0x00018E14
	private static SteamManager Instance
	{
		get
		{
			if (SteamManager.s_instance == null)
			{
				return new GameObject("SteamManager").AddComponent<SteamManager>();
			}
			return SteamManager.s_instance;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000428 RID: 1064 RVA: 0x0001AC38 File Offset: 0x00018E38
	public static bool Initialized
	{
		get
		{
			return SteamManager.Instance.m_bInitialized;
		}
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x0001AC44 File Offset: 0x00018E44
	private static void SteamAPIDebugTextHook(int nSeverity, StringBuilder pchDebugText)
	{
		Debug.LogWarning(pchDebugText);
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x0001AC4C File Offset: 0x00018E4C
	private void Awake()
	{
		if (SteamManager.s_instance != null)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		SteamManager.s_instance = this;
		if (SteamManager.s_EverInialized)
		{
			throw new Exception("Tried to Initialize the SteamAPI twice in one session!");
		}
		Object.DontDestroyOnLoad(base.gameObject);
		if (!Packsize.Test())
		{
			Debug.LogError("[Steamworks.NET] Packsize Test returned false, the wrong version of Steamworks.NET is being run in this platform.", this);
		}
		if (!DllCheck.Test())
		{
			Debug.LogError("[Steamworks.NET] DllCheck Test returned false, One or more of the Steamworks binaries seems to be the wrong version.", this);
		}
		try
		{
			if (SteamAPI.RestartAppIfNecessary((AppId_t)897820U))
			{
				Application.Quit();
				return;
			}
		}
		catch (DllNotFoundException arg)
		{
			Debug.LogError("[Steamworks.NET] Could not load [lib]steam_api.dll/so/dylib. It's likely not in the correct location. Refer to the README for more details.\n" + arg, this);
			Application.Quit();
			return;
		}
		this.m_bInitialized = SteamAPI.Init();
		if (!this.m_bInitialized)
		{
			Debug.LogError("[Steamworks.NET] SteamAPI_Init() failed. Refer to Valve's documentation or the comment above this line for more information.", this);
			return;
		}
		SteamManager.s_EverInialized = true;
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x0001AD24 File Offset: 0x00018F24
	private void OnEnable()
	{
		if (SteamManager.s_instance == null)
		{
			SteamManager.s_instance = this;
		}
		if (!this.m_bInitialized)
		{
			return;
		}
		if (this.m_SteamAPIWarningMessageHook == null)
		{
			this.m_SteamAPIWarningMessageHook = new SteamAPIWarningMessageHook_t(SteamManager.SteamAPIDebugTextHook);
			SteamClient.SetWarningMessageHook(this.m_SteamAPIWarningMessageHook);
		}
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x0001AD72 File Offset: 0x00018F72
	private void OnDestroy()
	{
		if (SteamManager.s_instance != this)
		{
			return;
		}
		SteamManager.s_instance = null;
		if (!this.m_bInitialized)
		{
			return;
		}
		SteamAPI.Shutdown();
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x0001AD96 File Offset: 0x00018F96
	private void Update()
	{
		if (!this.m_bInitialized)
		{
			return;
		}
		SteamAPI.RunCallbacks();
	}

	// Token: 0x040004E7 RID: 1255
	private static SteamManager s_instance;

	// Token: 0x040004E8 RID: 1256
	private static bool s_EverInialized;

	// Token: 0x040004E9 RID: 1257
	private bool m_bInitialized;

	// Token: 0x040004EA RID: 1258
	private SteamAPIWarningMessageHook_t m_SteamAPIWarningMessageHook;
}
