﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000076 RID: 118
public class SpeechAct : MonoBehaviour
{
	// Token: 0x06000409 RID: 1033 RVA: 0x00019EAC File Offset: 0x000180AC
	private void Awake()
	{
		this.CheckLang();
		if (this.lang == "jp" || this.lang == "sc" || this.lang == "tc")
		{
			this.asiaLayout = true;
		}
		SpeechAct.diff = this;
		this.OtherTexts = this.TreatTexts();
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x00019F10 File Offset: 0x00018110
	public void CheckLang()
	{
		if (SuperPrefs.HasKey("language"))
		{
			this.lang = SuperPrefs.GetString("language");
			return;
		}
		SystemLanguage systemLanguage = Application.systemLanguage;
		if (systemLanguage <= SystemLanguage.Korean)
		{
			if (systemLanguage <= SystemLanguage.English)
			{
				if (systemLanguage != SystemLanguage.Chinese)
				{
					if (systemLanguage != SystemLanguage.English)
					{
						goto IL_11F;
					}
					this.lang = "en";
					goto IL_12A;
				}
			}
			else
			{
				if (systemLanguage == SystemLanguage.French)
				{
					this.lang = "fr";
					goto IL_12A;
				}
				if (systemLanguage == SystemLanguage.German)
				{
					this.lang = "de";
					goto IL_12A;
				}
				switch (systemLanguage)
				{
				case SystemLanguage.Italian:
					this.lang = "it";
					goto IL_12A;
				case SystemLanguage.Japanese:
					this.lang = "jp";
					goto IL_12A;
				case SystemLanguage.Korean:
					this.lang = "ko";
					goto IL_12A;
				default:
					goto IL_11F;
				}
			}
		}
		else if (systemLanguage <= SystemLanguage.Russian)
		{
			if (systemLanguage == SystemLanguage.Portuguese)
			{
				this.lang = "bp";
				goto IL_12A;
			}
			if (systemLanguage != SystemLanguage.Russian)
			{
				goto IL_11F;
			}
			this.lang = "ru";
			goto IL_12A;
		}
		else
		{
			if (systemLanguage == SystemLanguage.Spanish)
			{
				this.lang = "es";
				goto IL_12A;
			}
			if (systemLanguage != SystemLanguage.ChineseSimplified)
			{
				if (systemLanguage != SystemLanguage.ChineseTraditional)
				{
					goto IL_11F;
				}
				this.lang = "tc";
				goto IL_12A;
			}
		}
		this.lang = "sc";
		goto IL_12A;
		IL_11F:
		this.lang = "en";
		IL_12A:
		SuperPrefs.SetString("language", this.lang);
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0001A058 File Offset: 0x00018258
	public void SetLang(string nlang)
	{
		this.lang = nlang;
		SuperPrefs.SetString("language", nlang);
		this.asiaLayout = (this.lang == "jp" || this.lang == "sc" || this.lang == "tc");
		this.OtherTexts = this.TreatTexts();
		PlayerPrefs.SetString("version", "changeloc");
		SceneManager.LoadScene("disclaimer");
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x0001A0DC File Offset: 0x000182DC
	private string[] GetFile(string file)
	{
		TextAsset textAsset = (TextAsset)Resources.Load("texts/" + this.lang + "/" + file, typeof(TextAsset));
		if (textAsset == null)
		{
			return new string[0];
		}
		return textAsset.text.Split(new char[]
		{
			'\n'
		});
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x0001A13C File Offset: 0x0001833C
	private string[] GetFile()
	{
		TextAsset textAsset = (TextAsset)Resources.Load("texts/" + this.lang, typeof(TextAsset));
		if (textAsset == null)
		{
			return new string[0];
		}
		return textAsset.text.Split(new char[]
		{
			'\n'
		});
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x0001A194 File Offset: 0x00018394
	public string[] GetLangIds()
	{
		return this.langs;
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0001A19C File Offset: 0x0001839C
	public string[] GetLangDisp()
	{
		return this.langsDisplay;
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x0001A1A4 File Offset: 0x000183A4
	public string GetName(Bearers bearer)
	{
		List<GText> list = this.OtherTexts[bearer.ToString()];
		string text = list[0].Get();
		if (text.Contains("<...>"))
		{
			int index = Util.RandInt(1, list.Count);
			text = text.Replace("<...>", list[index].Get());
		}
		return this.GenericName(text);
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x0001A218 File Offset: 0x00018418
	public string GenericName(string nam)
	{
		nam = this.FindAndReplace(nam, "west_first_male");
		nam = this.FindAndReplace(nam, "west_first_female");
		nam = this.FindAndReplace(nam, "essos_first_male");
		nam = this.FindAndReplace(nam, "essos_first_female");
		nam = this.FindAndReplace(nam, "essos_last");
		nam = this.FindAndReplace(nam, "west_last");
		nam = this.FindAndReplace(nam, "doth_first_male");
		nam = this.FindAndReplace(nam, "little_bird");
		nam = this.FindAndReplace(nam, "unsullied");
		return nam;
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x0001A2A4 File Offset: 0x000184A4
	private string FindAndReplace(string txt, string key)
	{
		if (!this.OtherTexts.ContainsKey(key))
		{
			return txt;
		}
		if (!this.nameCache.ContainsKey(key))
		{
			this.nameCache.Add(key, new List<GText>(this.OtherTexts[key]));
		}
		if (this.nameCache[key].Count == 0)
		{
			this.nameCache[key] = new List<GText>(this.OtherTexts[key]);
		}
		GText gtext = this.nameCache[key][Util.RandInt(0, this.nameCache[key].Count)];
		this.lastnam = gtext.Get();
		this.nameCache[key].Remove(gtext);
		return txt.Replace("<" + key + ">", this.lastnam);
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x0001A380 File Offset: 0x00018580
	private string RandName(string key)
	{
		return this.OtherTexts[key][Util.RandInt(0, this.OtherTexts[key].Count)].Get();
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x0001A3B0 File Offset: 0x000185B0
	public string GetKingName(string lastwas)
	{
		List<GText> list = new List<GText>(this.OtherTexts["queen_names"]);
		return list[Util.RandInt(0, list.Count)].Get();
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x0001A3EA File Offset: 0x000185EA
	public string JapanNum(string tid, int nb)
	{
		return this.GetSceneText(tid, 0) + nb.ToString() + this.GetSceneText(tid, 1);
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x0001A408 File Offset: 0x00018608
	private int SpanishNum(int nb)
	{
		string text = nb.ToString();
		string a = text.Substring(text.Length - 1, 1);
		if ((!(a == "1") && !(a == "3")) || nb == 11)
		{
			return 1;
		}
		return 0;
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x0001A450 File Offset: 0x00018650
	private int EnglishNum(int nb)
	{
		string text = nb.ToString();
		string a = text.Substring(text.Length - 1, 1);
		string a2 = (text.Length > 1) ? text.Substring(text.Length - 2, 2) : "00";
		if (a == "1" && a2 != "11")
		{
			return 0;
		}
		if (a == "2" && a2 != "12")
		{
			return 1;
		}
		if (!(a == "3") || !(a2 != "13"))
		{
			return 3;
		}
		return 2;
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x0001A4EC File Offset: 0x000186EC
	private int RussianNum(int nb)
	{
		string text = nb.ToString();
		string a = text.Substring(text.Length - 1, 1);
		string a2 = (text.Length > 1) ? text.Substring(text.Length - 2, 2) : "00";
		if (a == "1" && a2 != "11")
		{
			return 0;
		}
		if (a == "2" && a2 != "12")
		{
			return 1;
		}
		if (a == "3" && a2 != "13")
		{
			return 1;
		}
		if (!(a == "4") || !(a2 != "14"))
		{
			return 2;
		}
		return 1;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x0001A5A4 File Offset: 0x000187A4
	public string GetEnumeral(int nb)
	{
		string text = nb.ToString();
		string a = this.lang;
		if (a == "jp" || a == "sc" || a == "tc")
		{
			return this.GetSceneText("num", 0) + text + this.GetSceneText("num", 1);
		}
		if (!(a == "fr"))
		{
			if (a == "en")
			{
				return text + this.GetSceneText("num", this.EnglishNum(nb));
			}
			if (!(a == "es"))
			{
				return text + this.GetSceneText("num", 0);
			}
			return text + this.GetSceneText("num", this.SpanishNum(nb));
		}
		else
		{
			if (nb != 1)
			{
				return text + this.GetSceneText("num", 1);
			}
			return text + this.GetSceneText("num", 0);
		}
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x0001A6A0 File Offset: 0x000188A0
	private Dictionary<string, List<GText>> TreatTexts()
	{
		Dictionary<string, List<GText>> dictionary = new Dictionary<string, List<GText>>();
		string[] array = Util.GetTextFile("texts/all_i18n").Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(new char[]
		{
			';'
		});
		int num = 1;
		int num2 = num;
		for (int i = 0; i < array2.Length; i++)
		{
			if (array2[i].Contains(this.lang))
			{
				num2 = i;
			}
		}
		string text = "";
		List<GText> list = new List<GText>();
		for (int j = 1; j < array.Length; j++)
		{
			string[] array3 = array[j].Split(new char[]
			{
				';'
			});
			if (!string.IsNullOrEmpty(array3[0]))
			{
				if (text != "")
				{
					dictionary.Add(text, list);
				}
				text = array3[0];
				list = new List<GText>();
			}
			int num3 = num2;
			if (array3[num2].Length == 0 && this.lang != "en")
			{
				num3 = num;
			}
			string[] array4 = array3[num3].Split(new char[]
			{
				'|'
			});
			if (array4.Length > 1)
			{
				foreach (string input in array4)
				{
					list.Add(new GText(input));
				}
			}
			else
			{
				list.Add(new GText(array3[num3]));
			}
		}
		return dictionary;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x0001A800 File Offset: 0x00018A00
	public string GetSceneNum(string name, int num)
	{
		if (!this.OtherTexts.ContainsKey(name))
		{
			return "";
		}
		int index = 0;
		if (this.lang == "ru" && this.OtherTexts[name].Count == 3)
		{
			index = this.RussianNum(num);
		}
		else if (num != 1 && this.OtherTexts[name].Count == 2)
		{
			index = 1;
		}
		return this.OtherTexts[name][index].Get();
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x0001A884 File Offset: 0x00018A84
	public string GetSceneText(string name)
	{
		return this.GetSceneText(name, 0);
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x0001A890 File Offset: 0x00018A90
	public string GetSceneText(string name, int id)
	{
		if (!this.OtherTexts.ContainsKey(name))
		{
			return "";
		}
		if (this.asiaLayout)
		{
			return this.OtherTexts[name][id].Get().Replace("+", "\n");
		}
		return this.OtherTexts[name][id].Get();
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x0001A8F8 File Offset: 0x00018AF8
	public Dictionary<string, List<string>> GetNonPersonalElements(string phase, string prefixe = "item_")
	{
		Dictionary<string, List<string>> dictionary = this.PhasesTextes[phase];
		Dictionary<string, List<string>> dictionary2 = new Dictionary<string, List<string>>();
		foreach (KeyValuePair<string, List<string>> keyValuePair in dictionary)
		{
			if (keyValuePair.Key.Length > prefixe.Length && keyValuePair.Key.Substring(0, prefixe.Length) == prefixe && !keyValuePair.Value.Contains(">personal"))
			{
				dictionary2.Add(keyValuePair.Key.Substring(prefixe.Length, keyValuePair.Key.Length - prefixe.Length), keyValuePair.Value);
			}
		}
		return dictionary2;
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x0001A9C8 File Offset: 0x00018BC8
	public Dictionary<string, List<string>> GetElements(string phase, string prefixe = "item_")
	{
		Dictionary<string, List<string>> dictionary = this.PhasesTextes[phase];
		Dictionary<string, List<string>> dictionary2 = new Dictionary<string, List<string>>();
		foreach (KeyValuePair<string, List<string>> keyValuePair in dictionary)
		{
			if (keyValuePair.Key.Length > prefixe.Length && keyValuePair.Key.Substring(0, prefixe.Length) == prefixe)
			{
				dictionary2.Add(keyValuePair.Key.Substring(prefixe.Length, keyValuePair.Key.Length - prefixe.Length), keyValuePair.Value);
			}
		}
		return dictionary2;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x0001AA84 File Offset: 0x00018C84
	public List<string> GetElementsById(string phase, string item, string prefixe = "item_")
	{
		Dictionary<string, List<string>> dictionary = this.PhasesTextes[phase];
		if (!dictionary.ContainsKey(prefixe + item))
		{
			return new List<string>();
		}
		return dictionary[prefixe + item];
	}

	// Token: 0x040004DB RID: 1243
	public string lang = "en";

	// Token: 0x040004DC RID: 1244
	private string[] langs = new string[]
	{
		"en",
		"sc",
		"tc",
		"ko",
		"jp",
		"it",
		"fr",
		"es",
		"de",
		"ru",
		"bp"
	};

	// Token: 0x040004DD RID: 1245
	[HideInInspector]
	private string[] langsDisplay = new string[]
	{
		"English",
		"简体中文",
		"繁体中文",
		"한국어",
		"日本語",
		"Italiano",
		"Français",
		"Español",
		"Deutsch",
		"РУССКИЙ",
		"Português"
	};

	// Token: 0x040004DE RID: 1246
	public static SpeechAct diff;

	// Token: 0x040004DF RID: 1247
	public Dictionary<string, Dictionary<string, List<string>>> PhasesTextes = new Dictionary<string, Dictionary<string, List<string>>>();

	// Token: 0x040004E0 RID: 1248
	public Dictionary<string, List<string>> UITexts = new Dictionary<string, List<string>>();

	// Token: 0x040004E1 RID: 1249
	public Dictionary<string, List<GText>> OtherTexts = new Dictionary<string, List<GText>>();

	// Token: 0x040004E2 RID: 1250
	public bool asiaLayout;

	// Token: 0x040004E3 RID: 1251
	public bool isMonarkMale = true;

	// Token: 0x040004E4 RID: 1252
	public bool isSelfMale = true;

	// Token: 0x040004E5 RID: 1253
	private string lastnam;

	// Token: 0x040004E6 RID: 1254
	private Dictionary<string, List<GText>> nameCache = new Dictionary<string, List<GText>>();
}
