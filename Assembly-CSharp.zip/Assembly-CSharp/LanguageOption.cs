﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000066 RID: 102
public class LanguageOption : MonoBehaviour
{
	// Token: 0x060003AD RID: 941 RVA: 0x00017968 File Offset: 0x00015B68
	private void OnEnable()
	{
		this.dropLang.ClearOptions();
		List<string> options = new List<string>(SpeechAct.diff.GetLangDisp());
		this.dropLang.AddOptions(options);
		this.ids = SpeechAct.diff.GetLangIds();
		for (int i = 0; i < this.ids.Length; i++)
		{
			if (this.ids[i] == SpeechAct.diff.lang)
			{
				this.langid = i;
				this.dropLang.value = i;
			}
		}
	}

	// Token: 0x060003AE RID: 942 RVA: 0x000179EC File Offset: 0x00015BEC
	public void ChangeLang()
	{
		if (this.dropLang.value == this.langid)
		{
			this.applyBut.SetActive(false);
		}
		else
		{
			this.applyBut.SetActive(true);
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x060003AF RID: 943 RVA: 0x00017A44 File Offset: 0x00015C44
	public void ApplyLang()
	{
		if (this.dropLang.value != this.langid)
		{
			SpeechAct.diff.SetLang(this.ids[this.dropLang.value]);
		}
		this.applyBut.SetActive(false);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0400048E RID: 1166
	public GameObject applyBut;

	// Token: 0x0400048F RID: 1167
	public Dropdown dropLang;

	// Token: 0x04000490 RID: 1168
	private int langid = -1;

	// Token: 0x04000491 RID: 1169
	private string[] ids;
}
