﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000036 RID: 54
public class IntercaleCard : CardAct
{
	// Token: 0x060001A9 RID: 425 RVA: 0x0000B280 File Offset: 0x00009480
	private void Awake()
	{
		base._Awake();
	}

	// Token: 0x060001AA RID: 426 RVA: 0x0000B418 File Offset: 0x00009618
	private void Start()
	{
		if (SpeechAct.diff.asiaLayout)
		{
			this.intercaleTxt.fontSize = 13;
			this.intercaleTxt.horizontalOverflow = HorizontalWrapMode.Overflow;
			return;
		}
		this.intercaleTxt.fontSize = 15;
		this.intercaleTxt.horizontalOverflow = HorizontalWrapMode.Wrap;
	}

	// Token: 0x060001AB RID: 427 RVA: 0x0000B464 File Offset: 0x00009664
	public override void InitCard(string yesText, string noText, string otherText, int decision, bool withanim = true)
	{
		this.intercaleTxt.text = otherText;
		base.InitCard(yesText, noText, otherText, decision, true);
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0000B47E File Offset: 0x0000967E
	public override void HideCard()
	{
		base.HideCard();
	}

	// Token: 0x060001AD RID: 429 RVA: 0x0000B3BA File Offset: 0x000095BA
	public override void HideFond()
	{
		base.HideFond();
	}

	// Token: 0x060001AE RID: 430 RVA: 0x00003D07 File Offset: 0x00001F07
	public override void ShowDecision(int dec)
	{
	}

	// Token: 0x040001E2 RID: 482
	public Text intercaleTxt;
}
