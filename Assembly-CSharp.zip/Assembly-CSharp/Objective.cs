﻿using System;
using System.Collections.Generic;

// Token: 0x0200006B RID: 107
[Serializable]
public class Objective
{
	// Token: 0x060003C1 RID: 961 RVA: 0x00017F23 File Offset: 0x00016123
	public Objective()
	{
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x00017F38 File Offset: 0x00016138
	public Objective(string[] rawele, string[] columns, List<Objective> objects, int nid, Dictionary<string, string[]> i18n, bool nostatechange = false)
	{
		string[] array = new string[3];
		bool flag = false;
		this.id = nid;
		for (int i = 0; i < columns.Length; i++)
		{
			string val = rawele[i];
			string text = columns[i];
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
			if (num <= 2162217143U)
			{
				if (num != 879704937U)
				{
					if (num != 1896662429U)
					{
						if (num == 2162217143U)
						{
							if (text == "conditions")
							{
								this.conditions = Condition.TreatCondition(val);
							}
						}
					}
					else if (text == "blocked_until_revealed")
					{
						this.accessible = !(val == "x");
					}
				}
				else if (text == "description")
				{
					this.description = (flag ? array[1] : val);
				}
			}
			else if (num <= 2556802313U)
			{
				if (num != 2369371622U)
				{
					if (num == 2556802313U)
					{
						if (text == "title")
						{
							this.title = (flag ? new GText(array[0]) : new GText(val));
						}
					}
				}
				else if (text == "name")
				{
					this.name = val;
					if (i18n.Count > 0 && i18n.ContainsKey(val))
					{
						array = i18n[val];
						flag = true;
					}
				}
			}
			else if (num != 3103933528U)
			{
				if (num == 3939368189U)
				{
					if (text == "parent")
					{
						this.pid = ((val == "") ? (this.pid = this.id - 1) : (this.pid = objects.Find((Objective it) => it.name == val).id));
					}
				}
			}
			else if (text == "achievement")
			{
				this.achievement = (flag ? array[2] : val);
			}
		}
		if (this.id != 1)
		{
			if (nostatechange)
			{
				return;
			}
			if (!this.accessible)
			{
				foreach (Condition condition in this.conditions)
				{
					if (((condition.value > 0 && condition.bearer == Bearers.none) || (condition.value == 0 && condition.bearer != Bearers.none)) && condition.condition == Conditions.equal)
					{
						GameAct.diff.LockCards(condition, true);
					}
					if ((condition.value == -1 && condition.bearer == Bearers.none && condition.condition == Conditions.equal) || (condition.value == 0 && condition.bearer != Bearers.none && condition.condition == Conditions.notequal))
					{
						GameAct.diff.LockCardsOutcome(condition, true);
					}
				}
			}
		}
	}

	// Token: 0x0400049D RID: 1181
	public string name;

	// Token: 0x0400049E RID: 1182
	public int id;

	// Token: 0x0400049F RID: 1183
	public int pid;

	// Token: 0x040004A0 RID: 1184
	public GText title;

	// Token: 0x040004A1 RID: 1185
	public string description;

	// Token: 0x040004A2 RID: 1186
	public string achievement;

	// Token: 0x040004A3 RID: 1187
	public bool accessible;

	// Token: 0x040004A4 RID: 1188
	public bool fulfilled;

	// Token: 0x040004A5 RID: 1189
	public bool visible;

	// Token: 0x040004A6 RID: 1190
	public List<Condition> conditions = new List<Condition>();
}
