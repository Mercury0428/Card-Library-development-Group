﻿using System;
using UnityEngine;

// Token: 0x020000A2 RID: 162
public class UniRateEventHandler : MonoBehaviour
{
	// Token: 0x060004F3 RID: 1267 RVA: 0x0001E15C File Offset: 0x0001C35C
	private void Awake()
	{
		UniRate.Instance.ShouldUniRatePromptForRating += this.ShouldUniRatePromptForRating;
		UniRate.Instance.ShouldUniRateOpenRatePage += this.ShouldUniRateOpenRatePage;
		UniRate.Instance.OnPromptedForRating += this.OnPromptedForRating;
		UniRate.Instance.OnDetectAppUpdated += this.OnDetectAppUpdated;
		UniRate.Instance.OnUniRateFaild += this.OnUniRateFaild;
		UniRate.Instance.OnUserAttemptToRate += this.OnUserAttemptToRate;
		UniRate.Instance.OnUserDeclinedToRate += this.OnUserDeclinedToRate;
		UniRate.Instance.OnUserWantReminderToRate += this.OnUserWantReminderToRate;
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0000E36F File Offset: 0x0000C56F
	private bool ShouldUniRatePromptForRating()
	{
		return true;
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x0000E36F File Offset: 0x0000C56F
	private bool ShouldUniRateOpenRatePage()
	{
		return true;
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x00003D07 File Offset: 0x00001F07
	private void OnPromptedForRating()
	{
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x0001E219 File Offset: 0x0001C419
	private void OnDetectAppUpdated()
	{
		Debug.Log("A new version is installed. Current version: " + UniRate.Instance.applicationVersion);
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x0001E234 File Offset: 0x0001C434
	private void OnUniRateFaild(UniRate.Error error)
	{
		Debug.Log(error);
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x0001E241 File Offset: 0x0001C441
	private void OnUserAttemptToRate()
	{
		Debug.Log("Yeh, great, user want to rate us!");
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x0001E24D File Offset: 0x0001C44D
	private void OnUserDeclinedToRate()
	{
		Debug.Log("User declined the rate prompt.");
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x0001E259 File Offset: 0x0001C459
	private void OnUserWantReminderToRate()
	{
		Debug.Log("User wants to be reminded later.");
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0001E268 File Offset: 0x0001C468
	private void OnDestroy()
	{
		UniRate.Instance.ShouldUniRatePromptForRating -= this.ShouldUniRatePromptForRating;
		UniRate.Instance.ShouldUniRateOpenRatePage -= this.ShouldUniRateOpenRatePage;
		UniRate.Instance.OnPromptedForRating -= this.OnPromptedForRating;
		UniRate.Instance.OnDetectAppUpdated -= this.OnDetectAppUpdated;
		UniRate.Instance.OnUniRateFaild -= this.OnUniRateFaild;
		UniRate.Instance.OnUserAttemptToRate -= this.OnUserAttemptToRate;
		UniRate.Instance.OnUserDeclinedToRate -= this.OnUserDeclinedToRate;
		UniRate.Instance.OnUserWantReminderToRate -= this.OnUserWantReminderToRate;
	}
}
