﻿using System;
using UnityEngine.Events;

// Token: 0x02000082 RID: 130
[Serializable]
public class AnimationAction
{
	// Token: 0x0600045A RID: 1114 RVA: 0x0001B926 File Offset: 0x00019B26
	public void InvokeAnimationAction()
	{
		this.actionEvent.Invoke();
	}

	// Token: 0x04000503 RID: 1283
	public string name;

	// Token: 0x04000504 RID: 1284
	public AnimationAction.ActionEvent actionEvent = new AnimationAction.ActionEvent();

	// Token: 0x0200031E RID: 798
	[Serializable]
	public class ActionEvent : UnityEvent
	{
	}
}
