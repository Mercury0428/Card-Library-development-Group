﻿using System;
using UnityEngine;

// Token: 0x02000095 RID: 149
[Serializable]
public class SVGPath
{
	// Token: 0x060004B2 RID: 1202 RVA: 0x00002050 File Offset: 0x00000250
	public SVGPath()
	{
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x0001D019 File Offset: 0x0001B219
	public SVGPath(Vector2[] points)
	{
		this.points = points;
		this.RecalculateBounds();
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x0001D02E File Offset: 0x0001B22E
	public SVGPath(Vector2[] points, Rect bounds)
	{
		this.points = points;
		this.bounds = bounds;
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060004B5 RID: 1205 RVA: 0x0001D044 File Offset: 0x0001B244
	public int pointCount
	{
		get
		{
			if (this.points == null)
			{
				return 0;
			}
			return this.points.Length;
		}
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x0001D058 File Offset: 0x0001B258
	public void RecalculateBounds()
	{
		if (this.points == null || this.points.Length == 0)
		{
			this.bounds = default(Rect);
			return;
		}
		float num = float.MaxValue;
		float num2 = float.MinValue;
		float num3 = float.MaxValue;
		float num4 = float.MinValue;
		int num5 = this.points.Length;
		for (int i = 0; i < num5; i++)
		{
			if (this.points[i].x < num)
			{
				num = this.points[i].x;
			}
			if (this.points[i].x > num2)
			{
				num2 = this.points[i].x;
			}
			if (this.points[i].y < num3)
			{
				num3 = this.points[i].x;
			}
			if (this.points[i].y > num4)
			{
				num4 = this.points[i].x;
			}
		}
		this.bounds = new Rect(num, num4, num2 - num, num4 - num3);
	}

	// Token: 0x0400056A RID: 1386
	public Vector2[] points;

	// Token: 0x0400056B RID: 1387
	public Rect bounds;
}
