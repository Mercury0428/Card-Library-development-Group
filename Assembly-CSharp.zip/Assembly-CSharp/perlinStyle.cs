﻿using System;

// Token: 0x0200007E RID: 126
public enum perlinStyle
{
	// Token: 0x040004F5 RID: 1269
	ridges,
	// Token: 0x040004F6 RID: 1270
	low,
	// Token: 0x040004F7 RID: 1271
	lazy,
	// Token: 0x040004F8 RID: 1272
	tormented,
	// Token: 0x040004F9 RID: 1273
	moving
}
