﻿using System;
using System.Collections.Generic;

// Token: 0x0200002A RID: 42
[Serializable]
public class Condition
{
	// Token: 0x0600012E RID: 302 RVA: 0x00006790 File Offset: 0x00004990
	public Condition()
	{
	}

	// Token: 0x0600012F RID: 303 RVA: 0x000067BC File Offset: 0x000049BC
	public Condition(Variables nvar, string cname, Conditions ncond, int nval)
	{
		this.variable = nvar;
		this.value = nval;
		this.custom_name = cname;
		this.condition = ncond;
	}

	// Token: 0x06000130 RID: 304 RVA: 0x00006810 File Offset: 0x00004A10
	public Condition(Variables nvar, Bearers bea, Bearers isalso, Bearers isnot)
	{
		this.variable = nvar;
		this.bearer = bea;
		this.bearerIsAlso = isalso;
		this.bearerIsNot = isnot;
		this.condition = Conditions.equal;
	}

	// Token: 0x06000131 RID: 305 RVA: 0x00006868 File Offset: 0x00004A68
	public Condition(string condition_string, bool or)
	{
		this.orlimit = or;
		this.bearer = this.ExtractBearer("!has_", condition_string);
		if (this.bearer != Bearers.none)
		{
			this.variable = Variables.set;
			this.condition = Conditions.notequal;
			return;
		}
		this.bearer = this.ExtractBearer("has_", condition_string);
		if (this.bearer != Bearers.none)
		{
			this.variable = Variables.set;
			this.condition = Conditions.equal;
			return;
		}
		this.bearer = this.ExtractBearer("!seen_", condition_string);
		if (this.bearer != Bearers.none)
		{
			this.variable = Variables.seen;
			this.condition = Conditions.notequal;
			return;
		}
		this.bearer = this.ExtractBearer("seen_", condition_string);
		if (this.bearer != Bearers.none)
		{
			this.variable = Variables.seen;
			this.condition = Conditions.equal;
			return;
		}
		this.bearer = this.ExtractBearer("", condition_string);
		if (this.bearer != Bearers.none)
		{
			this.variable = Variables.set;
			this.condition = Conditions.round;
			return;
		}
		int num = 0;
		if (condition_string.StartsWith(">"))
		{
			this.condition = Conditions.equal;
			this.variable = Variables.chain;
			string text = condition_string.Substring(1);
			if (text.Length > 0)
			{
				int.TryParse(text, out this.value);
				if (this.value == 0)
				{
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), text);
					return;
				}
			}
			else
			{
				this.value = CardReader.diff.previousid;
			}
			return;
		}
		if (condition_string.StartsWith("<"))
		{
			this.condition = Conditions.notequal;
			this.value = 1;
			this.variable = Variables.chain;
			string text2 = condition_string.Substring(1);
			if (text2.Length > 0)
			{
				try
				{
					int.TryParse(text2, out this.value);
					if (this.value == 0)
					{
						this.bearer = (Bearers)Enum.Parse(typeof(Bearers), text2);
					}
					return;
				}
				catch
				{
					int.TryParse(text2, out this.value);
					return;
				}
			}
			this.value = CardReader.diff.previousid;
			return;
		}
		if (condition_string.StartsWith("seen_"))
		{
			this.variable = Variables.seen;
			this.condition = Conditions.equal;
			int.TryParse(condition_string.Substring(5), out this.value);
			return;
		}
		if (condition_string.StartsWith("!seen_"))
		{
			this.variable = Variables.seen;
			this.condition = Conditions.notequal;
			int.TryParse(condition_string.Substring(6), out this.value);
			return;
		}
		string[] array;
		if (condition_string.Contains("<"))
		{
			this.condition = Conditions.below;
			array = condition_string.Split(new char[]
			{
				'<'
			});
			num = -1;
		}
		else if (condition_string.Contains(">"))
		{
			this.condition = Conditions.above;
			array = condition_string.Split(new char[]
			{
				'>'
			});
			num = 1;
		}
		else if (condition_string.Contains("%"))
		{
			this.condition = Conditions.round;
			array = condition_string.Split(new char[]
			{
				'%'
			});
		}
		else if (condition_string.Contains("="))
		{
			this.condition = Conditions.equal;
			array = condition_string.Split(new char[]
			{
				'='
			});
		}
		else if (condition_string.StartsWith("!"))
		{
			this.condition = Conditions.equal;
			if (condition_string.StartsWith("!nb_") || condition_string.StartsWith("!inc_"))
			{
				array = new string[]
				{
					condition_string.Substring(1),
					"0"
				};
			}
			else
			{
				array = new string[]
				{
					condition_string.Substring(1),
					"-1"
				};
			}
		}
		else if (condition_string.StartsWith("nb_") || condition_string.StartsWith("inc_"))
		{
			this.condition = Conditions.above;
			array = new string[]
			{
				condition_string,
				"0"
			};
			num = 1;
		}
		else
		{
			this.condition = Conditions.equal;
			array = new string[]
			{
				condition_string,
				"1"
			};
		}
		if (array.Length == 2)
		{
			int.TryParse(array[1], out this.value);
		}
		this.value += num;
		this.bearer = this.ExtractBearer("no_", array[0]);
		if (this.bearer != Bearers.none)
		{
			this.value = -this.value;
			this.condition = ((this.condition == Conditions.above) ? Conditions.below : ((this.condition == Conditions.below) ? Conditions.above : this.condition));
			return;
		}
		this.bearer = this.ExtractBearer("yes_", array[0]);
		if (this.bearer != Bearers.none)
		{
			return;
		}
		try
		{
			this.variable = (Variables)Enum.Parse(typeof(Variables), array[0]);
		}
		catch
		{
			if (array[0].Contains("_"))
			{
				string[] array2 = array[0].Split(new char[]
				{
					'_'
				});
				try
				{
					this.variable = (Variables)Enum.Parse(typeof(Variables), array2[0]);
					goto IL_4DF;
				}
				catch
				{
					this.variable = Variables.custom;
					goto IL_4DF;
				}
			}
			this.variable = Variables.custom;
			IL_4DF:
			this.custom_name = array[0];
			if (GameAct.diff)
			{
				GameAct.diff.AddCustomVariable(this.custom_name);
			}
		}
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00006DA4 File Offset: 0x00004FA4
	public static List<Condition> TreatCondition(string val)
	{
		List<Condition> list = new List<Condition>();
		bool or = false;
		string[] array = val.Split(new string[]
		{
			" or "
		}, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length > 1)
		{
			or = true;
		}
		string[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			foreach (string condition_string in array2[i].Split(new string[]
			{
				" and "
			}, StringSplitOptions.RemoveEmptyEntries))
			{
				list.Add(new Condition(condition_string, or));
				or = false;
			}
			or = true;
		}
		return list;
	}

	// Token: 0x06000133 RID: 307 RVA: 0x00006E2C File Offset: 0x0000502C
	private Bearers ExtractBearer(string suffixe, string texte)
	{
		if (!texte.StartsWith(suffixe) && !string.IsNullOrEmpty(suffixe))
		{
			return Bearers.none;
		}
		string text = texte.Substring(suffixe.Length);
		string text2 = "";
		string text3 = "";
		if (text.Contains("&"))
		{
			string[] array = text.Split(new string[]
			{
				"&"
			}, StringSplitOptions.None);
			text = array[0];
			text2 = array[1];
		}
		if (text.Contains("!"))
		{
			string[] array2 = text.Split(new string[]
			{
				"!"
			}, StringSplitOptions.None);
			text = array2[0];
			text3 = array2[1];
		}
		Bearers result;
		try
		{
			if (!string.IsNullOrEmpty(text2))
			{
				this.bearerIsAlso = (Bearers)Enum.Parse(typeof(Bearers), text2);
			}
			if (!string.IsNullOrEmpty(text3))
			{
				this.bearerIsNot = (Bearers)Enum.Parse(typeof(Bearers), text3);
			}
			int num = 0;
			int.TryParse(text, out num);
			if (num != 0)
			{
				result = Bearers.none;
			}
			else
			{
				result = (Bearers)Enum.Parse(typeof(Bearers), text);
			}
		}
		catch
		{
			result = Bearers.none;
		}
		return result;
	}

	// Token: 0x04000131 RID: 305
	public Variables variable;

	// Token: 0x04000132 RID: 306
	public string custom_name;

	// Token: 0x04000133 RID: 307
	public Conditions condition;

	// Token: 0x04000134 RID: 308
	public int value;

	// Token: 0x04000135 RID: 309
	public Bearers bearer = Bearers.none;

	// Token: 0x04000136 RID: 310
	public Bearers bearerIsAlso = Bearers.none;

	// Token: 0x04000137 RID: 311
	public Bearers bearerIsNot = Bearers.none;

	// Token: 0x04000138 RID: 312
	public bool orlimit;
}
