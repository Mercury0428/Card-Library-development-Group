﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000069 RID: 105
public class MetersAct : MonoBehaviour
{
	// Token: 0x060003B7 RID: 951 RVA: 0x00017B7C File Offset: 0x00015D7C
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnRefresh = (Action<Card>)Delegate.Remove(diff.OnRefresh, new Action<Card>(this.UpdateMeters));
		GameAct diff2 = GameAct.diff;
		diff2.OnRefresh = (Action<Card>)Delegate.Combine(diff2.OnRefresh, new Action<Card>(this.UpdateMeters));
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x00017BD8 File Offset: 0x00015DD8
	private void Awake()
	{
		foreach (DataAnim dataAnim in this.meters)
		{
			this.variable2meters.Add(dataAnim.variable, dataAnim);
		}
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x00017C38 File Offset: 0x00015E38
	private void UpdateMeters(Card card)
	{
		foreach (DataAnim dataAnim in this.meters)
		{
			if (!dataAnim.isShown && card.name != null && card.name.Contains("show_" + dataAnim.variable.ToString()))
			{
				dataAnim.ShowDataCol(true);
			}
		}
	}

	// Token: 0x060003BA RID: 954 RVA: 0x00017CC4 File Offset: 0x00015EC4
	public void CheckDanger()
	{
		foreach (DataAnim dataAnim in this.meters)
		{
			dataAnim.UpdateDanger();
		}
	}

	// Token: 0x060003BB RID: 955 RVA: 0x00017D14 File Offset: 0x00015F14
	public void ShowAllData(bool yes)
	{
		foreach (DataAnim dataAnim in this.meters)
		{
			dataAnim.ShowDataCol(yes);
		}
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00003D07 File Offset: 0x00001F07
	public void SetDefault()
	{
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00017D68 File Offset: 0x00015F68
	public void ShowOutcome(List<Outcome> outcome, Bearer be, bool andresolve = false)
	{
		List<Outcome> list = new List<Outcome>(outcome);
		float num = (float)Mathf.Clamp(GameAct.diff.GetInt(Variables.age) + 10, 0, 100);
		int num2 = 0;
		if (be != null)
		{
			num2 = ((be.vote < 0f) ? 1 : 0);
		}
		int strength = num2 + 3 + Mathf.RoundToInt(num * 0.04f);
		using (List<DataAnim>.Enumerator enumerator = this.meters.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				DataAnim me = enumerator.Current;
				Outcome outcome2 = list.Find((Outcome it) => it.variable == me.variable);
				int value = (this.OnShowOutcome != null) ? this.OnShowOutcome(outcome2) : outcome2.value;
				if (outcome2 != null)
				{
					me.SetAdd(value, outcome2.display, strength);
				}
				else
				{
					me.SetAdd(0, DataDisplay.none, 0);
				}
				if (andresolve)
				{
					GameAct.diff.SetInt(me.variable, me.ResolveAddition());
				}
			}
		}
	}

	// Token: 0x060003BE RID: 958 RVA: 0x00017E98 File Offset: 0x00016098
	public void ResolveAddition()
	{
		foreach (DataAnim dataAnim in this.meters)
		{
			GameAct.diff.SetInt(dataAnim.variable, dataAnim.ResolveAddition());
		}
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00017EFC File Offset: 0x000160FC
	public void SendEffect(Variables va, Effect effect)
	{
		this.variable2meters[va].OpenEffect(effect);
	}

	// Token: 0x04000494 RID: 1172
	public List<DataAnim> meters;

	// Token: 0x04000495 RID: 1173
	private Dictionary<Variables, DataAnim> variable2meters = new Dictionary<Variables, DataAnim>();

	// Token: 0x04000496 RID: 1174
	public Func<Outcome, int> OnShowOutcome;
}
