﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000024 RID: 36
public class ModalAct : MonoBehaviour
{
	// Token: 0x06000114 RID: 276 RVA: 0x00006348 File Offset: 0x00004548
	public void Init(ModalTypes typ, object instance, float delay = 0f, string txtid = "", bool decal = true)
	{
		this.skipdelay = delay;
		this.box = base.GetComponent<RectTransform>();
		if (this.obj != null)
		{
			Object.Destroy(this.obj);
			this.obj = null;
		}
		switch (typ)
		{
		case ModalTypes.objective:
			this.obj = Object.Instantiate<GameObject>(this.objectivePrefab);
			break;
		case ModalTypes.death:
			this.obj = Object.Instantiate<GameObject>(this.deathPrefab);
			break;
		case ModalTypes.achievement:
			this.obj = Object.Instantiate<GameObject>(this.achievementPrefab);
			break;
		case ModalTypes.highscore:
			this.obj = Object.Instantiate<GameObject>(this.highscorePrefab);
			break;
		case ModalTypes.custom:
			this.obj = Object.Instantiate<GameObject>((GameObject)instance);
			break;
		}
		this.obj.transform.SetParent(this.contentBox, false);
		this.gra = this.obj.GetComponent<Graphic>();
		if (this.gra != null)
		{
			this.oricol = this.gra.color;
			this.gra.color = Color.Lerp(this.oricol, Color.white, 0.2f);
		}
		this.content = this.obj.GetComponent<RectTransform>();
		this.content.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(10000f, this.content.sizeDelta.y + 20f);
		this.scbo = this.content.GetComponent<ContentBox>();
		if (this.scbo != null)
		{
			this.scbo.Init(instance, txtid, false, false);
		}
	}

	// Token: 0x06000115 RID: 277 RVA: 0x000064E1 File Offset: 0x000046E1
	public IEnumerator Fire()
	{
		ModalAct.diff = this;
		base.StartCoroutine("MoveContent");
		if (this.scbo != null)
		{
			this.scbo.Validate();
		}
		yield return base.StartCoroutine("MoveBox");
		yield break;
	}

	// Token: 0x06000116 RID: 278 RVA: 0x000064F0 File Offset: 0x000046F0
	private IEnumerator MoveContent()
	{
		Vector2 anchoredPosition = new Vector2(0f, 0f);
		this.content.anchoredPosition = anchoredPosition;
		yield break;
	}

	// Token: 0x06000117 RID: 279 RVA: 0x000064FF File Offset: 0x000046FF
	private IEnumerator YieldAndReadySkip()
	{
		if (InputAct.diff.curInput == Inputs.twitch)
		{
			this.isReadyToSkip = true;
			yield break;
		}
		InputAct.diff.SuspendSlideFocus();
		yield return new WaitForSeconds(1.2f);
		if (this.gra)
		{
			this.gra.CrossFadeColor(this.oricol, 0.2f, true, false);
		}
		if (AnimBut.diff)
		{
			AnimBut.diff.SwitchSize(true);
			AnimBut.diff.UnLock(ControlModes.next, false, true);
		}
		InputAct.diff.GetActionFocus(new Action(this.Close), false);
		this.isReadyToSkip = true;
		yield break;
	}

	// Token: 0x06000118 RID: 280 RVA: 0x0000650E File Offset: 0x0000470E
	private IEnumerator MoveBox()
	{
		float t = 0f;
		Vector2 opos = new Vector2(0f, 130f);
		Vector2 tpos = new Vector2(0f, 10f);
		JukeBox.diff.PlaySound(SFXTypes.ui_achievement_completed, false, false, 2.5f, -1, 1.5f, 1f);
		base.StartCoroutine("YieldAndReadySkip");
		while (t < 1f)
		{
			if (this.isSkipped)
			{
				yield break;
			}
			this.box.anchoredPosition = Vector2.LerpUnclamped(opos, tpos, Easing.CircEaseOut(t, 0f, 1f, 1f));
			t += Time.deltaTime;
			yield return null;
		}
		this.but.SetActive(true);
		while (this.skipdelay <= 0f || !this.isReadyToSkip)
		{
			if (this.isSkipped)
			{
				yield break;
			}
			yield return null;
		}
		t = this.skipdelay;
		while (t > 0f)
		{
			if (this.isSkipped)
			{
				yield break;
			}
			t -= Time.deltaTime;
			yield return null;
		}
		this.Close();
		yield break;
	}

	// Token: 0x06000119 RID: 281 RVA: 0x0000651D File Offset: 0x0000471D
	private IEnumerator CloseBox(Vector2 tpos)
	{
		this.but.SetActive(false);
		Vector2 opos = new Vector2(0f, -700f);
		float t = 0f;
		while (t < 1f)
		{
			this.box.anchoredPosition = Vector2.Lerp(tpos, opos, Easing.CircEaseIn(t, 0f, 1f, 1f));
			t += Time.deltaTime * 4f;
			yield return null;
		}
		if (this.scbo != null)
		{
			this.scbo.Close();
		}
		yield return null;
		Object.Destroy(base.gameObject);
		yield break;
	}

	// Token: 0x0600011A RID: 282 RVA: 0x00006534 File Offset: 0x00004734
	public void Close()
	{
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(false);
		}
		InputAct.diff.RestoreSlideFocus();
		this.skipdelay = 0.01f;
		this.isSkipped = true;
		if (this.box != null)
		{
			base.StopCoroutine("CloseBox");
			base.StartCoroutine("CloseBox", this.box.anchoredPosition);
		}
	}

	// Token: 0x0600011B RID: 283 RVA: 0x000065A9 File Offset: 0x000047A9
	public void ForceClose()
	{
		InputAct.diff.TapAction();
	}

	// Token: 0x040000FD RID: 253
	private RectTransform content;

	// Token: 0x040000FE RID: 254
	private RectTransform box;

	// Token: 0x040000FF RID: 255
	private bool isSkipped;

	// Token: 0x04000100 RID: 256
	public ContentBox scbo;

	// Token: 0x04000101 RID: 257
	public static ModalAct diff;

	// Token: 0x04000102 RID: 258
	public GameObject objectivePrefab;

	// Token: 0x04000103 RID: 259
	public GameObject deathPrefab;

	// Token: 0x04000104 RID: 260
	public GameObject achievementPrefab;

	// Token: 0x04000105 RID: 261
	public GameObject highscorePrefab;

	// Token: 0x04000106 RID: 262
	public Transform contentBox;

	// Token: 0x04000107 RID: 263
	public GameObject but;

	// Token: 0x04000108 RID: 264
	private float skipdelay;

	// Token: 0x04000109 RID: 265
	private GameObject obj;

	// Token: 0x0400010A RID: 266
	private Color oricol;

	// Token: 0x0400010B RID: 267
	private Graphic gra;

	// Token: 0x0400010C RID: 268
	private bool isReadyToSkip;
}
