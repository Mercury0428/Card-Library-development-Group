﻿using System;
using UnityEngine;

// Token: 0x02000041 RID: 65
public class Easing
{
	// Token: 0x06000207 RID: 519 RVA: 0x0000C9C9 File Offset: 0x0000ABC9
	public static float Linear(float t, float b, float c, float d)
	{
		return c * t / d + b;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x0000C9D2 File Offset: 0x0000ABD2
	public static float ExpoEaseOut(float t, float b, float c, float d)
	{
		if (t != d)
		{
			return c * (-Mathf.Pow(2f, -10f * t / d) + 1f) + b;
		}
		return b + c;
	}

	// Token: 0x06000209 RID: 521 RVA: 0x0000C9FA File Offset: 0x0000ABFA
	public static float ExpoEaseIn(float t, float b, float c, float d)
	{
		if (t != 0f)
		{
			return c * Mathf.Pow(2f, 10f * (t / d - 1f)) + b;
		}
		return b;
	}

	// Token: 0x0600020A RID: 522 RVA: 0x0000CA24 File Offset: 0x0000AC24
	public static float ExpoEaseInOut(float t, float b, float c, float d)
	{
		if (t == 0f)
		{
			return b;
		}
		if (t == d)
		{
			return b + c;
		}
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * Mathf.Pow(2f, 10f * (t - 1f)) + b;
		}
		return c / 2f * (-Mathf.Pow(2f, -10f * (t -= 1f)) + 2f) + b;
	}

	// Token: 0x0600020B RID: 523 RVA: 0x0000CAA4 File Offset: 0x0000ACA4
	public static float ExpoEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.ExpoEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.ExpoEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x0600020C RID: 524 RVA: 0x0000CAF0 File Offset: 0x0000ACF0
	public static float CircEaseOut(float t, float b, float c, float d)
	{
		return c * Mathf.Sqrt(1f - (t = t / d - 1f) * t) + b;
	}

	// Token: 0x0600020D RID: 525 RVA: 0x0000CB0F File Offset: 0x0000AD0F
	public static float CircEaseIn(float t, float b, float c, float d)
	{
		return -c * (Mathf.Sqrt(1f - (t /= d) * t) - 1f) + b;
	}

	// Token: 0x0600020E RID: 526 RVA: 0x0000CB30 File Offset: 0x0000AD30
	public static float CircEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return -c / 2f * (Mathf.Sqrt(1f - t * t) - 1f) + b;
		}
		return c / 2f * (Mathf.Sqrt(1f - (t -= 2f) * t) + 1f) + b;
	}

	// Token: 0x0600020F RID: 527 RVA: 0x0000CB98 File Offset: 0x0000AD98
	public static float CircEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.CircEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.CircEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0000CBE4 File Offset: 0x0000ADE4
	public static float QuadEaseOut(float t, float b, float c, float d)
	{
		return -c * (t /= d) * (t - 2f) + b;
	}

	// Token: 0x06000211 RID: 529 RVA: 0x0000CBF9 File Offset: 0x0000ADF9
	public static float QuadEaseIn(float t, float b, float c, float d)
	{
		return c * (t /= d) * t + b;
	}

	// Token: 0x06000212 RID: 530 RVA: 0x0000CC08 File Offset: 0x0000AE08
	public static float QuadEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * t * t + b;
		}
		return -c / 2f * ((t -= 1f) * (t - 2f) - 1f) + b;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x0000CC5C File Offset: 0x0000AE5C
	public static float QuadEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.QuadEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.QuadEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000214 RID: 532 RVA: 0x0000CCA8 File Offset: 0x0000AEA8
	public static float SineEaseOut(float t, float b, float c, float d)
	{
		return c * Mathf.Sin(t / d * 1.5707964f) + b;
	}

	// Token: 0x06000215 RID: 533 RVA: 0x0000CCBC File Offset: 0x0000AEBC
	public static float SineEaseIn(float t, float b, float c, float d)
	{
		return -c * Mathf.Cos(t / d * 1.5707964f) + c + b;
	}

	// Token: 0x06000216 RID: 534 RVA: 0x0000CCD4 File Offset: 0x0000AED4
	public static float SineEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * Mathf.Sin(3.1415927f * t / 2f) + b;
		}
		return -c / 2f * (Mathf.Cos(3.1415927f * (t -= 1f) / 2f) - 2f) + b;
	}

	// Token: 0x06000217 RID: 535 RVA: 0x0000CD40 File Offset: 0x0000AF40
	public static float SineEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.SineEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.SineEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000218 RID: 536 RVA: 0x0000CD8C File Offset: 0x0000AF8C
	public static float CubicEaseOut(float t, float b, float c, float d)
	{
		return c * ((t = t / d - 1f) * t * t + 1f) + b;
	}

	// Token: 0x06000219 RID: 537 RVA: 0x0000CDA8 File Offset: 0x0000AFA8
	public static float CubicEaseIn(float t, float b, float c, float d)
	{
		return c * (t /= d) * t * t + b;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x0000CDB8 File Offset: 0x0000AFB8
	public static float CubicEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * t * t * t + b;
		}
		return c / 2f * ((t -= 2f) * t * t + 2f) + b;
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0000CE08 File Offset: 0x0000B008
	public static float CubicEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.CubicEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.CubicEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x0000CE54 File Offset: 0x0000B054
	public static float QuartEaseOut(float t, float b, float c, float d)
	{
		return -c * ((t = t / d - 1f) * t * t * t - 1f) + b;
	}

	// Token: 0x0600021D RID: 541 RVA: 0x0000CE73 File Offset: 0x0000B073
	public static float QuartEaseIn(float t, float b, float c, float d)
	{
		return c * (t /= d) * t * t * t + b;
	}

	// Token: 0x0600021E RID: 542 RVA: 0x0000CE88 File Offset: 0x0000B088
	public static float QuartEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * t * t * t * t + b;
		}
		return -c / 2f * ((t -= 2f) * t * t * t - 2f) + b;
	}

	// Token: 0x0600021F RID: 543 RVA: 0x0000CEDC File Offset: 0x0000B0DC
	public static float QuartEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.QuartEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.QuartEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000220 RID: 544 RVA: 0x0000CF28 File Offset: 0x0000B128
	public static float QuintEaseOut(float t, float b, float c, float d)
	{
		return c * ((t = t / d - 1f) * t * t * t * t + 1f) + b;
	}

	// Token: 0x06000221 RID: 545 RVA: 0x0000CF48 File Offset: 0x0000B148
	public static float QuintEaseIn(float t, float b, float c, float d)
	{
		return c * (t /= d) * t * t * t * t + b;
	}

	// Token: 0x06000222 RID: 546 RVA: 0x0000CF5C File Offset: 0x0000B15C
	public static float QuintEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * t * t * t * t * t + b;
		}
		return c / 2f * ((t -= 2f) * t * t * t * t + 2f) + b;
	}

	// Token: 0x06000223 RID: 547 RVA: 0x0000CFB4 File Offset: 0x0000B1B4
	public static float QuintEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.QuintEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.QuintEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000224 RID: 548 RVA: 0x0000D000 File Offset: 0x0000B200
	public static float ElasticEaseOut(float t, float b, float c, float d)
	{
		if ((t /= d) == 1f)
		{
			return b + c;
		}
		float num = d * 0.3f;
		float num2 = num / 4f;
		return c * Mathf.Pow(2f, -10f * t) * Mathf.Sin((t * d - num2) * 6.2831855f / num) + c + b;
	}

	// Token: 0x06000225 RID: 549 RVA: 0x0000D058 File Offset: 0x0000B258
	public static float ElasticEaseIn(float t, float b, float c, float d)
	{
		if ((t /= d) == 1f)
		{
			return b + c;
		}
		float num = d * 0.3f;
		float num2 = num / 4f;
		return -(c * Mathf.Pow(2f, 10f * (t -= 1f)) * Mathf.Sin((t * d - num2) * 6.2831855f / num)) + b;
	}

	// Token: 0x06000226 RID: 550 RVA: 0x0000D0B8 File Offset: 0x0000B2B8
	public static float ElasticEaseInOut(float t, float b, float c, float d)
	{
		if ((t /= d / 2f) == 2f)
		{
			return b + c;
		}
		float num = d * 0.45000002f;
		float num2 = num / 4f;
		if (t < 1f)
		{
			return -0.5f * (c * Mathf.Pow(2f, 10f * (t -= 1f)) * Mathf.Sin((t * d - num2) * 6.2831855f / num)) + b;
		}
		return c * Mathf.Pow(2f, -10f * (t -= 1f)) * Mathf.Sin((t * d - num2) * 6.2831855f / num) * 0.5f + c + b;
	}

	// Token: 0x06000227 RID: 551 RVA: 0x0000D168 File Offset: 0x0000B368
	public static float ElasticEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.ElasticEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.ElasticEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x06000228 RID: 552 RVA: 0x0000D1B4 File Offset: 0x0000B3B4
	public static float BounceEaseOut(float t, float b, float c, float d)
	{
		if ((t /= d) < 0.36363637f)
		{
			return c * (7.5625f * t * t) + b;
		}
		if (t < 0.72727275f)
		{
			return c * (7.5625f * (t -= 0.54545456f) * t + 0.75f) + b;
		}
		if (t < 0.90909094f)
		{
			return c * (7.5625f * (t -= 0.8181818f) * t + 0.9375f) + b;
		}
		return c * (7.5625f * (t -= 0.95454544f) * t + 0.984375f) + b;
	}

	// Token: 0x06000229 RID: 553 RVA: 0x0000D242 File Offset: 0x0000B442
	public static float BounceEaseIn(float t, float b, float c, float d)
	{
		return c - Easing.BounceEaseOut(d - t, 0f, c, d) + b;
	}

	// Token: 0x0600022A RID: 554 RVA: 0x0000D258 File Offset: 0x0000B458
	public static float BounceEaseInOut(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.BounceEaseIn(t * 2f, 0f, c, d) * 0.5f + b;
		}
		return Easing.BounceEaseOut(t * 2f - d, 0f, c, d) * 0.5f + c * 0.5f + b;
	}

	// Token: 0x0600022B RID: 555 RVA: 0x0000D2B0 File Offset: 0x0000B4B0
	public static float BounceEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.BounceEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.BounceEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x0000D2FC File Offset: 0x0000B4FC
	public static float BackEaseOut(float t, float b, float c, float d)
	{
		return c * ((t = t / d - 1f) * t * (2.70158f * t + 1.70158f) + 1f) + b;
	}

	// Token: 0x0600022D RID: 557 RVA: 0x0000D324 File Offset: 0x0000B524
	public static float BackEaseIn(float t, float b, float c, float d)
	{
		return c * (t /= d) * t * (2.70158f * t - 1.70158f) + b;
	}

	// Token: 0x0600022E RID: 558 RVA: 0x0000D340 File Offset: 0x0000B540
	public static float BackEaseInOut(float t, float b, float c, float d)
	{
		float num = 1.70158f;
		if ((t /= d / 2f) < 1f)
		{
			return c / 2f * (t * t * (((num *= 1.525f) + 1f) * t - num)) + b;
		}
		return c / 2f * ((t -= 2f) * t * (((num *= 1.525f) + 1f) * t + num) + 2f) + b;
	}

	// Token: 0x0600022F RID: 559 RVA: 0x0000D3B8 File Offset: 0x0000B5B8
	public static float BackEaseOutIn(float t, float b, float c, float d)
	{
		if (t < d / 2f)
		{
			return Easing.BackEaseOut(t * 2f, b, c / 2f, d);
		}
		return Easing.BackEaseIn(t * 2f - d, b + c / 2f, c / 2f, d);
	}
}
