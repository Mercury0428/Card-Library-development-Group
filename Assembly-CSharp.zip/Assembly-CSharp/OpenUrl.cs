﻿using System;
using UnityEngine;

// Token: 0x02000090 RID: 144
public class OpenUrl : MonoBehaviour
{
	// Token: 0x0600049A RID: 1178 RVA: 0x0001CB60 File Offset: 0x0001AD60
	public void OpenURL(string url)
	{
		Application.OpenURL(url);
	}
}
