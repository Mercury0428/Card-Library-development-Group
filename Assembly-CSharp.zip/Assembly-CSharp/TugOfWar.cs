﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200009B RID: 155
public class TugOfWar : MonoBehaviour
{
	// Token: 0x060004D4 RID: 1236 RVA: 0x0001D85D File Offset: 0x0001BA5D
	public void AddPoint()
	{
		this.currentPoints++;
		this.pVotes++;
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x0001D87B File Offset: 0x0001BA7B
	public void SubPoint()
	{
		this.currentPoints--;
		this.mVotes++;
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x0001D89C File Offset: 0x0001BA9C
	private void Update()
	{
		if (Mathf.Abs(this.currentPoints) >= this.PointLimit)
		{
			if (this.currentPoints < 0)
			{
				this.mWins++;
			}
			else
			{
				this.pWins++;
			}
			this.currentPoints = 0;
		}
		this.slider.value = 0.5f + (float)this.currentPoints / (float)this.PointLimit / 2f;
		this.PlusVotes.text = "Plust Votes\n" + this.pVotes;
		this.MinusVotes.text = "Minus Votes\n" + this.mVotes;
		this.PlusWins.text = "Plust Wins\n" + this.pWins;
		this.MinusWins.text = "Minus Wins\n" + this.mWins;
	}

	// Token: 0x0400058A RID: 1418
	public Slider slider;

	// Token: 0x0400058B RID: 1419
	public int PointLimit;

	// Token: 0x0400058C RID: 1420
	private int currentPoints;

	// Token: 0x0400058D RID: 1421
	public Text PlusVotes;

	// Token: 0x0400058E RID: 1422
	public Text MinusVotes;

	// Token: 0x0400058F RID: 1423
	private int pVotes;

	// Token: 0x04000590 RID: 1424
	private int mVotes;

	// Token: 0x04000591 RID: 1425
	public Text PlusWins;

	// Token: 0x04000592 RID: 1426
	public Text MinusWins;

	// Token: 0x04000593 RID: 1427
	private int pWins;

	// Token: 0x04000594 RID: 1428
	private int mWins;
}
