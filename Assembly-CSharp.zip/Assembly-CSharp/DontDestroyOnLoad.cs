﻿using System;
using UnityEngine;

// Token: 0x020000A9 RID: 169
public class DontDestroyOnLoad : MonoBehaviour
{
	// Token: 0x0600054F RID: 1359 RVA: 0x0001F769 File Offset: 0x0001D969
	private void Start()
	{
		Object.DontDestroyOnLoad(base.gameObject);
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x00003D07 File Offset: 0x00001F07
	private void Update()
	{
	}
}
