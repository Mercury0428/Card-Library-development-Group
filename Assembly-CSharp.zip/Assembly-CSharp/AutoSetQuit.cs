﻿using System;
using SVGImporter;
using UnityEngine;

// Token: 0x0200001B RID: 27
public class AutoSetQuit : MonoBehaviour
{
	// Token: 0x060000C5 RID: 197 RVA: 0x00004EEC File Offset: 0x000030EC
	private void OnEnable()
	{
		InputAct.diff.SetQuit(base.gameObject);
		if (this.keepImg)
		{
			return;
		}
		SVGImage component = base.GetComponent<SVGImage>();
		if (component != null)
		{
			if (InputAct.diff.NavigationMode())
			{
				component.enabled = false;
				return;
			}
			component.enabled = true;
		}
	}

	// Token: 0x040000A6 RID: 166
	public bool keepImg;
}
