﻿using System;
using UnityEngine;

// Token: 0x0200008E RID: 142
public class InstancerGrid : MonoBehaviour
{
	// Token: 0x0600048D RID: 1165 RVA: 0x0001C7E4 File Offset: 0x0001A9E4
	public void GridIntensity(float value)
	{
		this._gridIntensity = value;
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x0001C7ED File Offset: 0x0001A9ED
	public void SpaceIntensity(float value)
	{
		this._spaceIntensity = value;
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x0001C7F6 File Offset: 0x0001A9F6
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x0001C7FF File Offset: 0x0001A9FF
	public void HorizontalIntensity(float value)
	{
		this._horizontalIntensity = value;
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x0001C808 File Offset: 0x0001AA08
	public void SquareIntensity(float value)
	{
		this._squareIntensity = value;
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x0001C814 File Offset: 0x0001AA14
	private void Update()
	{
		float num = (float)this.instancer.instances.Length;
		int num2 = Mathf.RoundToInt((float)this.grid * this._gridIntensity);
		if (this.square && this._squareIntensity >= 0.5f)
		{
			num2 = Mathf.RoundToInt(Mathf.Sqrt(num));
		}
		if (num2 < 1)
		{
			num2 = 1;
		}
		float num3 = this.space * this._spaceIntensity;
		float t = Time.deltaTime * this.speed * this._speedIntensity;
		float num4 = (float)(num2 - 1) * 0.5f * num3;
		bool flag = this.horizontal && this._horizontalIntensity >= 0.5f;
		int num5 = 0;
		while ((float)num5 < num)
		{
			float num6;
			float num7;
			if (flag)
			{
				num6 = (float)(num5 % num2);
				num7 = Mathf.Floor((float)(num5 / num2));
			}
			else
			{
				num7 = (float)(num5 % num2);
				num6 = Mathf.Floor((float)(num5 / num2));
			}
			this.destination.x = -num4 + num7 * num3;
			this.destination.y = -num4 + num6 * num3;
			this.instancer.instances[num5].transform.localPosition = Vector3.Lerp(this.instancer.instances[num5].transform.localPosition, this.destination, t);
			num5++;
		}
	}

	// Token: 0x04000548 RID: 1352
	public Instancer instancer;

	// Token: 0x04000549 RID: 1353
	public int grid = 3;

	// Token: 0x0400054A RID: 1354
	protected float _gridIntensity = 1f;

	// Token: 0x0400054B RID: 1355
	public float space = 1f;

	// Token: 0x0400054C RID: 1356
	protected float _spaceIntensity = 1f;

	// Token: 0x0400054D RID: 1357
	public float speed = 1f;

	// Token: 0x0400054E RID: 1358
	protected float _speedIntensity = 1f;

	// Token: 0x0400054F RID: 1359
	public bool horizontal = true;

	// Token: 0x04000550 RID: 1360
	protected float _horizontalIntensity = 1f;

	// Token: 0x04000551 RID: 1361
	public bool square;

	// Token: 0x04000552 RID: 1362
	protected float _squareIntensity = 1f;

	// Token: 0x04000553 RID: 1363
	private Vector3 destination;
}
