﻿using System;
using UnityEngine;

// Token: 0x02000081 RID: 129
public class BindPoseExample : MonoBehaviour
{
	// Token: 0x06000458 RID: 1112 RVA: 0x0001B5A4 File Offset: 0x000197A4
	private void Start()
	{
		base.gameObject.AddComponent<Animation>();
		base.gameObject.AddComponent<SkinnedMeshRenderer>();
		SkinnedMeshRenderer component = base.GetComponent<SkinnedMeshRenderer>();
		Animation component2 = base.GetComponent<Animation>();
		Mesh mesh = new Mesh();
		mesh.vertices = new Vector3[]
		{
			new Vector3(-1f, 0f, 0f),
			new Vector3(1f, 0f, 0f),
			new Vector3(-1f, 5f, 0f),
			new Vector3(1f, 5f, 0f)
		};
		mesh.uv = new Vector2[]
		{
			new Vector2(0f, 0f),
			new Vector2(1f, 0f),
			new Vector2(0f, 1f),
			new Vector2(1f, 1f)
		};
		mesh.triangles = new int[]
		{
			0,
			1,
			2,
			1,
			3,
			2
		};
		mesh.RecalculateNormals();
		component.material = new Material(Shader.Find("Diffuse"));
		BoneWeight[] array = new BoneWeight[4];
		array[0].boneIndex0 = 0;
		array[0].weight0 = 1f;
		array[1].boneIndex0 = 0;
		array[1].weight0 = 1f;
		array[2].boneIndex0 = 1;
		array[2].weight0 = 1f;
		array[3].boneIndex0 = 1;
		array[3].weight0 = 1f;
		mesh.boneWeights = array;
		Transform[] array2 = new Transform[2];
		Matrix4x4[] array3 = new Matrix4x4[2];
		array2[0] = new GameObject("Lower").transform;
		array2[0].parent = base.transform;
		array2[0].localRotation = Quaternion.identity;
		array2[0].localPosition = Vector3.zero;
		array3[0] = array2[0].worldToLocalMatrix * base.transform.localToWorldMatrix;
		array2[1] = new GameObject("Upper").transform;
		array2[1].parent = base.transform;
		array2[1].localRotation = Quaternion.identity;
		array2[1].localPosition = new Vector3(0f, 5f, 0f);
		array3[1] = array2[1].worldToLocalMatrix * base.transform.localToWorldMatrix;
		mesh.bindposes = array3;
		component.bones = array2;
		component.sharedMesh = mesh;
		AnimationCurve animationCurve = new AnimationCurve();
		animationCurve.keys = new Keyframe[]
		{
			new Keyframe(0f, 0f, 0f, 0f),
			new Keyframe(1f, 3f, 0f, 0f),
			new Keyframe(2f, 0f, 0f, 0f)
		};
		AnimationClip animationClip = new AnimationClip();
		animationClip.SetCurve("Lower", typeof(Transform), "m_LocalPosition.z", animationCurve);
		animationClip.legacy = true;
		animationClip.wrapMode = WrapMode.Loop;
		component2.AddClip(animationClip, "test");
		component2.Play("test");
	}
}
