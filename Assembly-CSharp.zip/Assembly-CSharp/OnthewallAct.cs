﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000012 RID: 18
public class OnthewallAct : MonoBehaviour
{
	// Token: 0x0600008A RID: 138 RVA: 0x00003EA8 File Offset: 0x000020A8
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnUpdate = (Action<Card>)Delegate.Combine(diff.OnUpdate, new Action<Card>(this.CheckWall));
		GameAct diff2 = GameAct.diff;
		diff2.OnRefresh = (Action<Card>)Delegate.Combine(diff2.OnRefresh, new Action<Card>(this.CheckNoWall));
		this.selfT = base.GetComponent<RectTransform>();
	}

	// Token: 0x0600008B RID: 139 RVA: 0x00003F0D File Offset: 0x0000210D
	private void CheckWall(Card card)
	{
		if (this.hasWall)
		{
			return;
		}
		if (GameAct.diff.nextCard == "_goingup")
		{
			this.OpenWall();
		}
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00003F34 File Offset: 0x00002134
	private void CheckNoWall(Card card)
	{
		if (!this.hasWall)
		{
			return;
		}
		if (card != null && (card.bearer == Bearers.end || card.id == 1180 || GameAct.diff.GetBool("summer")))
		{
			this.CloseWall();
		}
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00003F70 File Offset: 0x00002170
	private void OpenWall()
	{
		base.StartCoroutine("DoFlick");
		GameAct diff = GameAct.diff;
		diff.OnRefresh = (Action<Card>)Delegate.Combine(diff.OnRefresh, new Action<Card>(this.CheckEvents));
		this.hasWall = true;
		BackgroundAct.diff.SwitchWithTop(this.selfT, true);
		this.Enable();
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00003FD0 File Offset: 0x000021D0
	private void CloseWall()
	{
		base.StopCoroutine("DoFlick");
		GameAct diff = GameAct.diff;
		diff.OnRefresh = (Action<Card>)Delegate.Remove(diff.OnRefresh, new Action<Card>(this.CheckEvents));
		this.hasWall = false;
		BackgroundAct.diff.SwitchWithTop(this.selfT, false);
		base.StartCoroutine("DoDisable");
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00004032 File Offset: 0x00002232
	private IEnumerator DoDisable()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(false);
		}
		base.StopAllCoroutines();
		yield break;
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00004044 File Offset: 0x00002244
	private void Enable()
	{
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(true);
		}
	}

	// Token: 0x06000091 RID: 145 RVA: 0x000040A0 File Offset: 0x000022A0
	private void CheckEvents(Card card)
	{
		this.CheckElement("eastwatch_flick", "eastwatch_broke", this.eastWatch, this.towerBroken0, SFXTypes.sfx_battle_pyromancer);
		this.CheckElement("shadow_flick", "shadow_broke", this.shadowTower, this.towerBroken1, SFXTypes.sfx_tourney_attack);
		this.CheckElement("westwall_flick", "westwall_broke", this.westWall, this.wallBroken, SFXTypes.sfx_dungeon_break_wall);
		this.CheckElement("eastwall_flick", "eastwall_broke", this.eastWall, this.wallBroken, SFXTypes.sfx_dungeon_break_wall);
		this.CheckElement("black_flick", "black_broke", this.castleBlack, this.towerBroken0, SFXTypes.sfx_battle_pyromancer);
		GameAct.diff.AddInt("nb_glass", 1);
	}

	// Token: 0x06000092 RID: 146 RVA: 0x00004164 File Offset: 0x00002364
	private void CheckElement(string var, string var2, SVGImage img, SVGAsset broke, SFXTypes sfx)
	{
		if (GameAct.diff.GetBool(var) && !this.ThingsToFlick.Contains(img))
		{
			this.ThingsToFlick.Add(img);
			return;
		}
		if (GameAct.diff.GetBool(var2) && this.ThingsToFlick.Contains(img))
		{
			this.ThingsToFlick.Remove(img);
			img.enabled = true;
			img.vectorGraphics = broke;
			foreach (object obj in img.transform)
			{
				((Transform)obj).GetComponent<SVGImage>().enabled = false;
			}
			JukeBox.diff.PlaySound(sfx, false, false, 2.5f, -1, 1.5f, 1f);
		}
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00004240 File Offset: 0x00002440
	private IEnumerator DoFlick()
	{
		for (;;)
		{
			List<SVGImage> toflick = new List<SVGImage>(this.ThingsToFlick);
			foreach (SVGImage svgimage in toflick)
			{
				svgimage.enabled = false;
				foreach (object obj in svgimage.transform)
				{
					((Transform)obj).GetComponent<SVGImage>().enabled = true;
				}
			}
			yield return new WaitForSeconds(0.4f);
			foreach (SVGImage svgimage2 in toflick)
			{
				svgimage2.enabled = true;
				foreach (object obj2 in svgimage2.transform)
				{
					((Transform)obj2).GetComponent<SVGImage>().enabled = false;
				}
			}
			yield return new WaitForSeconds(0.6f);
			toflick = null;
		}
		yield break;
	}

	// Token: 0x04000060 RID: 96
	private bool hasWall;

	// Token: 0x04000061 RID: 97
	private RectTransform selfT;

	// Token: 0x04000062 RID: 98
	public SVGAsset towerBroken0;

	// Token: 0x04000063 RID: 99
	public SVGAsset towerBroken1;

	// Token: 0x04000064 RID: 100
	public SVGAsset wallBroken;

	// Token: 0x04000065 RID: 101
	public SVGImage shadowTower;

	// Token: 0x04000066 RID: 102
	public SVGImage eastWatch;

	// Token: 0x04000067 RID: 103
	public SVGImage westWall;

	// Token: 0x04000068 RID: 104
	public SVGImage eastWall;

	// Token: 0x04000069 RID: 105
	public SVGImage castleBlack;

	// Token: 0x0400006A RID: 106
	private List<SVGImage> ThingsToFlick = new List<SVGImage>();
}
