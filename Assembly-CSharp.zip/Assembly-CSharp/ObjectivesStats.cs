﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x0200006E RID: 110
public class ObjectivesStats : MonoBehaviour
{
	// Token: 0x060003DD RID: 989 RVA: 0x00018E9E File Offset: 0x0001709E
	private void OnDisable()
	{
		this.Dismantle();
	}

	// Token: 0x060003DE RID: 990 RVA: 0x00018EA8 File Offset: 0x000170A8
	private void Dismantle()
	{
		if (this.objs.Count > 0)
		{
			foreach (GameObject obj in this.objs)
			{
				Object.Destroy(obj);
			}
		}
		this.objs = new List<GameObject>();
	}

	// Token: 0x060003DF RID: 991 RVA: 0x00018F14 File Offset: 0x00017114
	private void OnEnable()
	{
		this.Dismantle();
		this.allO = this.scOb.GetAll();
		List<Objective> list = this.allO.FindAll((Objective it) => it.fulfilled);
		list.AddRange(this.allO.FindAll((Objective it) => it.visible));
		list.AddRange(this.allO.FindAll((Objective it) => !it.visible && !it.fulfilled));
		int num = -80;
		int num2 = -65;
		int num3 = 0;
		for (int i = 0; i < list.Count; i++)
		{
			GameObject gameObject = Object.Instantiate<GameObject>(this.objectivePrefab);
			this.objs.Add(gameObject);
			gameObject.transform.SetParent(base.transform, false);
			num3 = num + num2 * i;
			gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, (float)num3);
			ObjectiveBox component = gameObject.GetComponent<ObjectiveBox>();
			if (list[i].fulfilled)
			{
				component.Init(list[i], "", true, false);
			}
			else if (list[i].visible)
			{
				component.Init(list[i], "", false, false);
				component.transform.Find("star").GetComponent<SVGImage>().enabled = true;
			}
			else
			{
				component.Init(list[i], "", false, true);
			}
		}
		base.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, (float)(-(float)num3 - num2));
	}

	// Token: 0x040004B5 RID: 1205
	public GameObject objectivePrefab;

	// Token: 0x040004B6 RID: 1206
	public ObjectiveAct scOb;

	// Token: 0x040004B7 RID: 1207
	private List<Objective> allO;

	// Token: 0x040004B8 RID: 1208
	private List<GameObject> objs = new List<GameObject>();
}
