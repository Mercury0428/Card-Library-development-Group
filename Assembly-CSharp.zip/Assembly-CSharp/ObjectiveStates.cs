﻿using System;

// Token: 0x0200006A RID: 106
public enum ObjectiveStates
{
	// Token: 0x04000498 RID: 1176
	hidden = 4,
	// Token: 0x04000499 RID: 1177
	waiting = 3,
	// Token: 0x0400049A RID: 1178
	active = 2,
	// Token: 0x0400049B RID: 1179
	assigned = 1,
	// Token: 0x0400049C RID: 1180
	archived = 0
}
