﻿using System;

// Token: 0x02000035 RID: 53
public class EndCard : CardAct
{
	// Token: 0x060001A5 RID: 421 RVA: 0x0000B280 File Offset: 0x00009480
	private void Awake()
	{
		base._Awake();
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000B3CA File Offset: 0x000095CA
	public override void InitCard(string yesText = "", string noText = "", string otherText = "", int decision = 0, bool withanim = true)
	{
		CardReader.diff.GetComponent<ObjectiveAct>().DestroyBoxes();
		BackgroundAct.diff.FadeToBlack();
		base.InitCard("", "", "", -decision, true);
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x0000B3FE File Offset: 0x000095FE
	public override void HideCard()
	{
		if (this.isFinalFree)
		{
			BackgroundAct.diff.FadeToBlack();
		}
		base.HideCard();
	}

	// Token: 0x040001E1 RID: 481
	private bool isFinalFree;
}
