﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Token: 0x0200004F RID: 79
public class GameAct : MonoBehaviour
{
	// Token: 0x1700000D RID: 13
	// (get) Token: 0x06000269 RID: 617 RVA: 0x0000E744 File Offset: 0x0000C944
	// (set) Token: 0x0600026A RID: 618 RVA: 0x0000E74C File Offset: 0x0000C94C
	public GameStates state
	{
		get
		{
			return this._state;
		}
		set
		{
			this.ConfigureState(value);
		}
	}

	// Token: 0x0600026B RID: 619 RVA: 0x0000E758 File Offset: 0x0000C958
	private void Awake()
	{
		GameAct.diff = this;
		this.questionY = this.question.rectTransform.anchoredPosition.y;
		this.agetxt = this.ageSign.transform.GetChild(0).GetComponent<RectTransform>();
		this.agexpos = this.agetxt.anchoredPosition.x;
		this.textcol = this.kingSign.color;
		Application.targetFrameRate = 60;
	}

	// Token: 0x0600026C RID: 620 RVA: 0x0000E7D0 File Offset: 0x0000C9D0
	private void Start()
	{
		try
		{
			if (PlayerPrefs.HasKey("version") && PlayerPrefs.GetString("version") != this.version)
			{
				this.UpdateGame();
			}
			else
			{
				PlayerPrefs.SetString("version", this.version);
				this.cardIdTxt.text = this.version;
				this.LoadGame();
			}
		}
		catch (Exception)
		{
			InputAct.diff.OfferReset(true, null);
		}
	}

	// Token: 0x0600026D RID: 621 RVA: 0x0000E850 File Offset: 0x0000CA50
	private IEnumerator ChronicUnload()
	{
		WaitForSeconds swait = new WaitForSeconds(60f);
		for (;;)
		{
			yield return swait;
			Resources.UnloadUnusedAssets();
		}
		yield break;
	}

	// Token: 0x0600026E RID: 622 RVA: 0x0000E858 File Offset: 0x0000CA58
	public void GameOver()
	{
		this.isOver = true;
	}

	// Token: 0x0600026F RID: 623 RVA: 0x0000E864 File Offset: 0x0000CA64
	private void ConfigureState(GameStates value)
	{
		this._oldstate = this._state;
		this._state = value;
		switch (this.state)
		{
		case GameStates.start:
		{
			int value2 = -1;
			this.dataCustom = new List<DataCustom>
			{
				new DataCustom("mobile_keep", value2)
			};
			this.decision = 0;
			this.cards = this.reader.GetCards(false);
			this.hiddenCards = this.reader.GetCards(true);
			this.scKi.StartReign(this.startyear, 0);
			if (this.OnInit != null)
			{
				this.OnInit();
			}
			this.StartReign(false);
			return;
		}
		case GameStates.restart:
			this.StartReign(false);
			return;
		case GameStates.interreign:
			return;
		case GameStates.interaction:
			return;
		case GameStates.transition:
			this.ShowNextCard();
			return;
		case GameStates.gameover:
			return;
		default:
			return;
		}
	}

	// Token: 0x06000270 RID: 624 RVA: 0x0000E934 File Offset: 0x0000CB34
	public void StartReign(bool suspendNextcard = false)
	{
		if (suspendNextcard)
		{
			base.StopCoroutine("DoShowNextCard");
			base.StopCoroutine("HideCard");
		}
		this.scKi.InitReign();
		this.isLive = true;
		this.question.text = "";
		if (this.OnStart != null)
		{
			this.OnStart(this.state);
		}
		this.HideDecision(false);
		this.InitNumbers();
		this.cardType = CardTypes.character;
		this.decision = 0;
		base.StartCoroutine("YieldStart");
		JukeBox.diff.PlayMusic(Bearers.none, false);
		if (SpeechAct.diff.asiaLayout)
		{
			this.question.horizontalOverflow = HorizontalWrapMode.Overflow;
			if (SpeechAct.diff.lang == "jp")
			{
				this.ageSign.fontSize = 21;
			}
			else
			{
				this.ageSign.fontSize = 28;
			}
			this.question.fontSize = 14;
			return;
		}
		this.question.horizontalOverflow = HorizontalWrapMode.Wrap;
		this.question.fontSize = 15;
	}

	// Token: 0x06000271 RID: 625 RVA: 0x0000EA3D File Offset: 0x0000CC3D
	private void IntercaleEnd(int dec)
	{
		this.OnCardClose = (Action<int>)Delegate.Remove(this.OnCardClose, new Action<int>(this.IntercaleEnd));
		this.ShowDataCol(true);
	}

	// Token: 0x06000272 RID: 626 RVA: 0x0000EA68 File Offset: 0x0000CC68
	private IEnumerator YieldStart()
	{
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(true);
		}
		yield return new WaitForSeconds(0.2f);
		this.logo.SetActive(false);
		if (this.state == GameStates.restart)
		{
			yield return new WaitForSeconds(0.4f);
		}
		else
		{
			yield return new WaitForSeconds(1.3f);
		}
		if (this.OnSuspendStart != null)
		{
			while (!this.OnSuspendStart(false))
			{
				yield return null;
			}
			yield return new WaitForSeconds(0.8f);
		}
		this.OnSuspendStart = null;
		this.StartInteraction();
		this.state = GameStates.transition;
		yield break;
	}

	// Token: 0x06000273 RID: 627 RVA: 0x0000EA78 File Offset: 0x0000CC78
	private void EndReign(bool forcend = false)
	{
		if (!forcend)
		{
			List<Card> list = this.hiddenCards.FindAll((Card it) => it.name == "_after_death");
			if (list.Count > 0)
			{
				this.isafterdeath = true;
				Card card = this.ProcessCards(list, true, false);
				if (card != null)
				{
					this.AfterDeath(card);
					return;
				}
			}
		}
		base.StartCoroutine("DoEndReign");
		this.spinner.SetActive(true);
	}

	// Token: 0x06000274 RID: 628 RVA: 0x0000EAF0 File Offset: 0x0000CCF0
	private void AfterDeath(Card newcard)
	{
		this.cardType = CardTypes.character;
		this.forceCard = newcard;
		BackgroundAct.diff.PrepareBackEnd();
		this.DestroyModals();
		this.scKi.FinishReign(this.GetInt(Variables.year), this.card.bearerVariation);
		this.lastage = this.GetInt(Variables.age);
		this.startyear = this.GetInt(Variables.year);
		this.SetDefaultVariable(Variables.age);
		if (this.lastage > 50)
		{
			SocialAct.diff.AddAchieve("over50GoT");
		}
		if (this.lastage > 100)
		{
			SocialAct.diff.AddAchieve("over100GoT");
		}
		SocialAct.diff.SetScore(this.lastage);
		foreach (DataCustom dataCustom in this.dataCustom)
		{
			if (!dataCustom.var.EndsWith("_keep"))
			{
				this.SetDefaultCustom(dataCustom);
			}
		}
		foreach (PostponeEvent postponeEvent in new List<PostponeEvent>(this.postponeEvents))
		{
			if (!string.IsNullOrEmpty(postponeEvent.card))
			{
				if (!postponeEvent.card.Contains("_keep"))
				{
					this.postponeEvents.Remove(postponeEvent);
				}
			}
			else
			{
				this.postponeEvents.Remove(postponeEvent);
			}
		}
		foreach (Card card in this.cards)
		{
			if (card.lockturn < 0)
			{
				card.nextturn = this.turns;
			}
		}
		foreach (Card card2 in this.hiddenCards)
		{
			if (card2.lockturn < 0)
			{
				card2.nextturn = this.turns;
			}
		}
		this.Equalize();
		foreach (Bearer bear in new List<Bearer>(this.bearers))
		{
			this.RemoveBearer(bear);
		}
		if (this.OnAfterDeath != null)
		{
			this.OnAfterDeath();
		}
		JukeBox.diff.PlaySound(SFXTypes.env_death_melisandre, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000275 RID: 629 RVA: 0x0000ED98 File Offset: 0x0000CF98
	private IEnumerator DoEndReign()
	{
		this.isafterdeath = false;
		BackgroundAct.diff.PrepareBackNew();
		try
		{
			base.StartCoroutine("HideCard", this.cardSc);
			this.DoDestroy();
			JukeBox.diff.FadeOutAmbient();
		}
		catch
		{
		}
		this.isLive = false;
		yield return new WaitForSeconds(0.4f);
		Resources.UnloadUnusedAssets();
		yield return new WaitForSeconds(0.2f);
		try
		{
			if (this.cardSc != null)
			{
				this.UnsetCard(this.cardSc);
			}
		}
		catch
		{
		}
		this.nextCard = "";
		this.card = null;
		this.cardSc = null;
		foreach (Bearer bear in new List<Bearer>(this.bearers))
		{
			this.RemoveBearer(bear);
		}
		this.postponeEvents.RemoveAll((PostponeEvent it) => it.bear != Bearers.none);
		this.bearers = new List<Bearer>();
		this.roles = new Dictionary<Bearers, Bearer>();
		if (!this.isOver)
		{
			this.AddInt(Variables.dynasty, 1);
			this.AddInt(Variables.year, 1);
			this.scKi.StartReign(this.GetInt(Variables.year), -1);
		}
		if (this.OnReignEnd != null)
		{
			this.OnReignEnd();
		}
		if (this.isOver)
		{
			this.state = GameStates.gameover;
		}
		this.spinner.SetActive(false);
		yield break;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x0000EDA7 File Offset: 0x0000CFA7
	public void UpdateGame()
	{
		DataStore.Load<Stat>("stat_save", new Action<Stat>(this.UpdateStatAfterLoad), false, false);
		DataStore.Load<Game>("game_save", new Action<Game>(this.UpdateAll), false, false);
	}

	// Token: 0x06000277 RID: 631 RVA: 0x0000EDDC File Offset: 0x0000CFDC
	private void UpdateAll(Game save)
	{
		if (save != null)
		{
			this.postponeEvents = save.postponeevents;
			this.cards = save.cards;
			this.hiddenCards = save.hiddencards;
			this.dataVar = save.variables;
			this.dataCustom = save.custom;
			this.title = save.title;
			this.nickname = save.nick;
			this.nextCard = save.nextcard;
			this.lastage = save.lastage;
			this.maxage = save.maxage;
			this.endCards = save.endcards;
			this.turns = save.turns;
			this.seenBearers = save.seenbearers;
			this.metBearers = save.metbearers;
			if (this.OnLoad != null)
			{
				this.OnLoad(save);
			}
			foreach (Bearers bearer in save.bearers)
			{
				this.AddBearer(bearer, null, true);
			}
		}
		if (this.logo)
		{
			this.logo.SetActive(true);
		}
		Text componentInChildren = this.logo.GetComponentInChildren<Text>();
		componentInChildren.GetComponent<AutoText>().enabled = false;
		componentInChildren.enabled = true;
		componentInChildren.transform.parent.gameObject.SetActive(true);
		componentInChildren.text = SpeechAct.diff.GetSceneText("updating");
		this.scKi.CloseWindows();
		InputAct.diff.SuspendSlideFocus();
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(true);
		}
		try
		{
			this.cards = this.reader.UpdateCards(this.cards, false, false);
			this.hiddenCards = this.reader.UpdateCards(this.hiddenCards, true, false);
			Action onUpdateCards = this.OnUpdateCards;
			if (onUpdateCards != null)
			{
				onUpdateCards();
			}
		}
		catch
		{
			InputAct.diff.OfferReset(true, null);
		}
		this.SaveGame();
		PlayerPrefs.SetString("version", this.version);
		SceneManager.LoadScene("disclaimer");
	}

	// Token: 0x06000278 RID: 632 RVA: 0x0000F004 File Offset: 0x0000D204
	private void SaveGame()
	{
		if (this.cards.Count == 0)
		{
			return;
		}
		Game game = new Game();
		game.bearers = this.bearersEnum;
		game.postponeevents = this.postponeEvents;
		game.cards = this.cards;
		game.hiddencards = this.hiddenCards;
		game.variables = this.dataVar;
		game.custom = this.dataCustom;
		game.title = this.title;
		game.nick = this.nickname;
		game.state = this.state;
		game.nextcard = this.nextCard;
		game.lastage = this.lastage;
		game.turns = this.turns;
		game.maxage = this.maxage;
		game.endcards = this.endCards;
		game.seenbearers = this.seenBearers;
		game.metbearers = this.metBearers;
		game.language = SpeechAct.diff.lang;
		if (this.OnSave != null)
		{
			this.OnSave(game);
		}
		DataStore.Save<Game>("game_save", game, false, false);
		DataStore.Save<Stat>("stat_save", new Stat
		{
			seencards = this.seenCards,
			seenendcards = this.seenEndCards
		}, false, false);
	}

	// Token: 0x06000279 RID: 633 RVA: 0x0000F141 File Offset: 0x0000D341
	private void LoadGame()
	{
		DataStore.Load<Stat>("stat_save", new Action<Stat>(this.UpdateStatAfterLoad), false, false);
		DataStore.Load<Game>("game_save", new Action<Game>(this.UpdateAfterLoad), false, false);
	}

	// Token: 0x0600027A RID: 634 RVA: 0x0000F173 File Offset: 0x0000D373
	private void UpdateStatAfterLoad(Stat statsave)
	{
		if (statsave == null)
		{
			return;
		}
		this.seenEndCards = statsave.seenendcards;
		this.seenCards = statsave.seencards;
	}

	// Token: 0x0600027B RID: 635 RVA: 0x0000F194 File Offset: 0x0000D394
	private void UpdateAfterLoad(Game save)
	{
		if (save == null)
		{
			if (this.reader.StartDownload())
			{
				return;
			}
			this.state = GameStates.start;
			return;
		}
		else
		{
			GameStates gameStates = GameStates.none;
			this.postponeEvents = save.postponeevents;
			this.cards = save.cards;
			this.hiddenCards = save.hiddencards;
			this.dataVar = save.variables;
			this.dataCustom = save.custom;
			foreach (DataCustom dataCustom in this.dataCustom)
			{
				if (dataCustom.var.StartsWith("inc_"))
				{
					this.incrCustom.Add(dataCustom.var);
				}
			}
			this.title = save.title;
			this.nickname = save.nick;
			gameStates = save.state;
			this.nextCard = save.nextcard;
			this.lastage = save.lastage;
			this.seenBearers = save.seenbearers;
			this.metBearers = save.metbearers;
			this.turns = save.turns;
			if (save.language != null && save.language.Length == 2 && save.language != SpeechAct.diff.lang)
			{
				SpeechAct.diff.lang = save.language;
				PlayerPrefs.SetString("language", save.language);
			}
			this.maxage = save.maxage;
			this.endCards = save.endcards;
			if (this.OnLoad != null)
			{
				this.OnLoad(save);
			}
			this.roles = new Dictionary<Bearers, Bearer>();
			foreach (Bearers bearer in save.bearers)
			{
				this.AddBearer(bearer, null, true);
			}
			if (gameStates == GameStates.start || gameStates == GameStates.interreign || gameStates == GameStates.gameover)
			{
				this.state = gameStates;
				return;
			}
			this.state = GameStates.restart;
			return;
		}
	}

	// Token: 0x0600027C RID: 636 RVA: 0x0000F39C File Offset: 0x0000D59C
	public void ValidSelectionDirect(string next)
	{
		InputAct.diff.DisableMenuNav(false);
		this.ExpandCards();
		foreach (CharacterCard characterCard in this.selection)
		{
			base.StartCoroutine("HideCard", characterCard);
			characterCard.DisableChoice(true);
		}
		this.card = null;
		this.curBearer = null;
		InputAct.diff.RestoreSlideFocus();
		Card card = this.hiddenCards.Find((Card it) => it.name == next);
		this.cardType = CardTypes.character;
		this.AddBearer(card.bearer, null, true);
		this.state = GameStates.interaction;
		this.OpenCard(card);
		JukeBox.diff.PlaySound(SFXTypes.sfx_weirwood_full_reveal, false, false, 2.5f, -1, 1.5f, 1f);
		JukeBox.diff.PlayMusic(Bearers.weirwood, false);
		SocialAct.diff.AddAchieve("endofendsGoT");
	}

	// Token: 0x0600027D RID: 637 RVA: 0x0000F4AC File Offset: 0x0000D6AC
	public void ValidSelection(CharacterCard scCa, Bearer be, Card ca)
	{
		if (this.state != GameStates.interaction)
		{
			return;
		}
		if (this.cardType != CardTypes.selection)
		{
			return;
		}
		InputAct.diff.DisableMenuNav(false);
		this.ExpandCards();
		this.card = ca;
		GText gtext = ca.question;
		this.curBearer = be;
		this.cardSc = scCa;
		string name = this.curBearer.generated.Get();
		if (this.card.bearerVariation.EndsWith("dark"))
		{
			name = "? ? ?";
		}
		this.scCh.ShowName(name, this.curBearer.title.Get());
		this.ChangeQuestion(gtext, false);
		this.lastBearer = this.curBearer.bearer;
		foreach (CharacterCard characterCard in this.selection)
		{
			if (characterCard != scCa)
			{
				base.StartCoroutine("HideCard", characterCard);
				characterCard.DisableChoice(true);
			}
		}
		this.cardType = CardTypes.character;
		this.UpdateStatBearer(this.curBearer.bearer, true);
		if (!this.isafterdeath)
		{
			BackgroundAct.diff.ShowBack();
		}
		InputAct.diff.RestoreSlideFocus();
		if (!this.CheckShortcut(this.card, gtext, true))
		{
			this.LoadCard(this.card);
		}
		else
		{
			this.card.wasSeen = true;
			if (!this.seenCards.Contains(this.card.id))
			{
				this.seenCards.Add(this.card.id);
			}
		}
		if (this.OnValidSelection != null)
		{
			this.OnValidSelection(this.card);
		}
		if (this.isafterdeath)
		{
			JukeBox.diff.PlaySound(SFXTypes.ui_death_characters_select, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_character_select, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x0000F6A4 File Offset: 0x0000D8A4
	private IEnumerator InitSelection()
	{
		string n = this.card.name;
		bool isChoiceHidden = n.EndsWith("hidden_choice");
		this.ignoredId = new List<int>();
		List<Card> list = this.card.name.StartsWith("_") ? this.hiddenCards.FindAll((Card it) => it.name == n) : this.cards.FindAll((Card it) => it.name == n);
		if (n == "_batdorne_choice" || n == "_batnorth_choice" || n == "_batlanni_choice")
		{
			string custom_name = list[0].yes_outcomes.Find((Outcome it) => it.variable == Variables.chain).custom_name;
			List<Card> list2 = this.hiddenCards.FindAll((Card it) => it.name == "_batgeneric_choice");
			foreach (Card card in list2)
			{
				card.yes_outcomes.Find((Outcome it) => it.variable == Variables.chain).custom_name = custom_name;
				card.no_outcomes.Find((Outcome it) => it.variable == Variables.chain).custom_name = custom_name;
			}
			list.AddRange(list2);
		}
		bool winterpath = this.card.name == "_winterpath_choice";
		List<Card> validCards = new List<Card>();
		List<DataDisplay> validDisplay = new List<DataDisplay>();
		Card card2 = null;
		foreach (Card card3 in list)
		{
			if (card3.weight == 0)
			{
				card2 = card3;
			}
			bool flag = this.TestCard(card3, true, true);
			if (flag)
			{
				if (card3.wasSeen || card3.weight != 106 || this.unlockedSelection.Contains(card3.bearer))
				{
					validDisplay.Add(DataDisplay.fullamount);
				}
				else
				{
					validDisplay.Add(DataDisplay.moving);
					if (!this.unlockedSelection.Contains(card3.bearer))
					{
						this.unlockedSelection.Add(card3.bearer);
					}
					if (card3.id == 227)
					{
						SocialAct.diff.AddAchieve("collectorGoT");
					}
				}
				validCards.Add(card3);
				this.card = card3;
			}
			else if (card3.weight == 106)
			{
				validDisplay.Add(DataDisplay.hidden);
				validCards.Add(card3);
				this.card = card3;
			}
			else if (!flag)
			{
				this.ignoredId.Add(card3.id);
			}
		}
		bool allwinterdone = winterpath && !validDisplay.Contains(DataDisplay.fullamount) && !validDisplay.Contains(DataDisplay.moving);
		this.selection = new List<CharacterCard>();
		int nb = Mathf.Clamp(validCards.Count, 0, 16);
		List<Card> list3 = new List<Card>();
		for (int j = 0; j < nb; j++)
		{
			bool flag2 = false;
			Card card4 = validCards[j];
			if (card4.weight == -1)
			{
				this.nextCard = card4.yes_outcomes.Find((Outcome it) => it.variable == Variables.chain).custom_name;
				this.card = card4;
				this.SetIntercale(card4.question);
				this.DisplayIntercaleCard();
				this.cardSc.GoToPos(this.centralPos);
				yield return new WaitForSeconds(0.4f);
				yield break;
			}
			Bearer bearer = (this.HasBearer(card4.bearer, card4.bearerIsAlso, card4.bearerIsNot) == null) ? this.AddBearer(card4.bearer, null, false) : this.SelectBearer(card4);
			if (bearer != null)
			{
				bearer = new Bearer(bearer);
				if (!this.selection.Contains(bearer.scCa))
				{
					this.selection.Add(bearer.scCa);
					flag2 = true;
				}
				else
				{
					bearer = this.AddBearer(card4.bearer, null, false);
					if (bearer != null)
					{
						this.selection.Add(bearer.scCa);
						flag2 = true;
					}
				}
			}
			if (!flag2)
			{
				list3.Add(card4);
			}
		}
		foreach (Card item in list3)
		{
			validCards.Remove(item);
		}
		nb = this.selection.Count;
		if (nb < 2)
		{
			this.nextCard = "cardId";
			this.nextCardId = ((nb == 0) ? card2.id : this.card.id);
			this.DisplayCharacterCard(1, true);
			this.cardSc.GoToPos(this.centralPos);
			yield return new WaitForSeconds(0.4f);
			yield break;
		}
		InputAct.diff.SuspendSlideFocus();
		BackgroundAct.diff.HideBack();
		int matrix = (nb > 9) ? 4 : ((nb > 4) ? 3 : 2);
		int lastcol = nb % matrix;
		int lastrow = (nb - lastcol) / matrix;
		int num = Mathf.FloorToInt((float)((nb - 1) / matrix));
		float amo = (matrix == 4) ? 0.225f : ((matrix == 3) ? 0.3f : 0.45f);
		bool showSubtitle = matrix <= 2 && !this.isafterdeath;
		float t = 0.1f;
		Vector2 displace = (num == 3) ? new Vector2(-110f, 75f) : ((num == 2 && matrix == 4) ? new Vector2(-110f, 50f) : ((num == 2 && matrix == 3) ? new Vector2(-100f, 60f) : ((num == 1 && matrix == 3) ? new Vector2(-100f, 20f) : ((num == 1 && matrix == 2) ? new Vector2(-75f, 50f) : new Vector2(-75f, -15f)))));
		this.ShrinkCards(amo, displace);
		if (this.OnInitSelection != null)
		{
			this.OnInitSelection(validCards);
		}
		bool hasfirst = false;
		InputAct.diff.OpenInventory();
		if (this.isafterdeath)
		{
			JukeBox.diff.PlaySound(SFXTypes.ui_death_characters, false, false, 2.5f, -1, 1.5f, 1f);
		}
		else
		{
			JukeBox.diff.PlaySound(SFXTypes.ui_character_transition, false, false, 2.5f, -1, 1.5f, 1f);
		}
		int num4;
		for (int i = 0; i < nb; i = num4 + 1)
		{
			Card card5 = validCards[i];
			CharacterCard characterCard = this.selection[i];
			characterCard.gameObject.SetActive(true);
			int num2 = i % matrix;
			int num3 = Mathf.FloorToInt((float)(i / matrix));
			Vector2 b = (num3 == lastrow) ? (Vector2.right * 165f * (float)(matrix - lastcol)) : Vector2.zero;
			Vector2 target = this.centralPos + Vector2.right * 330f * (float)num2 + Vector2.down * 330f * (float)num3 + b;
			characterCard.GoToPos(target);
			this.scCh.ShowName("", "");
			bool flag3 = !hasfirst && (validDisplay[i] != DataDisplay.hidden || allwinterdone);
			if (winterpath)
			{
				characterCard.UpdateWinterChoiceCard(card5, i, validDisplay[i], allwinterdone, flag3);
			}
			else
			{
				characterCard.UpdateChoiceCard(card5, isChoiceHidden, showSubtitle, validDisplay[i], flag3);
			}
			if (flag3)
			{
				hasfirst = true;
			}
			yield return new WaitForSeconds(t);
			t -= 0.01f;
			num4 = i;
		}
		yield return new WaitForSeconds(0.4f);
		yield break;
	}

	// Token: 0x0600027F RID: 639 RVA: 0x0000F6B4 File Offset: 0x0000D8B4
	private CharacterCard InstantiateCard(Bearer bear)
	{
		GameObject gameObject = Object.Instantiate<GameObject>(this.charaPrefab, this.characterRepo);
		CharacterCard component = gameObject.GetComponent<CharacterCard>();
		if (component != null)
		{
			component.Init(bear);
		}
		gameObject.SetActive(false);
		return component;
	}

	// Token: 0x06000280 RID: 640 RVA: 0x0000F6F0 File Offset: 0x0000D8F0
	private void SetBearer(Bearer perso, Bearers chara, Bearer charamodel = null)
	{
		if (!this.roles.ContainsKey(chara))
		{
			this.roles.Add(chara, perso);
		}
		if (charamodel == null)
		{
			if (!perso.title.isEmpty)
			{
				return;
			}
			using (List<Bearers>.Enumerator enumerator = perso.character.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Bearers cha = enumerator.Current;
					Bearer bearer = this.reader.bearerModels.Find((Bearer it) => it.bearer == cha);
					if (!bearer.title.isEmpty)
					{
						perso.title = bearer.title;
						break;
					}
				}
				return;
			}
		}
		if (!perso.character.Contains(chara))
		{
			perso.character.Add(chara);
		}
		if (charamodel.type == BearerTypes.function)
		{
			this.RemoveChara(Bearers.antagonist, perso);
		}
		if (!charamodel.title.isEmpty)
		{
			perso.title = charamodel.title;
		}
		if (chara == Bearers.hand)
		{
			perso.scCa.AddPin();
		}
	}

	// Token: 0x06000281 RID: 641 RVA: 0x0000F804 File Offset: 0x0000DA04
	private void AddChara(Bearers chara, Bearer perso)
	{
		Bearer bearer = CardReader.diff.bearerModels.Find((Bearer it) => it.bearer == chara);
		if (bearer.type == BearerTypes.function)
		{
			Bearer bearer2 = this.bearers.Find((Bearer it) => it.character.Contains(chara));
			if (bearer2 != null)
			{
				this.RemoveChara(chara, bearer2);
			}
		}
		if (!this.bearers.Contains(perso))
		{
			this.bearers.Add(perso);
		}
		this.SetBearer(perso, chara, bearer);
	}

	// Token: 0x06000282 RID: 642 RVA: 0x0000F894 File Offset: 0x0000DA94
	private void AddChara(Bearers chara, Bearers all)
	{
		Bearer bearer = this.bearers.Find((Bearer it) => it.bearer == all);
		if (bearer != null)
		{
			this.AddChara(chara, bearer);
			return;
		}
		CardReader.diff.AddCharacterToModel(chara, all);
		foreach (Bearer bearer2 in this.bearers.FindAll((Bearer it) => it.character.Contains(all)))
		{
			if (!bearer2.character.Contains(chara))
			{
				bearer2.character.Add(chara);
			}
		}
	}

	// Token: 0x06000283 RID: 643 RVA: 0x0000F950 File Offset: 0x0000DB50
	private void RemoveChara(Bearers chara, Bearers all)
	{
		Bearer bearer = this.bearers.Find((Bearer it) => it.bearer == all);
		if (bearer == null)
		{
			CardReader.diff.RemoveCharacterFromModel(chara, all);
			using (List<Bearer>.Enumerator enumerator = this.bearers.FindAll((Bearer it) => it.character.Contains(all)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Bearer bearer2 = enumerator.Current;
					if (bearer2.character.Contains(chara))
					{
						bearer2.character.Remove(chara);
						if (chara == Bearers.antagonist)
						{
							bearer2.vote = 1f;
						}
					}
				}
				return;
			}
		}
		this.RemoveChara(chara, bearer);
	}

	// Token: 0x06000284 RID: 644 RVA: 0x0000FA1C File Offset: 0x0000DC1C
	private void RemoveChara(Bearers chara, Bearer individual)
	{
		if (individual.character.Contains(chara))
		{
			individual.character.Remove(chara);
			if (chara == Bearers.hand && individual.scCa != null)
			{
				individual.scCa.RemovePin();
			}
			if (this.roles.ContainsKey(chara))
			{
				this.roles.Remove(chara);
			}
		}
	}

	// Token: 0x06000285 RID: 645 RVA: 0x0000FA7C File Offset: 0x0000DC7C
	private Bearer AddBearer(Bearers bearer, Bearers target)
	{
		if (target != Bearers.none)
		{
			return this.AddBearer(bearer, this.bearers.Find((Bearer it) => it.bearer == target), true);
		}
		return this.AddBearer(bearer, null, true);
	}

	// Token: 0x06000286 RID: 646 RVA: 0x0000FACC File Offset: 0x0000DCCC
	public Bearer AddBearer(Bearers bearer, Bearer targetBearer = null, bool addtobearers = true)
	{
		Bearer bearer2 = new Bearer(this.reader.bearerModels.Find((Bearer it) => it.bearer == bearer));
		switch (bearer2.type)
		{
		case BearerTypes.generated:
		case BearerTypes.individual:
		case BearerTypes.special:
		case BearerTypes.bannerman:
		{
			if (!this.isafterdeath && bearer == this.scKi.monarch.bearer)
			{
				return null;
			}
			List<Bearer> list = this.bearers.FindAll((Bearer it) => it.bearer == bearer);
			if (addtobearers && list.Count >= bearer2.max)
			{
				return null;
			}
			Bearer bearer3 = new Bearer(bearer2);
			bearer3.scCa = this.InstantiateCard(bearer3);
			if (addtobearers)
			{
				this.bearers.Add(bearer3);
			}
			if (addtobearers)
			{
				this.SetBearer(bearer3, bearer, null);
			}
			return bearer3;
		}
		case BearerTypes.function:
			if (addtobearers)
			{
				foreach (Bearer bearer4 in this.bearers)
				{
					if (bearer4.character.Contains(bearer))
					{
						bearer4.character.Remove(bearer);
						if (bearer == Bearers.hand)
						{
							bearer4.scCa.RemovePin();
						}
					}
				}
				this.roles.Remove(bearer);
			}
			break;
		case BearerTypes.house:
		case BearerTypes.system:
			break;
		case BearerTypes.none:
			goto IL_230;
		default:
			goto IL_230;
		}
		List<Bearer> list2 = this.bearers.FindAll((Bearer it) => it.character.Contains(bearer));
		if (addtobearers && list2.Count >= bearer2.max)
		{
			return null;
		}
		if (targetBearer == null)
		{
			List<Bearer> list3 = this.reader.bearerModels.FindAll((Bearer it) => it.character.Contains(bearer) && it.bearer != this.scKi.monarch.bearer && !this.roles.ContainsValue(this.bearers.Find((Bearer ti) => ti.bearer == it.bearer)) && this.postponeEvents.Find((PostponeEvent tt) => tt.bear == it.bearer) == null);
			list3.Shuffle<Bearer>();
			if (list3.Count == 0)
			{
				return null;
			}
			targetBearer = new Bearer(list3[0]);
			targetBearer.scCa = this.InstantiateCard(targetBearer);
			if (addtobearers)
			{
				this.bearers.Add(targetBearer);
			}
		}
		else if (addtobearers && !this.bearers.Contains(targetBearer))
		{
			this.bearers.Add(targetBearer);
		}
		if (addtobearers)
		{
			this.SetBearer(targetBearer, bearer, bearer2);
		}
		return targetBearer;
		IL_230:
		return null;
	}

	// Token: 0x06000287 RID: 647 RVA: 0x0000FD1C File Offset: 0x0000DF1C
	private void RemoveFromListBearers(Bearer b)
	{
		if (this.bearers.Contains(b))
		{
			this.bearers.Remove(b);
			this.bearersEnum.Remove(b.bearer);
		}
	}

	// Token: 0x06000288 RID: 648 RVA: 0x0000FD4C File Offset: 0x0000DF4C
	private void RemoveBearer(Bearers bearer)
	{
		Bearer bearer2 = this.HasBearer(bearer, Bearers.none, Bearers.none);
		if (bearer2 == null)
		{
			if (!this.roles.ContainsKey(bearer))
			{
				return;
			}
			bearer2 = this.roles[bearer];
		}
		this.RemoveBearer(bearer2);
	}

	// Token: 0x06000289 RID: 649 RVA: 0x0000FD94 File Offset: 0x0000DF94
	private void RemoveBearer(Bearer bear)
	{
		if (this.roles.ContainsKey(bear.bearer))
		{
			this.roles.Remove(bear.bearer);
		}
		foreach (Bearers bearers in bear.character)
		{
			if (this.roles.ContainsKey(bearers))
			{
				this.roles.Remove(bearers);
				if (bearers == Bearers.hand && bear.scCa != null)
				{
					bear.scCa.RemovePin();
				}
			}
		}
		Component scCa = bear.scCa;
		if (bear.staydead != -1)
		{
			this.postponeEvents.Add(new PostponeEvent(this.GetInt(Variables.year) + bear.staydead, bear.bearer));
		}
		this.RemoveFromListBearers(bear);
		Object.Destroy(scCa.gameObject);
	}

	// Token: 0x0600028A RID: 650 RVA: 0x0000FE84 File Offset: 0x0000E084
	public bool HasBearer(Bearer bearer)
	{
		return this.bearers.Find((Bearer it) => it.bearer == bearer.bearer) != null;
	}

	// Token: 0x0600028B RID: 651 RVA: 0x0000FEB8 File Offset: 0x0000E0B8
	public Bearer HasBearer(Bearers bearer, Bearers isalso = Bearers.none, Bearers isnot = Bearers.none)
	{
		if (isalso != Bearers.none && bearer == Bearers.anyone)
		{
			bearer = isalso;
		}
		Bearer bearer2 = this.bearers.Find((Bearer it) => it.bearer == bearer && !it.character.Contains(isnot));
		if (bearer2 != null)
		{
			return bearer2;
		}
		List<Bearer> list = this.bearers.FindAll((Bearer it) => it.character.Contains(bearer) && !it.character.Contains(isnot));
		if (list.Count > 0)
		{
			list.Shuffle<Bearer>();
			return list[0];
		}
		return null;
	}

	// Token: 0x0600028C RID: 652 RVA: 0x0000FF3F File Offset: 0x0000E13F
	private void ShowNextCard()
	{
		base.StopCoroutine("DoShowNextCard");
		base.StartCoroutine("DoShowNextCard");
		if (this.OnUpdate != null)
		{
			this.OnUpdate(this.card);
		}
	}

	// Token: 0x0600028D RID: 653 RVA: 0x0000FF71 File Offset: 0x0000E171
	private IEnumerator HideCard(CardAct cardsc)
	{
		if (cardsc == null)
		{
			yield break;
		}
		if (this.decision == -1)
		{
			JukeBox.diff.PlaySound(SFXTypes.card_discard_right, false, false, 2.5f, -1, 1.5f, 1f);
		}
		else
		{
			JukeBox.diff.PlaySound(SFXTypes.card_discard_left, false, false, 2.5f, -1, 1.5f, 1f);
		}
		cardsc.HideCard();
		this.cardSc.ShowDecision(0);
		float t = 0f;
		bool nodec = this.decision != -1 && this.decision != 1;
		float dec = (float)((!nodec) ? this.decision : ((Util.Rand(0f, 1f) > 0.5f) ? -1 : 1));
		while (t < 1f)
		{
			Vector2 vec = dec * Vector2.right * Time.deltaTime * 2000f * t;
			cardsc.Disappear(vec, nodec);
			t += Time.deltaTime * 4f;
			yield return null;
		}
		this.HideDecision(false);
		this.UnsetCard(cardsc);
		if (this.OnCardHiding != null)
		{
			while (!this.OnCardHiding(this.cardType))
			{
				yield return new WaitForSeconds(0.2f);
				if (this.OnCardHiding == null)
				{
					yield break;
				}
			}
		}
		yield break;
	}

	// Token: 0x0600028E RID: 654 RVA: 0x0000FF88 File Offset: 0x0000E188
	private void UnsetCard(CardAct cardsc)
	{
		cardsc.GoToPos(Vector2.right * 1000f);
		cardsc.RotateTo(0f);
		if (this.cardType == CardTypes.duel)
		{
			return;
		}
		cardsc.Unset();
		if (cardsc != null)
		{
			cardsc.gameObject.SetActive(false);
		}
	}

	// Token: 0x0600028F RID: 655 RVA: 0x0000FFDA File Offset: 0x0000E1DA
	private IEnumerator MoveCardToCenter(CardAct cardsc, int dec)
	{
		if (cardsc == null)
		{
			yield break;
		}
		float t = 0f;
		Vector2 opos = this.centralPos + (float)(100 * dec) * Vector2.right;
		Vector2 tarpos = this.centralPos;
		while (t < 1f)
		{
			cardsc.GoToPos(Vector3.Lerp(opos, tarpos, t));
			t += Time.deltaTime * 6f;
			yield return null;
		}
		cardsc.GoToPos(tarpos);
		yield break;
	}

	// Token: 0x06000290 RID: 656 RVA: 0x0000FFF7 File Offset: 0x0000E1F7
	private IEnumerator DoShowNextCard()
	{
		this.curdec = this.decision;
		if (this.cardSc != null)
		{
			yield return base.StartCoroutine("HideCard", this.cardSc);
		}
		this.DoDestroy();
		if (this.card != null && this.card.name != "_misplayed")
		{
			this.lastCard = this.card;
		}
		switch (this.cardType)
		{
		case CardTypes.character:
			this.DisplayCharacterCard(this.curdec, false);
			break;
		case CardTypes.effect:
			this.DisplayEffectCard();
			break;
		case CardTypes.end:
			yield break;
		case CardTypes.intercale:
			this.DisplayIntercaleCard();
			break;
		case CardTypes.duel:
			this.DisplayCharacterCard(this.curdec, true);
			break;
		}
		this.cardSc.GoToPos(this.centralPos);
		if (this.cardType == CardTypes.selection)
		{
			yield return base.StartCoroutine("InitSelection");
		}
		else
		{
			yield return new WaitForSeconds(0.4f);
		}
		this.LoadCard(this.card);
		if (this.OnRefresh != null && this.card != null)
		{
			this.OnRefresh(this.card);
		}
		this.state = GameStates.interaction;
		yield break;
	}

	// Token: 0x06000291 RID: 657 RVA: 0x00010008 File Offset: 0x0000E208
	private void LoadCard(Card card)
	{
		if (card != null && this.cardType != CardTypes.selection)
		{
			this.lastcardId = card.id;
			this.cardIdTxt.text = this.version + " id:" + card.id.ToString();
			if (this.cardType != CardTypes.intercale)
			{
				foreach (string var in this.incrCustom)
				{
					if (this.GetInt(var) > 0)
					{
						this.AddInt(var, 1);
					}
				}
			}
			this.TreatOutcomes(2);
			if (card.lockturn == -1)
			{
				this.DestroyCard(card);
			}
			if (this.cardType != CardTypes.intercale)
			{
				List<Card> list = this.cards.FindAll((Card it) => it.name == card.name);
				if (list.Count == 0 && (this.GetInt("inc_battle") > 0 || card.name == "_jousting_choice"))
				{
					list = this.hiddenCards.FindAll((Card it) => it.name == card.name && it.bearer == card.bearer && it.bearerIsAlso == card.bearerIsAlso);
				}
				if (list.Count == 0)
				{
					list = new List<Card>
					{
						card
					};
				}
				foreach (Card card2 in list)
				{
					if (card2.lockturn < 0)
					{
						card2.nextturn = this.turns + 1000;
					}
					else
					{
						card2.nextturn = this.turns + card2.lockturn;
					}
				}
			}
			if (!card.wasSeen)
			{
				card.wasSeen = true;
				if (!this.seenCards.Contains(card.id))
				{
					this.seenCards.Add(card.id);
					if (this.seenCards.Count == 1500)
					{
						SocialAct.diff.AddAchieve("cardsGoT");
					}
				}
				this.scKi.AddAchieve(card.name, AchieveTypes.card);
			}
		}
	}

	// Token: 0x06000292 RID: 658 RVA: 0x00010260 File Offset: 0x0000E460
	private void DisplayIntercaleCard()
	{
		this.cardSc = this.intercaleSc;
		this.cardSc.gameObject.SetActive(true);
		this.card = null;
		this.cardSc.InitCard("", "", this.intercale, this.curdec, true);
		this.scCh.ShowName("", "");
		this.cardType = CardTypes.character;
	}

	// Token: 0x06000293 RID: 659 RVA: 0x000102D0 File Offset: 0x0000E4D0
	public void DisplayCustomCard(string next, string overyes, string overno, Bearers forcebearer = Bearers.none)
	{
		Card card = this.SelectCard(next, forcebearer);
		string text = card.question.Get();
		this.ChangeQuestion(card.question, false);
		string yesText = string.IsNullOrEmpty(overyes) ? card.override_yes.Get() : overyes;
		string noText = string.IsNullOrEmpty(overno) ? card.override_no.Get() : overno;
		this.cardSc.UpdateCard(yesText, noText, text);
	}

	// Token: 0x06000294 RID: 660 RVA: 0x0001033C File Offset: 0x0000E53C
	private bool CheckShortcut(Card ccard, GText quest, bool andopen = false)
	{
		Outcome outcome = ccard.load_outcomes.Find((Outcome it) => it.variable == Variables.chain);
		if (outcome == null)
		{
			return !andopen;
		}
		if (this.OnShortcut != null)
		{
			this.OnShortcut(ccard);
		}
		this.ChangeQuestion(quest, false);
		this.LoadCard(ccard);
		this.ShowOutcome(this.GetOutcomeList(1));
		this.TreatOutcomes(1);
		if (outcome.custom_name == "force_end")
		{
			this.nextCard = "";
			this.cardType = CardTypes.end;
			this.EndReign(true);
			this.state = GameStates.interreign;
			return false;
		}
		this.card = this.SelectCard(outcome.custom_name, Bearers.none);
		if (andopen)
		{
			this.OpenCard(this.card);
		}
		else if (this.card.name.EndsWith("_choice"))
		{
			this.cardType = CardTypes.selection;
			return false;
		}
		return true;
	}

	// Token: 0x06000295 RID: 661 RVA: 0x00010438 File Offset: 0x0000E638
	private void DisplayCharacterCard(int curdec, bool notypechange = false)
	{
		this.card = this.SelectCard(this.nextCard, Bearers.none);
		if (this.card.name.EndsWith("_choice") && !notypechange)
		{
			this.cardType = CardTypes.selection;
			return;
		}
		GText gtext = this.card.question;
		if (!this.CheckShortcut(this.card, gtext, false))
		{
			return;
		}
		if (this.card.bearer == Bearers.end)
		{
			this.OpenEndCard(gtext);
			return;
		}
		this.cardType = CardTypes.character;
		this.curBearer = this.SelectBearer(this.card);
		SpeechAct.diff.isSelfMale = this.curBearer.character.Contains(Bearers.male);
		this.ChangeQuestion(gtext, false);
		if (this.OnCharacter != null)
		{
			this.OnCharacter(this.card.bearer);
		}
		this.cardSc = this.curBearer.scCa;
		this.cardSc.gameObject.SetActive(true);
		this.curBearer.scCa.UpdateCharacCard(this.card, curdec, true);
		string name = this.curBearer.generated.Get();
		if (this.card.bearerVariation.EndsWith("dark"))
		{
			name = "? ? ?";
		}
		if (this.isafterdeath)
		{
			this.scCh.ShowName(name, "");
		}
		else
		{
			this.scCh.ShowName(name, this.curBearer.title.Get());
		}
		this.lastBearer = this.curBearer.bearer;
		this.UpdateStatBearer(this.lastBearer, true);
	}

	// Token: 0x06000296 RID: 662 RVA: 0x000105CC File Offset: 0x0000E7CC
	private Bearer SelectBearer(Card card)
	{
		if (card.bearer == Bearers.anyone || card.bearer == Bearers.none)
		{
			if (card.bearer == Bearers.none && this.curBearer != null)
			{
				return this.curBearer;
			}
			List<Bearer> list;
			if (card.bearerIsAlso == Bearers.none)
			{
				if (card.bearerIsNot == Bearers.none)
				{
					list = this.bearers.FindAll((Bearer it) => !it.character.Contains(Bearers.antagonist) && it.type == BearerTypes.individual);
				}
				else
				{
					list = this.bearers.FindAll((Bearer it) => !it.character.Contains(Bearers.antagonist) && it.type == BearerTypes.individual && !it.character.Contains(card.bearerIsNot));
				}
			}
			else
			{
				list = this.bearers.FindAll((Bearer it) => !it.character.Contains(Bearers.antagonist) && it.type == BearerTypes.individual && (it.character.Contains(card.bearerIsAlso) || it.bearer == card.bearerIsAlso));
			}
			List<Bearer> list2 = list;
			if (list2.Count == 0)
			{
				list2 = this.bearers.FindAll((Bearer it) => !it.character.Contains(Bearers.antagonist) && it.type == BearerTypes.individual);
			}
			return list2[Util.RandInt(0, list2.Count)];
		}
		else
		{
			if (this.roles.ContainsKey(card.bearer))
			{
				return this.roles[card.bearer];
			}
			Bearer bearer = this.bearers.Find((Bearer it) => it.bearer == card.bearer);
			if (bearer == null)
			{
				List<Bearer> list3 = (card.bearerIsAlso != Bearers.none) ? this.bearers.FindAll((Bearer it) => it.character.Contains(card.bearer) && it.character.Contains(card.bearerIsAlso)) : ((card.bearerIsNot != Bearers.none) ? this.bearers.FindAll((Bearer it) => it.character.Contains(card.bearer) && !it.character.Contains(card.bearerIsNot)) : this.bearers.FindAll((Bearer it) => it.character.Contains(card.bearer)));
				if (list3.Count == 0)
				{
					list3 = this.bearers.FindAll((Bearer it) => !it.character.Contains(Bearers.antagonist) && it.type == BearerTypes.individual);
				}
				bearer = list3[Util.RandInt(0, list3.Count)];
			}
			this.roles.Add(card.bearer, bearer);
			return bearer;
		}
	}

	// Token: 0x06000297 RID: 663 RVA: 0x0001080B File Offset: 0x0000EA0B
	public bool HasSeenBearer(Bearers b)
	{
		return this.seenBearers.Contains(b);
	}

	// Token: 0x06000298 RID: 664 RVA: 0x0001081C File Offset: 0x0000EA1C
	public void UpdateStatBearer(Bearers b, bool andmet)
	{
		if (andmet && !this.metBearers.Contains(b))
		{
			this.metBearers.Add(b);
		}
		if (!this.seenBearers.Contains(b))
		{
			this.seenBearers.Add(b);
			if (this.seenBearers.Count == this.GetRegularBearers().Count)
			{
				SocialAct.diff.AddAchieve("charactersGoT");
			}
			this.scKi.AddAchieve(b.ToString(), AchieveTypes.character);
		}
	}

	// Token: 0x06000299 RID: 665 RVA: 0x000108A0 File Offset: 0x0000EAA0
	private void OpenEndCard(GText quest)
	{
		JukeBox.diff.StopMusic(false);
		JukeBox.diff.FadeOutAmbient();
		JukeBox.diff.FadeOutVO();
		JukeBox.diff.PlaySound(SFXTypes.ui_death_drone, false, false, 2.5f, -1, 1.5f, 1f);
		AudioClip audioClip = (AudioClip)Resources.Load("end_sfx/" + this.card.bearerVariation, typeof(AudioClip));
		if (audioClip != null)
		{
			JukeBox.diff.PlaySound(audioClip, true, false, 2.5f);
		}
		this.cardType = CardTypes.end;
		this.AddSeenEndCard(this.card.bearerVariation);
		this.cardSc = this.endSc;
		this.cardSc.gameObject.SetActive(true);
		this.scCh.ShowName("", "");
		this.cardSc.InitCard(this.card.bearerVariation, "", "", 0, true);
		this.ChangeQuestion(quest, false);
		if (this.card.bearerVariation != "")
		{
			this.cardSc.CustomImage(this.card.bearerVariation, "deaths");
		}
		this.curBearer = null;
		this.scMeters.CheckDanger();
		this.SaveGame();
	}

	// Token: 0x0600029A RID: 666 RVA: 0x000109ED File Offset: 0x0000EBED
	public void DeleteQuestion()
	{
		base.StopCoroutine("DoChangeQuestion");
		base.StartCoroutine("DoChangeQuestion", " ");
		this.scCh.ShowName("", "");
	}

	// Token: 0x0600029B RID: 667 RVA: 0x00010A20 File Offset: 0x0000EC20
	public void ResetQuestion()
	{
		base.StopCoroutine("DoChangeQuestion");
		if (this.card != null)
		{
			base.StartCoroutine("DoChangeQuestion", this.TreatText(this.card.question, false));
		}
	}

	// Token: 0x0600029C RID: 668 RVA: 0x00010A54 File Offset: 0x0000EC54
	public void ChangeQuestion(GText text, bool withCut = false)
	{
		string value = (this.OnQuestion == null) ? this.TreatText(text, false) : this.OnQuestion(this.TreatText(text, false));
		base.StopCoroutine("DoChangeQuestion");
		base.StartCoroutine("DoChangeQuestion", value);
	}

	// Token: 0x0600029D RID: 669 RVA: 0x00010A9F File Offset: 0x0000EC9F
	private IEnumerator DoChangeQuestion(string formatText)
	{
		Vector2 opos = new Vector2(0f, this.questionY);
		Vector2 hidepos = new Vector2(0f, this.questionY - 4f);
		Vector2 showpos = new Vector2(0f, this.questionY + 4f);
		this.question.CrossFadeAlpha(0.01f, 0.3f, true);
		RectTransform qTrans = this.question.rectTransform;
		float t = 0f;
		while (t < 1f)
		{
			qTrans.anchoredPosition = Vector2.Lerp(opos, hidepos, t);
			t += Time.deltaTime * 4f;
			yield return null;
		}
		this.question.text = ((formatText == "<do not translate>") ? " " : formatText);
		this.question.CrossFadeAlpha(1f, 0.6f, true);
		qTrans.anchoredPosition = showpos;
		t = 0f;
		while (t < 1f)
		{
			qTrans.anchoredPosition = Vector2.Lerp(showpos, opos, t);
			t += Time.deltaTime * 4f;
			yield return null;
		}
		qTrans.anchoredPosition = opos;
		yield break;
	}

	// Token: 0x0600029E RID: 670 RVA: 0x00010AB8 File Offset: 0x0000ECB8
	public Card SelectCard(string next, Bearers forcebearer = Bearers.none)
	{
		if (this.card != null)
		{
			this.lastBearerVariation = this.card.bearerVariation;
		}
		List<Card> list = new List<Card>();
		bool smallbatch = false;
		if (this.forceCard != null)
		{
			Card ca = this.forceCard;
			this.forceCard = null;
			return this.CardToReturn(ca, true);
		}
		if (!string.IsNullOrEmpty(next))
		{
			smallbatch = true;
			if (next == "cardId")
			{
				list = this.hiddenCards.FindAll((Card it) => it.id == this.nextCardId);
				this.forcenext = true;
			}
			else
			{
				List<Card> list2 = (next.Substring(0, 1) == "_") ? this.hiddenCards : this.cards;
				if (forcebearer != Bearers.none && forcebearer != Bearers.anyone)
				{
					list = list2.FindAll((Card it) => it.name == next && (it.bearer == forcebearer || it.bearer == Bearers.anyone));
				}
				else
				{
					list = list2.FindAll((Card it) => it.name == next);
				}
			}
			if (list.Count == 0)
			{
				next = (this.nextCard = "");
				smallbatch = false;
				list = this.cards;
			}
			else if (list.Count == 1)
			{
				Card card = list[0];
				if (((card.bearer == Bearers.end || card.bearer == Bearers.anyone || this.HasBearer(card.bearer, Bearers.none, Bearers.none) != null) && this.TestCond(card.conditions)) || this.forcenext)
				{
					this.forcenext = false;
					return this.CardToReturn(card, true);
				}
				next = (this.nextCard = "");
				smallbatch = false;
				list = this.cards;
			}
		}
		else
		{
			list = this.cards;
		}
		return this.ProcessCards(list, smallbatch, true);
	}

	// Token: 0x0600029F RID: 671 RVA: 0x00010CA0 File Offset: 0x0000EEA0
	public Card ProcessCards(List<Card> cardstotest, bool smallbatch, bool failsafe = true)
	{
		List<Card> list = new List<Card>();
		List<int> list2 = new List<int>
		{
			0
		};
		for (int i = 0; i < cardstotest.Count; i++)
		{
			Card card = cardstotest[i];
			bool flag = this.TestCard(card, smallbatch, false);
			if (flag)
			{
				list2.Add(card.weight + list2[list2.Count - 1]);
				list.Add(card);
				if (card.weight == -1)
				{
					return this.CardToReturn(card, failsafe);
				}
			}
			else if (!flag)
			{
				this.ignoredId.Add(card.id);
				if (card.weight != card.weightReal)
				{
					card.weight = card.weightReal;
				}
				if (card.weightNocond > 0)
				{
					list2.Add(card.weightNocond + list2[list2.Count - 1]);
					list.Add(card);
					if (card.weightNocond == -1)
					{
						return this.CardToReturn(card, failsafe);
					}
				}
			}
		}
		if (list.Count == 0)
		{
			if (failsafe)
			{
				return this.CardToReturn(cardstotest[0], failsafe);
			}
			return null;
		}
		else
		{
			if (list.Count == 1)
			{
				return this.CardToReturn(list[0], failsafe);
			}
			float num = (float)Util.RandInt(0, list2[list2.Count - 1]);
			for (int j = 0; j < list2.Count; j++)
			{
				if ((float)list2[j] > num)
				{
					return this.CardToReturn(list[j - 1], failsafe);
				}
			}
			return null;
		}
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x00010E20 File Offset: 0x0000F020
	private Card CardToReturn(Card ca, bool failsafe = true)
	{
		this.postponeEvents.RemoveAll((PostponeEvent it) => it.card == ca.name && !string.IsNullOrEmpty(ca.name));
		if (ca.id == 67)
		{
			foreach (Card card in this.cards)
			{
				card.nextturn -= 500;
			}
		}
		if (this.HasBearer(ca.bearer, Bearers.none, Bearers.none) == null)
		{
			this.AddBearer(ca.bearer, null, true);
		}
		if (ca.weight != ca.weightReal)
		{
			ca.weight = ca.weightReal;
		}
		return ca;
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x00010F18 File Offset: 0x0000F118
	private bool TestCard(int id)
	{
		Card card = this.hiddenCards.Find((Card it) => it.id == id);
		return card != null && this.TestCard(card, false, true);
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x00010F58 File Offset: 0x0000F158
	public bool TestCard(Card card, bool smallbatch, bool ignoreBearer = false)
	{
		if (card.isLocked)
		{
			return false;
		}
		if (card.weight == 0 || card.weight == -666)
		{
			return false;
		}
		if (card.bearer == this.lastBearer && !smallbatch && card.bearer != Bearers.anyone)
		{
			return false;
		}
		if (card.bearer == this.scKi.monarch.bearer && !this.isafterdeath)
		{
			return false;
		}
		Bearers cabear = card.bearer;
		Bearers bearers = card.bearerIsAlso;
		Bearers bearerIsNot = card.bearerIsNot;
		Bearer bearer;
		if (cabear == Bearers.anyone && bearers != Bearers.none)
		{
			bearer = this.HasBearer(bearers, Bearers.none, Bearers.none);
			bearers = Bearers.none;
		}
		else
		{
			bearer = this.HasBearer(cabear, Bearers.none, Bearers.none);
		}
		if (!this.isafterdeath && bearer == null && this.postponeEvents.Find((PostponeEvent it) => it.bear == card.bearer) != null)
		{
			return false;
		}
		if (!this.isafterdeath && !ignoreBearer)
		{
			if (bearer == null)
			{
				if (cabear != Bearers.end && cabear != Bearers.anyone && cabear != Bearers.none && card.conditions.Find((Condition it) => it.bearer == cabear && it.variable == Variables.set && it.condition == Conditions.notequal) == null)
				{
					return false;
				}
				if (bearers != Bearers.none && !this.reader.HasModelCharacter(cabear, bearers))
				{
					return false;
				}
				if (bearerIsNot != Bearers.none && this.reader.HasModelCharacter(cabear, bearerIsNot))
				{
					return false;
				}
			}
			else
			{
				if (bearers != Bearers.none && !bearer.character.Contains(bearers))
				{
					return false;
				}
				if (bearerIsNot != Bearers.none && bearer.character.Contains(bearerIsNot))
				{
					return false;
				}
			}
		}
		if (card.nextturn > this.turns)
		{
			return false;
		}
		bool flag = this.TestCond(card.conditions);
		if (flag && card.weightVar != 0)
		{
			card.weight = Mathf.Clamp(card.weight + card.weightVar, 0, 10000000);
		}
		return flag;
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x000111A8 File Offset: 0x0000F3A8
	public bool TestCond(List<Condition> conditions)
	{
		bool flag = true;
		using (List<Condition>.Enumerator enumerator = conditions.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Condition cond = enumerator.Current;
				Bearer bearer = this.HasBearer(cond.bearer, Bearers.none, Bearers.none);
				switch (cond.condition)
				{
				case Conditions.above:
					if (cond.bearer != Bearers.none)
					{
						if (bearer == null)
						{
							flag = false;
						}
						else if (bearer.vote < (float)cond.value)
						{
							flag = false;
						}
					}
					else if (this.GetVal(cond.variable, cond.custom_name) < cond.value)
					{
						flag = false;
					}
					break;
				case Conditions.below:
					if (cond.bearer != Bearers.none)
					{
						if (bearer == null)
						{
							flag = false;
						}
						else if (bearer.vote > (float)cond.value)
						{
							flag = false;
						}
					}
					else if (this.GetVal(cond.variable, cond.custom_name) > cond.value)
					{
						flag = false;
					}
					break;
				case Conditions.equal:
					if (cond.variable == Variables.seen)
					{
						if (cond.bearer != Bearers.none)
						{
							if (!this.seenBearers.Contains(cond.bearer))
							{
								flag = false;
							}
						}
						else if (!this.seenCards.Contains(cond.value))
						{
							flag = false;
						}
					}
					else if (cond.variable == Variables.chain)
					{
						if (cond.bearer == Bearers.none && this.lastcardId != cond.value)
						{
							flag = false;
						}
						else if (cond.bearer != Bearers.none && this.lastBearer != cond.bearer)
						{
							flag = false;
						}
					}
					else if (cond.bearer != Bearers.none)
					{
						if (cond.bearer == Bearers.reigning)
						{
							Bearer monarch = this.scKi.monarch;
							if (cond.bearerIsAlso != Bearers.none && cond.bearerIsAlso != monarch.bearer && !monarch.character.Contains(cond.bearerIsAlso))
							{
								flag = false;
							}
							else if (cond.bearerIsNot != Bearers.none && (cond.bearerIsNot == monarch.bearer || monarch.character.Contains(cond.bearerIsNot)))
							{
								flag = false;
							}
						}
						else if (bearer == null)
						{
							flag = false;
						}
						else if (cond.bearerIsAlso != Bearers.none && !bearer.character.Contains(cond.bearerIsAlso))
						{
							flag = false;
						}
						else if (cond.bearerIsNot != Bearers.none && bearer.character.Contains(cond.bearerIsNot))
						{
							flag = false;
						}
					}
					else if (this.GetVal(cond.variable, cond.custom_name) != cond.value)
					{
						flag = false;
					}
					break;
				case Conditions.round:
					if (cond.bearer != Bearers.none)
					{
						Bearer bearer2 = this.reader.bearerModels.Find((Bearer it) => it.bearer == cond.bearer);
						if (cond.bearerIsAlso != Bearers.none && !bearer2.character.Contains(cond.bearerIsAlso))
						{
							flag = false;
						}
						else if (cond.bearerIsNot != Bearers.none && bearer2.character.Contains(cond.bearerIsNot))
						{
							flag = false;
						}
						if (cond.bearer == Bearers.stark && cond.bearerIsNot == Bearers.antagonist)
						{
						}
					}
					else if (this.GetVal(cond.variable, cond.custom_name) % cond.value != 0)
					{
						flag = false;
					}
					break;
				case Conditions.notequal:
					if (cond.variable == Variables.seen)
					{
						if (cond.bearer != Bearers.none)
						{
							if (this.seenBearers.Contains(cond.bearer))
							{
								flag = false;
							}
						}
						else if (this.seenCards.Contains(cond.value))
						{
							flag = false;
						}
					}
					else if (cond.bearer != Bearers.none)
					{
						if (bearer != null)
						{
							flag = false;
						}
					}
					else if (cond.variable == Variables.chain)
					{
						if (this.card == null)
						{
							flag = false;
						}
						else if (this.TestCard(cond.value))
						{
							flag = false;
						}
					}
					else if (this.GetVal(cond.variable, cond.custom_name) == cond.value)
					{
						flag = false;
					}
					break;
				}
				if (!cond.orlimit && !flag)
				{
					return false;
				}
				if (cond.orlimit && flag)
				{
					return true;
				}
			}
		}
		return flag;
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x00011768 File Offset: 0x0000F968
	private int GetVal(Variables var, string customname)
	{
		if (!string.IsNullOrEmpty(customname))
		{
			return this.GetInt(customname);
		}
		return this.GetInt(var);
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x00011781 File Offset: 0x0000F981
	private void DestroyCard(Card card)
	{
		this.cardtoberemoved = card;
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x0001178C File Offset: 0x0000F98C
	private void DoDestroy()
	{
		if (this.cardtoberemoved != null)
		{
			this.cardtoberemoved.weight = (this.cardtoberemoved.weightReal = -666);
			this.cardtoberemoved.weightVar = 0;
			this.cardtoberemoved = null;
		}
		if (this.bearertoremove != Bearers.none)
		{
			this.RemoveBearer(this.bearertoremove);
			this.bearertoremove = Bearers.none;
		}
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x000117F8 File Offset: 0x0000F9F8
	public string TreatText(GText text, bool withcut = false)
	{
		string text2 = text.Get();
		bool maleSelf = true;
		foreach (KeyValuePair<Bearers, Bearer> keyValuePair in this.roles)
		{
			string value = "<" + keyValuePair.Key.ToString() + ">";
			if (text2.Contains(value) && keyValuePair.Value.character.Contains(Bearers.female))
			{
				maleSelf = false;
			}
		}
		string value2 = "<self>";
		if (text2.Contains(value2) && this.curBearer != null && this.curBearer.character.Contains(Bearers.female))
		{
			maleSelf = false;
		}
		return this.TreatText(text.Get(SpeechAct.diff.isMonarkMale, maleSelf), withcut);
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x000118DC File Offset: 0x0000FADC
	public string TreatText(string input, bool withcut = false)
	{
		foreach (KeyValuePair<Bearers, Bearer> keyValuePair in this.roles)
		{
			string text = "<" + keyValuePair.Key.ToString() + ">";
			if (input.Contains(text))
			{
				Bearer value = keyValuePair.Value;
				if (value != null)
				{
					input = input.Replace(text, value.generated.Get());
				}
			}
		}
		string value2 = "<self>";
		if (input.Contains(value2) && this.curBearer != null)
		{
			input = input.Replace(base.tag, this.curBearer.generated.Get());
		}
		foreach (DataCustom dataCustom in this.dataCustom)
		{
			string text2 = "<" + dataCustom.var + ">";
			if (input.Contains(text2))
			{
				input = input.Replace(text2, dataCustom.val.ToString());
			}
		}
		if (this.curBearer != null)
		{
			input = input.Replace("<anyone>", this.curBearer.name);
		}
		if (input.Contains("€"))
		{
			input = input.Remove(input.IndexOf("€"), 1);
		}
		if (input.Contains("$"))
		{
			input = input.Split(new char[]
			{
				'$'
			}, StringSplitOptions.None)[1];
		}
		return input;
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x00011A88 File Offset: 0x0000FC88
	public void LockCards(Condition cond, bool locked = true)
	{
		string name = cond.custom_name;
		Predicate<Condition> <>9__0;
		Predicate<Condition> <>9__1;
		Predicate<Condition> <>9__2;
		for (int i = 0; i < 2; i++)
		{
			List<Card> list = (i == 0) ? this.hiddenCards : this.cards;
			for (int j = 0; j < list.Count; j++)
			{
				Card card = list[j];
				if (cond.bearer == Bearers.none)
				{
					if (cond.variable == Variables.chain)
					{
						if (card.name == cond.custom_name)
						{
							card.isLocked = locked;
						}
					}
					else
					{
						List<Condition> conditions = card.conditions;
						Predicate<Condition> match;
						if ((match = <>9__0) == null)
						{
							match = (<>9__0 = ((Condition it) => it.condition == Conditions.notequal && it.value == cond.value));
						}
						if (conditions.Find(match) != null)
						{
							card.isLocked = locked;
						}
						else
						{
							List<Condition> conditions2 = card.conditions;
							Predicate<Condition> match2;
							if ((match2 = <>9__1) == null)
							{
								match2 = (<>9__1 = ((Condition it) => it.condition == Conditions.equal && it.value == -1 && it.custom_name == name));
							}
							if (conditions2.Find(match2) != null)
							{
								card.isLocked = locked;
							}
						}
					}
				}
				else
				{
					List<Condition> conditions3 = card.conditions;
					Predicate<Condition> match3;
					if ((match3 = <>9__2) == null)
					{
						match3 = (<>9__2 = ((Condition it) => it.condition == Conditions.notequal && it.value == 0 && it.bearer == cond.bearer));
					}
					if (conditions3.Find(match3) != null)
					{
						card.isLocked = locked;
					}
				}
			}
		}
	}

	// Token: 0x060002AA RID: 682 RVA: 0x00011BEC File Offset: 0x0000FDEC
	public void LockCardsOutcome(Condition cond, bool locked = true)
	{
		string name = cond.custom_name;
		Predicate<Outcome> <>9__0;
		Predicate<Outcome> <>9__1;
		Predicate<Outcome> <>9__2;
		Predicate<Outcome> <>9__3;
		for (int i = 0; i < 2; i++)
		{
			List<Card> list = (i == 0) ? this.hiddenCards : this.cards;
			for (int j = 0; j < list.Count; j++)
			{
				Card card = list[j];
				if (cond.bearer == Bearers.none)
				{
					List<Outcome> yes_outcomes = card.yes_outcomes;
					Predicate<Outcome> match;
					if ((match = <>9__0) == null)
					{
						match = (<>9__0 = ((Outcome it) => it.value == -1 && it.custom_name == name));
					}
					if (yes_outcomes.Find(match) == null)
					{
						List<Outcome> no_outcomes = card.no_outcomes;
						Predicate<Outcome> match2;
						if ((match2 = <>9__1) == null)
						{
							match2 = (<>9__1 = ((Outcome it) => it.value == -1 && it.custom_name == name));
						}
						if (no_outcomes.Find(match2) == null)
						{
							goto IL_127;
						}
					}
					card.isLocked = locked;
				}
				else
				{
					List<Outcome> yes_outcomes2 = card.yes_outcomes;
					Predicate<Outcome> match3;
					if ((match3 = <>9__2) == null)
					{
						match3 = (<>9__2 = ((Outcome it) => it.variable == Variables.remove && it.bearer == cond.bearer));
					}
					if (yes_outcomes2.Find(match3) == null)
					{
						List<Outcome> no_outcomes2 = card.no_outcomes;
						Predicate<Outcome> match4;
						if ((match4 = <>9__3) == null)
						{
							match4 = (<>9__3 = ((Outcome it) => it.variable == Variables.remove && it.bearer == cond.bearer));
						}
						if (no_outcomes2.Find(match4) == null)
						{
							goto IL_127;
						}
					}
					card.isLocked = locked;
				}
				IL_127:;
			}
		}
	}

	// Token: 0x060002AB RID: 683 RVA: 0x00011D3B File Offset: 0x0000FF3B
	public List<Bearer> GetRegularBearers()
	{
		return CardReader.diff.bearerModels.FindAll((Bearer it) => it.type == BearerTypes.special || it.type == BearerTypes.individual || it.type == BearerTypes.generated);
	}

	// Token: 0x060002AC RID: 684 RVA: 0x00011D6B File Offset: 0x0000FF6B
	public int GetCardsNb()
	{
		return this.hiddenCards.Count + this.cards.Count;
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00011D84 File Offset: 0x0000FF84
	public int GetSeenCardsNb()
	{
		return this.seenCards.Count;
	}

	// Token: 0x060002AE RID: 686 RVA: 0x00011D94 File Offset: 0x0000FF94
	private void Equalize()
	{
		this.SetInt(Variables.faith, 50);
		this.SetInt(Variables.power, 50);
		this.SetInt(Variables.money, 50);
		this.SetInt(Variables.people, 50);
		this.SetInt(Variables.overall, 50);
		this.SetInt(Variables.war, 0);
	}

	// Token: 0x060002AF RID: 687 RVA: 0x00011DE1 File Offset: 0x0000FFE1
	private void Equalize(Variables var)
	{
		this.SetInt(var, 50);
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x00011DF0 File Offset: 0x0000FFF0
	private float GetVote(Bearers bearer)
	{
		Bearer bearer2 = this.bearers.Find((Bearer it) => it.bearer == bearer);
		if (bearer2 != null)
		{
			return bearer2.vote;
		}
		return 0f;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x00011E34 File Offset: 0x00010034
	private void SetDefaultVariable(Variables var)
	{
		DataVariable dataVariable = this.dataVar.Find((DataVariable it) => it.var == var);
		if (dataVariable != null)
		{
			this.SetDefaultVariable(dataVariable);
		}
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x00011E70 File Offset: 0x00010070
	private void SetDefaultVariable(DataVariable data)
	{
		data.val = this.GetDefaultVariable(data.var);
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x00011E84 File Offset: 0x00010084
	private int GetDefaultVariable(Variables var)
	{
		if (var == Variables.age)
		{
			return this.startage;
		}
		if (var != Variables.year)
		{
			return 0;
		}
		return this.startyear;
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x00011EA2 File Offset: 0x000100A2
	public bool GetBool(string var)
	{
		return this.GetInt(var) == 1;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00011EB4 File Offset: 0x000100B4
	public int GetInt(Variables var)
	{
		DataVariable dataVariable = this.dataVar.Find((DataVariable it) => it.var == var);
		if (dataVariable == null)
		{
			int defaultVariable = this.GetDefaultVariable(var);
			this.dataVar.Add(new DataVariable(var, defaultVariable));
			return defaultVariable;
		}
		return dataVariable.val;
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00011F18 File Offset: 0x00010118
	public int GetInt(string var)
	{
		DataCustom dataCustom = this.dataCustom.Find((DataCustom it) => it.var == var);
		if (dataCustom == null)
		{
			return 0;
		}
		return dataCustom.val;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x00011F58 File Offset: 0x00010158
	public void SetBool(string var, bool boo)
	{
		int num = boo ? 1 : -1;
		DataCustom dataCustom = this.dataCustom.Find((DataCustom it) => it.var == var);
		if (dataCustom == null)
		{
			this.dataCustom.Add(new DataCustom(var, num));
			return;
		}
		dataCustom.val = num;
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00011FB4 File Offset: 0x000101B4
	public bool SetInt(Variables var, int val)
	{
		DataVariable dataVariable = this.dataVar.Find((DataVariable it) => it.var == var);
		if (dataVariable == null)
		{
			this.dataVar.Add(new DataVariable(var, val));
		}
		else
		{
			if (dataVariable.val == val)
			{
				return false;
			}
			dataVariable.val = val;
		}
		return true;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00012018 File Offset: 0x00010218
	public bool SetInt(string var, int val)
	{
		DataCustom dataCustom = this.dataCustom.Find((DataCustom it) => it.var == var);
		if (dataCustom == null)
		{
			this.dataCustom.Add(new DataCustom(var, val));
		}
		else
		{
			if (dataCustom.val == val)
			{
				return false;
			}
			dataCustom.val = val;
		}
		return true;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x0001207C File Offset: 0x0001027C
	public void AddInt(Variables var, int val)
	{
		DataVariable dataVariable = this.dataVar.Find((DataVariable it) => it.var == var);
		if (dataVariable == null)
		{
			this.dataVar.Add(new DataVariable(var, val));
			return;
		}
		dataVariable.val = Mathf.Clamp(dataVariable.val + val, 0, 99999999);
	}

	// Token: 0x060002BB RID: 699 RVA: 0x000120E4 File Offset: 0x000102E4
	public void AddInt(string var, int val)
	{
		DataCustom dataCustom = this.dataCustom.Find((DataCustom it) => it.var == var);
		if (dataCustom.val + val < 0)
		{
			dataCustom.val = 0;
			return;
		}
		dataCustom.val += val;
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00012137 File Offset: 0x00010337
	public int GetAge()
	{
		return this.GetInt(Variables.age);
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00012140 File Offset: 0x00010340
	public int GetYear()
	{
		return this.GetInt(Variables.year);
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00012149 File Offset: 0x00010349
	public bool IsMaxAge(int age)
	{
		if (age >= this.maxage)
		{
			this.maxage = age;
			return true;
		}
		return false;
	}

	// Token: 0x060002BF RID: 703 RVA: 0x00012160 File Offset: 0x00010360
	public bool Has(string var)
	{
		DataCustom dataCustom = this.dataCustom.Find((DataCustom it) => it.var == var);
		return dataCustom != null && dataCustom.val > 0;
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x000121A4 File Offset: 0x000103A4
	private bool Has(Variables var)
	{
		DataVariable dataVariable = this.dataVar.Find((DataVariable it) => it.var == var);
		return dataVariable != null && dataVariable.val > 0;
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x000121E8 File Offset: 0x000103E8
	public void AddKnownVariable(Variables var)
	{
		if (this.dataVar.Find((DataVariable it) => it.var == var) != null)
		{
			return;
		}
		int defaultVariable = this.GetDefaultVariable(var);
		this.dataVar.Add(new DataVariable(var, defaultVariable));
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00012240 File Offset: 0x00010440
	private void SetDefaultCustom(DataCustom data)
	{
		data.val = this.GetDefaultCustom(data.var);
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00012254 File Offset: 0x00010454
	private int GetDefaultCustom(string var)
	{
		if (!var.StartsWith("nb_") && !var.StartsWith("inc_"))
		{
			return -1;
		}
		return 0;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x00012274 File Offset: 0x00010474
	public void AddCustomVariable(string var)
	{
		if (this.dataCustom.Find((DataCustom it) => it.var == var) != null)
		{
			return;
		}
		if (var.StartsWith("inc_"))
		{
			this.incrCustom.Add(var);
		}
		this.dataCustom.Add(new DataCustom(var, this.GetDefaultCustom(var)));
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x000122ED File Offset: 0x000104ED
	public void AddEndCard(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return;
		}
		if (!this.endCards.Contains(name))
		{
			this.endCards.Add(name);
		}
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00012314 File Offset: 0x00010514
	private void AddSeenEndCard(string name)
	{
		if (!this.seenEndCards.Contains(name))
		{
			this.seenEndCards.Add(name);
			if (this.seenEndCards.Count == this.endCards.Count)
			{
				SocialAct.diff.AddAchieve("deathsGoT");
			}
			this.scKi.AddAchieve(name, AchieveTypes.endcard);
			if (this.seenEndCards.Count > 1)
			{
				this.PlayModal(ModalTypes.death, string.Concat(new string[]
				{
					this.seenEndCards.Count.ToString(),
					" / ",
					this.endCards.Count.ToString(),
					" ",
					SpeechAct.diff.GetSceneText("endcard_stats", 1)
				}), 0f, SpeechAct.diff.GetSceneText("end_" + name), true);
			}
		}
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x000123FD File Offset: 0x000105FD
	public void ForceDecision()
	{
		this.ValidateDecision();
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x00012408 File Offset: 0x00010608
	private void ValidateDecision()
	{
		if (this.OnCardClose != null)
		{
			this.OnCardClose(this.decision);
		}
		if (this.cardType == CardTypes.end)
		{
			this.EndReign(false);
		}
		this.AddOutcomes();
		if (this.state != GameStates.gameover)
		{
			this.state = GameStates.transition;
		}
		this.decision = -10;
		this.onlyNo = (this.onlyYes = false);
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x0001246C File Offset: 0x0001066C
	private List<Outcome> GetOutcomeList(int dec)
	{
		if (dec == -1)
		{
			return this.card.no_outcomes;
		}
		if (dec == 1)
		{
			return this.card.yes_outcomes;
		}
		if (dec != 2)
		{
			return this.null_outcomes;
		}
		return this.card.load_outcomes;
	}

	// Token: 0x060002CA RID: 714 RVA: 0x000124A4 File Offset: 0x000106A4
	private void UpdateDecision(int dec)
	{
		this.decision = dec;
		if (this.card == null)
		{
			return;
		}
		this.ShowOutcome(this.GetOutcomeList(dec));
	}

	// Token: 0x060002CB RID: 715 RVA: 0x000124C3 File Offset: 0x000106C3
	public string GetCurCardName()
	{
		if (this.card == null)
		{
			return "";
		}
		return this.card.name;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x000124E0 File Offset: 0x000106E0
	public float GetCurCardOutcome(bool yes, Variables variab)
	{
		if (this.card == null)
		{
			return 0f;
		}
		Outcome outcome = (yes ? this.card.yes_outcomes : this.card.no_outcomes).Find((Outcome it) => it.variable == variab);
		if (outcome != null)
		{
			return (float)outcome.value;
		}
		return 0f;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x00012545 File Offset: 0x00010745
	public void HideOutcome()
	{
		this.ShowOutcome(this.null_outcomes);
	}

	// Token: 0x060002CE RID: 718 RVA: 0x00012553 File Offset: 0x00010753
	private void ShowOutcome(List<Outcome> outco)
	{
		this.scMeters.ShowOutcome(outco, this.curBearer, false);
	}

	// Token: 0x060002CF RID: 719 RVA: 0x00012568 File Offset: 0x00010768
	private void InitNumbers()
	{
		this.scMeters.SetDefault();
		this.SetData(false);
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x0001257C File Offset: 0x0001077C
	public void ShowDataCol(bool yes)
	{
		this.scMeters.ShowAllData(yes);
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0001258A File Offset: 0x0001078A
	public void SetIntercale(string source)
	{
		this.intercale = this.TreatText(source, false);
		this.cardType = CardTypes.intercale;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x000125A1 File Offset: 0x000107A1
	public void SetIntercale(GText source)
	{
		this.intercale = this.TreatText(source, false);
		this.cardType = CardTypes.intercale;
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x000125B8 File Offset: 0x000107B8
	private void AddOutcomes()
	{
		if (this.nextCard == "force_end")
		{
			this.nextCard = "";
			this.cardType = CardTypes.end;
			this.EndReign(true);
			return;
		}
		if (this.decision == 0 || this.card == null)
		{
			return;
		}
		if (string.IsNullOrEmpty(this.card.name))
		{
			return;
		}
		if (this.cardType != CardTypes.duel)
		{
			this.nextCard = "";
			if (this.decision == -1 && !this.card.answer_no.isEmpty)
			{
				if (this.card.no_outcomes.Find((Outcome it) => it.variable == Variables.chain && it.custom_name.EndsWith("_choice")) != null)
				{
					this.ChangeQuestion(this.card.answer_no, false);
				}
				else
				{
					this.SetIntercale(this.card.answer_no);
				}
			}
			else if (this.decision == 1 && !this.card.answer_yes.isEmpty)
			{
				if (this.card.yes_outcomes.Find((Outcome it) => it.variable == Variables.chain && it.custom_name.EndsWith("_choice")) != null)
				{
					this.ChangeQuestion(this.card.answer_yes, false);
				}
				else
				{
					this.SetIntercale(this.card.answer_yes);
				}
			}
			if (this.curBearer != null && this.curBearer.hasVote)
			{
				float vote = this.curBearer.vote;
				this.curBearer.vote = Mathf.Clamp(vote / 2f + (float)(this.decision * 2), -5f, 5f);
			}
			this.TreatOutcomes(this.decision);
			this.NewYear(false);
			this.turns++;
			if (this.nextCard == "")
			{
				int @int = this.GetInt(Variables.power);
				int int2 = this.GetInt(Variables.faith);
				int int3 = this.GetInt(Variables.money);
				int int4 = this.GetInt(Variables.people);
				if (@int == 0 || @int == 100 || int2 == 0 || int2 == 100 || int3 == 0 || int3 == 100 || int4 == 0 || int4 == 100)
				{
					return;
				}
				List<PostponeEvent> list = this.postponeEvents.FindAll((PostponeEvent it) => it.year <= this.GetInt(Variables.year));
				if (list.Count > 0)
				{
					PostponeEvent postponeEvent = list[0];
					if (postponeEvent.bear == Bearers.none)
					{
						this.SetNextCard(postponeEvent.card);
					}
					this.postponeEvents.Remove(postponeEvent);
				}
			}
			return;
		}
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x00012834 File Offset: 0x00010A34
	private void TreatOutcomes(int decision)
	{
		List<Outcome> outcomeList = this.GetOutcomeList(decision);
		this.TreatOutcomes(outcomeList, decision);
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x00012854 File Offset: 0x00010A54
	public void TreatOutcomes(List<Outcome> outco, int decision = -1)
	{
		bool flag = false;
		Dictionary<Variables, int> dictionary = new Dictionary<Variables, int>();
		for (int i = outco.Count - 1; i > -1; i--)
		{
			Outcome outcome = outco[i];
			bool flag2 = false;
			if (outcome.orlimit)
			{
				if (Util.Rand(0f, 1f) > 0.5f)
				{
					flag2 = true;
				}
				else
				{
					flag = true;
				}
			}
			if (flag)
			{
				flag = false;
			}
			else
			{
				if (flag2)
				{
					flag = true;
				}
				string custom_name = outcome.custom_name;
				switch (outcome.variable)
				{
				case Variables.custom:
					if (string.IsNullOrEmpty(custom_name))
					{
						goto IL_394;
					}
					if (custom_name == "mus_stop")
					{
						JukeBox.diff.StopMusic(false);
						goto IL_394;
					}
					if (outcome.bearer != Bearers.none)
					{
						JukeBox.diff.PlayMusic(outcome.bearer, false);
						goto IL_394;
					}
					if (!custom_name.StartsWith("nb_") && !custom_name.StartsWith("inc_"))
					{
						this.SetInt(custom_name, outcome.value);
						goto IL_394;
					}
					if (outcome.value == 0)
					{
						this.SetInt(custom_name, 0);
						goto IL_394;
					}
					this.AddInt(custom_name, outcome.value);
					goto IL_394;
				case Variables.chain:
					if (outcome.value > 0)
					{
						this.postponeEvents.Add(new PostponeEvent(this.GetInt(Variables.year) + outcome.value, custom_name));
						goto IL_394;
					}
					if (decision != 2)
					{
						this.SetNextCard(custom_name);
						goto IL_394;
					}
					goto IL_394;
				case Variables.add:
					this.AddBearer(outcome.bearer, null, true);
					goto IL_394;
				case Variables.remove:
					if (string.IsNullOrEmpty(custom_name))
					{
						this.bearertoremove = ((outcome.bearer == Bearers.anyone) ? this.curBearer.bearer : outcome.bearer);
						goto IL_394;
					}
					if (custom_name == "self" || custom_name == "anyone")
					{
						this.RemoveChara(outcome.bearer, this.curBearer.bearer);
						goto IL_394;
					}
					this.RemoveChara(outcome.bearer, (Bearers)Enum.Parse(typeof(Bearers), custom_name));
					goto IL_394;
				case Variables.set:
					if (outcome.bearer == Bearers.none)
					{
						if (decision == 2)
						{
							BackgroundAct.diff.PrepareBackSwitch(custom_name, outcome.value, false, true);
							goto IL_394;
						}
						BackgroundAct.diff.PrepareBackSwitch(custom_name, outcome.value, false, false);
						goto IL_394;
					}
					else
					{
						if (custom_name == "self" || custom_name == "anyone")
						{
							this.AddChara(outcome.bearer, this.curBearer);
							goto IL_394;
						}
						this.AddChara(outcome.bearer, (Bearers)Enum.Parse(typeof(Bearers), custom_name));
						goto IL_394;
					}
					break;
				case Variables.destroy:
					if (outcome.bearer != Bearers.none)
					{
						this.bearertoremove = outcome.bearer;
						JukeBox.diff.PlaySound(SFXTypes.sfx_kill_character, false, false, 2.5f, -1, 1.5f, 1f);
						goto IL_394;
					}
					this.DestroyCard(this.card);
					goto IL_394;
				case Variables.people:
				case Variables.faith:
				case Variables.power:
				case Variables.money:
					dictionary.Add(outcome.variable, outcome.value);
					goto IL_394;
				}
				if (!string.IsNullOrEmpty(custom_name))
				{
					if (this.SetInt(outcome.custom_name, outcome.value) && outcome.variable != Variables.custom)
					{
						if (outcome.value == 0)
						{
							this.AddInt(outcome.variable, -1);
						}
						else
						{
							this.AddInt(outcome.variable, 1);
						}
					}
				}
				else
				{
					this.SetInt(outcome.variable, outcome.value);
				}
			}
			IL_394:;
		}
		JukeBox.diff.PlayValues(dictionary);
		if (decision == 2)
		{
			this.scMeters.ShowOutcome(outco, this.curBearer, true);
			return;
		}
		this.scMeters.ResolveAddition();
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00012C30 File Offset: 0x00010E30
	public void NewYear(bool force = false)
	{
		bool flag = this.GetInt(Variables.passturn) == 1;
		if (force || flag || (this.cardType != CardTypes.intercale && this.nextCard == "" && this.cardType != CardTypes.end))
		{
			if (flag)
			{
				this.SetInt(Variables.passturn, -1);
			}
			this.AddInt(Variables.year, 1);
			this.AddInt(Variables.age, 1);
			this.SetData(true);
			JukeBox.diff.PlaySound(SFXTypes.ui_ageup, false, false, 2.5f, -1, 1.5f, 1f);
		}
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00012CB8 File Offset: 0x00010EB8
	private void SetNextCard(string name)
	{
		if (name == "previous")
		{
			if (this.lastCard != null)
			{
				this.OpenCard(this.lastCard);
			}
			return;
		}
		if (name == "force_gameover")
		{
			this.state = GameStates.gameover;
			this.scKi.OpenOptions(true);
			return;
		}
		this.nextCard = name;
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x00012D10 File Offset: 0x00010F10
	private void SetData(bool kingupdate = true)
	{
		int @int = this.GetInt(Variables.age);
		if (SpeechAct.diff.lang == "jp")
		{
			this.ageSign.text = SpeechAct.diff.JapanNum("time_in_power", @int);
		}
		else
		{
			this.ageSign.text = @int.ToString();
			this.inpower.text = SpeechAct.diff.GetSceneNum("time_in_power", @int);
		}
		base.StartCoroutine("AnimData", this.ageSign);
		if (@int > 99)
		{
			this.agetxt.anchoredPosition = new Vector2(this.agexpos + 28f, this.agetxt.anchoredPosition.y);
			return;
		}
		if (@int > 9)
		{
			this.agetxt.anchoredPosition = new Vector2(this.agexpos + 14f, this.agetxt.anchoredPosition.y);
			return;
		}
		this.agetxt.anchoredPosition = new Vector2(this.agexpos, this.agetxt.anchoredPosition.y);
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x00012E21 File Offset: 0x00011021
	public void SetRulerName(string newname)
	{
		this.kingSign.text = newname;
		base.StartCoroutine("AnimData", this.kingSign);
	}

	// Token: 0x060002DA RID: 730 RVA: 0x00012E41 File Offset: 0x00011041
	private IEnumerator AnimData(Text target)
	{
		float t = 0f;
		target.rectTransform.localScale = new Vector3(1.6f, 1.6f, 1.6f);
		Vector3 tscal = new Vector3(1f, 1f, 1f);
		target.color = Color.white;
		while (t < 1f)
		{
			target.color = Color.Lerp(Color.white, this.textcol, t);
			target.rectTransform.localScale = Vector3.Lerp(target.rectTransform.localScale, tscal, 0.1f);
			t += Time.deltaTime;
			yield return null;
		}
		target.rectTransform.localScale = tscal;
		target.color = this.textcol;
		yield break;
	}

	// Token: 0x060002DB RID: 731 RVA: 0x00012E57 File Offset: 0x00011057
	public void AddEffectCard(Effect effect)
	{
		this.cardType = CardTypes.effect;
		this.cardSc = this.effectSc;
		this.cardSc.gameObject.SetActive(true);
		this.curEffect = effect;
	}

	// Token: 0x060002DC RID: 732 RVA: 0x00012E84 File Offset: 0x00011084
	private void DisplayEffectCard()
	{
		this.cardSc.gameObject.SetActive(true);
		this.cardSc.GetComponent<EffectCard>().InitEffect(this.curEffect, this.curdec);
		this.cardType = CardTypes.character;
		this.card = null;
	}

	// Token: 0x060002DD RID: 733 RVA: 0x00012EC4 File Offset: 0x000110C4
	public ModalAct PlayModal(ModalTypes type, object instance, float delay = 0f, string txtid = "", bool decal = true)
	{
		if (instance == this.lastinstance && this.modalsToFire.Count == 1)
		{
			return null;
		}
		this.lastinstance = instance;
		GameObject gameObject = Object.Instantiate<GameObject>(this.modalPrefab);
		gameObject.transform.SetParent(this.modalUI, false);
		ModalAct component = gameObject.GetComponent<ModalAct>();
		this.modalsToFire.Add(component);
		component.Init(type, instance, delay, txtid, decal);
		if (this.modalsToFire.Count == 1)
		{
			base.StopCoroutine("FireModals");
			base.StartCoroutine("FireModals");
		}
		return component;
	}

	// Token: 0x060002DE RID: 734 RVA: 0x00012F54 File Offset: 0x00011154
	public void DestroyModals()
	{
		foreach (object obj in this.modalUI)
		{
			Transform transform = (Transform)obj;
			if (transform != null)
			{
				Object.Destroy(transform.gameObject);
			}
		}
		this.modalsToFire = new List<ModalAct>();
	}

	// Token: 0x060002DF RID: 735 RVA: 0x00012FC8 File Offset: 0x000111C8
	private IEnumerator FireModals()
	{
		while (this.modalsToFire.Count > 0)
		{
			ModalAct scmod = this.modalsToFire[0];
			yield return base.StartCoroutine(scmod.Fire());
			this.modalsToFire.RemoveAt(0);
			if (this.OnNewModal != null)
			{
				this.OnNewModal(scmod);
			}
			scmod = null;
		}
		yield break;
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x00012FD7 File Offset: 0x000111D7
	private void ShrinkCards(float amo, Vector2 displace)
	{
		base.StopCoroutine("ResizeCards");
		base.StopCoroutine("DisplaceCards");
		base.StartCoroutine("ResizeCards", amo);
		base.StartCoroutine("DisplaceCards", displace);
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x00013014 File Offset: 0x00011214
	private void ExpandCards()
	{
		base.StopCoroutine("ResizeCards");
		base.StopCoroutine("DisplaceCards");
		base.StartCoroutine("ResizeCards", 1);
		base.StartCoroutine("DisplaceCards", new Vector2(0f, 0f));
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x00013069 File Offset: 0x00011269
	private IEnumerator ResizeCards(float targ)
	{
		float t = 0f;
		Vector3 tSize = new Vector3(targ, targ, 1f);
		while (t < 1f)
		{
			t += Time.deltaTime * 2f;
			this.characterRepo.localScale = Vector3.Lerp(this.characterRepo.localScale, tSize, Easing.QuintEaseOut(t, 0f, 1f, 1f));
			yield return 0;
		}
		this.characterRepo.localScale = tSize;
		yield break;
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x0001307F File Offset: 0x0001127F
	private IEnumerator DisplaceCards(Vector2 targ)
	{
		float t = 0f;
		RectTransform caTrans = this.characterRepo.GetComponent<RectTransform>();
		while (t < 1f)
		{
			t += Time.deltaTime * 2f;
			caTrans.anchoredPosition = Vector3.Lerp(caTrans.anchoredPosition, targ, Easing.QuintEaseOut(t, 0f, 1f, 1f));
			yield return 0;
		}
		caTrans.anchoredPosition = targ;
		yield break;
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x00013098 File Offset: 0x00011298
	private void StartInteraction()
	{
		this.cPo = this.centralPos;
		InputAct.diff.GetSlideFocus(new Action<Vector2>(this.UpdateSlide), new Action(this.StopSlide), new Action<Vector2>(this.StartSlide), new Action<Vector2>(this.ValidSlide), new Func<bool, bool>(this.DownSlide), false, 0.2f, 1f);
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x00013103 File Offset: 0x00011303
	public bool DownSlide(bool down)
	{
		return this.state == GameStates.interaction;
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x00013114 File Offset: 0x00011314
	public void UpdateSlide(Vector2 amo)
	{
		float num = Mathf.Abs(amo.x);
		float f = amo.x;
		if (this.onlyYes)
		{
			f = num;
		}
		if (this.onlyNo)
		{
			f = -num;
		}
		float y = amo.y;
		this.cPo = this.centralPos + new Vector2(Mathf.Sign(f) * Easing.QuintEaseOut(Mathf.Clamp(num * 2.4f, 0f, 1f), 0f, 1f, 1f) * 80f, y * 400f);
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x000131A4 File Offset: 0x000113A4
	public void ValidSlide(Vector2 xp)
	{
		if (this.cardType == CardTypes.selection)
		{
			return;
		}
		if (this.state != GameStates.interaction)
		{
			return;
		}
		this.cPo = this.centralPos;
		this.ValidateDecision();
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x000131CC File Offset: 0x000113CC
	public void StopSlide()
	{
		if (this.cardType == CardTypes.selection)
		{
			return;
		}
		if (this.cardSc != null)
		{
			this.cardSc.ShowDecision(0);
		}
		this.HideDecision(true);
		this.cPo = this.centralPos;
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x00013208 File Offset: 0x00011408
	public void StartSlide(Vector2 amo)
	{
		float num = amo.x;
		if (this.onlyYes)
		{
			num = Mathf.Abs(num);
		}
		if (this.onlyNo)
		{
			num = -Mathf.Abs(num);
		}
		if (num < 0f)
		{
			this.ShowYes();
			return;
		}
		if (num > 0f)
		{
			this.ShowNo();
		}
	}

	// Token: 0x060002EA RID: 746 RVA: 0x00013258 File Offset: 0x00011458
	private void ShowYes()
	{
		this.ShowDec(-1, SFXTypes.card_swipe_left);
	}

	// Token: 0x060002EB RID: 747 RVA: 0x00013263 File Offset: 0x00011463
	private void ShowNo()
	{
		this.ShowDec(1, SFXTypes.card_swipe_right);
	}

	// Token: 0x060002EC RID: 748 RVA: 0x00013270 File Offset: 0x00011470
	private void ShowDec(int dec, SFXTypes sfx)
	{
		if (this.cardType == CardTypes.selection)
		{
			return;
		}
		if (this.decision == dec)
		{
			return;
		}
		this.UpdateDecision(dec);
		if (this.OnChoice != null)
		{
			this.OnChoice(dec);
		}
		if (this.cardSc)
		{
			this.cardSc.ShowDecision(dec);
		}
		JukeBox.diff.PlaySound(sfx, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x060002ED RID: 749 RVA: 0x000132E2 File Offset: 0x000114E2
	private void HideDecision(bool forcenull = false)
	{
		if (this.decision == 0)
		{
			return;
		}
		if (forcenull)
		{
			this.UpdateDecision(0);
		}
		else
		{
			this.UpdateDecision(this.decision);
		}
		if (this.OnChoice != null)
		{
			this.OnChoice(this.decision);
		}
	}

	// Token: 0x060002EE RID: 750 RVA: 0x00013320 File Offset: 0x00011520
	public void OpenCard(string nxt)
	{
		base.StopCoroutine("YieldUntilInteraction");
		this.nextCard = nxt;
		GameStates state = this.state;
		if (state == GameStates.interaction)
		{
			this.state = GameStates.transition;
			return;
		}
		if (state == GameStates.transition)
		{
			base.StartCoroutine("YieldUntilInteraction");
			return;
		}
	}

	// Token: 0x060002EF RID: 751 RVA: 0x00013364 File Offset: 0x00011564
	public void OpenCard(Card nxt)
	{
		if (nxt == null)
		{
			return;
		}
		this.nextCard = nxt.name;
		this.forceCard = nxt;
		this.forcenext = true;
		base.StopCoroutine("YieldUntilInteraction");
		GameStates state = this.state;
		if (state != GameStates.interaction)
		{
			return;
		}
		this.state = GameStates.transition;
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x000133B1 File Offset: 0x000115B1
	private IEnumerator YieldUntilInteraction()
	{
		while (this.state != GameStates.interaction)
		{
			yield return null;
		}
		this.state = GameStates.transition;
		yield break;
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x000133C0 File Offset: 0x000115C0
	private void Update()
	{
		if (this.state != GameStates.interaction)
		{
			return;
		}
		if (this.cardType != CardTypes.selection && this.cardSc != null)
		{
			if (this.decision == 0)
			{
				this.cardSc.LerpToPos(this.cPo, Time.deltaTime * 6f);
			}
			else
			{
				this.cardSc.LerpToPos(this.cPo, Time.deltaTime * 8f);
			}
			this.cardSc.SlerpToPos(this.cPo.x, this.cPo.y);
		}
	}

	// Token: 0x04000351 RID: 849
	public string version = "";

	// Token: 0x04000352 RID: 850
	public string gamename = "reigns_got";

	// Token: 0x04000353 RID: 851
	public CardTypes cardType = CardTypes.character;

	// Token: 0x04000354 RID: 852
	public Text cardIdTxt;

	// Token: 0x04000355 RID: 853
	public int startage;

	// Token: 0x04000356 RID: 854
	private int startyear = 315;

	// Token: 0x04000357 RID: 855
	public CardReader reader;

	// Token: 0x04000358 RID: 856
	public MetersAct scMeters;

	// Token: 0x04000359 RID: 857
	public GameObject charaPrefab;

	// Token: 0x0400035A RID: 858
	public GameObject modalPrefab;

	// Token: 0x0400035B RID: 859
	public GameObject gameUI;

	// Token: 0x0400035C RID: 860
	public Transform modalUI;

	// Token: 0x0400035D RID: 861
	public GameObject interUI;

	// Token: 0x0400035E RID: 862
	public Transform characterRepo;

	// Token: 0x0400035F RID: 863
	public Text question;

	// Token: 0x04000360 RID: 864
	public string intercale;

	// Token: 0x04000361 RID: 865
	public Text yearSign;

	// Token: 0x04000362 RID: 866
	public Text inpower;

	// Token: 0x04000363 RID: 867
	public Text kingSign;

	// Token: 0x04000364 RID: 868
	public Text ageSign;

	// Token: 0x04000365 RID: 869
	public Text nickSign;

	// Token: 0x04000366 RID: 870
	public SVGImage reignSign;

	// Token: 0x04000367 RID: 871
	public WhoAct scCh;

	// Token: 0x04000368 RID: 872
	private string title;

	// Token: 0x04000369 RID: 873
	private string nickname;

	// Token: 0x0400036A RID: 874
	private List<Card> cards = new List<Card>();

	// Token: 0x0400036B RID: 875
	private List<Card> hiddenCards = new List<Card>();

	// Token: 0x0400036C RID: 876
	public List<PostponeEvent> postponeEvents = new List<PostponeEvent>();

	// Token: 0x0400036D RID: 877
	public Card card;

	// Token: 0x0400036E RID: 878
	private List<int> ignoredId = new List<int>();

	// Token: 0x0400036F RID: 879
	private Card forceCard;

	// Token: 0x04000370 RID: 880
	public CardAct cardSc;

	// Token: 0x04000371 RID: 881
	public CardAct intercaleSc;

	// Token: 0x04000372 RID: 882
	public CardAct objectiveSc;

	// Token: 0x04000373 RID: 883
	public CardAct effectSc;

	// Token: 0x04000374 RID: 884
	public CardAct endSc;

	// Token: 0x04000375 RID: 885
	private Card lastCard;

	// Token: 0x04000376 RID: 886
	private int lastcardId = -1;

	// Token: 0x04000377 RID: 887
	private List<Bearers> bearersEnum = new List<Bearers>();

	// Token: 0x04000378 RID: 888
	public List<Bearer> bearers = new List<Bearer>();

	// Token: 0x04000379 RID: 889
	public static GameAct diff;

	// Token: 0x0400037A RID: 890
	private List<string> incrCustom = new List<string>();

	// Token: 0x0400037B RID: 891
	public List<DataCustom> dataCustom = new List<DataCustom>();

	// Token: 0x0400037C RID: 892
	public List<DataVariable> dataVar = new List<DataVariable>();

	// Token: 0x0400037D RID: 893
	public List<string> endCards = new List<string>();

	// Token: 0x0400037E RID: 894
	public List<string> seenEndCards = new List<string>();

	// Token: 0x0400037F RID: 895
	public List<Bearers> seenBearers = new List<Bearers>();

	// Token: 0x04000380 RID: 896
	public List<Bearers> metBearers = new List<Bearers>();

	// Token: 0x04000381 RID: 897
	public List<int> seenCards = new List<int>();

	// Token: 0x04000382 RID: 898
	public float timespent;

	// Token: 0x04000383 RID: 899
	public int decision = -10;

	// Token: 0x04000384 RID: 900
	private Bearer curBearer;

	// Token: 0x04000385 RID: 901
	public Bearers lastBearer = Bearers.none;

	// Token: 0x04000386 RID: 902
	private Card cardtoberemoved;

	// Token: 0x04000387 RID: 903
	private Bearers bearertoremove = Bearers.none;

	// Token: 0x04000388 RID: 904
	private Vector2 centralPos = new Vector2(0f, 100f);

	// Token: 0x04000389 RID: 905
	public int lastage;

	// Token: 0x0400038A RID: 906
	private int maxage;

	// Token: 0x0400038B RID: 907
	public Action<Game> OnSave;

	// Token: 0x0400038C RID: 908
	public Action<Card> OnShortcut;

	// Token: 0x0400038D RID: 909
	public Func<CardTypes, bool> OnCardHiding;

	// Token: 0x0400038E RID: 910
	public Action OnInit;

	// Token: 0x0400038F RID: 911
	public Action<GameStates> OnStart;

	// Token: 0x04000390 RID: 912
	public Action<string> OnLoadOld;

	// Token: 0x04000391 RID: 913
	public Action<Game> OnLoad;

	// Token: 0x04000392 RID: 914
	public Action OnReignEnd;

	// Token: 0x04000393 RID: 915
	public Action OnAfterDeath;

	// Token: 0x04000394 RID: 916
	public Action<ModalAct> OnNewModal;

	// Token: 0x04000395 RID: 917
	public Action<Card> OnUpdate;

	// Token: 0x04000396 RID: 918
	public Action<Card> OnRefresh;

	// Token: 0x04000397 RID: 919
	public Action<int> OnChoice;

	// Token: 0x04000398 RID: 920
	public Action<Bearers> OnCharacter;

	// Token: 0x04000399 RID: 921
	public Action OnUpdateCards;

	// Token: 0x0400039A RID: 922
	public Func<string, string> OnQuestion;

	// Token: 0x0400039B RID: 923
	public Func<bool, bool> OnSuspendStart;

	// Token: 0x0400039C RID: 924
	public Action<int> OnCardClose;

	// Token: 0x0400039D RID: 925
	public Action<Card> OnValidSelection;

	// Token: 0x0400039E RID: 926
	public Action<List<Card>> OnInitSelection;

	// Token: 0x0400039F RID: 927
	public GameObject spinner;

	// Token: 0x040003A0 RID: 928
	private Dictionary<Bearers, Bearer> roles = new Dictionary<Bearers, Bearer>();

	// Token: 0x040003A1 RID: 929
	private GameStates _state = GameStates.none;

	// Token: 0x040003A2 RID: 930
	protected GameStates _oldstate;

	// Token: 0x040003A3 RID: 931
	public string nextCard = "";

	// Token: 0x040003A4 RID: 932
	private int nextCardId = -1;

	// Token: 0x040003A5 RID: 933
	public EffectAct scEf;

	// Token: 0x040003A6 RID: 934
	public bool onlyYes;

	// Token: 0x040003A7 RID: 935
	public bool onlyNo;

	// Token: 0x040003A8 RID: 936
	public KingdomAct scKi;

	// Token: 0x040003A9 RID: 937
	private float questionY;

	// Token: 0x040003AA RID: 938
	private int turns;

	// Token: 0x040003AB RID: 939
	public bool isLive;

	// Token: 0x040003AC RID: 940
	public JukeBox scJu;

	// Token: 0x040003AD RID: 941
	public GameObject logo;

	// Token: 0x040003AE RID: 942
	private RectTransform agetxt;

	// Token: 0x040003AF RID: 943
	private float agexpos;

	// Token: 0x040003B0 RID: 944
	public string lastBearerVariation;

	// Token: 0x040003B1 RID: 945
	public List<CharacterCard> selection;

	// Token: 0x040003B2 RID: 946
	private Color textcol;

	// Token: 0x040003B3 RID: 947
	private bool isOver;

	// Token: 0x040003B4 RID: 948
	public bool isafterdeath;

	// Token: 0x040003B5 RID: 949
	private List<Bearers> unlockedSelection = new List<Bearers>();

	// Token: 0x040003B6 RID: 950
	private int curdec;

	// Token: 0x040003B7 RID: 951
	private List<Outcome> null_outcomes = new List<Outcome>();

	// Token: 0x040003B8 RID: 952
	private List<ModalAct> modalsToFire = new List<ModalAct>();

	// Token: 0x040003B9 RID: 953
	private Effect curEffect;

	// Token: 0x040003BA RID: 954
	private object lastinstance;

	// Token: 0x040003BB RID: 955
	private Vector2 cPo;

	// Token: 0x040003BC RID: 956
	private bool forcenext;
}
