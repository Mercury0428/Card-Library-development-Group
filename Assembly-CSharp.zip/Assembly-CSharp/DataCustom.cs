﻿using System;

// Token: 0x0200004D RID: 77
[Serializable]
public class DataCustom
{
	// Token: 0x06000267 RID: 615 RVA: 0x00002050 File Offset: 0x00000250
	public DataCustom()
	{
	}

	// Token: 0x06000268 RID: 616 RVA: 0x0000E72E File Offset: 0x0000C92E
	public DataCustom(string variable, int value)
	{
		this.var = variable;
		this.val = value;
	}

	// Token: 0x04000347 RID: 839
	public string var;

	// Token: 0x04000348 RID: 840
	public int val;
}
