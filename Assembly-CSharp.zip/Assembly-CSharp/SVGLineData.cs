﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000094 RID: 148
public class SVGLineData
{
	// Token: 0x060004A2 RID: 1186 RVA: 0x0001CD6B File Offset: 0x0001AF6B
	public SVGLineData()
	{
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x0001CD7E File Offset: 0x0001AF7E
	public SVGLineData(List<Vector2> points)
	{
		this._points = points;
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x0001CD98 File Offset: 0x0001AF98
	public SVGLineData(Vector2[] points)
	{
		this._points = new List<Vector2>(points);
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x0001CDB7 File Offset: 0x0001AFB7
	public void Add(Vector2 point)
	{
		this._points.Add(point);
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x0001CDC5 File Offset: 0x0001AFC5
	public void Insert(int index, Vector2 item)
	{
		this._points.Insert(index, item);
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x0001CDD4 File Offset: 0x0001AFD4
	public void Remove(Vector2 point)
	{
		this._points.Remove(point);
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x0001CDE3 File Offset: 0x0001AFE3
	public void RemoveAt(int index)
	{
		this._points.RemoveAt(index);
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x0001CDF1 File Offset: 0x0001AFF1
	public SVGLineData.Edge GetEdge(int index)
	{
		return new SVGLineData.Edge(this._points[index], this._points[index + 1]);
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x0001CE12 File Offset: 0x0001B012
	public int GetEdgeCount()
	{
		if (this._points == null || this._points.Count < 2)
		{
			return 0;
		}
		return this._points.Count - 1;
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x0001CE3C File Offset: 0x0001B03C
	public void UpdateMagnitudes()
	{
		this._totalMagnitude = 0f;
		int edgeCount = this.GetEdgeCount();
		this._magnitudes = new float[edgeCount];
		for (int i = 0; i < edgeCount; i++)
		{
			this._magnitudes[i] = this.GetEdge(i).Magnitude();
			this._totalMagnitude += this._magnitudes[i];
		}
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x0001CEA0 File Offset: 0x0001B0A0
	public void UpdateNormals()
	{
		int edgeCount = this.GetEdgeCount();
		this._normals = new Vector2[edgeCount];
		for (int i = 0; i < edgeCount; i++)
		{
			this._normals[i] = this.GetEdge(i).DirectionNormalized();
		}
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x0001CEE8 File Offset: 0x0001B0E8
	public void UpdateAll()
	{
		int edgeCount = this.GetEdgeCount();
		this._magnitudes = new float[edgeCount];
		this._normals = new Vector2[edgeCount];
		for (int i = 0; i < edgeCount; i++)
		{
			SVGLineData.Edge edge = this.GetEdge(i);
			this._normals[i] = edge.Direction();
			this._magnitudes[i] = Mathf.Sqrt(this._normals[i].x * this._normals[i].x + this._normals[i].y * this._normals[i].y);
			if (this._magnitudes[i] != 0f)
			{
				Vector2[] normals = this._normals;
				int num = i;
				normals[num].x = normals[num].x / this._magnitudes[i];
				Vector2[] normals2 = this._normals;
				int num2 = i;
				normals2[num2].y = normals2[num2].y / this._magnitudes[i];
			}
		}
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x0001CFDE File Offset: 0x0001B1DE
	public void Clear()
	{
		this._points.Clear();
		this._normals = null;
		this._magnitudes = null;
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x0001CFF9 File Offset: 0x0001B1F9
	public Vector2 GetNormal(int index)
	{
		return this._normals[index];
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x0001D007 File Offset: 0x0001B207
	public float GetMagnitude(int index)
	{
		return this._magnitudes[index];
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060004B1 RID: 1201 RVA: 0x0001D011 File Offset: 0x0001B211
	public float totalMagnitude
	{
		get
		{
			return this._totalMagnitude;
		}
	}

	// Token: 0x04000566 RID: 1382
	public List<Vector2> _points = new List<Vector2>();

	// Token: 0x04000567 RID: 1383
	protected float[] _magnitudes;

	// Token: 0x04000568 RID: 1384
	protected Vector2[] _normals;

	// Token: 0x04000569 RID: 1385
	protected float _totalMagnitude;

	// Token: 0x02000322 RID: 802
	public struct Edge
	{
		// Token: 0x060015DD RID: 5597 RVA: 0x000711B0 File Offset: 0x0006F3B0
		public Edge(Vector2 start, Vector2 end)
		{
			this.start = start;
			this.end = end;
		}

		// Token: 0x060015DE RID: 5598 RVA: 0x000711C0 File Offset: 0x0006F3C0
		public Vector2 Direction()
		{
			return this.start - this.end;
		}

		// Token: 0x060015DF RID: 5599 RVA: 0x000711D4 File Offset: 0x0006F3D4
		public Vector2 DirectionNormalized()
		{
			Vector2 vector = this.start - this.end;
			float num = Mathf.Sqrt(vector.x * vector.x + vector.y * vector.y);
			if (num != 0f)
			{
				vector.x /= num;
				vector.y /= num;
			}
			return vector;
		}

		// Token: 0x060015E0 RID: 5600 RVA: 0x00071238 File Offset: 0x0006F438
		public float Magnitude()
		{
			Vector2 vector = this.start - this.end;
			return Mathf.Sqrt(vector.x * vector.x + vector.y * vector.y);
		}

		// Token: 0x040011BD RID: 4541
		public Vector2 start;

		// Token: 0x040011BE RID: 4542
		public Vector2 end;
	}
}
