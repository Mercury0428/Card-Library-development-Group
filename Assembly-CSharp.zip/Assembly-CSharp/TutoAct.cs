﻿using System;
using UnityEngine;

// Token: 0x0200007D RID: 125
public class TutoAct : MonoBehaviour
{
	// Token: 0x06000439 RID: 1081 RVA: 0x0001AE80 File Offset: 0x00019080
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnCharacter = (Action<Bearers>)Delegate.Combine(diff.OnCharacter, new Action<Bearers>(this.StartCheck));
		GameAct diff2 = GameAct.diff;
		diff2.OnCharacter = (Action<Bearers>)Delegate.Combine(diff2.OnCharacter, new Action<Bearers>(this.NewCard));
		GameAct diff3 = GameAct.diff;
		diff3.OnChoice = (Action<int>)Delegate.Combine(diff3.OnChoice, new Action<int>(this.UpdateTime));
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x0001AEFF File Offset: 0x000190FF
	private void UpdateTime(int decision)
	{
		if (decision == 1 | decision == -1)
		{
			this.timeChoice = Time.realtimeSinceStartup;
		}
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x0001AF18 File Offset: 0x00019118
	private void NewCard(Bearers bear)
	{
		if (!this.ghostly && GameAct.diff.card.name == "first_card")
		{
			this.ghostly = true;
			GameAct.diff.ShowDataCol(false);
			this.timeChoice = Time.realtimeSinceStartup;
			return;
		}
		if (this.ghostly)
		{
			string curCardName = GameAct.diff.GetCurCardName();
			if (curCardName == "_show_power")
			{
				this.Disable();
				return;
			}
			if (InputAct.diff.curInput != Inputs.touch)
			{
				return;
			}
			if (curCardName == "_show_faith" && Time.realtimeSinceStartup - this.timeChoice < 0.5f)
			{
				GameAct.diff.PlayModal(ModalTypes.custom, this.scmod, 10f, "", false);
				this.Disable();
				return;
			}
		}
		else if (!this.ghostly)
		{
			this.Disable();
		}
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x0001AFF0 File Offset: 0x000191F0
	private void Disable()
	{
		this.ghostly = false;
		base.gameObject.SetActive(false);
		GameAct diff = GameAct.diff;
		diff.OnCharacter = (Action<Bearers>)Delegate.Remove(diff.OnCharacter, new Action<Bearers>(this.StartCheck));
		GameAct diff2 = GameAct.diff;
		diff2.OnCharacter = (Action<Bearers>)Delegate.Remove(diff2.OnCharacter, new Action<Bearers>(this.NewCard));
		GameAct diff3 = GameAct.diff;
		diff3.OnCardClose = (Action<int>)Delegate.Remove(diff3.OnCardClose, new Action<int>(this.OutBut));
		GameAct diff4 = GameAct.diff;
		diff4.OnChoice = (Action<int>)Delegate.Remove(diff4.OnChoice, new Action<int>(this.ControlCheck));
		GameAct diff5 = GameAct.diff;
		diff5.OnChoice = (Action<int>)Delegate.Remove(diff5.OnChoice, new Action<int>(this.UpdateTime));
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x0001B0D0 File Offset: 0x000192D0
	private void ControlCheck(int dec)
	{
		if (dec == this.decision)
		{
			return;
		}
		this.decision = dec;
		if (InputAct.diff.isSimulating)
		{
			return;
		}
		if (!InputAct.diff.NavigationMode())
		{
			return;
		}
		if (this.decision == 0)
		{
			if (AnimBut.diff)
			{
				AnimBut.diff.Lock(false);
				return;
			}
		}
		else if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.next, true, true);
		}
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x0001B144 File Offset: 0x00019344
	private void OutBut(int dec)
	{
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(false);
		}
		GameAct diff = GameAct.diff;
		diff.OnChoice = (Action<int>)Delegate.Remove(diff.OnChoice, new Action<int>(this.ControlCheck));
		GameAct diff2 = GameAct.diff;
		diff2.OnCardClose = (Action<int>)Delegate.Remove(diff2.OnCardClose, new Action<int>(this.OutBut));
		this.decision = 0;
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x0001B1BC File Offset: 0x000193BC
	private void StartCheck(Bearers bear)
	{
		if (GameAct.diff.card.name != "first_card")
		{
			return;
		}
		InputAct.diff.Simulate(-0.5f, 0.5f);
		GameAct diff = GameAct.diff;
		diff.OnCardClose = (Action<int>)Delegate.Combine(diff.OnCardClose, new Action<int>(this.OutBut));
		GameAct diff2 = GameAct.diff;
		diff2.OnChoice = (Action<int>)Delegate.Combine(diff2.OnChoice, new Action<int>(this.ControlCheck));
	}

	// Token: 0x040004F0 RID: 1264
	public GameObject scmod;

	// Token: 0x040004F1 RID: 1265
	private bool ghostly;

	// Token: 0x040004F2 RID: 1266
	private int decision;

	// Token: 0x040004F3 RID: 1267
	private float timeChoice;
}
