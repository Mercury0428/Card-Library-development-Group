﻿using System;
using UnityEngine;

// Token: 0x02000087 RID: 135
public class AudioMove : MonoBehaviour
{
	// Token: 0x0600046F RID: 1135 RVA: 0x0001BFA9 File Offset: 0x0001A1A9
	public void VelocityMultiplierIntensity(float value)
	{
		this._velocityMultiplierIntensity = value;
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x0001BFB2 File Offset: 0x0001A1B2
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x0001BFBB File Offset: 0x0001A1BB
	public void RandomIntensity(float value)
	{
		this._randomIntensity = value;
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x0001BFC4 File Offset: 0x0001A1C4
	public void OnAudio(float audioVelocity)
	{
		float num = audioVelocity * this.velocityMultiplier * this._velocityMultiplierIntensity;
		if (this.random && this._randomIntensity >= 0.5f)
		{
			this.destination.x = Mathf.PerlinNoise(Time.realtimeSinceStartup * 1.5f, Time.realtimeSinceStartup * 3f) * this.velocity.x * num;
			this.destination.y = Mathf.PerlinNoise(Time.realtimeSinceStartup * 2f, Time.realtimeSinceStartup * 0.5f) * this.velocity.y * num;
		}
		else
		{
			this.destination.x = this.velocity.x * num;
			this.destination.y = this.velocity.y * num;
		}
		this.target.localPosition = Vector3.Lerp(this.target.localPosition, this.destination, Time.deltaTime * this.speed * this._speedIntensity);
	}

	// Token: 0x0400051F RID: 1311
	public Transform target;

	// Token: 0x04000520 RID: 1312
	public Vector2 velocity;

	// Token: 0x04000521 RID: 1313
	public float velocityMultiplier = 1f;

	// Token: 0x04000522 RID: 1314
	protected float _velocityMultiplierIntensity = 1f;

	// Token: 0x04000523 RID: 1315
	public float speed = 1f;

	// Token: 0x04000524 RID: 1316
	protected float _speedIntensity = 1f;

	// Token: 0x04000525 RID: 1317
	public bool random = true;

	// Token: 0x04000526 RID: 1318
	protected float _randomIntensity = 1f;

	// Token: 0x04000527 RID: 1319
	private Vector3 destination;
}
