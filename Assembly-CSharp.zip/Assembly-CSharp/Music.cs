﻿using System;
using UnityEngine;

// Token: 0x0200005C RID: 92
[Serializable]
public class Music
{
	// Token: 0x0600033D RID: 829 RVA: 0x00002050 File Offset: 0x00000250
	public Music()
	{
	}

	// Token: 0x0600033E RID: 830 RVA: 0x00014DF0 File Offset: 0x00012FF0
	public Music(AudioClip clip, bool looping)
	{
		this.sample = clip;
		this.name = clip.name;
		this.loop = looping;
		this.character = Bearers.anyone;
	}

	// Token: 0x0400041E RID: 1054
	public string name;

	// Token: 0x0400041F RID: 1055
	public AudioClip sample;

	// Token: 0x04000420 RID: 1056
	public bool loop;

	// Token: 0x04000421 RID: 1057
	public bool lead;

	// Token: 0x04000422 RID: 1058
	public Bearers character;

	// Token: 0x04000423 RID: 1059
	public bool nostop;
}
