﻿using System;

// Token: 0x0200002E RID: 46
public enum BearerTypes
{
	// Token: 0x04000164 RID: 356
	generated,
	// Token: 0x04000165 RID: 357
	function,
	// Token: 0x04000166 RID: 358
	house,
	// Token: 0x04000167 RID: 359
	individual,
	// Token: 0x04000168 RID: 360
	special,
	// Token: 0x04000169 RID: 361
	system,
	// Token: 0x0400016A RID: 362
	none,
	// Token: 0x0400016B RID: 363
	bannerman
}
