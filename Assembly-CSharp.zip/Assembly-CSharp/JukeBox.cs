﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Malee;
using UnityEngine;
using UnityEngine.Audio;

// Token: 0x02000061 RID: 97
public class JukeBox : MonoBehaviour
{
	// Token: 0x06000345 RID: 837 RVA: 0x00014ED1 File Offset: 0x000130D1
	private void Awake()
	{
		JukeBox.diff = this;
		this.musics = new List<Music>(this.allmusic);
		this.allmusic.Clear();
	}

	// Token: 0x06000346 RID: 838 RVA: 0x00014EF8 File Offset: 0x000130F8
	private void Start()
	{
		this.voVol = PlayerPrefs.GetFloat("volSpeech");
		if (this.voVol == 0f && PlayerPrefs.HasKey("volSpeech"))
		{
			this.MuteVoAndSave(false, false);
		}
		else
		{
			this.MuteVoAndSave(true, false);
		}
		if (PlayerPrefs.HasKey("volMusic"))
		{
			float @float = PlayerPrefs.GetFloat("volMusic");
			float float2 = PlayerPrefs.GetFloat("volExternal");
			this.MusicVolume(@float, false);
			this.SfxVolume(float2, false);
		}
		else
		{
			this.MusicVolume(0.6f, true);
			this.SfxVolume(0.5f, true);
		}
		this.SaveLevels(null);
		if (SuperPrefs.HasKey("trackId"))
		{
			this.trackid = SuperPrefs.GetInt("trackId");
		}
	}

	// Token: 0x06000347 RID: 839 RVA: 0x00014FB0 File Offset: 0x000131B0
	private void InitSources()
	{
		this.songSources = this.InitSource("songs");
		this.sfxSources = this.InitSource("sfx");
		this.uiSources = this.InitSource("UI");
		this.ambientSources = this.InitSource("ambient");
		this.voSources = this.InitSource("VO");
	}

	// Token: 0x06000348 RID: 840 RVA: 0x00015014 File Offset: 0x00013214
	private AudioSource[] InitSource(string child)
	{
		Transform transform = base.transform.Find(child);
		AudioSource[] array = new AudioSource[transform.childCount + 1];
		array[0] = transform.GetComponent<AudioSource>();
		int num = 1;
		foreach (object obj in transform)
		{
			Transform transform2 = (Transform)obj;
			array[num] = transform2.GetComponent<AudioSource>();
			num++;
		}
		return array;
	}

	// Token: 0x06000349 RID: 841 RVA: 0x00003D07 File Offset: 0x00001F07
	private void StartDrone()
	{
	}

	// Token: 0x0600034A RID: 842 RVA: 0x0001509C File Offset: 0x0001329C
	public void PlayMusicDelayed(Bearers character, float t)
	{
		base.StartCoroutine(this.DoStartDelayed(character, t));
	}

	// Token: 0x0600034B RID: 843 RVA: 0x000150AD File Offset: 0x000132AD
	private IEnumerator DoStartDelayed(Bearers character, float t)
	{
		yield return new WaitForSeconds(t);
		this.PlayMusic(character, false);
		yield break;
	}

	// Token: 0x0600034C RID: 844 RVA: 0x000150CC File Offset: 0x000132CC
	public void StopMusic(bool nofade = false)
	{
		if (ThemeAct.diff)
		{
			ThemeAct.diff.Stop();
		}
		AudioSource audioSource = this.songSources[0].isPlaying ? this.songSources[0] : this.songSources[1];
		if (audioSource.clip == null)
		{
			return;
		}
		if (!this.isPlayingMusic)
		{
			return;
		}
		this.pausetime = audioSource.time;
		if (nofade)
		{
			audioSource.Stop();
		}
		else
		{
			this.Fade(audioSource, 3f, false);
		}
		this.isPlayingMusic = false;
		this.MasterMix.TransitionToSnapshots(this.snapshots, this.weightLoop, 3f);
	}

	// Token: 0x0600034D RID: 845 RVA: 0x00015170 File Offset: 0x00013370
	public void RestartMusic()
	{
		this.PlayMusic(Bearers.none, true);
	}

	// Token: 0x0600034E RID: 846 RVA: 0x00015180 File Offset: 0x00013380
	public void PlayMusic(Bearers musicGroup = Bearers.none, bool restart = false)
	{
		if (ThemeAct.diff)
		{
			return;
		}
		if (this.nextplay != null)
		{
			base.StopCoroutine(this.nextplay);
		}
		if (!restart)
		{
			this.curMusic = this.SelectMusic(musicGroup);
		}
		if (this.curMusic == null)
		{
			return;
		}
		if (this.curMusic.loop)
		{
			this.MasterMix.TransitionToSnapshots(this.snapshots, this.weightLoop, 3f);
		}
		else
		{
			this.MasterMix.TransitionToSnapshots(this.snapshots, this.weightDefault, 3f);
		}
		AudioSource[] array = this.songSources;
		AudioSource source;
		AudioSource audioSource;
		if (array[0].isPlaying)
		{
			source = array[0];
			audioSource = array[1];
		}
		else
		{
			audioSource = array[0];
			source = array[1];
		}
		audioSource.clip = this.curMusic.sample;
		audioSource.loop = this.curMusic.loop;
		if (restart)
		{
			audioSource.time = this.pausetime;
			this.pausetime = 0f;
		}
		else if (this.curMusic.loop)
		{
			audioSource.time = Util.Rand(0f, audioSource.clip.length * 0.7f);
		}
		else
		{
			audioSource.time = 0f;
		}
		audioSource.Play();
		this.Fade(source, 3f, false);
		this.Fade(audioSource, 3f, true);
		this.isPlayingMusic = true;
		float time = this.curMusic.sample.length - audioSource.time;
		if (this.nextplay != null)
		{
			base.StopCoroutine(this.nextplay);
		}
		this.nextplay = (this.curMusic.loop ? base.StartCoroutine(this.NextPlay(180f, this.curMusic.character)) : base.StartCoroutine(this.NextPlay(time, this.curMusic.character)));
	}

	// Token: 0x0600034F RID: 847 RVA: 0x00015346 File Offset: 0x00013546
	private IEnumerator NextPlay(float time, Bearers thisGroup)
	{
		yield return new WaitForSeconds(time - 2f);
		this.StopMusic(false);
		yield return new WaitForSeconds(3f);
		if (!this.isPlayingMusic)
		{
			this.PlayMusic(thisGroup, false);
		}
		yield break;
	}

	// Token: 0x06000350 RID: 848 RVA: 0x00015364 File Offset: 0x00013564
	private Music SelectMusic(Bearers musicGroup)
	{
		if (this.allMus.Count == 0)
		{
			this.allMus = new List<Music>(this.musics.FindAll((Music it) => it.character == Bearers.anyone));
		}
		Bearers musicGroup2 = musicGroup;
		if (musicGroup2 == Bearers.anyone || musicGroup2 == Bearers.none)
		{
			SuperPrefs.SetInt("trackId", this.trackid);
			this.trackid = ((this.trackid < this.allMus.Count - 1) ? (this.trackid + 1) : 0);
			return this.allMus[this.trackid];
		}
		List<Music> list = this.musics.FindAll((Music it) => it.character == musicGroup);
		if (list.Count == 0)
		{
			list = this.musics.FindAll((Music it) => it.character == Bearers.anyone);
		}
		return list[Util.RandInt(0, list.Count)];
	}

	// Token: 0x06000351 RID: 849 RVA: 0x00015479 File Offset: 0x00013679
	private void Fade(AudioSource source, float lerpTime, bool fadeIn = true)
	{
		base.StartCoroutine(this.DoFadeSource(source, lerpTime, fadeIn));
	}

	// Token: 0x06000352 RID: 850 RVA: 0x0001548B File Offset: 0x0001368B
	private IEnumerator DoFadeSource(AudioSource source, float lerpTime, bool fadeIn)
	{
		float currentLerpTime = 0f;
		float start = fadeIn ? 0f : 1f;
		float end = fadeIn ? 1f : 0f;
		while (currentLerpTime < lerpTime)
		{
			currentLerpTime += Time.deltaTime;
			float t = currentLerpTime / lerpTime;
			source.volume = Mathf.Lerp(start, end, t);
			yield return null;
		}
		if (!fadeIn)
		{
			source.Stop();
		}
		source.volume = 1f;
		yield break;
	}

	// Token: 0x06000353 RID: 851 RVA: 0x000154A8 File Offset: 0x000136A8
	public void Remove()
	{
		base.StopAllCoroutines();
		Object.DestroyImmediate(base.gameObject);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x000154BC File Offset: 0x000136BC
	private float LinearToDecibel(float linear)
	{
		float result;
		if (linear != 0f)
		{
			result = 20f * Mathf.Log10(linear);
		}
		else
		{
			result = -144f;
		}
		return result;
	}

	// Token: 0x06000355 RID: 853 RVA: 0x000154E7 File Offset: 0x000136E7
	public void MusicVolumeAndSave(float val)
	{
		this.MusicVolume(val, true);
	}

	// Token: 0x06000356 RID: 854 RVA: 0x000154F1 File Offset: 0x000136F1
	public void MusicVolume(float val, bool andsave = true)
	{
		this.musVol = val;
		this.MasterMix.SetFloat("volMusic", this.LinearToDecibel(val));
		if (andsave)
		{
			this.SaveLevels(null);
		}
	}

	// Token: 0x06000357 RID: 855 RVA: 0x0001551C File Offset: 0x0001371C
	public void MuteVo(bool play = true)
	{
		this.MuteVoAndSave(play, true);
	}

	// Token: 0x06000358 RID: 856 RVA: 0x00015528 File Offset: 0x00013728
	private void MuteVoAndSave(bool play = true, bool andsave = true)
	{
		float num = (float)(play ? 1 : 0);
		this.voVol = num;
		if (andsave)
		{
			this.SaveLevels(null);
		}
	}

	// Token: 0x06000359 RID: 857 RVA: 0x0001554F File Offset: 0x0001374F
	public void SfxVolumeAndSave(float val)
	{
		this.SfxVolume(val, true);
	}

	// Token: 0x0600035A RID: 858 RVA: 0x00015559 File Offset: 0x00013759
	public void SfxVolume(float val, bool andsave = true)
	{
		this.sfxVol = val;
		this.MasterMix.SetFloat("externalVolume", this.LinearToDecibel(val));
		if (andsave)
		{
			this.SaveLevels(null);
		}
	}

	// Token: 0x0600035B RID: 859 RVA: 0x00015584 File Offset: 0x00013784
	private void SaveLevels(Game save = null)
	{
		PlayerPrefs.SetFloat("volMusic", this.musVol);
		PlayerPrefs.SetFloat("volExternal", this.sfxVol);
		PlayerPrefs.SetFloat("volSpeech", this.voVol);
	}

	// Token: 0x0600035C RID: 860 RVA: 0x000155B6 File Offset: 0x000137B6
	public void FadeOutMusic(float length = 1f)
	{
		base.StartCoroutine(this.DoFadeOutMusic(this.isalt, length));
	}

	// Token: 0x0600035D RID: 861 RVA: 0x000155CC File Offset: 0x000137CC
	private IEnumerator DoFadeOutMusic(bool alt, float length)
	{
		float t = 0f;
		using (List<Vox>.Enumerator enumerator = this.voces.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Vox vox = enumerator.Current;
				(alt ? vox.speakers[1] : vox.speakers[0]).Stop();
			}
			goto IL_10A;
		}
		IL_7D:
		foreach (Vox vox2 in this.voces)
		{
			(alt ? vox2.speakers[0] : vox2.speakers[1]).volume = 1f - t;
		}
		t += Time.deltaTime / length;
		yield return null;
		IL_10A:
		if (t >= 1f)
		{
			using (List<Vox>.Enumerator enumerator = this.voces.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Vox vox3 = enumerator.Current;
					AudioSource audioSource = alt ? vox3.speakers[0] : vox3.speakers[1];
					audioSource.Stop();
					audioSource.volume = 1f;
				}
				yield break;
			}
			yield break;
		}
		goto IL_7D;
	}

	// Token: 0x0600035E RID: 862 RVA: 0x000155E9 File Offset: 0x000137E9
	private IEnumerator DoFadeOutSource(AudioSource[] sources, float length)
	{
		float t = 0f;
		AudioSource source = (sources[0].isPlaying && !sources[1].isPlaying) ? sources[1] : sources[0];
		while (t < 1f)
		{
			source.volume = 1f - t;
			t += Time.deltaTime / length;
			yield return null;
		}
		source.Stop();
		source.volume = 1f;
		yield break;
	}

	// Token: 0x0600035F RID: 863 RVA: 0x000155FF File Offset: 0x000137FF
	public void FadeOutVO()
	{
		this.FadeOut(this.voSources);
	}

	// Token: 0x06000360 RID: 864 RVA: 0x00015610 File Offset: 0x00013810
	private void FadeOut(AudioSource[] sources)
	{
		foreach (AudioSource audioSource in sources)
		{
			if (audioSource.isPlaying)
			{
				base.StartCoroutine(this.DoFadeOutSource(audioSource, 1f));
			}
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0001564C File Offset: 0x0001384C
	private IEnumerator DoFadeOutSource(AudioSource source, float length)
	{
		float t = 0f;
		while (t < 1f)
		{
			source.volume = 1f - t;
			t += Time.deltaTime / length;
			yield return null;
		}
		source.Stop();
		source.volume = 1f;
		yield break;
	}

	// Token: 0x06000362 RID: 866 RVA: 0x00015664 File Offset: 0x00013864
	private AudioClip SetSequ(List<AudioClip> list, AudioClip cur, int id)
	{
		List<AudioClip> list2 = new List<AudioClip>(list);
		if (cur != null)
		{
			list2.Remove(cur);
		}
		return list2[id];
	}

	// Token: 0x06000363 RID: 867 RVA: 0x00015690 File Offset: 0x00013890
	private void PlaySequ(AudioSource source, AudioClip clip, double start, Vox vox, float totalVal)
	{
		source.clip = clip;
		float num = 0f;
		switch (vox.type)
		{
		case VoxTypes.soprano:
			num = -1f;
			break;
		case VoxTypes.alto:
			num = -1f;
			break;
		case VoxTypes.baryton:
			num = 1f;
			break;
		case VoxTypes.tenor:
			num = 1f;
			break;
		}
		float num2 = (GameAct.diff.state == GameStates.interreign) ? 1f : ((float)vox.dataRef.val / 100f);
		source.panStereo = num * num2;
		source.PlayScheduled(start);
	}

	// Token: 0x06000364 RID: 868 RVA: 0x00015720 File Offset: 0x00013920
	public List<Music> GetMusics()
	{
		return this.musics;
	}

	// Token: 0x06000365 RID: 869 RVA: 0x00015728 File Offset: 0x00013928
	public void UpdateVocalMix()
	{
		float num = 0f;
		float num2 = 0f;
		foreach (Vox vox in this.voces)
		{
			num2 += (float)vox.dataRef.val;
			if ((float)vox.dataRef.val > num)
			{
				num = (float)vox.dataRef.val;
			}
		}
		foreach (Vox vox2 in this.voces)
		{
			string text = "";
			switch (vox2.type)
			{
			case VoxTypes.soprano:
				text = this.s[0];
				break;
			case VoxTypes.alto:
				text = this.s[1];
				break;
			case VoxTypes.baryton:
				text = this.s[3];
				break;
			case VoxTypes.tenor:
				text = this.s[2];
				break;
			}
			float num3 = Mathf.Min((float)vox2.dataRef.val, this.attenCeilVal);
			float prevVol;
			this.MasterMix.GetFloat("vol" + text, out prevVol);
			float newVol = (num3 < 1f) ? -60f : (-1f * (Mathf.Pow(1f - num3 / this.attenCeilVal, 3f) * (float)(this.volFloor - this.volCeiling)) - (float)this.volCeiling);
			float prevFreq;
			this.MasterMix.GetFloat("cutoff" + text, out prevFreq);
			float newFreq = (num3 < 1f) ? ((float)this.filterMinFreq) : (Mathf.Pow(num3 / this.attenCeilVal, 3f) * (float)(22000 - this.filterMinFreq) + (float)this.filterMinFreq);
			base.StartCoroutine(this.LerpAttenuate(text, prevVol, newVol, prevFreq, newFreq, 2f));
		}
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0001594C File Offset: 0x00013B4C
	private IEnumerator LerpPitch(string param, float prevPitch, float newPitch, float lerpTime = 1f)
	{
		float currentLerpTime = 0f;
		while (currentLerpTime < lerpTime)
		{
			currentLerpTime += Time.deltaTime;
			float num = currentLerpTime / lerpTime;
			num = num * num * num * (num * (6f * num - 15f) + 10f);
			this.MasterMix.SetFloat(param, Mathf.Lerp(prevPitch, newPitch, num));
			yield return null;
		}
		yield break;
	}

	// Token: 0x06000367 RID: 871 RVA: 0x00015978 File Offset: 0x00013B78
	public void DuckMusic(bool duck, float length = 2.5f)
	{
		try
		{
			string text = "volMusic";
			float prevVal;
			this.MasterMix.GetFloat(text, out prevVal);
			float num = duck ? -80f : 0f;
			if (length < 0.001f)
			{
				this.MasterMix.SetFloat(text, num);
			}
			else
			{
				base.StartCoroutine(this.LerpParam(text, prevVal, num, length));
			}
		}
		catch
		{
		}
	}

	// Token: 0x06000368 RID: 872 RVA: 0x000159E8 File Offset: 0x00013BE8
	private IEnumerator LerpParam(string param, float prevVal, float newVal, float lerpTime = 2f)
	{
		float currentLerpTime = 0f;
		while (currentLerpTime < lerpTime)
		{
			currentLerpTime += Time.deltaTime;
			float num = currentLerpTime / lerpTime;
			num = num * num * num * (num * (6f * num - 15f) + 10f);
			this.MasterMix.SetFloat(param, Mathf.Lerp(prevVal, newVal, num));
			yield return null;
		}
		yield break;
	}

	// Token: 0x06000369 RID: 873 RVA: 0x00015A14 File Offset: 0x00013C14
	private IEnumerator LerpAttenuate(string chan, float prevVol, float newVol, float prevFreq, float newFreq, float lerpTime)
	{
		float currentLerpTime = 0f;
		while (currentLerpTime < lerpTime)
		{
			currentLerpTime += Time.deltaTime;
			float num = currentLerpTime / lerpTime;
			num = num * num * num * (num * (6f * num - 15f) + 10f);
			this.MasterMix.SetFloat("vol" + chan, Mathf.Lerp(prevVol, newVol, num));
			this.MasterMix.SetFloat("cutoff" + chan, Mathf.Lerp(prevFreq, newFreq, num));
			yield return null;
		}
		yield break;
	}

	// Token: 0x0600036A RID: 874 RVA: 0x00015A50 File Offset: 0x00013C50
	public void DefaultSnapshot(float fadeLength = 2.5f)
	{
		this.TransitionToSnapshot("Default", fadeLength);
	}

	// Token: 0x0600036B RID: 875 RVA: 0x00015A60 File Offset: 0x00013C60
	public void TransitionToSnapshot(string id, float t = 2.5f)
	{
		for (int i = 0; i < this.snapshots.Length; i++)
		{
			if (this.snapshots[i].name == id)
			{
				float[] array = new float[this.snapshots.Length];
				for (int j = 0; j < this.snapshots.Length; j++)
				{
					array[j] = (float)((i == j) ? 1 : 0);
				}
				this.MasterMix.TransitionToSnapshots(this.snapshots, array, t);
				return;
			}
		}
	}

	// Token: 0x0600036C RID: 876 RVA: 0x00015AD8 File Offset: 0x00013CD8
	public void Speak(string text, Bearers type, float voPitch, float voCenterFrequ, float voFrequGain, float voGain)
	{
		if (this.voVol == 0f || this.sfxVol == 0f)
		{
			return;
		}
		if (this.speakCorout != null)
		{
			base.StopCoroutine(this.speakCorout);
		}
		base.StartCoroutine(this.FadeSound(this.voSources[1], false, 0.25f));
		base.StartCoroutine(this.FadeSound(this.voSources[0], false, 0.25f));
		if (this.OnSpeak != null)
		{
			type = this.OnSpeak(false);
			voPitch = 0.96f;
			voCenterFrequ = 2900f;
			voFrequGain = 1f;
			voGain = 1f;
		}
		this.speakCorout = this.DoSpeak(text, type, voPitch, voCenterFrequ, voFrequGain, voGain);
		base.StartCoroutine(this.speakCorout);
	}

	// Token: 0x0600036D RID: 877 RVA: 0x00015B9E File Offset: 0x00013D9E
	private IEnumerator DoSpeak(string text, Bearers type, float voPitch, float voCenterFrequ, float voFrequGain, float voGain)
	{
		yield return new WaitForSeconds(0.5f);
		this.MasterMix.SetFloat("voPitch", voPitch);
		this.MasterMix.SetFloat("voCenterFrequ", voCenterFrequ);
		this.MasterMix.SetFloat("voFrequGain", voFrequGain);
		this.MasterMix.SetFloat("voGain", voGain);
		float textLength = Mathf.Clamp((float)text.Length / 65f, 0f, 3f);
		float soundLength = 0f;
		string[] collection = this.allvo.Find((VO it) => it.type == type).samples;
		List<string> tempClip = new List<string>(collection);
		List<AudioClip> clipsToPlay = new List<AudioClip>();
		float i = 1f;
		bool alt = false;
		int num = 0;
		while (soundLength < textLength && tempClip.Count > 0)
		{
			int index = Util.RandInt(0, tempClip.Count);
			AudioClip audioClip = (AudioClip)Resources.Load("VO/" + type.ToString() + "/" + tempClip[index], typeof(AudioClip));
			tempClip.Remove(tempClip[index]);
			if (audioClip != null)
			{
				clipsToPlay.Add(audioClip);
				soundLength += this.GetLength(audioClip);
			}
			else
			{
				num++;
			}
			if (num > 10)
			{
				yield break;
			}
		}
		AudioClip longestClip = clipsToPlay.Aggregate(delegate(AudioClip seed, AudioClip c)
		{
			if (c.length <= seed.length)
			{
				return seed;
			}
			return c;
		});
		int index2 = clipsToPlay.FindIndex((AudioClip c) => c.length == longestClip.length);
		clipsToPlay.RemoveAt(index2);
		clipsToPlay.Add(longestClip);
		int num2;
		for (int j = 0; j < clipsToPlay.Count; j = num2 + 1)
		{
			AudioSource audioSource = alt ? this.voSources[1] : this.voSources[0];
			alt = !alt;
			AudioClip oldclip = audioSource.clip;
			audioSource.clip = clipsToPlay[j];
			audioSource.Play();
			yield return null;
			float length = this.GetLength(clipsToPlay[j]);
			yield return new WaitForSeconds(length);
			Resources.UnloadAsset(oldclip);
			oldclip = null;
			num2 = j;
		}
		while (soundLength < textLength && tempClip.Count > 0)
		{
			int index3 = Util.RandInt(0, tempClip.Count);
			AudioClip oldclip = (AudioClip)Resources.Load("VO/" + type.ToString() + "/" + tempClip[index3], typeof(AudioClip));
			tempClip.Remove(tempClip[index3]);
			soundLength += this.GetLength(oldclip);
			float num3 = i;
			i = num3 + 1f;
			AudioSource audioSource2 = alt ? this.voSources[1] : this.voSources[0];
			alt = !alt;
			AudioClip oldclip2 = audioSource2.clip;
			audioSource2.clip = oldclip;
			audioSource2.Play();
			yield return null;
			Resources.UnloadAsset(oldclip2);
			float length2 = this.GetLength(oldclip);
			yield return new WaitForSeconds(length2);
			oldclip = null;
			oldclip2 = null;
		}
		yield break;
	}

	// Token: 0x0600036E RID: 878 RVA: 0x00015BDA File Offset: 0x00013DDA
	private float GetLength(AudioClip clip)
	{
		if (clip == null)
		{
			return 0f;
		}
		return clip.length - Mathf.Clamp(clip.length / 10f - 0.02f, -0.02f, 0.06f);
	}

	// Token: 0x0600036F RID: 879 RVA: 0x00015C13 File Offset: 0x00013E13
	public void PlayValues(Dictionary<Variables, int> SFXvalues)
	{
		if (SFXvalues.Count == 0)
		{
			return;
		}
		base.StopCoroutine("DoPlayValues");
		base.StartCoroutine("DoPlayValues", SFXvalues);
	}

	// Token: 0x06000370 RID: 880 RVA: 0x00015C38 File Offset: 0x00013E38
	private void PlayValue(SFXTypes up, SFXTypes down, int val)
	{
		if (val == 0 || val > 15)
		{
			return;
		}
		if (val < 0)
		{
			this.PlaySound(down, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		this.PlaySound(up, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000371 RID: 881 RVA: 0x00015C85 File Offset: 0x00013E85
	private IEnumerator DoPlayValues(Dictionary<Variables, int> SFXvalues)
	{
		foreach (KeyValuePair<Variables, int> keyValuePair in from it in SFXvalues
		orderby it.Value
		select it)
		{
			switch (keyValuePair.Key)
			{
			case Variables.people:
				this.PlayValue(SFXTypes.ui_score_people_decrease, SFXTypes.ui_score_people_increase, keyValuePair.Value);
				break;
			case Variables.faith:
				this.PlayValue(SFXTypes.ui_score_church_decrease, SFXTypes.ui_score_church_increase, keyValuePair.Value);
				break;
			case Variables.power:
				this.PlayValue(SFXTypes.ui_score_army_decrease, SFXTypes.ui_score_army_increase, keyValuePair.Value);
				break;
			case Variables.money:
				this.PlayValue(SFXTypes.ui_score_bank_decrease, SFXTypes.ui_score_bank_increase, keyValuePair.Value);
				break;
			}
			yield return new WaitForSeconds(0.15f);
		}
		IEnumerator<KeyValuePair<Variables, int>> enumerator = null;
		yield break;
		yield break;
	}

	// Token: 0x06000372 RID: 882 RVA: 0x00015C9B File Offset: 0x00013E9B
	private AudioSource[] GetSoundSource(SFXSources type)
	{
		switch (type)
		{
		case SFXSources.sfx:
			return this.sfxSources;
		case SFXSources.ui:
			return this.uiSources;
		case SFXSources.ambient:
			return this.ambientSources;
		case SFXSources.songs:
			return this.songSources;
		}
		return null;
	}

	// Token: 0x06000373 RID: 883 RVA: 0x00015CD8 File Offset: 0x00013ED8
	private AudioSource GetFreeSource(AudioSource[] sources)
	{
		foreach (AudioSource audioSource in sources)
		{
			if (!audioSource.isPlaying)
			{
				return audioSource;
			}
		}
		return sources[0];
	}

	// Token: 0x06000374 RID: 884 RVA: 0x00015D06 File Offset: 0x00013F06
	public void FadeOutAmbient()
	{
		this.FadeOut(this.ambientSources);
	}

	// Token: 0x06000375 RID: 885 RVA: 0x00015D14 File Offset: 0x00013F14
	public void PlaySound(AudioClip type, bool fadeIn = false, bool duckMusic = false, float duckLength = 2.5f)
	{
		if (this.sfxVol == 0f)
		{
			return;
		}
		AudioSource[] soundSource = this.GetSoundSource(SFXSources.sfx);
		AudioSource freeSource = this.GetFreeSource(soundSource);
		freeSource.clip = type;
		if (duckMusic)
		{
			this.DuckMusic(true, duckLength);
		}
		freeSource.Stop();
		if (fadeIn)
		{
			freeSource.volume = 0f;
			freeSource.Play();
			base.StartCoroutine(this.FadeSound(freeSource, true, 1.5f));
			return;
		}
		freeSource.Play();
	}

	// Token: 0x06000376 RID: 886 RVA: 0x00015D87 File Offset: 0x00013F87
	public void PlayAttenuatedSound(SFXTypes name, float volume = 1f)
	{
		this.PlaySound(name, false, false, 2.5f, -1, 1.5f, volume);
	}

	// Token: 0x06000377 RID: 887 RVA: 0x00015DA0 File Offset: 0x00013FA0
	public void PlaySound(SFXTypes name, bool fadeIn = false, bool duckMusic = false, float duckLength = 2.5f, int id = -1, float fadeInLength = 1.5f, float volume = 1f)
	{
		if (HapticAct.diff)
		{
			SFXTypes name2 = name;
			if (name2 == SFXTypes.ui_button_next || name2 == SFXTypes.ui_menu_close || name2 == SFXTypes.ui_menu_open)
			{
				HapticAct.diff.Tap(iOSHapticFeedback.iOSFeedbackType.ImpactLight);
			}
		}
		if (this.sfxVol == 0f)
		{
			return;
		}
		SFX sfx = this.samples.Find((SFX it) => it.type == name);
		if (sfx == null)
		{
			return;
		}
		if (sfx.source == SFXSources.ambient)
		{
			fadeIn = true;
			this.FadeOutAmbient();
		}
		AudioSource[] soundSource = this.GetSoundSource(sfx.source);
		AudioSource freeSource = this.GetFreeSource(soundSource);
		AudioClip audioClip;
		if (sfx.clips.Count > 1)
		{
			List<AudioClip> list = new List<AudioClip>(sfx.clips);
			if (id == -1 && list.Contains(sfx.lastclip))
			{
				list.Remove(sfx.lastclip);
			}
			audioClip = ((id == -1) ? list[Util.RandInt(0, list.Count)] : list[id]);
			sfx.lastclip = audioClip;
		}
		else
		{
			audioClip = sfx.clips[0];
		}
		freeSource.clip = audioClip;
		freeSource.loop = sfx.loop;
		if (sfx.loop)
		{
			freeSource.time = Util.Rand(0f, audioClip.length) * 0.5f;
		}
		else
		{
			freeSource.time = 0f;
		}
		sfx.lastsource = freeSource;
		if (duckMusic)
		{
			this.DuckMusic(true, duckLength);
		}
		freeSource.Stop();
		if (fadeIn)
		{
			freeSource.volume = 0f;
			freeSource.Play();
			base.StartCoroutine(this.FadeSound(freeSource, true, fadeInLength));
			return;
		}
		freeSource.volume = volume;
		freeSource.Play();
	}

	// Token: 0x06000378 RID: 888 RVA: 0x00015F54 File Offset: 0x00014154
	public void FadeStopSound(SFXTypes name, float fadeLength, bool unduckMusic = false, float duckLength = 2.5f)
	{
		SFX sfx = this.samples.Find((SFX it) => it.type == name);
		if (sfx == null)
		{
			return;
		}
		if (unduckMusic)
		{
			this.DuckMusic(false, duckLength);
		}
		if (sfx.lastsource)
		{
			base.StartCoroutine(this.FadeSound(sfx.lastsource, false, fadeLength));
		}
	}

	// Token: 0x06000379 RID: 889 RVA: 0x00015FB8 File Offset: 0x000141B8
	public void StopSound(SFXTypes name, bool unduckMusic = false, float duckLength = 2.5f)
	{
		SFX sfx = this.samples.Find((SFX it) => it.type == name);
		if (sfx == null)
		{
			return;
		}
		if (unduckMusic)
		{
			this.DuckMusic(false, duckLength);
		}
		if (sfx.lastsource)
		{
			sfx.lastsource.Stop();
		}
	}

	// Token: 0x0600037A RID: 890 RVA: 0x00016011 File Offset: 0x00014211
	private IEnumerator FadeSound(AudioSource source, bool fadeIn, float lerpTime)
	{
		if (!fadeIn && !source.isPlaying)
		{
			yield break;
		}
		float currentLerpTime = 0f;
		float start = fadeIn ? 0f : 1f;
		float end = fadeIn ? 1f : 0f;
		while (currentLerpTime < lerpTime)
		{
			currentLerpTime += Time.deltaTime;
			float t = currentLerpTime / lerpTime;
			source.volume = Mathf.Lerp(start, end, t);
			yield return new WaitForEndOfFrame();
		}
		if (!fadeIn)
		{
			source.Stop();
		}
		source.volume = 1f;
		yield break;
	}

	// Token: 0x0600037B RID: 891 RVA: 0x00016030 File Offset: 0x00014230
	public void LinkVar(List<DataVariable> vars)
	{
		foreach (Vox vox in this.voces)
		{
		}
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0001607C File Offset: 0x0001427C
	private void AddSample(List<AudioClip> list, string nam, string name, AudioClip sample)
	{
		if (name.Contains(nam) && !list.Contains(sample))
		{
			list.Add(sample);
		}
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0001609C File Offset: 0x0001429C
	public JukeBox()
	{
		float[] array = new float[2];
		array[0] = 1f;
		this.weightDefault = array;
		this.weightLoop = new float[]
		{
			0f,
			1f
		};
		this.allMus = new List<Music>();
		this.trackid = -1;
		this.voVol = 1f;
		base..ctor();
	}

	// Token: 0x04000432 RID: 1074
	public List<Bearers> musicGroups;

	// Token: 0x04000433 RID: 1075
	public int id;

	// Token: 0x04000434 RID: 1076
	public List<Vox> voces;

	// Token: 0x04000435 RID: 1077
	public float cst = 0.06f;

	// Token: 0x04000436 RID: 1078
	public int mode;

	// Token: 0x04000437 RID: 1079
	public static JukeBox diff;

	// Token: 0x04000438 RID: 1080
	public AudioMixer MasterMix;

	// Token: 0x04000439 RID: 1081
	public AudioMixerGroup VOGroup;

	// Token: 0x0400043A RID: 1082
	public List<Music> musics = new List<Music>();

	// Token: 0x0400043B RID: 1083
	[Reorderable]
	public MusicList allmusic = new MusicList();

	// Token: 0x0400043C RID: 1084
	public int curDynastyId;

	// Token: 0x0400043D RID: 1085
	public int volCeiling = 12;

	// Token: 0x0400043E RID: 1086
	public int volFloor = 24;

	// Token: 0x0400043F RID: 1087
	public float attenCeilVal = 100f;

	// Token: 0x04000440 RID: 1088
	public int filterMinFreq = 1000;

	// Token: 0x04000441 RID: 1089
	private Music curMusic;

	// Token: 0x04000442 RID: 1090
	private string[] s = new string[]
	{
		"Church",
		"Folk",
		"Military",
		"Treasury"
	};

	// Token: 0x04000443 RID: 1091
	public List<VO> allvo = new List<VO>();

	// Token: 0x04000444 RID: 1092
	public AudioSource[] sfxSources;

	// Token: 0x04000445 RID: 1093
	public AudioSource[] uiSources;

	// Token: 0x04000446 RID: 1094
	public AudioSource[] ambientSources;

	// Token: 0x04000447 RID: 1095
	public AudioSource[] songSources;

	// Token: 0x04000448 RID: 1096
	public AudioSource[] voSources;

	// Token: 0x04000449 RID: 1097
	public List<SFX> samples;

	// Token: 0x0400044A RID: 1098
	private int lastclipid;

	// Token: 0x0400044B RID: 1099
	public Func<bool, Bearers> OnSpeak;

	// Token: 0x0400044C RID: 1100
	public AudioMixerSnapshot[] snapshots;

	// Token: 0x0400044D RID: 1101
	private float[] weightDefault;

	// Token: 0x0400044E RID: 1102
	private float[] weightLoop;

	// Token: 0x0400044F RID: 1103
	public bool RandomizeClip;

	// Token: 0x04000450 RID: 1104
	private Coroutine nextplay;

	// Token: 0x04000451 RID: 1105
	public bool isPlayingMusic;

	// Token: 0x04000452 RID: 1106
	private float pausetime;

	// Token: 0x04000453 RID: 1107
	private List<Music> allMus;

	// Token: 0x04000454 RID: 1108
	private int trackid;

	// Token: 0x04000455 RID: 1109
	private float sfxVol;

	// Token: 0x04000456 RID: 1110
	private float musVol;

	// Token: 0x04000457 RID: 1111
	private float voVol;

	// Token: 0x04000458 RID: 1112
	private bool isalt;

	// Token: 0x04000459 RID: 1113
	private IEnumerator speakCorout;
}
