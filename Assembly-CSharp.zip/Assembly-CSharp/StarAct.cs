﻿using System;
using UnityEngine;

// Token: 0x02000078 RID: 120
public class StarAct : MonoBehaviour
{
	// Token: 0x06000425 RID: 1061 RVA: 0x0001ABFD File Offset: 0x00018DFD
	public void DestroyStar()
	{
		Object.Destroy(base.transform.parent.gameObject);
	}
}
