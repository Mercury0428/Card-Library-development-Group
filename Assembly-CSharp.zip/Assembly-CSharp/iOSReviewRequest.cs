﻿using System;
using UnityEngine;

// Token: 0x02000058 RID: 88
public class iOSReviewRequest : MonoBehaviour
{
	// Token: 0x0600033B RID: 827 RVA: 0x00003D07 File Offset: 0x00001F07
	public static void Request()
	{
	}
}
