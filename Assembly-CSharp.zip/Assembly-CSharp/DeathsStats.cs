﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200003E RID: 62
public class DeathsStats : MonoBehaviour
{
	// Token: 0x060001F8 RID: 504 RVA: 0x0000C5A6 File Offset: 0x0000A7A6
	private void OnDisable()
	{
		this.Dismantle();
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x0000C5B0 File Offset: 0x0000A7B0
	private void Dismantle()
	{
		if (this.objs.Count > 0)
		{
			foreach (GameObject obj in this.objs)
			{
				Object.Destroy(obj);
			}
		}
		this.objs = new List<GameObject>();
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0000C61C File Offset: 0x0000A81C
	private void OnEnable()
	{
		this.Dismantle();
		this.seenD = GameAct.diff.seenEndCards;
		this.allD = GameAct.diff.endCards;
		int num = 0;
		int num2 = 0;
		int num3 = -80;
		int num4 = -180;
		int num5 = 0;
		List<Achievement> achieves = this.scKi.GetAchieves(AchieveTypes.endcard);
		int i;
		int j;
		for (i = 0; i < this.allD.Count; i = j + 1)
		{
			GameObject gameObject = Object.Instantiate<GameObject>(this.portraitPrefab);
			this.objs.Add(gameObject);
			gameObject.transform.SetParent(base.transform, false);
			SVGImage component = gameObject.GetComponent<SVGImage>();
			Text componentInChildren = gameObject.GetComponentInChildren<Text>();
			num5 = num3 + num4 * num;
			component.rectTransform.anchoredPosition = new Vector2((float)(-66 + num2 * 136), (float)num5);
			if (this.seenD.Contains(this.allD[i]))
			{
				component.vectorGraphics = (SVGAsset)Resources.Load("deaths/" + this.allD[i], typeof(SVGAsset));
				if (achieves.Find((Achievement it) => it.name == this.allD[i]) != null)
				{
					component.transform.Find("star").GetComponent<SVGImage>().enabled = true;
				}
			}
			componentInChildren.text = SpeechAct.diff.GetSceneText("end_" + this.allD[i]);
			num2++;
			if (num2 > 1)
			{
				num++;
				num2 = 0;
			}
			j = i;
		}
		base.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, (float)(-(float)num5 - num4));
	}

	// Token: 0x04000220 RID: 544
	public GameObject portraitPrefab;

	// Token: 0x04000221 RID: 545
	private List<string> seenD;

	// Token: 0x04000222 RID: 546
	private List<string> allD;

	// Token: 0x04000223 RID: 547
	public KingdomAct scKi;

	// Token: 0x04000224 RID: 548
	private List<GameObject> objs = new List<GameObject>();
}
