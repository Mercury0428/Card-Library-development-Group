﻿using System;
using UnityEngine;

// Token: 0x0200000D RID: 13
public class iOSHapticFeedback : MonoBehaviour
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000070 RID: 112 RVA: 0x00003BDD File Offset: 0x00001DDD
	public static iOSHapticFeedback Instance
	{
		get
		{
			if (!iOSHapticFeedback._instance)
			{
				Debug.LogWarning("No iOS Haptic Feedback instance available. Creating one.");
				iOSHapticFeedback._instance = new GameObject("iOS Haptic Feedback").AddComponent<iOSHapticFeedback>();
			}
			return iOSHapticFeedback._instance;
		}
	}

	// Token: 0x06000071 RID: 113 RVA: 0x00003C10 File Offset: 0x00001E10
	protected void Awake()
	{
		if (iOSHapticFeedback._instance)
		{
			Debug.LogWarning("There is already an instance of iOSHapticFeedback.");
			Object.Destroy(base.gameObject);
			return;
		}
		iOSHapticFeedback._instance = this;
		for (int i = 0; i < 5; i++)
		{
			if (this.FeedbackIdSet(i))
			{
				this.InstantiateFeedbackGenerator(i);
			}
		}
		this.feedbackGeneratorsSetUp = true;
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00003C68 File Offset: 0x00001E68
	protected void OnDestroy()
	{
		if (!this.feedbackGeneratorsSetUp)
		{
			return;
		}
		for (int i = 0; i < 5; i++)
		{
			if (this.FeedbackIdSet(i))
			{
				this.ReleaseFeedbackGenerator(i);
			}
		}
	}

	// Token: 0x06000073 RID: 115 RVA: 0x00003C9C File Offset: 0x00001E9C
	protected bool FeedbackIdSet(int id)
	{
		return (id == 0 && this.usedFeedbackTypes.SelectionChange) || (id == 1 && this.usedFeedbackTypes.ImpactLight) || (id == 2 && this.usedFeedbackTypes.ImpactMedium) || (id == 3 && this.usedFeedbackTypes.ImpactHeavy) || ((id == 4 || id == 5 || id == 6) && this.usedFeedbackTypes.Notifications);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00003D07 File Offset: 0x00001F07
	private void _instantiateFeedbackGenerator(int id)
	{
	}

	// Token: 0x06000075 RID: 117 RVA: 0x00003D07 File Offset: 0x00001F07
	private void _prepareFeedbackGenerator(int id)
	{
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00003D07 File Offset: 0x00001F07
	private void _triggerFeedbackGenerator(int id, bool advanced)
	{
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00003D07 File Offset: 0x00001F07
	private void _releaseFeedbackGenerator(int id)
	{
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003D09 File Offset: 0x00001F09
	protected void InstantiateFeedbackGenerator(int id)
	{
		if (this.debug)
		{
			Debug.Log("Instantiate iOS feedback generator " + (iOSHapticFeedback.iOSFeedbackType)id);
		}
		this._instantiateFeedbackGenerator(id);
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00003D2F File Offset: 0x00001F2F
	protected void PrepareFeedbackGenerator(int id)
	{
		if (this.debug)
		{
			Debug.Log("Prepare iOS feedback generator " + (iOSHapticFeedback.iOSFeedbackType)id);
		}
		this._prepareFeedbackGenerator(id);
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00003D58 File Offset: 0x00001F58
	protected void TriggerFeedbackGenerator(int id, bool advanced)
	{
		if (this.debug)
		{
			Debug.Log(string.Concat(new object[]
			{
				"Trigger iOS feedback generator ",
				(iOSHapticFeedback.iOSFeedbackType)id,
				", advanced mode: ",
				advanced.ToString()
			}));
		}
		this._triggerFeedbackGenerator(id, advanced);
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00003DA8 File Offset: 0x00001FA8
	protected void ReleaseFeedbackGenerator(int id)
	{
		if (this.debug)
		{
			Debug.Log("Release iOS feedback generator " + (iOSHapticFeedback.iOSFeedbackType)id);
		}
		this._releaseFeedbackGenerator(id);
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00003DCE File Offset: 0x00001FCE
	public void Trigger(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		if (this.FeedbackIdSet((int)feedbackType))
		{
			this.TriggerFeedbackGenerator((int)feedbackType, false);
			return;
		}
		Debug.LogError("You cannot trigger a feedback generator without instantiating it first");
	}

	// Token: 0x0400005C RID: 92
	private static iOSHapticFeedback _instance;

	// Token: 0x0400005D RID: 93
	public iOSHapticFeedback.iOSFeedbackTypeSettings usedFeedbackTypes = new iOSHapticFeedback.iOSFeedbackTypeSettings();

	// Token: 0x0400005E RID: 94
	private bool feedbackGeneratorsSetUp;

	// Token: 0x0400005F RID: 95
	public bool debug = true;

	// Token: 0x0200025A RID: 602
	[Serializable]
	public class iOSFeedbackTypeSettings
	{
		// Token: 0x1700033A RID: 826
		// (get) Token: 0x06001248 RID: 4680 RVA: 0x000676A6 File Offset: 0x000658A6
		public bool Notifications
		{
			get
			{
				return this.NotificationSuccess || this.NotificationWarning || this.NotificationFailure;
			}
		}

		// Token: 0x04000EBE RID: 3774
		public bool SelectionChange = true;

		// Token: 0x04000EBF RID: 3775
		public bool ImpactLight = true;

		// Token: 0x04000EC0 RID: 3776
		public bool ImpactMedium = true;

		// Token: 0x04000EC1 RID: 3777
		public bool ImpactHeavy = true;

		// Token: 0x04000EC2 RID: 3778
		public bool NotificationSuccess = true;

		// Token: 0x04000EC3 RID: 3779
		public bool NotificationWarning = true;

		// Token: 0x04000EC4 RID: 3780
		public bool NotificationFailure = true;
	}

	// Token: 0x0200025B RID: 603
	public enum iOSFeedbackType
	{
		// Token: 0x04000EC6 RID: 3782
		SelectionChange,
		// Token: 0x04000EC7 RID: 3783
		ImpactLight,
		// Token: 0x04000EC8 RID: 3784
		ImpactMedium,
		// Token: 0x04000EC9 RID: 3785
		ImpactHeavy,
		// Token: 0x04000ECA RID: 3786
		Success,
		// Token: 0x04000ECB RID: 3787
		Warning,
		// Token: 0x04000ECC RID: 3788
		Failure,
		// Token: 0x04000ECD RID: 3789
		None
	}
}
