﻿using System;

// Token: 0x02000056 RID: 86
public enum Inputs
{
	// Token: 0x040003D6 RID: 982
	xbox,
	// Token: 0x040003D7 RID: 983
	ps,
	// Token: 0x040003D8 RID: 984
	keyboard,
	// Token: 0x040003D9 RID: 985
	mouse,
	// Token: 0x040003DA RID: 986
	leap,
	// Token: 0x040003DB RID: 987
	touch,
	// Token: 0x040003DC RID: 988
	none,
	// Token: 0x040003DD RID: 989
	tv,
	// Token: 0x040003DE RID: 990
	twitch
}
