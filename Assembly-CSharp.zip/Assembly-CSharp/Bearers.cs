﻿using System;

// Token: 0x02000047 RID: 71
public enum Bearers
{
	// Token: 0x04000275 RID: 629
	coins = 1,
	// Token: 0x04000276 RID: 630
	grand_maester = 3,
	// Token: 0x04000277 RID: 631
	hand = 2,
	// Token: 0x04000278 RID: 632
	high_septon = 62,
	// Token: 0x04000279 RID: 633
	spider = 4,
	// Token: 0x0400027A RID: 634
	archer = 97,
	// Token: 0x0400027B RID: 635
	arryn_male = 83,
	// Token: 0x0400027C RID: 636
	arya = 46,
	// Token: 0x0400027D RID: 637
	banker = 82,
	// Token: 0x0400027E RID: 638
	blacksmith = 36,
	// Token: 0x0400027F RID: 639
	arryn = 49,
	// Token: 0x04000280 RID: 640
	cat = 98,
	// Token: 0x04000281 RID: 641
	greyjoy = 25,
	// Token: 0x04000282 RID: 642
	cersei = 55,
	// Token: 0x04000283 RID: 643
	lannister = 11,
	// Token: 0x04000284 RID: 644
	clegane = 56,
	// Token: 0x04000285 RID: 645
	martell = 8,
	// Token: 0x04000286 RID: 646
	commoner_female = 85,
	// Token: 0x04000287 RID: 647
	stark = 12,
	// Token: 0x04000288 RID: 648
	commoner_male = 84,
	// Token: 0x04000289 RID: 649
	targaryen = 13,
	// Token: 0x0400028A RID: 650
	tully = 30,
	// Token: 0x0400028B RID: 651
	cook = 38,
	// Token: 0x0400028C RID: 652
	tyrell = 10,
	// Token: 0x0400028D RID: 653
	courtesan = 94,
	// Token: 0x0400028E RID: 654
	crow = 5,
	// Token: 0x0400028F RID: 655
	crowd = 71,
	// Token: 0x04000290 RID: 656
	daenerys = 47,
	// Token: 0x04000291 RID: 657
	dothraki = 50,
	// Token: 0x04000292 RID: 658
	drogon = 27,
	// Token: 0x04000293 RID: 659
	dungeon = 68,
	// Token: 0x04000294 RID: 660
	forest_child = 105,
	// Token: 0x04000295 RID: 661
	freefolk = 90,
	// Token: 0x04000296 RID: 662
	gendry = 75,
	// Token: 0x04000297 RID: 663
	goldcloak = 89,
	// Token: 0x04000298 RID: 664
	greyjoy_male = 72,
	// Token: 0x04000299 RID: 665
	handmaiden = 32,
	// Token: 0x0400029A RID: 666
	jaime = 74,
	// Token: 0x0400029B RID: 667
	jon = 54,
	// Token: 0x0400029C RID: 668
	kingsguard = 87,
	// Token: 0x0400029D RID: 669
	kirsten = 101,
	// Token: 0x0400029E RID: 670
	knight = 88,
	// Token: 0x0400029F RID: 671
	lannister_male = 65,
	// Token: 0x040002A0 RID: 672
	lannister_soldier = 103,
	// Token: 0x040002A1 RID: 673
	little_bird = 95,
	// Token: 0x040002A2 RID: 674
	maester = 17,
	// Token: 0x040002A3 RID: 675
	martell_female = 102,
	// Token: 0x040002A4 RID: 676
	melisandre = 51,
	// Token: 0x040002A5 RID: 677
	militant = 78,
	// Token: 0x040002A6 RID: 678
	nobleman = 48,
	// Token: 0x040002A7 RID: 679
	pirate = 91,
	// Token: 0x040002A8 RID: 680
	pyromancer = 52,
	// Token: 0x040002A9 RID: 681
	raven = 79,
	// Token: 0x040002AA RID: 682
	rhaegal = 106,
	// Token: 0x040002AB RID: 683
	sam = 73,
	// Token: 0x040002AC RID: 684
	sansa = 14,
	// Token: 0x040002AD RID: 685
	scorpion = 63,
	// Token: 0x040002AE RID: 686
	sellsword = 96,
	// Token: 0x040002AF RID: 687
	septa = 92,
	// Token: 0x040002B0 RID: 688
	septon = 44,
	// Token: 0x040002B1 RID: 689
	soldier = 16,
	// Token: 0x040002B2 RID: 690
	stark_male = 66,
	// Token: 0x040002B3 RID: 691
	three_eyed_raven = 45,
	// Token: 0x040002B4 RID: 692
	throne = 26,
	// Token: 0x040002B5 RID: 693
	tully_male = 100,
	// Token: 0x040002B6 RID: 694
	tyrell_female = 69,
	// Token: 0x040002B7 RID: 695
	tyrion = 61,
	// Token: 0x040002B8 RID: 696
	unsullied = 86,
	// Token: 0x040002B9 RID: 697
	varys = 59,
	// Token: 0x040002BA RID: 698
	walker = 93,
	// Token: 0x040002BB RID: 699
	weirwood = 107,
	// Token: 0x040002BC RID: 700
	white_raven = 80,
	// Token: 0x040002BD RID: 701
	wolf = 60,
	// Token: 0x040002BE RID: 702
	antagonist = 64,
	// Token: 0x040002BF RID: 703
	anyone = 19,
	// Token: 0x040002C0 RID: 704
	commander = 104,
	// Token: 0x040002C1 RID: 705
	end = 18,
	// Token: 0x040002C2 RID: 706
	female = 29,
	// Token: 0x040002C3 RID: 707
	male = 28,
	// Token: 0x040002C4 RID: 708
	military = 99,
	// Token: 0x040002C5 RID: 709
	noble = 41,
	// Token: 0x040002C6 RID: 710
	people = 70,
	// Token: 0x040002C7 RID: 711
	pious = 81,
	// Token: 0x040002C8 RID: 712
	reigning = 37,
	// Token: 0x040002C9 RID: 713
	cell = 108,
	// Token: 0x040002CA RID: 714
	jailor = 110,
	// Token: 0x040002CB RID: 715
	wall,
	// Token: 0x040002CC RID: 716
	wight,
	// Token: 0x040002CD RID: 717
	none = 1000
}
