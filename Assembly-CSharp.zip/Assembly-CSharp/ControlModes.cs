﻿using System;

// Token: 0x02000017 RID: 23
public enum ControlModes
{
	// Token: 0x04000080 RID: 128
	next,
	// Token: 0x04000081 RID: 129
	nextmenu,
	// Token: 0x04000082 RID: 130
	selectback,
	// Token: 0x04000083 RID: 131
	resetmenu,
	// Token: 0x04000084 RID: 132
	multichoice,
	// Token: 0x04000085 RID: 133
	none
}
