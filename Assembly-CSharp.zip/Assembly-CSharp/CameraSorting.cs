﻿using System;
using UnityEngine;

// Token: 0x0200008B RID: 139
[RequireComponent(typeof(Camera))]
[ExecuteInEditMode]
public class CameraSorting : MonoBehaviour
{
	// Token: 0x06000482 RID: 1154 RVA: 0x0001C579 File Offset: 0x0001A779
	private void OnEnable()
	{
		if (this.cameraTarget == null)
		{
			this.cameraTarget = base.GetComponent<Camera>();
		}
		this.cameraTarget.transparencySortMode = this.transparencySortMode;
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x0001C579 File Offset: 0x0001A779
	private void OnValidate()
	{
		if (this.cameraTarget == null)
		{
			this.cameraTarget = base.GetComponent<Camera>();
		}
		this.cameraTarget.transparencySortMode = this.transparencySortMode;
	}

	// Token: 0x0400053F RID: 1343
	public TransparencySortMode transparencySortMode;

	// Token: 0x04000540 RID: 1344
	protected Camera cameraTarget;
}
