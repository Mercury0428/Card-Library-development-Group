﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000020 RID: 32
public class AchieveBox : ContentBox
{
	// Token: 0x06000108 RID: 264 RVA: 0x0000620C File Offset: 0x0000440C
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
		List<string> list = (List<string>)instance;
		this.titleTxt.text = list[0];
		this.descriptTxt.text = list[1];
		if (list.Count == 3)
		{
			base.StartCoroutine("ShowHighScore", list[2]);
		}
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00002EE2 File Offset: 0x000010E2
	public override void Validate()
	{
		base.StartCoroutine("PlayAnim");
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00006260 File Offset: 0x00004460
	private IEnumerator PlayAnim()
	{
		yield return new WaitForSeconds(0.2f);
		yield break;
	}

	// Token: 0x0600010B RID: 267 RVA: 0x00006268 File Offset: 0x00004468
	private IEnumerator ShowHighScore(string alt)
	{
		string txt = this.titleTxt.text;
		WaitForSeconds swait = new WaitForSeconds(0.4f);
		WaitForSeconds lwait = new WaitForSeconds(1f);
		for (;;)
		{
			this.titleTxt.text = txt;
			yield return lwait;
			this.titleTxt.text = "";
			yield return swait;
			int num;
			for (int i = 0; i < 3; i = num + 1)
			{
				this.titleTxt.text = alt;
				yield return swait;
				this.titleTxt.text = "";
				yield return swait;
				num = i;
			}
		}
		yield break;
	}

	// Token: 0x040000E7 RID: 231
	public Text titleTxt;

	// Token: 0x040000E8 RID: 232
	public Text descriptTxt;

	// Token: 0x040000E9 RID: 233
	public string sfx;
}
