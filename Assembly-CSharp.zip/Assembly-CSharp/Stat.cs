﻿using System;
using System.Collections.Generic;

// Token: 0x0200004A RID: 74
[Serializable]
public class Stat
{
	// Token: 0x04000340 RID: 832
	public List<string> seenendcards;

	// Token: 0x04000341 RID: 833
	public List<int> seencards;
}
