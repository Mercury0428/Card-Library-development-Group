﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000065 RID: 101
public class KingdomAct : MonoBehaviour
{
	// Token: 0x06000383 RID: 899 RVA: 0x00016798 File Offset: 0x00014998
	private void Awake()
	{
		this.scObj = base.GetComponent<ObjectiveAct>();
		this.scEff = base.GetComponent<EffectAct>();
		this.GetReignsModels();
	}

	// Token: 0x06000384 RID: 900 RVA: 0x000167B8 File Offset: 0x000149B8
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnSave = (Action<Game>)Delegate.Combine(diff.OnSave, new Action<Game>(this.SaveReigns));
		GameAct diff2 = GameAct.diff;
		diff2.OnLoad = (Action<Game>)Delegate.Combine(diff2.OnLoad, new Action<Game>(this.LoadReigns));
		GameAct diff3 = GameAct.diff;
		diff3.OnLoadOld = (Action<string>)Delegate.Combine(diff3.OnLoadOld, new Action<string>(this.LoadOldReigns));
	}

	// Token: 0x06000385 RID: 901 RVA: 0x00016838 File Offset: 0x00014A38
	private void GetReignsModels()
	{
		Dictionary<string, string[]> i18n = new Dictionary<string, string[]>();
		string[] array = Util.GetTextFile("texts/reigns").Split(new char[]
		{
			'\n'
		});
		string[] columns = array[0].Split(new char[]
		{
			this.dele
		});
		for (int i = 1; i < array.Length; i++)
		{
			this.reignsModels.Add(new Reign(array[i].Split(new char[]
			{
				this.dele
			}), columns, this.dele, i18n));
		}
	}

	// Token: 0x06000386 RID: 902 RVA: 0x000168BC File Offset: 0x00014ABC
	private void SaveReigns(Game save)
	{
		if (this.reigns.Count == 0)
		{
			return;
		}
		this.reigns[this.reigns.Count - 1].end = GameAct.diff.GetYear();
		save.reigns = this.reigns;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x0001690A File Offset: 0x00014B0A
	private void LoadReigns(Game save)
	{
		this.reigns = save.reigns;
		if (this.reigns == null)
		{
			this.reigns = new List<Reign>();
		}
	}

	// Token: 0x06000388 RID: 904 RVA: 0x0001692B File Offset: 0x00014B2B
	private void LoadOldReigns(string name)
	{
		this.reigns = DataStore.LoadOld<List<Reign>>("reigns_" + name, false);
		if (this.reigns == null)
		{
			this.reigns = new List<Reign>();
		}
	}

	// Token: 0x06000389 RID: 905 RVA: 0x00016958 File Offset: 0x00014B58
	public List<Outcome> PotentialReigns()
	{
		List<Outcome> list = new List<Outcome>();
		int notthatone = -1;
		for (int i = 0; i < 2; i++)
		{
			Reign reign = this.PotentialReign(notthatone);
			notthatone = reign.id;
			list.Add(new Outcome(Variables.nextreign, reign.id));
		}
		return list;
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0001699C File Offset: 0x00014B9C
	private Reign PotentialReign(int notthatone = -1)
	{
		List<Reign> list = new List<Reign>();
		List<Reign> list2 = this.reignsModels.FindAll((Reign it) => it.id != notthatone);
		List<float> list3 = new List<float>
		{
			0f
		};
		for (int i = 0; i < list2.Count; i++)
		{
			Reign reign = list2[i];
			if (this.TestReign(reign))
			{
				list3.Add((float)reign.weight + list3[list3.Count - 1]);
				list.Add(reign);
				if (reign.weight == -1)
				{
					return reign;
				}
			}
		}
		if (list.Count == 1)
		{
			return list[0];
		}
		float num = Util.Rand(0.1f, list3[list3.Count - 1]);
		for (int j = 0; j < list3.Count; j++)
		{
			if (list3[j] > num)
			{
				return list[j];
			}
		}
		return null;
	}

	// Token: 0x0600038B RID: 907 RVA: 0x00016A98 File Offset: 0x00014C98
	private bool TestReign(Reign reign)
	{
		if (this.reigns.Count > 0)
		{
			int num = this.reigns.FindLastIndex((Reign it) => it.id == reign.id);
			if (this.reigns.Count - num < reign.lockturn || reign.lockturn == -1)
			{
				return false;
			}
		}
		return GameAct.diff.HasBearer(reign.bearer, Bearers.none, Bearers.none) != null && GameAct.diff.TestCond(reign.conditions);
	}

	// Token: 0x0600038C RID: 908 RVA: 0x00016B40 File Offset: 0x00014D40
	public void SetCurrentNick(string nick, string id)
	{
		Reign reign = this.reigns[this.reigns.Count - 1];
		if (!string.IsNullOrEmpty(id))
		{
			reign.nickId = id;
		}
		reign.name = this.monarch.firstname + " " + nick;
		GameAct.diff.SetRulerName(reign.name);
	}

	// Token: 0x0600038D RID: 909 RVA: 0x00016BA4 File Offset: 0x00014DA4
	public void FinishReign(int nend, string nendcard)
	{
		if (this.reigns.Count == 0)
		{
			return;
		}
		Reign reign = this.reigns[this.reigns.Count - 1];
		reign.end = nend;
		reign.isDead = true;
		reign.endCard = nendcard;
		if (this.reigns.Count > 99)
		{
			SocialAct.diff.AddAchieve("hundredGoT");
		}
		DataStore.Save<List<Achievement>>("achievetodisplay_save", this.achieves, false, false);
		this.achieves = new List<Achievement>();
	}

	// Token: 0x0600038E RID: 910 RVA: 0x00016C28 File Offset: 0x00014E28
	public Reign StartReign(int start, int forceid = -1)
	{
		int nextid = (forceid == -1) ? GameAct.diff.GetInt(Variables.nextreign) : forceid;
		List<Reign> list = this.reignsModels.FindAll((Reign it) => it.id == nextid);
		List<Reign> list2 = new List<Reign>();
		foreach (Reign reign in list)
		{
			if (GameAct.diff.TestCond(reign.conditions))
			{
				list2.Add(reign);
			}
		}
		if (list2.Count == 0)
		{
			return null;
		}
		Reign reign2 = new Reign(list2[Util.RandInt(0, list2.Count)], start);
		this.reigns.Add(reign2);
		this.TempReign();
		return reign2;
	}

	// Token: 0x0600038F RID: 911 RVA: 0x00016CFC File Offset: 0x00014EFC
	public void TempReign()
	{
		this.monarch = CardReader.diff.bearerModels.Find((Bearer it) => it.bearer == this.reigns[this.reigns.Count - 1].bearer);
		SpeechAct.diff.isMonarkMale = this.monarch.character.Contains(Bearers.male);
	}

	// Token: 0x06000390 RID: 912 RVA: 0x00016D3C File Offset: 0x00014F3C
	public void InitReign()
	{
		List<Bearer> bearerModels = CardReader.diff.bearerModels;
		Reign reign = this.reignsModels.Find((Reign it) => it.bearer == Bearers.anyone);
		Reign nreign = (this.reigns.Count == 0) ? this.reignsModels[1] : this.reigns[this.reigns.Count - 1];
		foreach (Bearer bearer in bearerModels)
		{
			bearer.vote = (float)(nreign.unhappy.Contains(bearer.bearer) ? -4 : 1);
		}
		CardReader.diff.ResetSystemChara();
		CardReader.diff.AddCharacterToModels(Bearers.antagonist, nreign.antagonists);
		this.monarch = bearerModels.Find((Bearer it) => it.bearer == nreign.bearer);
		CardReader.diff.AddCharacterToModel(Bearers.reigning, this.monarch.bearer);
		SpeechAct.diff.isMonarkMale = this.monarch.character.Contains(Bearers.male);
		GameAct.diff.kingSign.text = (string.IsNullOrEmpty(this.monarch.firstname) ? this.monarch.generated.Get() : (SpeechAct.diff.GetSceneText("ruler") + " " + this.monarch.firstname));
		for (int i = 0; i < reign.court.Count; i++)
		{
			if (GameAct.diff.HasSeenBearer(reign.court[i]))
			{
				Bearer targetBearer = GameAct.diff.AddBearer(reign.court[i], null, true);
				if (reign.functions[i] != Bearers.none)
				{
					GameAct.diff.AddBearer(reign.functions[i], targetBearer, true);
				}
			}
		}
		for (int j = 0; j < nreign.court.Count; j++)
		{
			Bearer targetBearer2 = GameAct.diff.AddBearer(nreign.court[j], null, true);
			if (nreign.functions[j] != Bearers.none)
			{
				GameAct.diff.AddBearer(nreign.functions[j], targetBearer2, true);
			}
			if (nreign.id == 0)
			{
				GameAct.diff.UpdateStatBearer(nreign.court[j], false);
			}
		}
		Outcome outcome = nreign.startActions.Find((Outcome it) => it.variable == Variables.set && it.bearer == Bearers.none);
		if (outcome != null)
		{
			BackgroundAct.diff.PrepareBackSwitch(outcome.custom_name, 0, true, false);
		}
		else
		{
			BackgroundAct.diff.PrepareBackSwitch("defaut", 0, true, false);
		}
		GameAct.diff.TreatOutcomes(reign.startActions, -1);
		GameAct.diff.TreatOutcomes(nreign.startActions, -1);
		foreach (Outcome outcome2 in nreign.startActions)
		{
			Variables variable = outcome2.variable;
			if (variable - Variables.people <= 3)
			{
				GameAct.diff.SetInt(outcome2.variable, outcome2.value);
			}
		}
		Effect effect = this.scEff.GetEffect(this.monarch.bearer.ToString() + "_super");
		if (effect != null && effect.seen)
		{
			GameAct.diff.SetInt(effect.tag, 1);
		}
	}

	// Token: 0x06000391 RID: 913 RVA: 0x00017144 File Offset: 0x00015344
	public Reign GetLastDead()
	{
		Reign reign = this.reigns.FindLast((Reign it) => it.isDead);
		if (reign == null)
		{
			return this.reigns[this.reigns.Count - 1];
		}
		return reign;
	}

	// Token: 0x06000392 RID: 914 RVA: 0x00017199 File Offset: 0x00015399
	public List<Reign> GetReignsWithCurrent()
	{
		return this.reigns;
	}

	// Token: 0x06000393 RID: 915 RVA: 0x000171A1 File Offset: 0x000153A1
	public Reign GetCurrentReign()
	{
		return this.reigns[this.reigns.Count - 1];
	}

	// Token: 0x06000394 RID: 916 RVA: 0x000171BC File Offset: 0x000153BC
	private void ClearWindows(bool openmenu = false)
	{
		InputAct.diff.SuspendSlideFocus();
		base.StopAllCoroutines();
		this.optionsBloc.SetActive(false);
		this.kingdomBloc.SetActive(false);
		this.effectsBloc.SetActive(false);
		if (openmenu)
		{
			JukeBox.diff.PlaySound(SFXTypes.ui_menu_open, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000395 RID: 917 RVA: 0x00017240 File Offset: 0x00015440
	public void CloseWindows()
	{
		InputAct.diff.RestoreSlideFocus();
		this.optionsBloc.SetActive(false);
		this.kingdomBloc.SetActive(false);
		this.effectsBloc.SetActive(false);
		if (AnimBut.diff)
		{
			AnimBut.diff.ResetLock(true);
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_menu_close, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000396 RID: 918 RVA: 0x000172B3 File Offset: 0x000154B3
	public void OpenStats(bool openmenu = false)
	{
		this.ClearWindows(openmenu);
		this.kingdomBloc.SetActive(true);
		this.UpdateStats();
	}

	// Token: 0x06000397 RID: 919 RVA: 0x000172CE File Offset: 0x000154CE
	public List<Achievement> GetAchieves()
	{
		this.curAchieve = DataStore.LoadOld<List<Achievement>>("achievetodisplay_save", false);
		return this.curAchieve;
	}

	// Token: 0x06000398 RID: 920 RVA: 0x000172E8 File Offset: 0x000154E8
	public List<Achievement> GetAchieves(AchieveTypes type)
	{
		if (this.curAchieve != null && this.curAchieve.Count > 0)
		{
			return this.curAchieve.FindAll((Achievement it) => it.type == type);
		}
		return new List<Achievement>();
	}

	// Token: 0x06000399 RID: 921 RVA: 0x00017335 File Offset: 0x00015535
	public void AddAchieve(string nam, AchieveTypes typ)
	{
		this.achieves.Add(new Achievement(nam, typ));
	}

	// Token: 0x0600039A RID: 922 RVA: 0x00017349 File Offset: 0x00015549
	public void OpenObjectives()
	{
		this.kingdomBloc.SetActive(false);
		this.objectivesBloc.SetActive(true);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0600039B RID: 923 RVA: 0x00017381 File Offset: 0x00015581
	public void OpenBearers()
	{
		this.kingdomBloc.SetActive(false);
		this.bearersBloc.SetActive(true);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0600039C RID: 924 RVA: 0x000173B9 File Offset: 0x000155B9
	public void OpenDeaths()
	{
		this.kingdomBloc.SetActive(false);
		this.deathsBloc.SetActive(true);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x0600039D RID: 925 RVA: 0x000173F1 File Offset: 0x000155F1
	public void CloseStats()
	{
		InputAct.diff.RestoreSlideFocus();
		this.kingdomBloc.SetActive(false);
	}

	// Token: 0x0600039E RID: 926 RVA: 0x00017409 File Offset: 0x00015609
	public void CloseBlocs()
	{
		this.bearersBloc.SetActive(false);
		this.deathsBloc.SetActive(false);
		this.objectivesBloc.SetActive(false);
		this.OpenStats(false);
	}

	// Token: 0x0600039F RID: 927 RVA: 0x00017436 File Offset: 0x00015636
	public void CloseMore()
	{
		this.moreBloc.SetActive(false);
		this.OpenOptions(false);
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x0001744B File Offset: 0x0001564B
	public bool IsInSubMenu()
	{
		return this.bearersBloc.activeSelf || this.deathsBloc.activeSelf || this.objectivesBloc.activeSelf;
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x00017478 File Offset: 0x00015678
	private void UpdateStats()
	{
		try
		{
			float num = GameAct.diff.timespent / 60f;
			float num2 = Mathf.Floor(num / 60f);
			Mathf.Round(num - num2 * 60f);
			this.SetAchieve("objective_stats", 0, this.scObj.GetFulfilled().Count, this.scObj.GetAll().Count, false);
			this.SetAchieve("endcard_stats", 1, GameAct.diff.seenEndCards.Count, GameAct.diff.endCards.Count, false);
			this.SetAchieve("character_stats", 2, GameAct.diff.metBearers.Count, GameAct.diff.GetRegularBearers().Count, false);
			this.SetAchieve("card_stats", 3, GameAct.diff.GetSeenCardsNb(), GameAct.diff.GetCardsNb(), true);
			List<Achievement> list = this.GetAchieves();
			if (list != null)
			{
				bool active = list.Find((Achievement it) => it.type == AchieveTypes.objective) != null;
				this.newSigns[0].SetActive(active);
				active = (list.Find((Achievement it) => it.type == AchieveTypes.endcard) != null);
				this.newSigns[1].SetActive(active);
				active = (list.Find((Achievement it) => it.type == AchieveTypes.character) != null);
				this.newSigns[2].SetActive(active);
			}
			foreach (object obj in this.allobjBoxInStat)
			{
				Object.Destroy(((Transform)obj).gameObject);
			}
			this.scObj.ShowObjectives(this.allobjBoxInStat, 0, false, false, 2f);
		}
		catch
		{
			InputAct.diff.OfferReset(true, null);
		}
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x000176B0 File Offset: 0x000158B0
	public string FormatPower(Reign re, bool justnum = false)
	{
		if (re == null)
		{
			return "";
		}
		if (SpeechAct.diff.lang == "jp")
		{
			return SpeechAct.diff.JapanNum("time", 1 + re.end - re.start);
		}
		if (!justnum)
		{
			return (1 + re.end - re.start).ToString() + " " + SpeechAct.diff.GetSceneNum("time", 1 + re.end - re.start);
		}
		return (1 + re.end - re.start).ToString();
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00017758 File Offset: 0x00015958
	public bool CheckHighScore(int age)
	{
		return this.reigns.Count != 1 && this.reigns.Find((Reign it) => it.end - it.start > age) == null;
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x000177A0 File Offset: 0x000159A0
	public bool IsHighScore(Reign last)
	{
		if (this.reigns.Count < 3)
		{
			return false;
		}
		return (from it in this.reigns
		orderby it.end - it.start descending
		select it).ToList<Reign>()[0] == last;
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x000177F8 File Offset: 0x000159F8
	private IEnumerator StillAlive(int id, string alt)
	{
		yield return new WaitForSeconds(1f);
		WaitForSeconds lwait = new WaitForSeconds(0.4f);
		WaitForSeconds swait = new WaitForSeconds(0.2f);
		for (;;)
		{
			int num;
			for (int i = 0; i < 4; i = num + 1)
			{
				this.scoreYearsTxts[id].text = SpeechAct.diff.GetSceneText("highscore_label", 1);
				yield return lwait;
				this.scoreYearsTxts[id].text = "";
				yield return swait;
				num = i;
			}
			this.scoreYearsTxts[id].text = alt;
			yield return swait;
		}
		yield break;
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x00017818 File Offset: 0x00015A18
	private void SetAchieve(string txtid, int id, int cur, int max, bool shorttxt = false)
	{
		this.achieveTxts[id].text = (shorttxt ? (cur.ToString() + " " + SpeechAct.diff.GetSceneText(txtid, 1)) : string.Concat(new string[]
		{
			cur.ToString(),
			" / ",
			max.ToString(),
			" ",
			SpeechAct.diff.GetSceneText(txtid, 1)
		}));
		float value = (float)cur / (float)max;
		this.achieveSliders[id].value = value;
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x000178A8 File Offset: 0x00015AA8
	public void OpenEffects(bool openmenu = false)
	{
		this.ClearWindows(openmenu);
		this.effectsBloc.SetActive(true);
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x000178BD File Offset: 0x00015ABD
	public void CloseEffects()
	{
		InputAct.diff.RestoreSlideFocus();
		this.effectsBloc.SetActive(false);
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000178D5 File Offset: 0x00015AD5
	public void OpenOptions(bool openmenu)
	{
		this.ClearWindows(openmenu);
		this.optionsBloc.SetActive(true);
	}

	// Token: 0x060003AA RID: 938 RVA: 0x000178EA File Offset: 0x00015AEA
	public void CloseOptions()
	{
		InputAct.diff.RestoreSlideFocus();
		this.optionsBloc.SetActive(false);
	}

	// Token: 0x04000476 RID: 1142
	private ObjectiveAct scObj;

	// Token: 0x04000477 RID: 1143
	private EffectAct scEff;

	// Token: 0x04000478 RID: 1144
	public List<Reign> reignsModels = new List<Reign>();

	// Token: 0x04000479 RID: 1145
	public List<Reign> reigns = new List<Reign>();

	// Token: 0x0400047A RID: 1146
	public Bearer monarch;

	// Token: 0x0400047B RID: 1147
	private char dele = ';';

	// Token: 0x0400047C RID: 1148
	public GameObject kingdomBloc;

	// Token: 0x0400047D RID: 1149
	public GameObject effectsBloc;

	// Token: 0x0400047E RID: 1150
	public GameObject objectivesBloc;

	// Token: 0x0400047F RID: 1151
	public GameObject optionsBloc;

	// Token: 0x04000480 RID: 1152
	public GameObject bearersBloc;

	// Token: 0x04000481 RID: 1153
	public GameObject deathsBloc;

	// Token: 0x04000482 RID: 1154
	public GameObject moreBloc;

	// Token: 0x04000483 RID: 1155
	public Text timeTxt;

	// Token: 0x04000484 RID: 1156
	public Text[] achieveTxts;

	// Token: 0x04000485 RID: 1157
	public Slider[] achieveSliders;

	// Token: 0x04000486 RID: 1158
	public Text[] scoreKingTxts;

	// Token: 0x04000487 RID: 1159
	public Text[] scoreYearsTxts;

	// Token: 0x04000488 RID: 1160
	public GameObject[] newSigns;

	// Token: 0x04000489 RID: 1161
	private List<Achievement> achieves = new List<Achievement>();

	// Token: 0x0400048A RID: 1162
	public Transform allobjBoxInStat;

	// Token: 0x0400048B RID: 1163
	private List<Achievement> curAchieve = new List<Achievement>();

	// Token: 0x0400048C RID: 1164
	public GameObject DiaPrefab;

	// Token: 0x0400048D RID: 1165
	public Transform canvas;
}
