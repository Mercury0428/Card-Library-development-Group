﻿using System;

// Token: 0x02000042 RID: 66
public enum SpecialEffects
{
	// Token: 0x0400022F RID: 559
	lover,
	// Token: 0x04000230 RID: 560
	deaf,
	// Token: 0x04000231 RID: 561
	drunk,
	// Token: 0x04000232 RID: 562
	stone,
	// Token: 0x04000233 RID: 563
	mothervisit,
	// Token: 0x04000234 RID: 564
	devilcurse,
	// Token: 0x04000235 RID: 565
	nochurch,
	// Token: 0x04000236 RID: 566
	dungeon,
	// Token: 0x04000237 RID: 567
	crusade,
	// Token: 0x04000238 RID: 568
	colonies,
	// Token: 0x04000239 RID: 569
	clarity
}
