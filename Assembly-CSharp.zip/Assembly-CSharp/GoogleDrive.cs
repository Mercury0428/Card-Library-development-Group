﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using JsonFx.Json;
using Midworld;
using UnityEngine;

// Token: 0x0200000A RID: 10
internal class GoogleDrive
{
	// Token: 0x17000002 RID: 2
	// (get) Token: 0x0600003D RID: 61 RVA: 0x00003578 File Offset: 0x00001778
	// (set) Token: 0x0600003E RID: 62 RVA: 0x00003580 File Offset: 0x00001780
	public string ClientID { get; set; }

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x0600003F RID: 63 RVA: 0x00003589 File Offset: 0x00001789
	// (set) Token: 0x06000040 RID: 64 RVA: 0x00003591 File Offset: 0x00001791
	public string ClientSecret { get; set; }

	// Token: 0x06000041 RID: 65 RVA: 0x0000359C File Offset: 0x0000179C
	public static T GetResult<T>(IEnumerator async)
	{
		if (async.Current is GoogleDrive.AsyncSuccess)
		{
			return (T)((object)(async.Current as GoogleDrive.AsyncSuccess).Result);
		}
		return default(T);
	}

	// Token: 0x06000042 RID: 66 RVA: 0x000035D5 File Offset: 0x000017D5
	public static bool IsDone(IEnumerator async)
	{
		return async.Current is GoogleDrive.AsyncSuccess || async.Current is GoogleDrive.Exception;
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000044 RID: 68 RVA: 0x00003612 File Offset: 0x00001812
	private string RedirectURI
	{
		get
		{
			return "http://localhost:" + 9271;
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000046 RID: 70 RVA: 0x0000363B File Offset: 0x0000183B
	// (set) Token: 0x06000045 RID: 69 RVA: 0x00003628 File Offset: 0x00001828
	public string[] Scopes
	{
		get
		{
			return this.scopes;
		}
		set
		{
			this.scopes = (string[])value.Clone();
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000047 RID: 71 RVA: 0x00003644 File Offset: 0x00001844
	private Uri AuthorizationURL
	{
		get
		{
			return new Uri(string.Concat(new string[]
			{
				"https://accounts.google.com/o/oauth2/auth?scope=",
				string.Join(" ", this.Scopes),
				"&response_type=code&redirect_uri=",
				this.RedirectURI,
				"&client_id=",
				this.ClientID
			}));
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000048 RID: 72 RVA: 0x0000369E File Offset: 0x0000189E
	// (set) Token: 0x06000049 RID: 73 RVA: 0x000036A6 File Offset: 0x000018A6
	public bool IsAuthorized
	{
		get
		{
			return this.isAuthorized;
		}
		private set
		{
			this.isAuthorized = value;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x0600004A RID: 74 RVA: 0x000036B0 File Offset: 0x000018B0
	// (set) Token: 0x0600004B RID: 75 RVA: 0x000036F8 File Offset: 0x000018F8
	private string AccessToken
	{
		get
		{
			if (this.accessToken == null)
			{
				int hashCode = this.ClientID.GetHashCode();
				this.accessToken = PlayerPrefs.GetString("UnityGoogleDrive_Token_" + hashCode, "");
			}
			return this.accessToken;
		}
		set
		{
			if (this.accessToken != value)
			{
				this.accessToken = value;
				int hashCode = this.ClientID.GetHashCode();
				if (this.accessToken != null)
				{
					PlayerPrefs.SetString("UnityGoogleDrive_Token_" + hashCode, this.accessToken);
					return;
				}
				PlayerPrefs.DeleteKey("UnityGoogleDrive_Token_" + hashCode);
			}
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x0600004C RID: 76 RVA: 0x00003760 File Offset: 0x00001960
	// (set) Token: 0x0600004D RID: 77 RVA: 0x000037A8 File Offset: 0x000019A8
	private string RefreshToken
	{
		get
		{
			if (this.refreshToken == null)
			{
				int hashCode = this.ClientID.GetHashCode();
				this.refreshToken = PlayerPrefs.GetString("UnityGoogleDrive_RefreshToken_" + hashCode, "");
			}
			return this.refreshToken;
		}
		set
		{
			if (this.refreshToken != value)
			{
				this.refreshToken = value;
				int hashCode = this.ClientID.GetHashCode();
				if (this.refreshToken != null)
				{
					PlayerPrefs.SetString("UnityGoogleDrive_RefreshToken_" + hashCode, this.refreshToken);
					return;
				}
				PlayerPrefs.DeleteKey("UnityGoogleDrive_RefreshToken_" + hashCode);
			}
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x0600004E RID: 78 RVA: 0x00003810 File Offset: 0x00001A10
	// (set) Token: 0x0600004F RID: 79 RVA: 0x00003858 File Offset: 0x00001A58
	public string UserAccount
	{
		get
		{
			if (this.userAccount == null)
			{
				int hashCode = this.ClientID.GetHashCode();
				this.userAccount = PlayerPrefs.GetString("UnityGoogleDrive_UserAccount_" + hashCode, "");
			}
			return this.userAccount;
		}
		private set
		{
			if (this.userAccount != value)
			{
				this.userAccount = value;
				int hashCode = this.ClientID.GetHashCode();
				if (this.userAccount != null)
				{
					PlayerPrefs.SetString("UnityGoogleDrive_UserAccount_" + hashCode, this.userAccount);
					return;
				}
				PlayerPrefs.DeleteKey("UnityGoogleDrive_UserAccount_" + hashCode);
			}
		}
	}

	// Token: 0x06000050 RID: 80 RVA: 0x000038BF File Offset: 0x00001ABF
	public IEnumerator Authorize()
	{
		if (Application.platform == RuntimePlatform.Android)
		{
			if (this.ClientID == null)
			{
				yield return new GoogleDrive.Exception(-1, "ClientID is null.");
				yield break;
			}
		}
		else if (this.ClientID == null || this.ClientSecret == null)
		{
			yield return new GoogleDrive.Exception(-1, "ClientID or ClientSecret is null.");
			yield break;
		}
		if (this.AccessToken == "")
		{
			IEnumerator routine = this.GetAuthorizationCodeAndAccessToken();
			while (routine.MoveNext())
			{
				yield return null;
			}
			if (routine.Current is GoogleDrive.Exception)
			{
				yield return routine.Current;
				yield break;
			}
			if (this.AccessToken == "")
			{
				yield return new GoogleDrive.Exception(-1, "Authorization failed.");
				yield break;
			}
			this.IsAuthorized = true;
			routine = null;
		}
		else
		{
			IEnumerator routine = GoogleDrive.ValidateToken(this.accessToken);
			while (routine.MoveNext())
			{
				yield return null;
			}
			if (routine.Current is GoogleDrive.Exception)
			{
				yield return routine.Current;
				yield break;
			}
			GoogleDrive.TokenInfoResponse tokenInfoResponse = (GoogleDrive.TokenInfoResponse)routine.Current;
			if (tokenInfoResponse.error != null)
			{
				this.AccessToken = null;
				if (this.RefreshToken != "")
				{
					IEnumerator refresh = this.RefreshAccessToken();
					while (refresh.MoveNext())
					{
						yield return null;
					}
					refresh = null;
				}
				if (this.AccessToken == "")
				{
					IEnumerator refresh = this.GetAuthorizationCodeAndAccessToken();
					while (refresh.MoveNext())
					{
						yield return null;
					}
					if (refresh.Current is GoogleDrive.Exception)
					{
						yield return refresh.Current;
						yield break;
					}
					refresh = null;
				}
				if (!(this.AccessToken != ""))
				{
					yield return new GoogleDrive.Exception(-1, "Authorization failed.");
					yield break;
				}
				this.IsAuthorized = true;
			}
			else
			{
				this.IsAuthorized = true;
				this.UserAccount = tokenInfoResponse.email;
				this.expiresIn = DateTime.Now + new TimeSpan(0, 0, tokenInfoResponse.expiresIn);
			}
			routine = null;
		}
		IEnumerator getAppData = this.GetFile("appdata");
		while (getAppData.MoveNext())
		{
			yield return null;
		}
		if (getAppData.Current is GoogleDrive.AsyncSuccess)
		{
			this.AppData = ((getAppData.Current as GoogleDrive.AsyncSuccess).Result as GoogleDrive.File);
		}
		else
		{
			Debug.LogWarning("Cannot get the AppData folder: " + getAppData.Current);
		}
		yield return new GoogleDrive.AsyncSuccess();
		yield break;
	}

	// Token: 0x06000051 RID: 81 RVA: 0x000038CE File Offset: 0x00001ACE
	public IEnumerator Unauthorize()
	{
		this.IsAuthorized = false;
		IEnumerator revoke = GoogleDrive.RevokeToken(this.AccessToken);
		while (revoke.MoveNext())
		{
			yield return null;
		}
		this.AccessToken = null;
		this.RefreshToken = null;
		if (revoke.Current is GoogleDrive.Exception)
		{
			yield return revoke.Current;
			yield break;
		}
		GoogleDrive.RevokeResponse revokeResponse = (GoogleDrive.RevokeResponse)revoke.Current;
		if (revokeResponse.error != null)
		{
			yield return revokeResponse.error;
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess();
		yield break;
	}

	// Token: 0x06000052 RID: 82 RVA: 0x000038DD File Offset: 0x00001ADD
	private IEnumerator GetAuthorizationCodeAndAccessToken()
	{
		Uri authorizationURL = this.AuthorizationURL;
		bool windows = false;
		Process browser;
		if (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.WindowsEditor)
		{
			windows = true;
			ProcessStartInfo processStartInfo = new ProcessStartInfo("IExplore.exe");
			processStartInfo.Arguments = authorizationURL.ToString();
			browser = new Process();
			browser.StartInfo = processStartInfo;
			browser.Start();
		}
		else
		{
			browser = Process.Start(authorizationURL.ToString());
		}
		AuthRedirectionServer server = new AuthRedirectionServer();
		server.StartServer(9271);
		while (!windows || !browser.HasExited)
		{
			if (server.AuthorizationCode != null)
			{
				browser.CloseMainWindow();
				browser.Close();
				break;
			}
			yield return null;
		}
		server.StopServer();
		if (server.AuthorizationCode == null)
		{
			yield return new GoogleDrive.Exception(-1, "Authorization rejected.");
			yield break;
		}
		string authorizationCode = server.AuthorizationCode;
		IEnumerator getAccessToken = this.GetAccessTokenByAuthorizationCode(authorizationCode);
		while (getAccessToken.MoveNext())
		{
			yield return null;
		}
		if (getAccessToken.Current is GoogleDrive.Exception)
		{
			yield return getAccessToken.Current;
			yield break;
		}
		GoogleDrive.TokenResponse tokenResponse = (GoogleDrive.TokenResponse)getAccessToken.Current;
		if (tokenResponse.error != null)
		{
			yield return tokenResponse.error;
			yield break;
		}
		this.AccessToken = tokenResponse.accessToken;
		this.RefreshToken = tokenResponse.refreshToken;
		IEnumerator validate = GoogleDrive.ValidateToken(this.accessToken);
		while (validate.MoveNext())
		{
			yield return null;
		}
		if (validate.Current is GoogleDrive.Exception)
		{
			yield return validate.Current;
			yield break;
		}
		GoogleDrive.TokenInfoResponse tokenInfoResponse = (GoogleDrive.TokenInfoResponse)validate.Current;
		if (tokenInfoResponse.error != null)
		{
			yield return tokenInfoResponse.error;
			yield break;
		}
		if (tokenInfoResponse.email != null)
		{
			this.UserAccount = tokenInfoResponse.email;
		}
		yield break;
	}

	// Token: 0x06000053 RID: 83 RVA: 0x000038EC File Offset: 0x00001AEC
	private IEnumerator RefreshAccessToken()
	{
		IEnumerator refresh = this.GetAccessTokenByRefreshToken(this.RefreshToken);
		while (refresh.MoveNext())
		{
			yield return null;
		}
		if (refresh.Current is GoogleDrive.Exception)
		{
			yield return refresh.Current;
			yield break;
		}
		GoogleDrive.TokenResponse tokenResponse = (GoogleDrive.TokenResponse)refresh.Current;
		if (tokenResponse.error != null)
		{
			yield return tokenResponse.error;
			yield break;
		}
		this.AccessToken = tokenResponse.accessToken;
		IEnumerator validate = GoogleDrive.ValidateToken(this.accessToken);
		while (validate.MoveNext())
		{
			yield return null;
		}
		if (validate.Current is GoogleDrive.Exception)
		{
			yield return validate.Current;
			yield break;
		}
		GoogleDrive.TokenInfoResponse tokenInfoResponse = (GoogleDrive.TokenInfoResponse)validate.Current;
		if (tokenInfoResponse.error != null)
		{
			yield return tokenInfoResponse.error;
			yield break;
		}
		if (tokenInfoResponse.email != null)
		{
			this.UserAccount = tokenInfoResponse.email;
		}
		yield break;
	}

	// Token: 0x06000054 RID: 84 RVA: 0x000038FB File Offset: 0x00001AFB
	private IEnumerator CheckExpiration()
	{
		if (DateTime.Now >= this.expiresIn)
		{
			IEnumerator refresh = this.RefreshAccessToken();
			while (refresh.MoveNext())
			{
				yield return null;
			}
			yield return refresh.Current;
			refresh = null;
		}
		yield break;
	}

	// Token: 0x06000055 RID: 85 RVA: 0x0000390A File Offset: 0x00001B0A
	private IEnumerator GetAccessTokenByAuthorizationCode(string authorizationCode)
	{
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://accounts.google.com/o/oauth2/token");
		unityWebRequest.method = "POST";
		unityWebRequest.headers["Content-Type"] = "application/x-www-form-urlencoded";
		unityWebRequest.body = Encoding.UTF8.GetBytes(string.Format("code={0}&client_id={1}&client_secret={2}&redirect_uri={3}&grant_type=authorization_code", new object[]
		{
			authorizationCode,
			this.ClientID,
			this.ClientSecret,
			this.RedirectURI
		}));
		UnityWebResponse response = unityWebRequest.GetResponse();
		while (!response.isDone)
		{
			yield return null;
		}
		if (response.error != null)
		{
			yield return response.error;
			yield break;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "GetAccessToken response parsing failed.");
			yield break;
		}
		yield return new GoogleDrive.TokenResponse(dictionary);
		yield break;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00003920 File Offset: 0x00001B20
	private IEnumerator GetAccessTokenByRefreshToken(string refreshToken)
	{
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://accounts.google.com/o/oauth2/token");
		unityWebRequest.method = "POST";
		unityWebRequest.headers["Content-Type"] = "application/x-www-form-urlencoded";
		unityWebRequest.body = Encoding.UTF8.GetBytes(string.Format("client_id={0}&client_secret={1}&refresh_token={2}&grant_type=refresh_token", this.ClientID, this.ClientSecret, refreshToken));
		UnityWebResponse response = unityWebRequest.GetResponse();
		while (!response.isDone)
		{
			yield return null;
		}
		if (response.error != null)
		{
			yield return response.error;
			yield break;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "RefreshToken response parsing failed.");
			yield break;
		}
		yield return new GoogleDrive.TokenResponse(dictionary);
		yield break;
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003936 File Offset: 0x00001B36
	private static IEnumerator ValidateToken(string accessToken)
	{
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" + accessToken);
		UnityWebResponse response = unityWebRequest.GetResponse();
		while (!response.isDone)
		{
			yield return null;
		}
		if (response.error != null)
		{
			yield return response.error;
			yield break;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "TokenInfo response parsing failed.");
			yield break;
		}
		yield return new GoogleDrive.TokenInfoResponse(dictionary);
		yield break;
	}

	// Token: 0x06000058 RID: 88 RVA: 0x00003945 File Offset: 0x00001B45
	private static IEnumerator RevokeToken(string token)
	{
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://accounts.google.com/o/oauth2/revoke?token=" + token);
		UnityWebResponse response = unityWebRequest.GetResponse();
		while (!response.isDone)
		{
			yield return null;
		}
		if (response.error != null)
		{
			yield return response.error;
			yield break;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return default(GoogleDrive.RevokeResponse);
		}
		else
		{
			yield return new GoogleDrive.RevokeResponse(dictionary);
		}
		yield break;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x00003954 File Offset: 0x00001B54
	private static GoogleDrive.Exception GetError(Dictionary<string, object> json)
	{
		if (!json.ContainsKey("error"))
		{
			return null;
		}
		object obj = json["error"];
		if (obj is string)
		{
			return new GoogleDrive.Exception(-1, obj as string);
		}
		if (obj is Dictionary<string, object>)
		{
			Dictionary<string, object> dict = obj as Dictionary<string, object>;
			int code = GoogleDrive.TryGet<int>(dict, "code");
			string message = GoogleDrive.TryGet<string>(dict, "message");
			return new GoogleDrive.Exception(code, message);
		}
		return new GoogleDrive.Exception(-1, obj.ToString());
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600005A RID: 90 RVA: 0x000039CA File Offset: 0x00001BCA
	// (set) Token: 0x0600005B RID: 91 RVA: 0x000039D2 File Offset: 0x00001BD2
	public GoogleDrive.File AppData { get; private set; }

	// Token: 0x0600005C RID: 92 RVA: 0x000039DB File Offset: 0x00001BDB
	public IEnumerator GetFile(string id)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest(new Uri("https://www.googleapis.com/drive/v2/files/" + id));
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "GetFile response parsing failed.");
			yield break;
		}
		if (dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary));
		yield break;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x000039F1 File Offset: 0x00001BF1
	public IEnumerator ListAllFiles()
	{
		IEnumerator listFiles = this.ListFilesByQueary("");
		while (listFiles.MoveNext())
		{
			object obj = listFiles.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00003A00 File Offset: 0x00001C00
	public IEnumerator ListFiles(GoogleDrive.File parentFolder)
	{
		IEnumerator listFiles = this.ListFilesByQueary(string.Format("'{0}' in parents", parentFolder.ID));
		while (listFiles.MoveNext())
		{
			object obj = listFiles.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00003A16 File Offset: 0x00001C16
	public IEnumerator ListFilesByQueary(string query)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest(new Uri("https://www.googleapis.com/drive/v2/files?q=" + query));
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "ListFiles response parsing failed.");
			yield break;
		}
		if (dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		List<GoogleDrive.File> list = new List<GoogleDrive.File>();
		if (dictionary.ContainsKey("items") && dictionary["items"] is Dictionary<string, object>[])
		{
			foreach (Dictionary<string, object> metadata in dictionary["items"] as Dictionary<string, object>[])
			{
				list.Add(new GoogleDrive.File(metadata));
			}
		}
		yield return new GoogleDrive.AsyncSuccess(list);
		yield break;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003A2C File Offset: 0x00001C2C
	public IEnumerator InsertFolder(string title)
	{
		IEnumerator insertFolder = this.InsertFolder(title, null);
		while (insertFolder.MoveNext())
		{
			object obj = insertFolder.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003A42 File Offset: 0x00001C42
	public IEnumerator InsertFolder(string title, GoogleDrive.File parentFolder)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/drive/v2/files");
		unityWebRequest.method = "POST";
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		unityWebRequest.headers["Content-Type"] = "application/json";
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary["title"] = title;
		dictionary["mimeType"] = "application/vnd.google-apps.folder";
		if (parentFolder != null)
		{
			dictionary["parents"] = new List<Dictionary<string, string>>
			{
				new Dictionary<string, string>
				{
					{
						"id",
						parentFolder.ID
					}
				}
			};
		}
		unityWebRequest.body = Encoding.UTF8.GetBytes(JsonWriter.Serialize(dictionary));
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary2 = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary2 == null)
		{
			yield return new GoogleDrive.Exception(-1, "InsertFolder response parsing failed.");
			yield break;
		}
		if (dictionary2.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary2);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary2));
		yield break;
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00003A5F File Offset: 0x00001C5F
	public IEnumerator DeleteFile(GoogleDrive.File file)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/drive/v2/files/" + file.ID);
		unityWebRequest.method = "DELETE";
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary != null && dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess();
		yield break;
	}

	// Token: 0x06000063 RID: 99 RVA: 0x00003A75 File Offset: 0x00001C75
	public IEnumerator UpdateFile(GoogleDrive.File file)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/drive/v2/files/" + file.ID);
		unityWebRequest.method = "PUT";
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		unityWebRequest.headers["Content-Type"] = "application/json";
		string s = JsonWriter.Serialize(file.ToJSON());
		unityWebRequest.body = Encoding.UTF8.GetBytes(s);
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "UpdateFile response parsing failed.");
			yield break;
		}
		if (dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary));
		yield break;
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00003A8B File Offset: 0x00001C8B
	public IEnumerator TouchFile(GoogleDrive.File file)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/drive/v2/files/" + file.ID + "/touch");
		unityWebRequest.method = "POST";
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		unityWebRequest.body = new byte[0];
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "TouchFile response parsing failed.");
			yield break;
		}
		if (dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary));
		yield break;
	}

	// Token: 0x06000065 RID: 101 RVA: 0x00003AA1 File Offset: 0x00001CA1
	public IEnumerator DuplicateFile(GoogleDrive.File file, string newTitle)
	{
		IEnumerator duplicate = this.DuplicateFile(file, new GoogleDrive.File(file.ToJSON())
		{
			Title = newTitle
		});
		while (duplicate.MoveNext())
		{
			object obj = duplicate.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x06000066 RID: 102 RVA: 0x00003ABE File Offset: 0x00001CBE
	public IEnumerator DuplicateFile(GoogleDrive.File file, string newTitle, GoogleDrive.File newParentFolder)
	{
		GoogleDrive.File file2 = new GoogleDrive.File(file.ToJSON());
		file2.Title = newTitle;
		if (newParentFolder != null)
		{
			file2.Parents = new List<string>
			{
				newParentFolder.ID
			};
		}
		else
		{
			file2.Parents = new List<string>();
		}
		IEnumerator duplicate = this.DuplicateFile(file, file2);
		while (duplicate.MoveNext())
		{
			object obj = duplicate.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00003AE2 File Offset: 0x00001CE2
	private IEnumerator DuplicateFile(GoogleDrive.File file, GoogleDrive.File newFile)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/drive/v2/files/" + file.ID + "/copy");
		unityWebRequest.method = "POST";
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		unityWebRequest.headers["Content-Type"] = "application/json";
		string s = JsonWriter.Serialize(newFile.ToJSON());
		unityWebRequest.body = Encoding.UTF8.GetBytes(s);
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary == null)
		{
			yield return new GoogleDrive.Exception(-1, "DuplicateFile response parsing failed.");
			yield break;
		}
		if (dictionary.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary));
		yield break;
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00003AFF File Offset: 0x00001CFF
	public IEnumerator UploadFile(string title, string mimeType, byte[] data)
	{
		IEnumerator upload = this.UploadFile(title, mimeType, null, data);
		while (upload.MoveNext())
		{
			object obj = upload.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00003B23 File Offset: 0x00001D23
	public IEnumerator UploadFile(string title, string mimeType, GoogleDrive.File parentFolder, byte[] data)
	{
		GoogleDrive.File file = new GoogleDrive.File(new Dictionary<string, object>
		{
			{
				"title",
				title
			},
			{
				"mimeType",
				mimeType
			}
		});
		if (parentFolder != null)
		{
			file.Parents = new List<string>
			{
				parentFolder.ID
			};
		}
		IEnumerator upload = this.UploadFile(file, data);
		while (upload.MoveNext())
		{
			object obj = upload.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003B4F File Offset: 0x00001D4F
	public IEnumerator UploadFile(GoogleDrive.File file, byte[] data)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebResponse response;
		string uri;
		if (file.ID == null || file.ID == string.Empty)
		{
			UnityWebRequest unityWebRequest = new UnityWebRequest("https://www.googleapis.com/upload/drive/v2/files?uploadType=resumable");
			unityWebRequest.method = "POST";
			unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
			unityWebRequest.headers["Content-Type"] = "application/json";
			unityWebRequest.headers["X-Upload-Content-Type"] = file.MimeType;
			unityWebRequest.headers["X-Upload-Content-Length"] = data.Length;
			string s = JsonWriter.Serialize(file.ToJSON());
			unityWebRequest.body = Encoding.UTF8.GetBytes(s);
			response = new UnityWebResponse(unityWebRequest);
			while (!response.isDone)
			{
				yield return null;
			}
			if (response.statusCode != 200)
			{
				Dictionary<string, object> dictionary = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
				if (dictionary == null)
				{
					yield return new GoogleDrive.Exception(-1, "UploadFile response parsing failed.");
					yield break;
				}
				if (dictionary.ContainsKey("error"))
				{
					yield return GoogleDrive.GetError(dictionary);
					yield break;
				}
			}
			uri = (response.headers["Location"] as string);
			response = null;
		}
		else
		{
			uri = "https://www.googleapis.com/upload/drive/v2/files/" + file.ID;
		}
		UnityWebRequest unityWebRequest2 = new UnityWebRequest(uri);
		unityWebRequest2.method = "PUT";
		unityWebRequest2.headers["Authorization"] = "Bearer " + this.AccessToken;
		unityWebRequest2.headers["Content-Type"] = "application/octet-stream";
		unityWebRequest2.body = data;
		response = new UnityWebResponse(unityWebRequest2);
		while (!response.isDone)
		{
			yield return null;
		}
		Dictionary<string, object> dictionary2 = new JsonReader(response.text).Deserialize<Dictionary<string, object>>();
		if (dictionary2 == null)
		{
			yield return new GoogleDrive.Exception(-1, "UploadFile response parsing failed.");
			yield break;
		}
		if (dictionary2.ContainsKey("error"))
		{
			yield return GoogleDrive.GetError(dictionary2);
			yield break;
		}
		yield return new GoogleDrive.AsyncSuccess(new GoogleDrive.File(dictionary2));
		response = null;
		yield break;
	}

	// Token: 0x0600006B RID: 107 RVA: 0x00003B6C File Offset: 0x00001D6C
	public IEnumerator DownloadFile(GoogleDrive.File file)
	{
		if (file.DownloadUrl == null || file.DownloadUrl == string.Empty)
		{
			yield return new GoogleDrive.Exception(-1, "No download URL.");
			yield break;
		}
		IEnumerator download = this.DownloadFile(file.DownloadUrl);
		while (download.MoveNext())
		{
			object obj = download.Current;
			yield return obj;
		}
		yield break;
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00003B82 File Offset: 0x00001D82
	public IEnumerator DownloadFile(string url)
	{
		IEnumerator check = this.CheckExpiration();
		while (check.MoveNext())
		{
			yield return null;
		}
		if (check.Current is GoogleDrive.Exception)
		{
			yield return check.Current;
			yield break;
		}
		UnityWebRequest unityWebRequest = new UnityWebRequest(url);
		unityWebRequest.headers["Authorization"] = "Bearer " + this.AccessToken;
		UnityWebResponse response = new UnityWebResponse(unityWebRequest);
		while (!response.isDone)
		{
			yield return null;
		}
		yield return new GoogleDrive.AsyncSuccess(response.bytes);
		yield break;
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00003B98 File Offset: 0x00001D98
	private static T TryGet<T>(Dictionary<string, object> dict, string key)
	{
		object obj;
		if (dict.TryGetValue(key, out obj) && obj is T)
		{
			return (T)((object)obj);
		}
		return default(T);
	}

	// Token: 0x04000048 RID: 72
	private const int SERVER_PORT = 9271;

	// Token: 0x04000049 RID: 73
	private static readonly string[] DefaultScopes = new string[]
	{
		"https://www.googleapis.com/auth/drive.readonly"
	};

	// Token: 0x0400004A RID: 74
	private string[] scopes = GoogleDrive.DefaultScopes;

	// Token: 0x0400004B RID: 75
	private bool isAuthorized;

	// Token: 0x0400004C RID: 76
	private string accessToken;

	// Token: 0x0400004D RID: 77
	private string refreshToken;

	// Token: 0x0400004E RID: 78
	private string userAccount;

	// Token: 0x0400004F RID: 79
	private DateTime expiresIn = DateTime.MaxValue;

	// Token: 0x0200023A RID: 570
	public class AsyncSuccess
	{
		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06001188 RID: 4488 RVA: 0x0006493A File Offset: 0x00062B3A
		// (set) Token: 0x06001189 RID: 4489 RVA: 0x00064942 File Offset: 0x00062B42
		public object Result { get; private set; }

		// Token: 0x0600118A RID: 4490 RVA: 0x0006494B File Offset: 0x00062B4B
		public AsyncSuccess() : this(null)
		{
		}

		// Token: 0x0600118B RID: 4491 RVA: 0x00064954 File Offset: 0x00062B54
		public AsyncSuccess(object o)
		{
			this.Result = o;
		}
	}

	// Token: 0x0200023B RID: 571
	private struct TokenResponse
	{
		// Token: 0x0600118C RID: 4492 RVA: 0x00064964 File Offset: 0x00062B64
		public TokenResponse(Dictionary<string, object> json)
		{
			this.error = null;
			this.accessToken = null;
			this.refreshToken = null;
			this.expiresIn = 0;
			this.tokenType = null;
			if (json.ContainsKey("error"))
			{
				this.error = GoogleDrive.GetError(json);
				return;
			}
			if (json.ContainsKey("access_token"))
			{
				this.accessToken = (json["access_token"] as string);
			}
			if (json.ContainsKey("refresh_token"))
			{
				this.refreshToken = (json["refresh_token"] as string);
			}
			if (json.ContainsKey("expires_in"))
			{
				this.expiresIn = (int)json["expires_in"];
			}
			if (json.ContainsKey("token_type"))
			{
				this.tokenType = (json["token_type"] as string);
			}
		}

		// Token: 0x04000E11 RID: 3601
		public GoogleDrive.Exception error;

		// Token: 0x04000E12 RID: 3602
		public string accessToken;

		// Token: 0x04000E13 RID: 3603
		public string refreshToken;

		// Token: 0x04000E14 RID: 3604
		public int expiresIn;

		// Token: 0x04000E15 RID: 3605
		public string tokenType;
	}

	// Token: 0x0200023C RID: 572
	private struct TokenInfoResponse
	{
		// Token: 0x0600118D RID: 4493 RVA: 0x00064A3C File Offset: 0x00062C3C
		public TokenInfoResponse(Dictionary<string, object> json)
		{
			this.error = null;
			this.audience = null;
			this.scope = null;
			this.userId = null;
			this.expiresIn = 0;
			this.email = null;
			if (json.ContainsKey("error"))
			{
				this.error = GoogleDrive.GetError(json);
				return;
			}
			if (json.ContainsKey("audience"))
			{
				this.audience = (json["audience"] as string);
			}
			if (json.ContainsKey("scope"))
			{
				this.scope = (json["scope"] as string);
			}
			if (json.ContainsKey("user_id"))
			{
				this.userId = (json["user_id"] as string);
			}
			if (json.ContainsKey("expires_in"))
			{
				this.expiresIn = (int)json["expires_in"];
			}
			if (json.ContainsKey("email"))
			{
				this.email = (json["email"] as string);
			}
		}

		// Token: 0x04000E16 RID: 3606
		public GoogleDrive.Exception error;

		// Token: 0x04000E17 RID: 3607
		public string audience;

		// Token: 0x04000E18 RID: 3608
		public string scope;

		// Token: 0x04000E19 RID: 3609
		public string userId;

		// Token: 0x04000E1A RID: 3610
		public int expiresIn;

		// Token: 0x04000E1B RID: 3611
		public string email;
	}

	// Token: 0x0200023D RID: 573
	private struct RevokeResponse
	{
		// Token: 0x0600118E RID: 4494 RVA: 0x00064B3C File Offset: 0x00062D3C
		public RevokeResponse(Dictionary<string, object> json)
		{
			if (json.ContainsKey("error"))
			{
				this.error = GoogleDrive.GetError(json);
				return;
			}
			this.error = null;
		}

		// Token: 0x04000E1C RID: 3612
		public GoogleDrive.Exception error;
	}

	// Token: 0x0200023E RID: 574
	public class Exception : System.Exception
	{
		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x0600118F RID: 4495 RVA: 0x00064B5F File Offset: 0x00062D5F
		// (set) Token: 0x06001190 RID: 4496 RVA: 0x00064B67 File Offset: 0x00062D67
		public int Code { get; private set; }

		// Token: 0x06001191 RID: 4497 RVA: 0x00064B70 File Offset: 0x00062D70
		public Exception(int code, string message) : base(message)
		{
			this.Code = code;
		}
	}

	// Token: 0x0200023F RID: 575
	public class File
	{
		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06001192 RID: 4498 RVA: 0x00064B80 File Offset: 0x00062D80
		// (set) Token: 0x06001193 RID: 4499 RVA: 0x00064B88 File Offset: 0x00062D88
		public string ID { get; private set; }

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x06001194 RID: 4500 RVA: 0x00064B91 File Offset: 0x00062D91
		// (set) Token: 0x06001195 RID: 4501 RVA: 0x00064B99 File Offset: 0x00062D99
		public string Title { get; set; }

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06001196 RID: 4502 RVA: 0x00064BA2 File Offset: 0x00062DA2
		// (set) Token: 0x06001197 RID: 4503 RVA: 0x00064BAA File Offset: 0x00062DAA
		public string MimeType { get; set; }

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06001198 RID: 4504 RVA: 0x00064BB3 File Offset: 0x00062DB3
		// (set) Token: 0x06001199 RID: 4505 RVA: 0x00064BBB File Offset: 0x00062DBB
		public string Description { get; set; }

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x0600119A RID: 4506 RVA: 0x00064BC4 File Offset: 0x00062DC4
		// (set) Token: 0x0600119B RID: 4507 RVA: 0x00064BCC File Offset: 0x00062DCC
		public DateTime CreatedDate { get; private set; }

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x0600119C RID: 4508 RVA: 0x00064BD5 File Offset: 0x00062DD5
		// (set) Token: 0x0600119D RID: 4509 RVA: 0x00064BDD File Offset: 0x00062DDD
		public DateTime ModifiedDate { get; private set; }

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x0600119E RID: 4510 RVA: 0x00064BE6 File Offset: 0x00062DE6
		// (set) Token: 0x0600119F RID: 4511 RVA: 0x00064BEE File Offset: 0x00062DEE
		public string ThumbnailLink { get; private set; }

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x060011A0 RID: 4512 RVA: 0x00064BF7 File Offset: 0x00062DF7
		// (set) Token: 0x060011A1 RID: 4513 RVA: 0x00064BFF File Offset: 0x00062DFF
		public string DownloadUrl { get; private set; }

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x060011A2 RID: 4514 RVA: 0x00064C08 File Offset: 0x00062E08
		// (set) Token: 0x060011A3 RID: 4515 RVA: 0x00064C10 File Offset: 0x00062E10
		public string MD5Checksum { get; private set; }

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x060011A4 RID: 4516 RVA: 0x00064C19 File Offset: 0x00062E19
		// (set) Token: 0x060011A5 RID: 4517 RVA: 0x00064C21 File Offset: 0x00062E21
		public long FileSize { get; private set; }

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x060011A6 RID: 4518 RVA: 0x00064C2A File Offset: 0x00062E2A
		// (set) Token: 0x060011A7 RID: 4519 RVA: 0x00064C32 File Offset: 0x00062E32
		public List<string> Parents { get; set; }

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x060011A8 RID: 4520 RVA: 0x00064C3B File Offset: 0x00062E3B
		public bool IsFolder
		{
			get
			{
				return this.MimeType == "application/vnd.google-apps.folder";
			}
		}

		// Token: 0x060011A9 RID: 4521 RVA: 0x00064C50 File Offset: 0x00062E50
		public File(Dictionary<string, object> metadata)
		{
			this.ID = GoogleDrive.TryGet<string>(metadata, "id");
			this.Title = GoogleDrive.TryGet<string>(metadata, "title");
			this.MimeType = GoogleDrive.TryGet<string>(metadata, "mimeType");
			this.Description = GoogleDrive.TryGet<string>(metadata, "description");
			DateTime createdDate;
			DateTime.TryParse(GoogleDrive.TryGet<string>(metadata, "createdDate"), out createdDate);
			this.CreatedDate = createdDate;
			DateTime modifiedDate;
			DateTime.TryParse(GoogleDrive.TryGet<string>(metadata, "modifiedDate"), out modifiedDate);
			this.ModifiedDate = modifiedDate;
			this.ThumbnailLink = GoogleDrive.TryGet<string>(metadata, "thumbnailLink");
			this.DownloadUrl = GoogleDrive.TryGet<string>(metadata, "downloadUrl");
			this.MD5Checksum = GoogleDrive.TryGet<string>(metadata, "md5Checksum");
			string text = GoogleDrive.TryGet<string>(metadata, "fileSize");
			if (text != null)
			{
				this.FileSize = long.Parse(text);
			}
			this.Parents = new List<string>();
			if (metadata.ContainsKey("parents") && metadata["parents"] is Dictionary<string, object>[])
			{
				foreach (Dictionary<string, object> dictionary in metadata["parents"] as Dictionary<string, object>[])
				{
					if (dictionary.ContainsKey("id"))
					{
						this.Parents.Add(dictionary["id"] as string);
					}
				}
			}
		}

		// Token: 0x060011AA RID: 4522 RVA: 0x00064DA8 File Offset: 0x00062FA8
		public Dictionary<string, object> ToJSON()
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary["title"] = this.Title;
			dictionary["mimeType"] = this.MimeType;
			dictionary["description"] = this.Description;
			Dictionary<string, object>[] array = new Dictionary<string, object>[this.Parents.Count];
			for (int i = 0; i < this.Parents.Count; i++)
			{
				array[i] = new Dictionary<string, object>();
				array[i]["id"] = this.Parents[i];
			}
			dictionary["parents"] = array;
			return dictionary;
		}

		// Token: 0x060011AB RID: 4523 RVA: 0x00064E44 File Offset: 0x00063044
		public override string ToString()
		{
			return string.Format("{{ title: {0}, mimeType: {1}, fileSize: {2}, id: {3}, parents: [{4}] }}", new object[]
			{
				this.Title,
				this.MimeType,
				this.FileSize,
				this.ID,
				string.Join(", ", this.Parents.ToArray())
			});
		}
	}
}
