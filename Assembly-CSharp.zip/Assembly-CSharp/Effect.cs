﻿using System;
using System.Collections.Generic;

// Token: 0x02000043 RID: 67
[Serializable]
public class Effect
{
	// Token: 0x06000231 RID: 561 RVA: 0x0000D404 File Offset: 0x0000B604
	public Effect()
	{
	}

	// Token: 0x06000232 RID: 562 RVA: 0x0000D418 File Offset: 0x0000B618
	public Effect(string[] rawele, string[] columns, Dictionary<string, string[]> i18n, EffectAct scEf = null)
	{
		string[] array = new string[2];
		bool flag = false;
		for (int i = 0; i < columns.Length; i++)
		{
			string text = rawele[i];
			string text2 = columns[i];
			if (!(text2 == "tag"))
			{
				if (!(text2 == "title"))
				{
					if (!(text2 == "alwayshowcard"))
					{
						if (!(text2 == "description"))
						{
							if (!(text2 == "custom"))
							{
								if (!string.IsNullOrEmpty(text2) && !string.IsNullOrEmpty(text))
								{
									this.outcomes.Add(new Outcome(text2, text, false));
								}
							}
							else if (!string.IsNullOrEmpty(text))
							{
								this.outcomes.AddRange(Outcome.TreatOutcome(text));
							}
						}
						else
						{
							this.description = (flag ? this.TreatText(array[1]) : this.TreatText(text));
						}
					}
					else
					{
						this.alwayshowcard = !string.IsNullOrEmpty(text);
					}
				}
				else
				{
					this.title = (flag ? array[0] : text);
				}
			}
			else
			{
				this.tag = text;
				if (i18n.Count > 0 && i18n.ContainsKey(text))
				{
					array = i18n[text];
					flag = true;
				}
			}
		}
	}

	// Token: 0x06000233 RID: 563 RVA: 0x0000D554 File Offset: 0x0000B754
	public string TreatText(string val)
	{
		if (string.IsNullOrEmpty(val))
		{
			return "";
		}
		val = val.Replace("<*", "<color=#e2081e>");
		val = val.Replace("*>", "</color>");
		if (SpeechAct.diff && SpeechAct.diff.asiaLayout)
		{
			val = val.Replace("+", "\n");
		}
		return val;
	}

	// Token: 0x0400023A RID: 570
	public string tag;

	// Token: 0x0400023B RID: 571
	public string title;

	// Token: 0x0400023C RID: 572
	public string description;

	// Token: 0x0400023D RID: 573
	public bool active;

	// Token: 0x0400023E RID: 574
	public int length;

	// Token: 0x0400023F RID: 575
	public bool seen;

	// Token: 0x04000240 RID: 576
	public bool alwayshowcard;

	// Token: 0x04000241 RID: 577
	public List<Outcome> outcomes = new List<Outcome>();
}
