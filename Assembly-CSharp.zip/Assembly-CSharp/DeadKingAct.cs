﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200003D RID: 61
public class DeadKingAct : MonoBehaviour
{
	// Token: 0x060001F4 RID: 500 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	private void OnEnable()
	{
		if (GameAct.diff.GetInt(Variables.dynasty) == 0)
		{
			this.portraits[0].gameObject.SetActive(false);
			this.portraits[1].gameObject.SetActive(false);
			this.portraits[2].gameObject.SetActive(false);
			this.portraits[3].gameObject.SetActive(false);
			this.scOb.ShowObjectives(this.allobjBox, 0, true, true, 1f);
			this.isgone.SetActive(true);
			this.isdead.SetActive(false);
			return;
		}
		this.portraits[0].gameObject.SetActive(true);
		this.portraits[1].gameObject.SetActive(true);
		this.portraits[2].gameObject.SetActive(true);
		this.portraits[3].gameObject.SetActive(true);
		this.isgone.SetActive(false);
		this.isdead.SetActive(true);
		this.scOb.ShowObjectives(this.allobjBox, 0, true, true, 1f);
		List<Reign> list = (from it in this.scKi.reigns
		orderby it.end - it.start descending
		select it).ToList<Reign>();
		Reign cure = this.scKi.GetCurrentReign();
		for (int i = 0; i < 3; i++)
		{
			if (i < list.Count)
			{
				Reign re = list[i];
				this.names[i].text = CardReader.diff.bearerModels.Find((Bearer it) => it.bearer == re.bearer).firstname;
				this.inpowers[i].text = this.scKi.FormatPower(re, false);
				this.portraits[i].vectorGraphics = (SVGAsset)Resources.Load("bearers/no_bg/" + re.bearer.ToString(), typeof(SVGAsset));
				this.stars[i].SetActive(re == cure);
			}
		}
		this.names[3].text = (string.IsNullOrEmpty(cure.name) ? CardReader.diff.bearerModels.Find((Bearer it) => it.bearer == cure.bearer).firstname : cure.name);
		this.portraits[3].vectorGraphics = (SVGAsset)Resources.Load("bearers/no_bg/" + cure.bearer.ToString(), typeof(SVGAsset));
		this.numbers[3].text = this.scKi.FormatPower(cure, true);
		if (cure != null && 1 + cure.end - cure.start < 5)
		{
			SocialAct.diff.AddAchieve("bellowGoT");
		}
		if (SpeechAct.diff.lang == "jp")
		{
			this.numbers[3].fontSize = 22;
			this.inpowers[3].text = "";
		}
		else
		{
			this.numbers[3].fontSize = 42;
			this.inpowers[3].text = SpeechAct.diff.GetSceneNum("time_in_power", 1 + cure.end - cure.start);
		}
		base.StartCoroutine("ChangeText");
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x0000C56B File Offset: 0x0000A76B
	private IEnumerator ChangeText()
	{
		JukeBox.diff.PlaySound(SFXTypes.ui_death_stats_start, false, false, 2.5f, -1, 1.5f, 1f);
		yield return new WaitForSeconds(1.9f);
		JukeBox.diff.PlaySound(SFXTypes.ui_death_stats_whoosh, false, false, 2.5f, -1, 1.5f, 1f);
		yield break;
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x0000C573 File Offset: 0x0000A773
	private void OnDisable()
	{
		JukeBox.diff.PlaySound(SFXTypes.ui_death_start, false, false, 2.5f, -1, 1.5f, 1f);
		base.StopAllCoroutines();
		GameAct.diff.DestroyModals();
	}

	// Token: 0x04000214 RID: 532
	public Text highscoreTxt;

	// Token: 0x04000215 RID: 533
	public Text yearsTxt;

	// Token: 0x04000216 RID: 534
	public KingdomAct scKi;

	// Token: 0x04000217 RID: 535
	public GameObject isdead;

	// Token: 0x04000218 RID: 536
	public GameObject isgone;

	// Token: 0x04000219 RID: 537
	public SVGImage[] portraits;

	// Token: 0x0400021A RID: 538
	public Text[] names;

	// Token: 0x0400021B RID: 539
	public Text[] numbers;

	// Token: 0x0400021C RID: 540
	public Text[] inpowers;

	// Token: 0x0400021D RID: 541
	public GameObject[] stars;

	// Token: 0x0400021E RID: 542
	public ObjectiveAct scOb;

	// Token: 0x0400021F RID: 543
	public Transform allobjBox;
}
