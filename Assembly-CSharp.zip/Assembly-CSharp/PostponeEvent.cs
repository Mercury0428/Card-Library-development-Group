﻿using System;

// Token: 0x0200004B RID: 75
[Serializable]
public class PostponeEvent
{
	// Token: 0x06000262 RID: 610 RVA: 0x0000E6C3 File Offset: 0x0000C8C3
	public PostponeEvent()
	{
	}

	// Token: 0x06000263 RID: 611 RVA: 0x0000E6D6 File Offset: 0x0000C8D6
	public PostponeEvent(int ye, string ca)
	{
		this.year = ye;
		this.card = ca;
	}

	// Token: 0x06000264 RID: 612 RVA: 0x0000E6F7 File Offset: 0x0000C8F7
	public PostponeEvent(int ye, Bearers be)
	{
		this.year = ye;
		this.bear = be;
	}

	// Token: 0x04000342 RID: 834
	public int year;

	// Token: 0x04000343 RID: 835
	public string card;

	// Token: 0x04000344 RID: 836
	public Bearers bear = Bearers.none;
}
