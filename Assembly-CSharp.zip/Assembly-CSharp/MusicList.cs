﻿using System;
using Malee;

// Token: 0x02000060 RID: 96
[Serializable]
public class MusicList : ReorderableArray<Music>
{
}
