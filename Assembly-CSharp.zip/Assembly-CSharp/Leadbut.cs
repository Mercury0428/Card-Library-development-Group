﻿using System;
using UnityEngine;

// Token: 0x02000067 RID: 103
public class Leadbut : MonoBehaviour
{
	// Token: 0x060003B1 RID: 945 RVA: 0x00017AB9 File Offset: 0x00015CB9
	public void OpenLeadeboard()
	{
		SocialAct.diff.OpenLeaderBoard();
	}
}
