﻿using System;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000092 RID: 146
public class RealtimeImportDemo : MonoBehaviour
{
	// Token: 0x0600049F RID: 1183 RVA: 0x0001CCFC File Offset: 0x0001AEFC
	public void Load()
	{
		if (this.svgInput == null || string.IsNullOrEmpty(this.svgInput.text))
		{
			return;
		}
		if (this.svgAsset != null)
		{
			Object.Destroy(this.svgAsset);
		}
		this.svgAsset = SVGAsset.Load(this.svgInput.text, null);
		this.preview.vectorGraphics = this.svgAsset;
	}

	// Token: 0x04000563 RID: 1379
	public SVGImage preview;

	// Token: 0x04000564 RID: 1380
	public InputField svgInput;

	// Token: 0x04000565 RID: 1381
	protected SVGAsset svgAsset;
}
