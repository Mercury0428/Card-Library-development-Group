﻿using System;
using UnityEngine;

// Token: 0x02000091 RID: 145
public class HologramController : MonoBehaviour
{
	// Token: 0x0600049C RID: 1180 RVA: 0x0001CB68 File Offset: 0x0001AD68
	private void Start()
	{
		for (int i = 0; i < this.layers.Length; i++)
		{
			if (!(this.layers[i].transform == null))
			{
				this.layers[i].startLocalPosition = this.layers[i].transform.localPosition;
			}
		}
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x0001CBC8 File Offset: 0x0001ADC8
	private void Update()
	{
		this.elapsedTime += Time.deltaTime * this.depthSpeed;
		this.depth = this.depthAnimation.Evaluate(Mathf.PingPong(this.elapsedTime, 1f));
		for (int i = 0; i < this.layers.Length; i++)
		{
			if (!(this.layers[i].transform == null))
			{
				Vector3 localPosition = this.layers[i].transform.localPosition;
				localPosition.z = Mathf.LerpUnclamped(0f, this.layers[i].startLocalPosition.z, this.depth);
				this.layers[i].transform.localPosition = localPosition;
				this.layers[i].transform.localRotation *= Quaternion.Euler(0f, 0f, this.layers[i].rotation * Time.deltaTime);
			}
		}
	}

	// Token: 0x0400055E RID: 1374
	public HologramController.HologramLayer[] layers;

	// Token: 0x0400055F RID: 1375
	public float depth;

	// Token: 0x04000560 RID: 1376
	public float depthSpeed = 1f;

	// Token: 0x04000561 RID: 1377
	public AnimationCurve depthAnimation;

	// Token: 0x04000562 RID: 1378
	private float elapsedTime;

	// Token: 0x02000321 RID: 801
	[Serializable]
	public struct HologramLayer
	{
		// Token: 0x040011BA RID: 4538
		public Transform transform;

		// Token: 0x040011BB RID: 4539
		public Vector3 startLocalPosition;

		// Token: 0x040011BC RID: 4540
		public float rotation;
	}
}
