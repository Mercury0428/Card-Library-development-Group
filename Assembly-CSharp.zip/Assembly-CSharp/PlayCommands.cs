﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x0200009C RID: 156
[RequireComponent(typeof(TwitchIRC))]
public class PlayCommands : MonoBehaviour
{
	// Token: 0x060004D8 RID: 1240 RVA: 0x0001D990 File Offset: 0x0001BB90
	private void Start()
	{
		this.twitch = base.GetComponent<TwitchIRC>();
		this.twitch.messageRecievedEvent.AddListener(new UnityAction<string>(this.getCommand));
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0001D9BC File Offset: 0x0001BBBC
	private void getCommand(string str)
	{
		Debug.Log(str);
		int num = str.IndexOf("PRIVMSG #");
		int num2 = str.IndexOf("!");
		string arg = str.Substring(1, num2 - 1);
		str = str.Substring(num + this.twitch.nickName.Length + 11);
		string text = str;
		if (this.delimiter.Length > 0 && str.Split(this.delimiter.ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length > 1)
		{
			string[] array = str.Split(this.delimiter.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			text = array[0];
			str = "";
			for (int i = 1; i < array.Length; i++)
			{
				str += array[i];
			}
		}
		Debug.Log("Got Command: " + text);
		foreach (TwitchCommand twitchCommand in this.Commands)
		{
			if (text.Trim().ToLower().Equals(twitchCommand.commandKey.Trim().ToLower()))
			{
				twitchCommand.onCommand.Invoke(arg);
			}
		}
	}

	// Token: 0x04000595 RID: 1429
	[Tooltip("List of available twitch commands")]
	public List<TwitchCommand> Commands;

	// Token: 0x04000596 RID: 1430
	[Tooltip("Optional delimiter for command options\n   ie. 'vote: 1', delimiter would be ':'")]
	public string delimiter;

	// Token: 0x04000597 RID: 1431
	private TwitchIRC twitch;
}
