﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200002D RID: 45
public class CardReader : MonoBehaviour
{
	// Token: 0x06000140 RID: 320 RVA: 0x00008188 File Offset: 0x00006388
	private void Awake()
	{
		CardReader.diff = this;
		this.authenticBearers = new List<Bearer>(this.bearerModels);
	}

	// Token: 0x06000141 RID: 321 RVA: 0x000081A1 File Offset: 0x000063A1
	private void OnEnable()
	{
		this.generatedId = PlayerPrefs.GetInt("generatedId");
	}

	// Token: 0x06000142 RID: 322 RVA: 0x000081B3 File Offset: 0x000063B3
	private void OnDisable()
	{
		PlayerPrefs.SetInt("generatedId", this.generatedId);
	}

	// Token: 0x06000143 RID: 323 RVA: 0x000081C5 File Offset: 0x000063C5
	public int GetGenerated()
	{
		this.generatedId++;
		return this.generatedId;
	}

	// Token: 0x06000144 RID: 324 RVA: 0x000081DB File Offset: 0x000063DB
	private string[] GetRawCards()
	{
		return (this.tempCards.ContainsKey("cards") ? this.tempCards["cards"] : Util.GetTextFile("texts/cards")).Split(new char[]
		{
			'\n'
		});
	}

	// Token: 0x06000145 RID: 325 RVA: 0x0000821B File Offset: 0x0000641B
	public bool StartDownload()
	{
		return false;
	}

	// Token: 0x06000146 RID: 326 RVA: 0x0000821E File Offset: 0x0000641E
	public string GetTempText(string name)
	{
		if (this.tempCards.ContainsKey(name))
		{
			return this.tempCards[name];
		}
		return Util.GetTextFile("texts/" + name);
	}

	// Token: 0x06000147 RID: 327 RVA: 0x0000824C File Offset: 0x0000644C
	public List<Card> GetCards(bool hidden)
	{
		Dictionary<string, string[]> languageStrings = this.GetLanguageStrings(hidden);
		List<Card> list = new List<Card>();
		string[] rawCards = this.GetRawCards();
		string[] columns = rawCards[0].Split(new char[]
		{
			this.dele
		});
		string[] array = rawCards[1].Split(new char[]
		{
			this.dele
		});
		string[] array2 = new string[array.Length];
		array.CopyTo(array2, 0);
		for (int i = 1; i < rawCards.Length; i++)
		{
			this.previousname = this.currentname;
			if (array2[1] == "_")
			{
				this.currentname = "_" + array2[2];
			}
			else if (string.IsNullOrEmpty(array2[1]))
			{
				this.currentname = array2[2];
			}
			else
			{
				this.currentname = array2[1];
			}
			bool flag = array2[1].Length > 0 && array2[1].Substring(0, 1) == "_";
			if (i < rawCards.Length - 1)
			{
				array = rawCards[i + 1].Split(new char[]
				{
					this.dele
				});
				if (string.IsNullOrEmpty(array[1]))
				{
					array[1] = array[2];
				}
				else if (array[1] == "_")
				{
					array[1] = "_" + array[2];
				}
				this.nextname = array[1];
			}
			else
			{
				this.nextname = "";
			}
			if ((hidden && flag) || (!hidden && !flag))
			{
				Card card = new Card(array2, columns, this.dele, languageStrings, this.previousid);
				this.previousid = card.id;
				list.Add(card);
			}
			array.CopyTo(array2, 0);
		}
		this.nextname = "";
		list.RemoveAll((Card it) => string.IsNullOrEmpty(it.question.mMsM));
		return list;
	}

	// Token: 0x06000148 RID: 328 RVA: 0x00008434 File Offset: 0x00006634
	private Dictionary<string, string[]> GetLanguageStrings(bool hidden)
	{
		string lang = SpeechAct.diff.lang;
		if (lang == "en")
		{
			return new Dictionary<string, string[]>();
		}
		Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
		string[] array = (this.tempCards.ContainsKey("cards_i18n") ? this.tempCards["cards_i18n"] : Util.GetTextFile("texts/cards_i18n")).Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(new char[]
		{
			this.dele
		});
		for (int i = 1; i < array.Length; i++)
		{
			string[] array3 = array[i].Split(new char[]
			{
				this.dele
			});
			string[] array4 = new string[5];
			string key = "";
			for (int j = 0; j < array2.Length; j++)
			{
				string a = array2[j];
				if (a == "id")
				{
					key = array3[j];
				}
				else if (a == lang + "_question")
				{
					array4[0] = array3[j];
				}
				else if (a == lang + "_override_yes")
				{
					array4[1] = array3[j];
				}
				else if (a == lang + "_override_no")
				{
					array4[2] = array3[j];
				}
				else if (a == lang + "_answer_yes")
				{
					array4[3] = array3[j];
				}
				else if (a == lang + "_answer_no")
				{
					array4[4] = array3[j];
				}
			}
			dictionary.Add(key, array4);
		}
		return dictionary;
	}

	// Token: 0x06000149 RID: 329 RVA: 0x000085DC File Offset: 0x000067DC
	public void ResetSystemChara()
	{
		if (this.authenticBearers != null)
		{
			this.bearerModels = new List<Bearer>(this.authenticBearers);
		}
		foreach (Bearer bearer in this.bearerModels)
		{
			bearer.character.Remove(Bearers.antagonist);
			bearer.character.Remove(Bearers.reigning);
		}
		foreach (Bearer bearer2 in this.bearerModels.FindAll((Bearer it) => it.type == BearerTypes.function))
		{
			foreach (Bearer bearer3 in this.bearerModels)
			{
				bearer3.character.Remove(bearer2.bearer);
			}
		}
		Bearer bearer4 = this.bearerModels.Find((Bearer it) => it.bearer == Bearers.arya);
		if (bearer4 != null && bearer4.character.Contains(Bearers.lannister))
		{
			bearer4.character.Remove(Bearers.lannister);
		}
	}

	// Token: 0x0600014A RID: 330 RVA: 0x00008750 File Offset: 0x00006950
	public void AddCharacterToModels(Bearers charac, List<Bearers> tochange)
	{
		foreach (Bearers be in tochange)
		{
			this.AddCharacterToModel(charac, be);
		}
	}

	// Token: 0x0600014B RID: 331 RVA: 0x000087A0 File Offset: 0x000069A0
	public void AddCharacterToModel(Bearers charac, Bearers be)
	{
		List<Bearer> list = this.bearerModels.FindAll((Bearer it) => it.bearer == be || it.character.Contains(be));
		bool flag = false;
		foreach (Bearer bearer in list)
		{
			if (!bearer.character.Contains(charac))
			{
				flag = true;
				bearer.character.Add(charac);
			}
		}
		if (flag && list.Count > 1 && charac == Bearers.antagonist)
		{
			GameAct.diff.AddInt(Variables.war, 1);
		}
	}

	// Token: 0x0600014C RID: 332 RVA: 0x0000884C File Offset: 0x00006A4C
	public void RemoveCharacterFromModel(Bearers charac, Bearers be)
	{
		List<Bearer> list = this.bearerModels.FindAll((Bearer it) => it.bearer == be || it.character.Contains(be));
		bool flag = false;
		foreach (Bearer bearer in list)
		{
			if (bearer.character.Contains(charac))
			{
				flag = true;
				bearer.character.Remove(charac);
			}
		}
		if (flag && list.Count > 1 && charac == Bearers.antagonist)
		{
			GameAct.diff.AddInt(Variables.war, -1);
		}
	}

	// Token: 0x0600014D RID: 333 RVA: 0x000088F8 File Offset: 0x00006AF8
	public bool HasModelCharacter(Bearers target, Bearers charac)
	{
		return this.bearerModels.Find((Bearer it) => it.bearer == target && it.character.Contains(charac)) != null;
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00008938 File Offset: 0x00006B38
	public List<Card> UpdateCards(List<Card> cards, bool ishidden = false, bool isinventory = false)
	{
		using (List<Card>.Enumerator enumerator = this.GetCards(ishidden).GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Card ca = enumerator.Current;
				Card card = cards.Find((Card it) => it.id == ca.id);
				if (card != null)
				{
					if (card.weight != -666)
					{
						card.answer_no = ca.answer_no;
						card.answer_yes = ca.answer_yes;
						card.bearer = ca.bearer;
						card.bearerVariation = ca.bearerVariation;
						card.bearerIsAlso = ca.bearerIsAlso;
						card.bearerIsNot = ca.bearerIsNot;
						card.conditions = ca.conditions;
						card.wasSeen = ca.wasSeen;
						int lockturn = card.lockturn;
						if (lockturn != ca.lockturn && card.nextturn > 0)
						{
							card.nextturn = Mathf.Clamp(card.nextturn + ca.lockturn - lockturn, 0, 100000000);
						}
						card.lockturn = ca.lockturn;
						card.name = ca.name;
						card.no_outcomes = ca.no_outcomes;
						card.yes_outcomes = ca.yes_outcomes;
						card.load_outcomes = ca.load_outcomes;
						card.override_no = ca.override_no;
						card.override_yes = ca.override_yes;
						card.question = ca.question;
						card.weight = ca.weight;
						card.weightNocond = ca.weightNocond;
						card.weightReal = ca.weightReal;
						card.weightVar = ca.weightVar;
					}
				}
				else
				{
					cards.Add(ca);
				}
			}
		}
		cards.RemoveAll((Card it) => string.IsNullOrEmpty(it.question.mMsM));
		return cards;
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00008B98 File Offset: 0x00006D98
	private void Start()
	{
		GameAct gameAct = GameAct.diff;
		gameAct.OnInit = (Action)Delegate.Combine(gameAct.OnInit, new Action(this.CheckChara));
		GameAct gameAct2 = GameAct.diff;
		gameAct2.OnLoad = (Action<Game>)Delegate.Combine(gameAct2.OnLoad, new Action<Game>(this.CheckChara));
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00008BF1 File Offset: 0x00006DF1
	private void CheckChara(Game ga)
	{
		this.CheckChara();
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00008BF9 File Offset: 0x00006DF9
	private void CheckChara()
	{
		if (SpeechAct.diff.lang != "en")
		{
			this.UpdateListBearers();
		}
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00008C18 File Offset: 0x00006E18
	private Dictionary<string, string[]> GetCharaLanguageStrings()
	{
		if (SpeechAct.diff == null)
		{
			return new Dictionary<string, string[]>();
		}
		string lang = SpeechAct.diff.lang;
		if (lang == "en")
		{
			return new Dictionary<string, string[]>();
		}
		Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
		string[] array = (this.tempCards.ContainsKey("characters_i18n") ? this.tempCards["characters_i18n"] : Util.GetTextFile("texts/characters_i18n")).Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(new char[]
		{
			this.dele
		});
		for (int i = 1; i < array.Length; i++)
		{
			string[] array3 = array[i].Split(new char[]
			{
				this.dele
			});
			string[] array4 = new string[4];
			string key = "";
			for (int j = 0; j < array2.Length; j++)
			{
				string a = array2[j];
				if (a == "id")
				{
					key = array3[j];
				}
				else if (a == "firstname_" + lang)
				{
					array4[0] = array3[j];
				}
				else if (a == "generated_" + lang)
				{
					array4[1] = array3[j];
				}
				else if (a == "name_" + lang)
				{
					array4[2] = array3[j];
				}
				else if (a == "title_" + lang)
				{
					array4[3] = array3[j];
				}
			}
			dictionary.Add(key, array4);
		}
		return dictionary;
	}

	// Token: 0x06000153 RID: 339 RVA: 0x00008DB0 File Offset: 0x00006FB0
	public void UpdateListBearers()
	{
		this.authenticBearers = (this.bearerModels = new List<Bearer>());
		Dictionary<string, string[]> charaLanguageStrings = this.GetCharaLanguageStrings();
		this.bearerModels = new List<Bearer>();
		this.bearerGenModels = new List<BearerGen>();
		char[] array = new char[]
		{
			';'
		};
		string[] array2 = Util.GetTextFile("texts/characters").Split(new char[]
		{
			'\n'
		});
		string[] columns = array2[0].Split(array, StringSplitOptions.RemoveEmptyEntries);
		for (int i = 1; i < array2.Length; i++)
		{
			Bearer bearer = new Bearer(array2[i].Split(array), columns, array[0], charaLanguageStrings);
			this.bearerModels.Add(bearer);
			if (bearer.type == BearerTypes.generated)
			{
				this.bearerGenModels.Add(new BearerGen(bearer.bearer));
			}
		}
		this.authenticBearers = new List<Bearer>(this.bearerModels);
	}

	// Token: 0x04000156 RID: 342
	private int generatedId;

	// Token: 0x04000157 RID: 343
	private List<Bearer> authenticBearers;

	// Token: 0x04000158 RID: 344
	public List<Bearer> bearerModels;

	// Token: 0x04000159 RID: 345
	public List<BearerGen> bearerGenModels;

	// Token: 0x0400015A RID: 346
	private char dele = ';';

	// Token: 0x0400015B RID: 347
	public string nextname = "";

	// Token: 0x0400015C RID: 348
	private string currentname = "";

	// Token: 0x0400015D RID: 349
	public string previousname = "";

	// Token: 0x0400015E RID: 350
	public int previousid = -1;

	// Token: 0x0400015F RID: 351
	public static CardReader diff;

	// Token: 0x04000160 RID: 352
	private Dictionary<string, string> tempCards = new Dictionary<string, string>();

	// Token: 0x04000161 RID: 353
	private List<Card> cacheHiddenCards;

	// Token: 0x04000162 RID: 354
	private List<Card> cacheCards;
}
