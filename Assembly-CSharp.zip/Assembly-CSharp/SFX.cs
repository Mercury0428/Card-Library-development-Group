﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200005E RID: 94
[Serializable]
public class SFX
{
	// Token: 0x06000341 RID: 833 RVA: 0x00002050 File Offset: 0x00000250
	public SFX()
	{
	}

	// Token: 0x06000342 RID: 834 RVA: 0x00014E30 File Offset: 0x00013030
	public SFX(string nam, List<AudioClip> cls)
	{
		if (nam.StartsWith("amb_") || nam.StartsWith("env_"))
		{
			this.source = SFXSources.ambient;
			this.loop = true;
		}
		else if (nam.StartsWith("sting_"))
		{
			this.source = SFXSources.songs;
		}
		else if (nam.StartsWith("ui_"))
		{
			this.source = SFXSources.ui;
		}
		else
		{
			this.source = SFXSources.sfx;
		}
		this.type = (SFXTypes)Enum.Parse(typeof(SFXTypes), nam);
		this.clips = cls;
		this.name = nam;
	}

	// Token: 0x04000426 RID: 1062
	public string name;

	// Token: 0x04000427 RID: 1063
	public SFXTypes type;

	// Token: 0x04000428 RID: 1064
	public SFXSources source;

	// Token: 0x04000429 RID: 1065
	public List<AudioClip> clips;

	// Token: 0x0400042A RID: 1066
	[HideInInspector]
	public AudioClip lastclip;

	// Token: 0x0400042B RID: 1067
	[HideInInspector]
	public AudioSource lastsource;

	// Token: 0x0400042C RID: 1068
	public bool loop;
}
