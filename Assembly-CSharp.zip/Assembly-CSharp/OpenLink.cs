﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006F RID: 111
public class OpenLink : MonoBehaviour
{
	// Token: 0x060003E1 RID: 993 RVA: 0x000190E8 File Offset: 0x000172E8
	private void OnEnable()
	{
		if (GameAct.diff.state == GameStates.gameover)
		{
			base.StartCoroutine("YieldReset");
		}
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00019103 File Offset: 0x00017303
	private IEnumerator YieldReset()
	{
		yield return 0;
		this.Open();
		yield return new WaitForSeconds(5f);
		if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.resetmenu, false, true);
		}
		this.isunlocked = true;
		yield break;
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00019112 File Offset: 0x00017312
	private IEnumerator YieldAutoClose()
	{
		if (base.GetComponent<Image>().enabled)
		{
			yield return new WaitForSeconds(100f);
		}
		else
		{
			yield return new WaitForSeconds(55f);
		}
		this.Close();
		yield break;
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00019121 File Offset: 0x00017321
	private void Reset()
	{
		InputAct.diff.ResetGame(false);
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x00019130 File Offset: 0x00017330
	public void Open()
	{
		base.StartCoroutine("YieldAutoClose");
		this.video.SetActive(true);
		this.fond.gameObject.SetActive(true);
		this.fond.Select();
		InputAct.diff.SetQuit(this.fond.gameObject);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x000191A4 File Offset: 0x000173A4
	public void Close()
	{
		if (GameAct.diff.state == GameStates.gameover)
		{
			if (this.isunlocked)
			{
				InputAct.diff.ResetGame(false);
			}
			return;
		}
		this.video.SetActive(false);
		this.fond.gameObject.SetActive(false);
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
		this.fond.Select();
		InputAct.diff.SetQuit(this.quit);
		base.StopCoroutine("YieldReset");
		base.StopCoroutine("YieldAutoClose");
	}

	// Token: 0x040004B9 RID: 1209
	public GameObject video;

	// Token: 0x040004BA RID: 1210
	public Button fond;

	// Token: 0x040004BB RID: 1211
	private bool isunlocked;

	// Token: 0x040004BC RID: 1212
	public GameObject quit;
}
