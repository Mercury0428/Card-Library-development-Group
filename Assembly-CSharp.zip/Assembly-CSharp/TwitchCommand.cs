﻿using System;
using UnityEngine;

// Token: 0x0200009D RID: 157
[Serializable]
public class TwitchCommand
{
	// Token: 0x04000598 RID: 1432
	[Tooltip("Name of Command, not relevant to code")]
	public string name;

	// Token: 0x04000599 RID: 1433
	[Tooltip("string key for command\n   ie 'vote', 'A', 'up'")]
	public string commandKey;

	// Token: 0x0400059A RID: 1434
	[Tooltip("Method to call, will pass command options as a string")]
	[SerializeField]
	public stringEvent onCommand;
}
