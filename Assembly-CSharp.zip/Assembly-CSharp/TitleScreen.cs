﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200007C RID: 124
public class TitleScreen : MonoBehaviour
{
	// Token: 0x06000434 RID: 1076 RVA: 0x0001AE05 File Offset: 0x00019005
	private void Awake()
	{
		this.mytrans = base.GetComponent<RectTransform>();
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x0001AE13 File Offset: 0x00019013
	public virtual IEnumerator Open()
	{
		this.mytrans.anchoredPosition = new Vector2(0f, 0f);
		yield return null;
		yield break;
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x0001AE22 File Offset: 0x00019022
	public void LerpToPos(Vector2 target, float amount)
	{
		this.mytrans.anchoredPosition = Vector2.Lerp(this.mytrans.anchoredPosition, target, amount);
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x0001AE41 File Offset: 0x00019041
	public void AddToPos()
	{
		this.mytrans.anchoredPosition = Vector2.Lerp(this.mytrans.anchoredPosition, this.mytrans.anchoredPosition * 2f, Time.deltaTime * 4f);
	}

	// Token: 0x040004EF RID: 1263
	private RectTransform mytrans;
}
