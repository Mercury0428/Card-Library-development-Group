﻿using System;
using System.Collections;
using System.Collections.Generic;
using Steamworks;
using UnityEngine;
using UnityEngine.SocialPlatforms;

// Token: 0x02000072 RID: 114
public class SocialAct : MonoBehaviour
{
	// Token: 0x060003F0 RID: 1008 RVA: 0x00003D07 File Offset: 0x00001F07
	private void InitCallback()
	{
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x00019570 File Offset: 0x00017770
	private void OnHideUnity(bool isGameShown)
	{
		if (!isGameShown)
		{
			Time.timeScale = 0f;
			return;
		}
		Time.timeScale = 1f;
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x0001958A File Offset: 0x0001778A
	private void Awake()
	{
		if (SocialAct.diff != null)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		SocialAct.diff = this;
		Object.DontDestroyOnLoad(base.gameObject);
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x000195B6 File Offset: 0x000177B6
	private void Start()
	{
		if (PlayerPrefs.HasKey("nosocial"))
		{
			return;
		}
		if (this.socialReadyOrNot)
		{
			return;
		}
		this.socialReadyOrNot = false;
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x00003D07 File Offset: 0x00001F07
	public void Disconnect()
	{
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x000195D5 File Offset: 0x000177D5
	private void SocialAuthent(bool success)
	{
		if (success)
		{
			this.authenticated = true;
			this.cloudEnabled = false;
		}
		else
		{
			PlayerPrefs.SetInt("nosocial", 1);
		}
		this.socialReadyOrNot = true;
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x000195FC File Offset: 0x000177FC
	public void AddAchieve(string id)
	{
		if (this.seenAchieve.Contains(id))
		{
			return;
		}
		this.seenAchieve.Add(id);
		try
		{
			if (!SteamManager.Initialized)
			{
				return;
			}
			SteamUserStats.SetAchievement(id);
			this.StatUpload();
			return;
		}
		catch
		{
		}
		IAchievement achievement = Social.CreateAchievement();
		achievement.id = id;
		achievement.percentCompleted = 100.0;
		achievement.ReportProgress(delegate(bool success)
		{
		});
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x00019690 File Offset: 0x00017890
	public void SetScore(int years)
	{
		if (!Social.localUser.authenticated)
		{
			return;
		}
		string board = this.iosBoardId;
		Social.ReportScore((long)years, board, delegate(bool success)
		{
		});
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x00003D07 File Offset: 0x00001F07
	public void OpenLeaderBoard()
	{
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x000196D8 File Offset: 0x000178D8
	private void OnApplicationQuit()
	{
		if (this.hasStatsPending)
		{
			SteamUserStats.StoreStats();
		}
		this.hasStatsPending = false;
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x000196EF File Offset: 0x000178EF
	private IEnumerator UploadStats()
	{
		for (;;)
		{
			yield return new WaitForSeconds(10f);
			if (this.hasStatsPending && SteamUserStats.StoreStats())
			{
				this.hasStatsPending = false;
			}
		}
		yield break;
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x000196FE File Offset: 0x000178FE
	private void StatUpload()
	{
		if (!SteamUserStats.StoreStats())
		{
			this.hasStatsPending = true;
		}
	}

	// Token: 0x040004C6 RID: 1222
	public static SocialAct diff;

	// Token: 0x040004C7 RID: 1223
	private bool hasStatsPending;

	// Token: 0x040004C8 RID: 1224
	private Dictionary<string, string> achieveId = new Dictionary<string, string>
	{
		{
			"cardsGoT",
			"CgkIppbDtKUZEAIQAg"
		},
		{
			"collectorGoT",
			"CgkIppbDtKUZEAIQAw"
		},
		{
			"charactersGoT",
			"CgkIppbDtKUZEAIQBA"
		},
		{
			"deathsGoT",
			"CgkIppbDtKUZEAIQBQ"
		},
		{
			"bellowGoT",
			"CgkIppbDtKUZEAIQBg"
		},
		{
			"over50GoT",
			"CgkIppbDtKUZEAIQBw"
		},
		{
			"over100GoT",
			"CgkIppbDtKUZEAIQCA"
		},
		{
			"hundredGoT",
			"CgkIppbDtKUZEAIQCQ"
		},
		{
			"summerGoT",
			"CgkIppbDtKUZEAIQCg"
		},
		{
			"endofendsGoT",
			"CgkIppbDtKUZEAIQCw"
		}
	};

	// Token: 0x040004C9 RID: 1225
	private string andBoardId = "CgkIppbDtKUZEAIQAQ";

	// Token: 0x040004CA RID: 1226
	private string iosBoardId = "real_longest_reign";

	// Token: 0x040004CB RID: 1227
	private List<string> seenAchieve = new List<string>();

	// Token: 0x040004CC RID: 1228
	public bool socialReadyOrNot;

	// Token: 0x040004CD RID: 1229
	private bool authenticated;

	// Token: 0x040004CE RID: 1230
	public bool cloudEnabled;
}
