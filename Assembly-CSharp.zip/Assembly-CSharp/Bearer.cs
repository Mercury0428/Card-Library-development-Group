﻿using System;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000030 RID: 48
[Serializable]
public class Bearer
{
	// Token: 0x06000156 RID: 342 RVA: 0x00009014 File Offset: 0x00007214
	public Bearer(Bearer be)
	{
		if (be == null)
		{
			return;
		}
		this.name = be.name;
		this.generated = be.generated.TreatName();
		this.title = be.title;
		this.staydead = be.staydead;
		this.bearer = be.bearer;
		this.sprite = be.sprite;
		this.eyes = be.eyes;
		this.eyesPos = be.eyesPos;
		this.title = be.title;
		this.max = be.max;
		this.hasVote = be.hasVote;
		this.super = be.super;
		this.vote = be.vote;
		this.type = be.type;
		this.character = be.character;
		this.scCa = be.scCa;
		this.hasEyes = be.hasEyes;
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00009118 File Offset: 0x00007318
	public Bearer(string[] rawele, string[] columns, char dele, Dictionary<string, string[]> i18n)
	{
		string[] array = new string[4];
		bool flag = false;
		int i = 0;
		while (i < columns.Length)
		{
			string text = rawele[i];
			string text2 = columns[i];
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num <= 1769387450U)
			{
				if (num <= 926444256U)
				{
					if (num != 217793883U)
					{
						if (num != 453108228U)
						{
							if (num == 926444256U)
							{
								if (text2 == "id")
								{
									if (i18n.Count > 0 && i18n.ContainsKey(text))
									{
										array = i18n[text];
										flag = true;
									}
								}
							}
						}
						else if (text2 == "keyword")
						{
							goto IL_2F2;
						}
					}
					else if (text2 == "house")
					{
						goto IL_2F2;
					}
				}
				else if (num != 1139653707U)
				{
					if (num != 1361572173U)
					{
						if (num == 1769387450U)
						{
							if (text2 == "firstname")
							{
								this.firstname = (flag ? array[0] : text);
							}
						}
					}
					else if (text2 == "type")
					{
						this.type = (BearerTypes)Enum.Parse(typeof(BearerTypes), text);
						if (this.type == BearerTypes.individual || this.type == BearerTypes.generated)
						{
							this.hasVote = true;
						}
					}
				}
				else if (text2 == "eyes")
				{
					this.hasEyes = true;
					if (text == "no")
					{
						this.hasEyes = false;
					}
					else
					{
						int.TryParse(text, out this.eyesPos);
						string str = this.bearer.ToString();
						this.eyes = (SVGAsset)Resources.Load("eyes/" + str, typeof(SVGAsset));
						if (this.eyes == null)
						{
							this.eyes = (SVGAsset)Resources.Load("eyes/anyone", typeof(SVGAsset));
						}
					}
				}
			}
			else if (num <= 2094874946U)
			{
				if (num != 1986820544U)
				{
					if (num != 2039327246U)
					{
						if (num == 2094874946U)
						{
							if (text2 == "generated")
							{
								this.generated = (flag ? new GText(array[1]) : new GText(text));
							}
						}
					}
					else if (text2 == "staydead")
					{
						int.TryParse(text, out this.staydead);
					}
				}
				else if (text2 == "genre")
				{
					goto IL_2F2;
				}
			}
			else if (num <= 2556802313U)
			{
				if (num != 2369371622U)
				{
					if (num == 2556802313U)
					{
						if (text2 == "title")
						{
							this.title = (flag ? new GText(array[3]) : new GText(text));
						}
					}
				}
				else if (text2 == "name")
				{
					if (string.IsNullOrEmpty(text))
					{
						this.name = this.generated.Get(true, true);
					}
					else
					{
						this.name = (flag ? array[2] : text);
					}
				}
			}
			else if (num != 3617776409U)
			{
				if (num == 4269779792U)
				{
					if (text2 == "bearer")
					{
						this.bearer = (Bearers)Enum.Parse(typeof(Bearers), text);
						this.sprite = (SVGAsset)Resources.Load("bearers/" + text, typeof(SVGAsset));
					}
				}
			}
			else if (text2 == "max")
			{
				int.TryParse(text, out this.max);
			}
			IL_43F:
			i++;
			continue;
			IL_2F2:
			if (!string.IsNullOrEmpty(text))
			{
				this.character.Add((Bearers)Enum.Parse(typeof(Bearers), text));
				goto IL_43F;
			}
			goto IL_43F;
		}
	}

	// Token: 0x04000172 RID: 370
	public string name;

	// Token: 0x04000173 RID: 371
	public string firstname;

	// Token: 0x04000174 RID: 372
	public GText title;

	// Token: 0x04000175 RID: 373
	public GText generated;

	// Token: 0x04000176 RID: 374
	public SVGAsset sprite;

	// Token: 0x04000177 RID: 375
	public SVGAsset body;

	// Token: 0x04000178 RID: 376
	public SVGAsset cloth;

	// Token: 0x04000179 RID: 377
	public SVGAsset hair;

	// Token: 0x0400017A RID: 378
	public Bearers bearer;

	// Token: 0x0400017B RID: 379
	public bool hasVote;

	// Token: 0x0400017C RID: 380
	public int super;

	// Token: 0x0400017D RID: 381
	public float vote;

	// Token: 0x0400017E RID: 382
	public int max = 1;

	// Token: 0x0400017F RID: 383
	public BearerTypes type;

	// Token: 0x04000180 RID: 384
	public List<Bearers> character = new List<Bearers>();

	// Token: 0x04000181 RID: 385
	public CharacterCard scCa;

	// Token: 0x04000182 RID: 386
	public bool hasEyes;

	// Token: 0x04000183 RID: 387
	public SVGAsset eyes;

	// Token: 0x04000184 RID: 388
	public int staydead = 100;

	// Token: 0x04000185 RID: 389
	public int eyesPos;
}
