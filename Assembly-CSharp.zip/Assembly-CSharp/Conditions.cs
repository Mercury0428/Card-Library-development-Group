﻿using System;

// Token: 0x02000029 RID: 41
public enum Conditions
{
	// Token: 0x0400012C RID: 300
	above,
	// Token: 0x0400012D RID: 301
	below,
	// Token: 0x0400012E RID: 302
	equal,
	// Token: 0x0400012F RID: 303
	round,
	// Token: 0x04000130 RID: 304
	notequal
}
