﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000054 RID: 84
public class InitToggle : MonoBehaviour
{
	// Token: 0x06000308 RID: 776 RVA: 0x00013A79 File Offset: 0x00011C79
	private void OnEnable()
	{
		this.toggle.isOn = (PlayerPrefs.GetFloat(this.id) != 0f);
	}

	// Token: 0x040003D0 RID: 976
	public Toggle toggle;

	// Token: 0x040003D1 RID: 977
	public string id;
}
