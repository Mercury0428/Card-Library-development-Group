﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000206 RID: 518
	public enum LeaderboardStart
	{
		// Token: 0x04000D43 RID: 3395
		TopScores = 1,
		// Token: 0x04000D44 RID: 3396
		PlayerCentered
	}
}
