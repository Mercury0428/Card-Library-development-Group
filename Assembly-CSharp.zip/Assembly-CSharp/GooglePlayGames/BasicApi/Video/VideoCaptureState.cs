﻿using System;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x02000211 RID: 529
	public class VideoCaptureState
	{
		// Token: 0x060010AA RID: 4266 RVA: 0x00062E77 File Offset: 0x00061077
		internal VideoCaptureState(bool isCapturing, VideoCaptureMode captureMode, VideoQualityLevel qualityLevel, bool isOverlayVisible, bool isPaused)
		{
			this.mIsCapturing = isCapturing;
			this.mCaptureMode = captureMode;
			this.mQualityLevel = qualityLevel;
			this.mIsOverlayVisible = isOverlayVisible;
			this.mIsPaused = isPaused;
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x060010AB RID: 4267 RVA: 0x00062EA4 File Offset: 0x000610A4
		public bool IsCapturing
		{
			get
			{
				return this.mIsCapturing;
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x060010AC RID: 4268 RVA: 0x00062EAC File Offset: 0x000610AC
		public VideoCaptureMode CaptureMode
		{
			get
			{
				return this.mCaptureMode;
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x060010AD RID: 4269 RVA: 0x00062EB4 File Offset: 0x000610B4
		public VideoQualityLevel QualityLevel
		{
			get
			{
				return this.mQualityLevel;
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x060010AE RID: 4270 RVA: 0x00062EBC File Offset: 0x000610BC
		public bool IsOverlayVisible
		{
			get
			{
				return this.mIsOverlayVisible;
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x060010AF RID: 4271 RVA: 0x00062EC4 File Offset: 0x000610C4
		public bool IsPaused
		{
			get
			{
				return this.mIsPaused;
			}
		}

		// Token: 0x060010B0 RID: 4272 RVA: 0x00062ECC File Offset: 0x000610CC
		public override string ToString()
		{
			return string.Format("[VideoCaptureState: mIsCapturing={0}, mCaptureMode={1}, mQualityLevel={2}, mIsOverlayVisible={3}, mIsPaused={4}]", new object[]
			{
				this.mIsCapturing,
				this.mCaptureMode.ToString(),
				this.mQualityLevel.ToString(),
				this.mIsOverlayVisible,
				this.mIsPaused
			});
		}

		// Token: 0x04000D67 RID: 3431
		private bool mIsCapturing;

		// Token: 0x04000D68 RID: 3432
		private VideoCaptureMode mCaptureMode;

		// Token: 0x04000D69 RID: 3433
		private VideoQualityLevel mQualityLevel;

		// Token: 0x04000D6A RID: 3434
		private bool mIsOverlayVisible;

		// Token: 0x04000D6B RID: 3435
		private bool mIsPaused;
	}
}
