﻿using System;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x0200020E RID: 526
	public interface CaptureOverlayStateListener
	{
		// Token: 0x0600109B RID: 4251
		void OnCaptureOverlayStateChanged(VideoCaptureOverlayState overlayState);
	}
}
