﻿using System;
using System.Linq;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x02000210 RID: 528
	public class VideoCapabilities
	{
		// Token: 0x060010A3 RID: 4259 RVA: 0x00062D3F File Offset: 0x00060F3F
		internal VideoCapabilities(bool isCameraSupported, bool isMicSupported, bool isWriteStorageSupported, bool[] captureModesSupported, bool[] qualityLevelsSupported)
		{
			this.mIsCameraSupported = isCameraSupported;
			this.mIsMicSupported = isMicSupported;
			this.mIsWriteStorageSupported = isWriteStorageSupported;
			this.mCaptureModesSupported = captureModesSupported;
			this.mQualityLevelsSupported = qualityLevelsSupported;
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060010A4 RID: 4260 RVA: 0x00062D6C File Offset: 0x00060F6C
		public bool IsCameraSupported
		{
			get
			{
				return this.mIsCameraSupported;
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060010A5 RID: 4261 RVA: 0x00062D74 File Offset: 0x00060F74
		public bool IsMicSupported
		{
			get
			{
				return this.mIsMicSupported;
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x060010A6 RID: 4262 RVA: 0x00062D7C File Offset: 0x00060F7C
		public bool IsWriteStorageSupported
		{
			get
			{
				return this.mIsWriteStorageSupported;
			}
		}

		// Token: 0x060010A7 RID: 4263 RVA: 0x00062D84 File Offset: 0x00060F84
		public bool SupportsCaptureMode(VideoCaptureMode captureMode)
		{
			if (captureMode != VideoCaptureMode.Unknown)
			{
				return this.mCaptureModesSupported[(int)captureMode];
			}
			Logger.w("SupportsCaptureMode called with an unknown captureMode.");
			return false;
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x00062D9E File Offset: 0x00060F9E
		public bool SupportsQualityLevel(VideoQualityLevel qualityLevel)
		{
			if (qualityLevel != VideoQualityLevel.Unknown)
			{
				return this.mQualityLevelsSupported[(int)qualityLevel];
			}
			Logger.w("SupportsCaptureMode called with an unknown qualityLevel.");
			return false;
		}

		// Token: 0x060010A9 RID: 4265 RVA: 0x00062DB8 File Offset: 0x00060FB8
		public override string ToString()
		{
			string format = "[VideoCapabilities: mIsCameraSupported={0}, mIsMicSupported={1}, mIsWriteStorageSupported={2}, mCaptureModesSupported={3}, mQualityLevelsSupported={4}]";
			object[] array = new object[5];
			array[0] = this.mIsCameraSupported;
			array[1] = this.mIsMicSupported;
			array[2] = this.mIsWriteStorageSupported;
			array[3] = string.Join(",", (from p in this.mCaptureModesSupported
			select p.ToString()).ToArray<string>());
			array[4] = string.Join(",", (from p in this.mQualityLevelsSupported
			select p.ToString()).ToArray<string>());
			return string.Format(format, array);
		}

		// Token: 0x04000D62 RID: 3426
		private bool mIsCameraSupported;

		// Token: 0x04000D63 RID: 3427
		private bool mIsMicSupported;

		// Token: 0x04000D64 RID: 3428
		private bool mIsWriteStorageSupported;

		// Token: 0x04000D65 RID: 3429
		private bool[] mCaptureModesSupported;

		// Token: 0x04000D66 RID: 3430
		private bool[] mQualityLevelsSupported;
	}
}
