﻿using System;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x0200020F RID: 527
	public interface IVideoClient
	{
		// Token: 0x0600109C RID: 4252
		void GetCaptureCapabilities(Action<ResponseStatus, VideoCapabilities> callback);

		// Token: 0x0600109D RID: 4253
		void ShowCaptureOverlay();

		// Token: 0x0600109E RID: 4254
		void GetCaptureState(Action<ResponseStatus, VideoCaptureState> callback);

		// Token: 0x0600109F RID: 4255
		void IsCaptureAvailable(VideoCaptureMode captureMode, Action<ResponseStatus, bool> callback);

		// Token: 0x060010A0 RID: 4256
		bool IsCaptureSupported();

		// Token: 0x060010A1 RID: 4257
		void RegisterCaptureOverlayStateChangedListener(CaptureOverlayStateListener listener);

		// Token: 0x060010A2 RID: 4258
		void UnregisterCaptureOverlayStateChangedListener();
	}
}
