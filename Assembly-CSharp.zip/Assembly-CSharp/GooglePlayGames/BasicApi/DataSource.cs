﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000203 RID: 515
	public enum DataSource
	{
		// Token: 0x04000D2F RID: 3375
		ReadCacheOrNetwork,
		// Token: 0x04000D30 RID: 3376
		ReadNetworkOnly
	}
}
