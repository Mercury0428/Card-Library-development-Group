﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000204 RID: 516
	public enum ResponseStatus
	{
		// Token: 0x04000D32 RID: 3378
		Success = 1,
		// Token: 0x04000D33 RID: 3379
		SuccessWithStale,
		// Token: 0x04000D34 RID: 3380
		LicenseCheckFailed = -1,
		// Token: 0x04000D35 RID: 3381
		InternalError = -2,
		// Token: 0x04000D36 RID: 3382
		NotAuthorized = -3,
		// Token: 0x04000D37 RID: 3383
		VersionUpdateRequired = -4,
		// Token: 0x04000D38 RID: 3384
		Timeout = -5
	}
}
