﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000209 RID: 521
	public enum VideoCaptureMode
	{
		// Token: 0x04000D4D RID: 3405
		Unknown = -1,
		// Token: 0x04000D4E RID: 3406
		File,
		// Token: 0x04000D4F RID: 3407
		Stream
	}
}
