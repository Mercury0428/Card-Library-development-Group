﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200020D RID: 525
	public class CommonTypesUtil
	{
		// Token: 0x06001099 RID: 4249 RVA: 0x00062D39 File Offset: 0x00060F39
		public static bool StatusIsSuccess(ResponseStatus status)
		{
			return status > (ResponseStatus)0;
		}
	}
}
