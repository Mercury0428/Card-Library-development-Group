﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000217 RID: 535
	public interface IConflictResolver
	{
		// Token: 0x060010BC RID: 4284
		void ChooseMetadata(ISavedGameMetadata chosenMetadata);

		// Token: 0x060010BD RID: 4285
		void ResolveConflict(ISavedGameMetadata chosenMetadata, SavedGameMetadataUpdate metadataUpdate, byte[] updatedData);
	}
}
