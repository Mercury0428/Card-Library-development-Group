﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000215 RID: 533
	// (Invoke) Token: 0x060010B2 RID: 4274
	public delegate void ConflictCallback(IConflictResolver resolver, ISavedGameMetadata original, byte[] originalData, ISavedGameMetadata unmerged, byte[] unmergedData);
}
