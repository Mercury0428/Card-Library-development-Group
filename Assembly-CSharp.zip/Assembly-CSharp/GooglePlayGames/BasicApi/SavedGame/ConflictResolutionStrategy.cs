﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000212 RID: 530
	public enum ConflictResolutionStrategy
	{
		// Token: 0x04000D6D RID: 3437
		UseLongestPlaytime,
		// Token: 0x04000D6E RID: 3438
		UseOriginal,
		// Token: 0x04000D6F RID: 3439
		UseUnmerged,
		// Token: 0x04000D70 RID: 3440
		UseManual,
		// Token: 0x04000D71 RID: 3441
		UseLastKnownGood,
		// Token: 0x04000D72 RID: 3442
		UseMostRecentlySaved
	}
}
