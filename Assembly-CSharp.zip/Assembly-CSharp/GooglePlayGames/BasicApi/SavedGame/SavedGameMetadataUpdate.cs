﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000219 RID: 537
	public struct SavedGameMetadataUpdate
	{
		// Token: 0x060010C4 RID: 4292 RVA: 0x00062F3B File Offset: 0x0006113B
		private SavedGameMetadataUpdate(SavedGameMetadataUpdate.Builder builder)
		{
			this.mDescriptionUpdated = builder.mDescriptionUpdated;
			this.mNewDescription = builder.mNewDescription;
			this.mCoverImageUpdated = builder.mCoverImageUpdated;
			this.mNewPngCoverImage = builder.mNewPngCoverImage;
			this.mNewPlayedTime = builder.mNewPlayedTime;
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x060010C5 RID: 4293 RVA: 0x00062F79 File Offset: 0x00061179
		public bool IsDescriptionUpdated
		{
			get
			{
				return this.mDescriptionUpdated;
			}
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060010C6 RID: 4294 RVA: 0x00062F81 File Offset: 0x00061181
		public string UpdatedDescription
		{
			get
			{
				return this.mNewDescription;
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060010C7 RID: 4295 RVA: 0x00062F89 File Offset: 0x00061189
		public bool IsCoverImageUpdated
		{
			get
			{
				return this.mCoverImageUpdated;
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x060010C8 RID: 4296 RVA: 0x00062F91 File Offset: 0x00061191
		public byte[] UpdatedPngCoverImage
		{
			get
			{
				return this.mNewPngCoverImage;
			}
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x060010C9 RID: 4297 RVA: 0x00062F99 File Offset: 0x00061199
		public bool IsPlayedTimeUpdated
		{
			get
			{
				return this.mNewPlayedTime != null;
			}
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x060010CA RID: 4298 RVA: 0x00062FA6 File Offset: 0x000611A6
		public TimeSpan? UpdatedPlayedTime
		{
			get
			{
				return this.mNewPlayedTime;
			}
		}

		// Token: 0x04000D80 RID: 3456
		private readonly bool mDescriptionUpdated;

		// Token: 0x04000D81 RID: 3457
		private readonly string mNewDescription;

		// Token: 0x04000D82 RID: 3458
		private readonly bool mCoverImageUpdated;

		// Token: 0x04000D83 RID: 3459
		private readonly byte[] mNewPngCoverImage;

		// Token: 0x04000D84 RID: 3460
		private readonly TimeSpan? mNewPlayedTime;

		// Token: 0x020003DD RID: 989
		public struct Builder
		{
			// Token: 0x060018A0 RID: 6304 RVA: 0x0007828C File Offset: 0x0007648C
			public SavedGameMetadataUpdate.Builder WithUpdatedDescription(string description)
			{
				this.mNewDescription = Misc.CheckNotNull<string>(description);
				this.mDescriptionUpdated = true;
				return this;
			}

			// Token: 0x060018A1 RID: 6305 RVA: 0x000782A7 File Offset: 0x000764A7
			public SavedGameMetadataUpdate.Builder WithUpdatedPngCoverImage(byte[] newPngCoverImage)
			{
				this.mCoverImageUpdated = true;
				this.mNewPngCoverImage = newPngCoverImage;
				return this;
			}

			// Token: 0x060018A2 RID: 6306 RVA: 0x000782BD File Offset: 0x000764BD
			public SavedGameMetadataUpdate.Builder WithUpdatedPlayedTime(TimeSpan newPlayedTime)
			{
				if (newPlayedTime.TotalMilliseconds > 1.8446744073709552E+19)
				{
					throw new InvalidOperationException("Timespans longer than ulong.MaxValue milliseconds are not allowed");
				}
				this.mNewPlayedTime = new TimeSpan?(newPlayedTime);
				return this;
			}

			// Token: 0x060018A3 RID: 6307 RVA: 0x000782EE File Offset: 0x000764EE
			public SavedGameMetadataUpdate Build()
			{
				return new SavedGameMetadataUpdate(this);
			}

			// Token: 0x04001502 RID: 5378
			internal bool mDescriptionUpdated;

			// Token: 0x04001503 RID: 5379
			internal string mNewDescription;

			// Token: 0x04001504 RID: 5380
			internal bool mCoverImageUpdated;

			// Token: 0x04001505 RID: 5381
			internal byte[] mNewPngCoverImage;

			// Token: 0x04001506 RID: 5382
			internal TimeSpan? mNewPlayedTime;
		}
	}
}
