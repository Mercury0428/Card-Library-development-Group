﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000214 RID: 532
	public enum SelectUIStatus
	{
		// Token: 0x04000D7A RID: 3450
		SavedGameSelected = 1,
		// Token: 0x04000D7B RID: 3451
		UserClosedUI,
		// Token: 0x04000D7C RID: 3452
		InternalError = -1,
		// Token: 0x04000D7D RID: 3453
		TimeoutError = -2,
		// Token: 0x04000D7E RID: 3454
		AuthenticationError = -3,
		// Token: 0x04000D7F RID: 3455
		BadInputError = -4
	}
}
