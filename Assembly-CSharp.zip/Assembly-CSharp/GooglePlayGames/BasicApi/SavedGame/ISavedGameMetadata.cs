﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000218 RID: 536
	public interface ISavedGameMetadata
	{
		// Token: 0x170002AB RID: 683
		// (get) Token: 0x060010BE RID: 4286
		bool IsOpen { get; }

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x060010BF RID: 4287
		string Filename { get; }

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x060010C0 RID: 4288
		string Description { get; }

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x060010C1 RID: 4289
		string CoverImageURL { get; }

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x060010C2 RID: 4290
		TimeSpan TotalTimePlayed { get; }

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x060010C3 RID: 4291
		DateTime LastModifiedTimestamp { get; }
	}
}
