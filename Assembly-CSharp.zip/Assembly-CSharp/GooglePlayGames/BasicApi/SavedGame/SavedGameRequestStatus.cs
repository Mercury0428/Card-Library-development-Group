﻿using System;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02000213 RID: 531
	public enum SavedGameRequestStatus
	{
		// Token: 0x04000D74 RID: 3444
		Success = 1,
		// Token: 0x04000D75 RID: 3445
		TimeoutError = -1,
		// Token: 0x04000D76 RID: 3446
		InternalError = -2,
		// Token: 0x04000D77 RID: 3447
		AuthenticationError = -3,
		// Token: 0x04000D78 RID: 3448
		BadInputError = -4
	}
}
