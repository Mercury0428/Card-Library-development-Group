﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000208 RID: 520
	public enum LeaderboardCollection
	{
		// Token: 0x04000D4A RID: 3402
		Public = 1,
		// Token: 0x04000D4B RID: 3403
		Social
	}
}
