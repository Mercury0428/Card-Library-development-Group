﻿using System;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021F RID: 543
	public interface IDiscoveryListener
	{
		// Token: 0x060010E4 RID: 4324
		void OnEndpointFound(EndpointDetails discoveredEndpoint);

		// Token: 0x060010E5 RID: 4325
		void OnEndpointLost(string lostEndpointId);
	}
}
