﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021D RID: 541
	public struct EndpointDetails
	{
		// Token: 0x060010DE RID: 4318 RVA: 0x000630C1 File Offset: 0x000612C1
		public EndpointDetails(string endpointId, string name, string serviceId)
		{
			this.mEndpointId = Misc.CheckNotNull<string>(endpointId);
			this.mName = Misc.CheckNotNull<string>(name);
			this.mServiceId = Misc.CheckNotNull<string>(serviceId);
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x060010DF RID: 4319 RVA: 0x000630E7 File Offset: 0x000612E7
		public string EndpointId
		{
			get
			{
				return this.mEndpointId;
			}
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x060010E0 RID: 4320 RVA: 0x000630EF File Offset: 0x000612EF
		public string Name
		{
			get
			{
				return this.mName;
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x060010E1 RID: 4321 RVA: 0x000630F7 File Offset: 0x000612F7
		public string ServiceId
		{
			get
			{
				return this.mServiceId;
			}
		}

		// Token: 0x04000D8E RID: 3470
		private readonly string mEndpointId;

		// Token: 0x04000D8F RID: 3471
		private readonly string mName;

		// Token: 0x04000D90 RID: 3472
		private readonly string mServiceId;
	}
}
