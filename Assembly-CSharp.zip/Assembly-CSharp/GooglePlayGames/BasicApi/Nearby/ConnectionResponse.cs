﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021C RID: 540
	public struct ConnectionResponse
	{
		// Token: 0x060010D2 RID: 4306 RVA: 0x00063015 File Offset: 0x00061215
		private ConnectionResponse(long localClientId, string remoteEndpointId, ConnectionResponse.Status code, byte[] payload)
		{
			this.mLocalClientId = localClientId;
			this.mRemoteEndpointId = Misc.CheckNotNull<string>(remoteEndpointId);
			this.mResponseStatus = code;
			this.mPayload = Misc.CheckNotNull<byte[]>(payload);
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x060010D3 RID: 4307 RVA: 0x0006303E File Offset: 0x0006123E
		public long LocalClientId
		{
			get
			{
				return this.mLocalClientId;
			}
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x060010D4 RID: 4308 RVA: 0x00063046 File Offset: 0x00061246
		public string RemoteEndpointId
		{
			get
			{
				return this.mRemoteEndpointId;
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x060010D5 RID: 4309 RVA: 0x0006304E File Offset: 0x0006124E
		public ConnectionResponse.Status ResponseStatus
		{
			get
			{
				return this.mResponseStatus;
			}
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x060010D6 RID: 4310 RVA: 0x00063056 File Offset: 0x00061256
		public byte[] Payload
		{
			get
			{
				return this.mPayload;
			}
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0006305E File Offset: 0x0006125E
		public static ConnectionResponse Rejected(long localClientId, string remoteEndpointId)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.Rejected, ConnectionResponse.EmptyPayload);
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x0006306D File Offset: 0x0006126D
		public static ConnectionResponse NetworkNotConnected(long localClientId, string remoteEndpointId)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.ErrorNetworkNotConnected, ConnectionResponse.EmptyPayload);
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x0006307C File Offset: 0x0006127C
		public static ConnectionResponse InternalError(long localClientId, string remoteEndpointId)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.ErrorInternal, ConnectionResponse.EmptyPayload);
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0006308B File Offset: 0x0006128B
		public static ConnectionResponse EndpointNotConnected(long localClientId, string remoteEndpointId)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.ErrorEndpointNotConnected, ConnectionResponse.EmptyPayload);
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x0006309A File Offset: 0x0006129A
		public static ConnectionResponse Accepted(long localClientId, string remoteEndpointId, byte[] payload)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.Accepted, payload);
		}

		// Token: 0x060010DC RID: 4316 RVA: 0x000630A5 File Offset: 0x000612A5
		public static ConnectionResponse AlreadyConnected(long localClientId, string remoteEndpointId)
		{
			return new ConnectionResponse(localClientId, remoteEndpointId, ConnectionResponse.Status.ErrorAlreadyConnected, ConnectionResponse.EmptyPayload);
		}

		// Token: 0x04000D89 RID: 3465
		private static readonly byte[] EmptyPayload = new byte[0];

		// Token: 0x04000D8A RID: 3466
		private readonly long mLocalClientId;

		// Token: 0x04000D8B RID: 3467
		private readonly string mRemoteEndpointId;

		// Token: 0x04000D8C RID: 3468
		private readonly ConnectionResponse.Status mResponseStatus;

		// Token: 0x04000D8D RID: 3469
		private readonly byte[] mPayload;

		// Token: 0x020003DE RID: 990
		public enum Status
		{
			// Token: 0x04001508 RID: 5384
			Accepted,
			// Token: 0x04001509 RID: 5385
			Rejected,
			// Token: 0x0400150A RID: 5386
			ErrorInternal,
			// Token: 0x0400150B RID: 5387
			ErrorNetworkNotConnected,
			// Token: 0x0400150C RID: 5388
			ErrorEndpointNotConnected,
			// Token: 0x0400150D RID: 5389
			ErrorAlreadyConnected
		}
	}
}
