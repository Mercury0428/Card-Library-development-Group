﻿using System;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021E RID: 542
	public interface IMessageListener
	{
		// Token: 0x060010E2 RID: 4322
		void OnMessageReceived(string remoteEndpointId, byte[] data, bool isReliableMessage);

		// Token: 0x060010E3 RID: 4323
		void OnRemoteEndpointDisconnected(string remoteEndpointId);
	}
}
