﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021B RID: 539
	public struct ConnectionRequest
	{
		// Token: 0x060010CF RID: 4303 RVA: 0x00062FDE File Offset: 0x000611DE
		public ConnectionRequest(string remoteEndpointId, string remoteEndpointName, string serviceId, byte[] payload)
		{
			Logger.d("Constructing ConnectionRequest");
			this.mRemoteEndpoint = new EndpointDetails(remoteEndpointId, remoteEndpointName, serviceId);
			this.mPayload = Misc.CheckNotNull<byte[]>(payload);
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x060010D0 RID: 4304 RVA: 0x00063005 File Offset: 0x00061205
		public EndpointDetails RemoteEndpoint
		{
			get
			{
				return this.mRemoteEndpoint;
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x060010D1 RID: 4305 RVA: 0x0006300D File Offset: 0x0006120D
		public byte[] Payload
		{
			get
			{
				return this.mPayload;
			}
		}

		// Token: 0x04000D87 RID: 3463
		private readonly EndpointDetails mRemoteEndpoint;

		// Token: 0x04000D88 RID: 3464
		private readonly byte[] mPayload;
	}
}
