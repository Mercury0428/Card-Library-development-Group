﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x02000221 RID: 545
	public struct NearbyConnectionConfiguration
	{
		// Token: 0x060010E6 RID: 4326 RVA: 0x000630FF File Offset: 0x000612FF
		public NearbyConnectionConfiguration(Action<InitializationStatus> callback, long localClientId)
		{
			this.mInitializationCallback = Misc.CheckNotNull<Action<InitializationStatus>>(callback);
			this.mLocalClientId = localClientId;
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x060010E7 RID: 4327 RVA: 0x00063114 File Offset: 0x00061314
		public long LocalClientId
		{
			get
			{
				return this.mLocalClientId;
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x060010E8 RID: 4328 RVA: 0x0006311C File Offset: 0x0006131C
		public Action<InitializationStatus> InitializationCallback
		{
			get
			{
				return this.mInitializationCallback;
			}
		}

		// Token: 0x04000D95 RID: 3477
		public const int MaxUnreliableMessagePayloadLength = 1168;

		// Token: 0x04000D96 RID: 3478
		public const int MaxReliableMessagePayloadLength = 4096;

		// Token: 0x04000D97 RID: 3479
		private readonly Action<InitializationStatus> mInitializationCallback;

		// Token: 0x04000D98 RID: 3480
		private readonly long mLocalClientId;
	}
}
