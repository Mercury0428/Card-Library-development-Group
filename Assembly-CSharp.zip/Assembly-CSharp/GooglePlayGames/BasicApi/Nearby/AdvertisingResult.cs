﻿using System;
using GooglePlayGames.OurUtils;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200021A RID: 538
	public struct AdvertisingResult
	{
		// Token: 0x060010CB RID: 4299 RVA: 0x00062FAE File Offset: 0x000611AE
		public AdvertisingResult(ResponseStatus status, string localEndpointName)
		{
			this.mStatus = status;
			this.mLocalEndpointName = Misc.CheckNotNull<string>(localEndpointName);
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x060010CC RID: 4300 RVA: 0x00062FC3 File Offset: 0x000611C3
		public bool Succeeded
		{
			get
			{
				return this.mStatus == ResponseStatus.Success;
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x060010CD RID: 4301 RVA: 0x00062FCE File Offset: 0x000611CE
		public ResponseStatus Status
		{
			get
			{
				return this.mStatus;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x060010CE RID: 4302 RVA: 0x00062FD6 File Offset: 0x000611D6
		public string LocalEndpointName
		{
			get
			{
				return this.mLocalEndpointName;
			}
		}

		// Token: 0x04000D85 RID: 3461
		private readonly ResponseStatus mStatus;

		// Token: 0x04000D86 RID: 3462
		private readonly string mLocalEndpointName;
	}
}
