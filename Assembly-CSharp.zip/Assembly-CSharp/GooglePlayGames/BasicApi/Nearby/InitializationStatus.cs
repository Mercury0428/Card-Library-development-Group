﻿using System;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x02000220 RID: 544
	public enum InitializationStatus
	{
		// Token: 0x04000D92 RID: 3474
		Success,
		// Token: 0x04000D93 RID: 3475
		VersionUpdateRequired,
		// Token: 0x04000D94 RID: 3476
		InternalError
	}
}
