﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200020C RID: 524
	public enum Gravity
	{
		// Token: 0x04000D5D RID: 3421
		TOP = 48,
		// Token: 0x04000D5E RID: 3422
		BOTTOM = 80,
		// Token: 0x04000D5F RID: 3423
		LEFT = 3,
		// Token: 0x04000D60 RID: 3424
		RIGHT = 5,
		// Token: 0x04000D61 RID: 3425
		CENTER_HORIZONTAL = 1
	}
}
