﻿using System;

namespace GooglePlayGames.BasicApi.Events
{
	// Token: 0x02000223 RID: 547
	public interface IEvent
	{
		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x060010E9 RID: 4329
		string Id { get; }

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x060010EA RID: 4330
		string Name { get; }

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x060010EB RID: 4331
		string Description { get; }

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x060010EC RID: 4332
		string ImageUrl { get; }

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x060010ED RID: 4333
		ulong CurrentCount { get; }

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x060010EE RID: 4334
		EventVisibility Visibility { get; }
	}
}
