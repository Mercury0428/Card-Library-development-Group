﻿using System;

namespace GooglePlayGames.BasicApi.Events
{
	// Token: 0x02000222 RID: 546
	public enum EventVisibility
	{
		// Token: 0x04000D9A RID: 3482
		Hidden = 1,
		// Token: 0x04000D9B RID: 3483
		Revealed
	}
}
