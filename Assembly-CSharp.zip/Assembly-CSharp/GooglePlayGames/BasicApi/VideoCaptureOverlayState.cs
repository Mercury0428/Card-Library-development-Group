﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200020B RID: 523
	public enum VideoCaptureOverlayState
	{
		// Token: 0x04000D57 RID: 3415
		Unknown = -1,
		// Token: 0x04000D58 RID: 3416
		Shown = 1,
		// Token: 0x04000D59 RID: 3417
		Started,
		// Token: 0x04000D5A RID: 3418
		Stopped,
		// Token: 0x04000D5B RID: 3419
		Dismissed
	}
}
