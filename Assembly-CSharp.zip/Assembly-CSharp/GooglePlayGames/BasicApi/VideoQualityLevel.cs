﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200020A RID: 522
	public enum VideoQualityLevel
	{
		// Token: 0x04000D51 RID: 3409
		Unknown = -1,
		// Token: 0x04000D52 RID: 3410
		SD,
		// Token: 0x04000D53 RID: 3411
		HD,
		// Token: 0x04000D54 RID: 3412
		XHD,
		// Token: 0x04000D55 RID: 3413
		FullHD
	}
}
