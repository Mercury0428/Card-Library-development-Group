﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000207 RID: 519
	public enum LeaderboardTimeSpan
	{
		// Token: 0x04000D46 RID: 3398
		Daily = 1,
		// Token: 0x04000D47 RID: 3399
		Weekly,
		// Token: 0x04000D48 RID: 3400
		AllTime
	}
}
