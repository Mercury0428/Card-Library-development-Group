﻿using System;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02000205 RID: 517
	public enum UIStatus
	{
		// Token: 0x04000D3A RID: 3386
		Valid = 1,
		// Token: 0x04000D3B RID: 3387
		InternalError = -2,
		// Token: 0x04000D3C RID: 3388
		NotAuthorized = -3,
		// Token: 0x04000D3D RID: 3389
		VersionUpdateRequired = -4,
		// Token: 0x04000D3E RID: 3390
		Timeout = -5,
		// Token: 0x04000D3F RID: 3391
		UserClosedUI = -6,
		// Token: 0x04000D40 RID: 3392
		UiBusy = -12,
		// Token: 0x04000D41 RID: 3393
		LeftRoom = -18
	}
}
