﻿using System;

namespace GooglePlayGames
{
	// Token: 0x020001FF RID: 511
	public class PluginVersion
	{
		// Token: 0x04000D19 RID: 3353
		public const string VersionKeyCPP = "00911";

		// Token: 0x04000D1A RID: 3354
		public const string VersionKeyU5 = "00915";

		// Token: 0x04000D1B RID: 3355
		public const string VersionKey27Patch = "00927a";

		// Token: 0x04000D1C RID: 3356
		public const string VersionKeyJarResolver = "00928";

		// Token: 0x04000D1D RID: 3357
		public const string VersionKeyNativeCRM = "00930";

		// Token: 0x04000D1E RID: 3358
		public const string VersionKeyJNIStats = "00934";

		// Token: 0x04000D1F RID: 3359
		public const string VersionKeyJarResolverDLL = "00935";

		// Token: 0x04000D20 RID: 3360
		public const int VersionInt = 2404;

		// Token: 0x04000D21 RID: 3361
		public const string VersionString = "0.9.64";

		// Token: 0x04000D22 RID: 3362
		public const string VersionKey = "00964";

		// Token: 0x04000D23 RID: 3363
		public const int MinGmsCoreVersionCode = 10200000;

		// Token: 0x04000D24 RID: 3364
		public const string PlayServicesVersionConstraint = "10+";
	}
}
