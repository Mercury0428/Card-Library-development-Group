﻿using System;
using UnityEngine;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02000200 RID: 512
	public class Logger
	{
		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x0600107C RID: 4220 RVA: 0x000627C4 File Offset: 0x000609C4
		// (set) Token: 0x0600107D RID: 4221 RVA: 0x000627CB File Offset: 0x000609CB
		public static bool DebugLogEnabled
		{
			get
			{
				return Logger.debugLogEnabled;
			}
			set
			{
				Logger.debugLogEnabled = value;
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x0600107E RID: 4222 RVA: 0x000627D3 File Offset: 0x000609D3
		// (set) Token: 0x0600107F RID: 4223 RVA: 0x000627DA File Offset: 0x000609DA
		public static bool WarningLogEnabled
		{
			get
			{
				return Logger.warningLogEnabled;
			}
			set
			{
				Logger.warningLogEnabled = value;
			}
		}

		// Token: 0x06001080 RID: 4224 RVA: 0x000627E4 File Offset: 0x000609E4
		public static void d(string msg)
		{
			if (Logger.debugLogEnabled)
			{
				PlayGamesHelperObject.RunOnGameThread(delegate
				{
					Debug.Log(Logger.ToLogMessage(string.Empty, "DEBUG", msg));
				});
			}
		}

		// Token: 0x06001081 RID: 4225 RVA: 0x00062818 File Offset: 0x00060A18
		public static void w(string msg)
		{
			if (Logger.warningLogEnabled)
			{
				PlayGamesHelperObject.RunOnGameThread(delegate
				{
					Debug.LogWarning(Logger.ToLogMessage("!!!", "WARNING", msg));
				});
			}
		}

		// Token: 0x06001082 RID: 4226 RVA: 0x0006284C File Offset: 0x00060A4C
		public static void e(string msg)
		{
			if (Logger.warningLogEnabled)
			{
				PlayGamesHelperObject.RunOnGameThread(delegate
				{
					Debug.LogWarning(Logger.ToLogMessage("***", "ERROR", msg));
				});
			}
		}

		// Token: 0x06001083 RID: 4227 RVA: 0x0006287E File Offset: 0x00060A7E
		public static string describe(byte[] b)
		{
			if (b != null)
			{
				return "byte[" + b.Length + "]";
			}
			return "(null)";
		}

		// Token: 0x06001084 RID: 4228 RVA: 0x000628A0 File Offset: 0x00060AA0
		private static string ToLogMessage(string prefix, string logType, string msg)
		{
			string text = null;
			try
			{
				text = DateTime.Now.ToString("MM/dd/yy H:mm:ss zzz");
			}
			catch (Exception)
			{
				PlayGamesHelperObject.RunOnGameThread(delegate
				{
					Debug.LogWarning("*** [Play Games Plugin DLL] ERROR: Failed to format DateTime.Now");
				});
				text = string.Empty;
			}
			return string.Format("{0} [Play Games Plugin DLL] {1} {2}: {3}", new object[]
			{
				prefix,
				text,
				logType,
				msg
			});
		}

		// Token: 0x04000D25 RID: 3365
		private static bool debugLogEnabled = false;

		// Token: 0x04000D26 RID: 3366
		private static bool warningLogEnabled = true;
	}
}
