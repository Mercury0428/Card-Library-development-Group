﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02000202 RID: 514
	public class PlayGamesHelperObject : MonoBehaviour
	{
		// Token: 0x0600108B RID: 4235 RVA: 0x000629FC File Offset: 0x00060BFC
		public static void CreateObject()
		{
			if (PlayGamesHelperObject.instance != null)
			{
				return;
			}
			if (Application.isPlaying)
			{
				GameObject gameObject = new GameObject("PlayGames_QueueRunner");
				Object.DontDestroyOnLoad(gameObject);
				PlayGamesHelperObject.instance = gameObject.AddComponent<PlayGamesHelperObject>();
				return;
			}
			PlayGamesHelperObject.instance = new PlayGamesHelperObject();
			PlayGamesHelperObject.sIsDummy = true;
		}

		// Token: 0x0600108C RID: 4236 RVA: 0x0001F769 File Offset: 0x0001D969
		public void Awake()
		{
			Object.DontDestroyOnLoad(base.gameObject);
		}

		// Token: 0x0600108D RID: 4237 RVA: 0x00062A49 File Offset: 0x00060C49
		public void OnDisable()
		{
			if (PlayGamesHelperObject.instance == this)
			{
				PlayGamesHelperObject.instance = null;
			}
		}

		// Token: 0x0600108E RID: 4238 RVA: 0x00062A60 File Offset: 0x00060C60
		public static void RunCoroutine(IEnumerator action)
		{
			if (PlayGamesHelperObject.instance != null)
			{
				PlayGamesHelperObject.RunOnGameThread(delegate
				{
					PlayGamesHelperObject.instance.StartCoroutine(action);
				});
			}
		}

		// Token: 0x0600108F RID: 4239 RVA: 0x00062A98 File Offset: 0x00060C98
		public static void RunOnGameThread(Action action)
		{
			if (action == null)
			{
				throw new ArgumentNullException("action");
			}
			if (PlayGamesHelperObject.sIsDummy)
			{
				return;
			}
			List<Action> obj = PlayGamesHelperObject.sQueue;
			lock (obj)
			{
				PlayGamesHelperObject.sQueue.Add(action);
				PlayGamesHelperObject.sQueueEmpty = false;
			}
		}

		// Token: 0x06001090 RID: 4240 RVA: 0x00062AFC File Offset: 0x00060CFC
		public void Update()
		{
			if (PlayGamesHelperObject.sIsDummy || PlayGamesHelperObject.sQueueEmpty)
			{
				return;
			}
			this.localQueue.Clear();
			List<Action> obj = PlayGamesHelperObject.sQueue;
			lock (obj)
			{
				this.localQueue.AddRange(PlayGamesHelperObject.sQueue);
				PlayGamesHelperObject.sQueue.Clear();
				PlayGamesHelperObject.sQueueEmpty = true;
			}
			for (int i = 0; i < this.localQueue.Count; i++)
			{
				this.localQueue[i]();
			}
		}

		// Token: 0x06001091 RID: 4241 RVA: 0x00062B9C File Offset: 0x00060D9C
		public void OnApplicationFocus(bool focused)
		{
			foreach (Action<bool> action in PlayGamesHelperObject.sFocusCallbackList)
			{
				try
				{
					action(focused);
				}
				catch (Exception ex)
				{
					Debug.LogError("Exception in OnApplicationFocus:" + ex.Message + "\n" + ex.StackTrace);
				}
			}
		}

		// Token: 0x06001092 RID: 4242 RVA: 0x00062C20 File Offset: 0x00060E20
		public void OnApplicationPause(bool paused)
		{
			foreach (Action<bool> action in PlayGamesHelperObject.sPauseCallbackList)
			{
				try
				{
					action(paused);
				}
				catch (Exception ex)
				{
					Debug.LogError("Exception in OnApplicationPause:" + ex.Message + "\n" + ex.StackTrace);
				}
			}
		}

		// Token: 0x06001093 RID: 4243 RVA: 0x00062CA4 File Offset: 0x00060EA4
		public static void AddFocusCallback(Action<bool> callback)
		{
			if (!PlayGamesHelperObject.sFocusCallbackList.Contains(callback))
			{
				PlayGamesHelperObject.sFocusCallbackList.Add(callback);
			}
		}

		// Token: 0x06001094 RID: 4244 RVA: 0x00062CBE File Offset: 0x00060EBE
		public static bool RemoveFocusCallback(Action<bool> callback)
		{
			return PlayGamesHelperObject.sFocusCallbackList.Remove(callback);
		}

		// Token: 0x06001095 RID: 4245 RVA: 0x00062CCB File Offset: 0x00060ECB
		public static void AddPauseCallback(Action<bool> callback)
		{
			if (!PlayGamesHelperObject.sPauseCallbackList.Contains(callback))
			{
				PlayGamesHelperObject.sPauseCallbackList.Add(callback);
			}
		}

		// Token: 0x06001096 RID: 4246 RVA: 0x00062CE5 File Offset: 0x00060EE5
		public static bool RemovePauseCallback(Action<bool> callback)
		{
			return PlayGamesHelperObject.sPauseCallbackList.Remove(callback);
		}

		// Token: 0x04000D27 RID: 3367
		private static PlayGamesHelperObject instance = null;

		// Token: 0x04000D28 RID: 3368
		private static bool sIsDummy = false;

		// Token: 0x04000D29 RID: 3369
		private static List<Action> sQueue = new List<Action>();

		// Token: 0x04000D2A RID: 3370
		private List<Action> localQueue = new List<Action>();

		// Token: 0x04000D2B RID: 3371
		private static volatile bool sQueueEmpty = true;

		// Token: 0x04000D2C RID: 3372
		private static List<Action<bool>> sPauseCallbackList = new List<Action<bool>>();

		// Token: 0x04000D2D RID: 3373
		private static List<Action<bool>> sFocusCallbackList = new List<Action<bool>>();
	}
}
