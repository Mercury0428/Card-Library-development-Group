﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000014 RID: 20
public class RavenAct : MonoBehaviour
{
	// Token: 0x06000098 RID: 152 RVA: 0x00004340 File Offset: 0x00002540
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnInitSelection = (Action<List<Card>>)Delegate.Combine(diff.OnInitSelection, new Action<List<Card>>(this.RavenTalk));
		GameAct diff2 = GameAct.diff;
		diff2.OnValidSelection = (Action<Card>)Delegate.Combine(diff2.OnValidSelection, new Action<Card>(this.StopTalk));
	}

	// Token: 0x06000099 RID: 153 RVA: 0x0000439C File Offset: 0x0000259C
	private void RavenTalk(List<Card> cards)
	{
		if (cards.Count == 0)
		{
			return;
		}
		Card card = cards[0];
		if (card.bearer != Bearers.raven && card.bearer != Bearers.three_eyed_raven)
		{
			return;
		}
		if (card.load_outcomes.Find((Outcome it) => it.variable == Variables.chain) == null)
		{
			return;
		}
		if (GameAct.diff.card.name == "_winterpath_choice" || !GameAct.diff.isafterdeath)
		{
			return;
		}
		int index = cards.FindIndex((Card it) => it.bearer == Bearers.three_eyed_raven);
		this.showncards = new List<CharacterCard>(GameAct.diff.selection);
		CharacterCard item = this.showncards[index];
		this.showncards.RemoveAt(index);
		this.showncards.Shuffle<CharacterCard>();
		this.showncards.Add(item);
		base.StopCoroutine("DoRavenTalk");
		base.StartCoroutine("DoRavenTalk", cards);
	}

	// Token: 0x0600009A RID: 154 RVA: 0x000044A7 File Offset: 0x000026A7
	private void StopTalk(Card ca)
	{
		base.StopCoroutine("DoRavenTalk");
	}

	// Token: 0x0600009B RID: 155 RVA: 0x000044B4 File Offset: 0x000026B4
	private IEnumerator DoRavenTalk(List<Card> cards)
	{
		yield return new WaitForSeconds(1f);
		GameAct.diff.state = GameStates.interaction;
		bool first = true;
		for (;;)
		{
			int num3;
			for (int i = 0; i < cards.Count; i = num3 + 1)
			{
				Card card = cards[i];
				CharacterCard characterCard = this.showncards[cards.Count - i - 1];
				characterCard.UnlockBlue();
				characterCard.ActivateButton(first);
				GText quest = new GText(card.question.mMsM);
				GameAct.diff.ChangeQuestion(quest, false);
				float num = (float)quest.mMsM.Length;
				JukeBox.diff.Speak(quest.mMsM, Bearers.three_eyed_raven, 1f, 2100f, 1f, 1f);
				yield return new WaitForSeconds(0.8f + num * 0.03f);
				for (int j = 0; j < 3; j = num3 + 1)
				{
					int num2 = Util.RandInt(3, quest.mMsM.Length - 3);
					string str = quest.mMsM.Substring(num2);
					string str2 = quest.mMsM.Substring(0, num2 - 1);
					quest.mMsM = str + str2;
					GameAct.diff.ChangeQuestion(quest, false);
					yield return new WaitForSeconds(0.4f - (float)j * 0.1f);
					num3 = j;
				}
				first = false;
				quest = null;
				num3 = i;
			}
		}
		yield break;
	}

	// Token: 0x0400006E RID: 110
	private List<CharacterCard> showncards;
}
