﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000071 RID: 113
public class ResolutionOption : MonoBehaviour
{
	// Token: 0x060003EC RID: 1004 RVA: 0x0001925C File Offset: 0x0001745C
	private void OnEnable()
	{
		this.dropResol.ClearOptions();
		this.isReady = false;
		this.resol = new Resolution[0];
		this.resol = Screen.resolutions;
		Array.Reverse(this.resol);
		this.isFullscreen = Screen.fullScreen;
		List<string> list = new List<string>();
		list.Add("AUTO");
		for (int i = 0; i < this.resol.Length; i++)
		{
			Resolution resolution = this.resol[i];
			if ((float)resolution.width / (float)resolution.height > 1.2f)
			{
				if (resolution.refreshRate != 0)
				{
					list.Add(string.Concat(new object[]
					{
						resolution.width,
						"x",
						resolution.height,
						" ",
						resolution.refreshRate,
						"Hz"
					}));
				}
				else
				{
					list.Add(resolution.width + "x" + resolution.height);
				}
				if (resolution.width == Screen.width && resolution.height == Screen.height)
				{
					this.resolid = i;
				}
			}
		}
		this.dropResol.AddOptions(list);
		this.dropResol.value = this.resolid;
		this.toggleResol.isOn = this.isFullscreen;
		this.isReady = true;
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x000193DC File Offset: 0x000175DC
	public void ChangeResol()
	{
		if (!this.isReady)
		{
			return;
		}
		if (this.dropResol.value - 1 == this.resolid && this.isFullscreen == this.toggleResol.isOn)
		{
			this.applyBut.SetActive(false);
		}
		else
		{
			this.applyBut.SetActive(true);
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x00019454 File Offset: 0x00017654
	public void ApplyResol()
	{
		if (this.dropResol.value == 0)
		{
			DataStore.RemoveFile("resol_keep", false);
			Screen.SetResolution(Screen.width, Screen.height, this.toggleResol.isOn);
		}
		else if (this.dropResol.value - 1 != this.resolid || this.isFullscreen != this.toggleResol.isOn)
		{
			Resolution resolution = this.resol[this.dropResol.value - 1];
			DataStore.Save<List<int>>("resol_keep", new List<int>
			{
				resolution.width,
				resolution.height
			}, false, false);
			if (resolution.refreshRate != 0)
			{
				Screen.SetResolution(resolution.width, resolution.height, this.toggleResol.isOn, resolution.refreshRate);
			}
			else
			{
				Screen.SetResolution(resolution.width, resolution.height, this.toggleResol.isOn);
			}
		}
		this.applyBut.SetActive(false);
	}

	// Token: 0x040004BE RID: 1214
	public GameObject applyBut;

	// Token: 0x040004BF RID: 1215
	public Dropdown dropResol;

	// Token: 0x040004C0 RID: 1216
	public Toggle toggleResol;

	// Token: 0x040004C1 RID: 1217
	private int resolid = -1;

	// Token: 0x040004C2 RID: 1218
	private string[] ids;

	// Token: 0x040004C3 RID: 1219
	private bool isFullscreen;

	// Token: 0x040004C4 RID: 1220
	private Resolution[] resol;

	// Token: 0x040004C5 RID: 1221
	public bool isReady;
}
