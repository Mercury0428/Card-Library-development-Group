﻿using System;

// Token: 0x020000A6 RID: 166
public class UniRatePlayerPrefs
{
	// Token: 0x0600054B RID: 1355 RVA: 0x0001F668 File Offset: 0x0001D868
	public static void SetDate(string key, DateTime value)
	{
		SuperPrefs.SetString(key, value.Ticks.ToString());
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x0001F68C File Offset: 0x0001D88C
	public static DateTime GetDate(string key)
	{
		string @string = SuperPrefs.GetString(key);
		long ticks = 0L;
		if (long.TryParse(@string, out ticks))
		{
			return new DateTime(ticks);
		}
		return DateTime.MaxValue;
	}
}
