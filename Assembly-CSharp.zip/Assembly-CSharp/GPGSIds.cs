﻿using System;

// Token: 0x0200000C RID: 12
public static class GPGSIds
{
	// Token: 0x04000051 RID: 81
	public const string achievement_completionist = "CgkIppbDtKUZEAIQAg";

	// Token: 0x04000052 RID: 82
	public const string achievement_all_the_deaths = "CgkIppbDtKUZEAIQBQ";

	// Token: 0x04000053 RID: 83
	public const string leaderboard_the_longest_reign = "CgkIppbDtKUZEAIQAQ";

	// Token: 0x04000054 RID: 84
	public const string achievement_wise = "CgkIppbDtKUZEAIQBw";

	// Token: 0x04000055 RID: 85
	public const string achievement_throne_master = "CgkIppbDtKUZEAIQCA";

	// Token: 0x04000056 RID: 86
	public const string achievement_the_end_of_ends = "CgkIppbDtKUZEAIQCw";

	// Token: 0x04000057 RID: 87
	public const string achievement_all_the_characters = "CgkIppbDtKUZEAIQBA";

	// Token: 0x04000058 RID: 88
	public const string achievement_collector = "CgkIppbDtKUZEAIQAw";

	// Token: 0x04000059 RID: 89
	public const string achievement_hecatomb = "CgkIppbDtKUZEAIQCQ";

	// Token: 0x0400005A RID: 90
	public const string achievement_candle_in_the_wind = "CgkIppbDtKUZEAIQBg";

	// Token: 0x0400005B RID: 91
	public const string achievement_summer = "CgkIppbDtKUZEAIQCg";
}
