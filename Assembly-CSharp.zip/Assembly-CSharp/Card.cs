﻿using System;
using System.Collections.Generic;

// Token: 0x0200002C RID: 44
[Serializable]
public class Card
{
	// Token: 0x0600013C RID: 316 RVA: 0x00007780 File Offset: 0x00005980
	public Card()
	{
	}

	// Token: 0x0600013D RID: 317 RVA: 0x000077EC File Offset: 0x000059EC
	public Card(string[] rawele, string[] columns, char dele, Dictionary<string, string[]> i18n, int lastid)
	{
		string[] array = new string[5];
		bool flag = false;
		this.id = -1;
		int i = 0;
		while (i < columns.Length)
		{
			string text = rawele[i];
			string text2 = columns[i];
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num <= 1352703673U)
			{
				if (num <= 926444256U)
				{
					if (num <= 614966709U)
					{
						if (num != 114665541U)
						{
							if (num != 614966709U)
							{
								goto IL_77C;
							}
							if (!(text2 == "override_no"))
							{
								goto IL_77C;
							}
							this.override_no = (flag ? this.TreatText(array[2]) : this.TreatText(text));
						}
						else
						{
							if (!(text2 == "question"))
							{
								goto IL_77C;
							}
							this.question = (flag ? this.TreatText(array[0]) : this.TreatText(text));
						}
					}
					else if (num != 793562634U)
					{
						if (num != 926444256U)
						{
							goto IL_77C;
						}
						if (!(text2 == "id"))
						{
							goto IL_77C;
						}
						if (i18n.Count > 0)
						{
							if (i18n.ContainsKey(text))
							{
								array = i18n[text];
							}
							flag = true;
						}
						int.TryParse(text, out this.id);
						if (this.id == -1)
						{
							InputAct.diff.OfferReset(false, "It seems an uninvited return carriage is crashing the spreadsheet. \n Around card id: " + lastid);
						}
					}
					else if (!(text2 == "thematic"))
					{
						goto IL_77C;
					}
				}
				else if (num <= 1272380337U)
				{
					if (num != 1254074961U)
					{
						if (num != 1272380337U)
						{
							goto IL_77C;
						}
						if (!(text2 == "override_yes"))
						{
							goto IL_77C;
						}
						this.override_yes = (flag ? this.TreatText(array[1]) : this.TreatText(text));
					}
					else
					{
						if (!(text2 == "lockturn"))
						{
							goto IL_77C;
						}
						if (text == "del")
						{
							this.lockturn = -1;
						}
						else if (text == "reign")
						{
							this.lockturn = -10;
						}
						else
						{
							int.TryParse(text, out this.lockturn);
						}
						this.nextturn = 0;
					}
				}
				else if (num != 1319056784U)
				{
					if (num != 1352703673U)
					{
						goto IL_77C;
					}
					if (!(text2 == "weight"))
					{
						goto IL_77C;
					}
					if (text == "lock")
					{
						this.weight = (this.weightReal = 106);
					}
					else
					{
						if (text.Contains("c"))
						{
							string[] array2 = text.Split(new string[]
							{
								"c"
							}, StringSplitOptions.None);
							text = array2[0];
							this.weightNocond = this.TreatWeight(array2[1]);
						}
						if (text.Contains("+"))
						{
							string[] array3 = text.Split(new string[]
							{
								"+"
							}, StringSplitOptions.None);
							text = array3[0];
							this.weightVar = this.TreatWeight(array3[1]);
						}
						if (text.Contains("-"))
						{
							string[] array4 = text.Split(new string[]
							{
								"-"
							}, StringSplitOptions.None);
							text = array4[0];
							this.weightVar = -this.TreatWeight(array4[1]);
						}
						this.weight = (this.weightReal = this.TreatWeight(text));
					}
				}
				else
				{
					if (!(text2 == "yes"))
					{
						goto IL_77C;
					}
					this.yes_outcomes.AddRange(Outcome.TreatOutcome(text));
				}
			}
			else if (num <= 2284280159U)
			{
				if (num <= 1647734778U)
				{
					if (num != 1496995842U)
					{
						if (num != 1647734778U)
						{
							goto IL_77C;
						}
						if (!(text2 == "no"))
						{
							goto IL_77C;
						}
						this.no_outcomes.AddRange(Outcome.TreatOutcome(text));
					}
					else
					{
						if (!(text2 == "reigning"))
						{
							goto IL_77C;
						}
						if (!string.IsNullOrEmpty(text))
						{
							if (text.StartsWith("!"))
							{
								this.conditions.Add(new Condition(Variables.set, Bearers.reigning, Bearers.none, (Bearers)Enum.Parse(typeof(Bearers), text.Substring(1, text.Length - 1))));
							}
							else
							{
								this.conditions.Add(new Condition(Variables.set, Bearers.reigning, (Bearers)Enum.Parse(typeof(Bearers), text), Bearers.none));
							}
						}
					}
				}
				else if (num != 2162217143U)
				{
					if (num != 2284280159U)
					{
						goto IL_77C;
					}
					if (!(text2 == "card"))
					{
						goto IL_77C;
					}
					if (string.IsNullOrEmpty(text))
					{
						text = this.id.ToString();
					}
					if (text == "_")
					{
						text = "_" + this.id;
					}
					this.name = text;
				}
				else
				{
					if (!(text2 == "conditions"))
					{
						goto IL_77C;
					}
					this.conditions.AddRange(Condition.TreatCondition(text));
				}
			}
			else if (num <= 3161242655U)
			{
				if (num != 2951516011U)
				{
					if (num != 3161242655U)
					{
						goto IL_77C;
					}
					if (!(text2 == "answer_no"))
					{
						goto IL_77C;
					}
					this.answer_no = (flag ? this.TreatText(array[4]) : this.TreatText(text));
				}
				else
				{
					if (!(text2 == "answer_yes"))
					{
						goto IL_77C;
					}
					this.answer_yes = (flag ? this.TreatText(array[3]) : this.TreatText(text));
				}
			}
			else if (num != 3859241449U)
			{
				if (num != 4269779792U)
				{
					goto IL_77C;
				}
				if (!(text2 == "bearer"))
				{
					goto IL_77C;
				}
				if (text.Contains(">"))
				{
					string[] array5 = text.Split(new string[]
					{
						">"
					}, StringSplitOptions.None);
					text = array5[0];
					this.bearerVariation = array5[1];
				}
				if (text.Contains("&"))
				{
					string[] array6 = text.Split(new string[]
					{
						"&"
					}, StringSplitOptions.None);
					text = array6[0];
					this.bearerIsAlso = (Bearers)Enum.Parse(typeof(Bearers), array6[1]);
				}
				if (text.Contains("!"))
				{
					string[] array7 = text.Split(new string[]
					{
						"!"
					}, StringSplitOptions.None);
					text = array7[0];
					this.bearerIsNot = (Bearers)Enum.Parse(typeof(Bearers), array7[1]);
				}
				if (string.IsNullOrEmpty(text))
				{
					this.bearer = Bearers.none;
				}
				try
				{
					this.bearer = (Bearers)Enum.Parse(typeof(Bearers), text);
				}
				catch
				{
					this.bearer = Bearers.anyone;
				}
				if (this.bearer == Bearers.end)
				{
					GameAct.diff.AddEndCard(this.bearerVariation);
				}
			}
			else
			{
				if (!(text2 == "load"))
				{
					goto IL_77C;
				}
				this.load_outcomes.AddRange(Outcome.TreatOutcome(text));
			}
			IL_8D3:
			i++;
			continue;
			IL_77C:
			if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(text2) || text2.Contains("vide"))
			{
				goto IL_8D3;
			}
			Variables var = (Variables)Enum.Parse(typeof(Variables), text2);
			if (text == "pos")
			{
				this.yes_outcomes.Add(new Outcome(var, "1", DataDisplay.towards));
				this.no_outcomes.Add(new Outcome(var, "-1", DataDisplay.towards));
				goto IL_8D3;
			}
			if (text == "neg")
			{
				this.yes_outcomes.Add(new Outcome(var, "-1", DataDisplay.towards));
				this.no_outcomes.Add(new Outcome(var, "1", DataDisplay.towards));
				goto IL_8D3;
			}
			int num2 = 0;
			int num3 = 0;
			if (text.Length == 4)
			{
				int.TryParse(text.Substring(2, 2), out num2);
				text = text.Substring(0, 2);
			}
			else if (text.Length == 3)
			{
				int.TryParse(text.Substring(1, 2), out num2);
				text = text.Substring(0, 1);
			}
			int.TryParse(text, out num3);
			if (num3 + num2 != 0)
			{
				this.yes_outcomes.Add(new Outcome(var, num3 + num2));
			}
			if (-(num3 != 0) + num2 != 0)
			{
				this.no_outcomes.Add(new Outcome(var, -num3 + num2));
				goto IL_8D3;
			}
			goto IL_8D3;
		}
	}

	// Token: 0x0600013E RID: 318 RVA: 0x000080EC File Offset: 0x000062EC
	private int TreatWeight(string val)
	{
		if (val == "max")
		{
			return -1;
		}
		int result;
		int.TryParse(val, out result);
		return result;
	}

	// Token: 0x0600013F RID: 319 RVA: 0x00008114 File Offset: 0x00006314
	public GText TreatText(string val)
	{
		if (string.IsNullOrEmpty(val))
		{
			return new GText("");
		}
		val = val.Replace("<*", "<color=#e2081e>");
		val = val.Replace("*>", "</color>");
		if (SpeechAct.diff && SpeechAct.diff.asiaLayout)
		{
			val = val.Replace("+", "\n");
		}
		return new GText(val);
	}

	// Token: 0x0400013F RID: 319
	public string name;

	// Token: 0x04000140 RID: 320
	public int id;

	// Token: 0x04000141 RID: 321
	public GText question;

	// Token: 0x04000142 RID: 322
	public GText override_yes;

	// Token: 0x04000143 RID: 323
	public GText override_no;

	// Token: 0x04000144 RID: 324
	public GText answer_yes;

	// Token: 0x04000145 RID: 325
	public GText answer_no;

	// Token: 0x04000146 RID: 326
	public Bearers bearer = Bearers.none;

	// Token: 0x04000147 RID: 327
	public Bearers bearerIsAlso = Bearers.none;

	// Token: 0x04000148 RID: 328
	public Bearers bearerIsNot = Bearers.none;

	// Token: 0x04000149 RID: 329
	public string bearerVariation = "";

	// Token: 0x0400014A RID: 330
	public List<Condition> conditions = new List<Condition>();

	// Token: 0x0400014B RID: 331
	public int weight;

	// Token: 0x0400014C RID: 332
	public int weightVar;

	// Token: 0x0400014D RID: 333
	public int weightReal;

	// Token: 0x0400014E RID: 334
	public int weightNocond;

	// Token: 0x0400014F RID: 335
	public int lockturn;

	// Token: 0x04000150 RID: 336
	public int nextturn;

	// Token: 0x04000151 RID: 337
	public bool isLocked;

	// Token: 0x04000152 RID: 338
	public bool wasSeen;

	// Token: 0x04000153 RID: 339
	public List<Outcome> yes_outcomes = new List<Outcome>();

	// Token: 0x04000154 RID: 340
	public List<Outcome> no_outcomes = new List<Outcome>();

	// Token: 0x04000155 RID: 341
	public List<Outcome> load_outcomes = new List<Outcome>();
}
