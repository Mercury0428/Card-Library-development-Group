﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000025 RID: 37
public class NewsetBox : ContentBox
{
	// Token: 0x0600011D RID: 285 RVA: 0x000065B5 File Offset: 0x000047B5
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
		this.setTxt.text = txtid;
	}

	// Token: 0x0600011E RID: 286 RVA: 0x00002EE2 File Offset: 0x000010E2
	public override void Validate()
	{
		base.StartCoroutine("PlayAnim");
	}

	// Token: 0x0600011F RID: 287 RVA: 0x000065C3 File Offset: 0x000047C3
	private IEnumerator PlayAnim()
	{
		yield return new WaitForSeconds(0.2f);
		JukeBox.diff.PlaySound(SFXTypes.ui_new_cards, false, false, 2.5f, -1, 1.5f, 1f);
		yield return new WaitForSeconds(0.5f);
		BackgroundAct.diff.ShowBacks(true);
		yield break;
	}

	// Token: 0x0400010D RID: 269
	public Text setTxt;
}
