﻿using System;
using UnityEngine;

// Token: 0x0200008D RID: 141
public class Instancer : MonoBehaviour
{
	// Token: 0x06000488 RID: 1160 RVA: 0x0001C5CC File Offset: 0x0001A7CC
	private void OnEnable()
	{
		this.instances = new Instanced[this.count];
		Vector3 position = base.transform.position;
		Quaternion rotation = base.transform.rotation;
		for (int i = 0; i < this.count; i++)
		{
			GameObject gameObject = Object.Instantiate<GameObject>(this.GetInstance(), position, rotation);
			gameObject.transform.SetParent(base.transform);
			this.instances[i] = gameObject.GetComponent<Instanced>();
		}
		this.lastInstanceIndex = 0;
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x0001C648 File Offset: 0x0001A848
	private GameObject GetInstance()
	{
		if (this.prefabs == null || this.prefabs.Length == 0)
		{
			return null;
		}
		if (this.prefabs.Length == 1)
		{
			return this.prefabs[0].gameObject;
		}
		Instanced instanced;
		if (this.pickRandom)
		{
			instanced = this.prefabs[Mathf.RoundToInt(Random.value * (float)(this.prefabs.Length - 1))];
		}
		else
		{
			instanced = this.prefabs[this.lastInstanceIndex];
			this.lastInstanceIndex = Mathf.RoundToInt(Mathf.Repeat((float)(this.lastInstanceIndex + 1), (float)(this.prefabs.Length - 1)));
		}
		return instanced.gameObject;
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x0001C6E4 File Offset: 0x0001A8E4
	private void OnDisable()
	{
		if (this.instances != null)
		{
			for (int i = 0; i < this.instances.Length; i++)
			{
				if (!(this.instances[i] == null))
				{
					Object.Destroy(this.instances[i].gameObject);
				}
			}
		}
		this.instances = null;
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x0001C738 File Offset: 0x0001A938
	public void OnUpdate(float value)
	{
		if (this.instances != null)
		{
			float num = (float)this.instances.Length;
			int num2 = 0;
			while ((float)num2 < num)
			{
				float time = (float)num2 / num;
				this.instances[num2].onUpdate.Invoke(value * this.updateFallof.Evaluate(time));
				num2++;
			}
		}
	}

	// Token: 0x04000542 RID: 1346
	public Instanced[] prefabs;

	// Token: 0x04000543 RID: 1347
	public int count = 10;

	// Token: 0x04000544 RID: 1348
	public bool pickRandom;

	// Token: 0x04000545 RID: 1349
	public AnimationCurve updateFallof = new AnimationCurve(new Keyframe[]
	{
		new Keyframe(0f, 1f),
		new Keyframe(1f, 1f)
	});

	// Token: 0x04000546 RID: 1350
	[HideInInspector]
	public Instanced[] instances;

	// Token: 0x04000547 RID: 1351
	private int lastInstanceIndex;
}
