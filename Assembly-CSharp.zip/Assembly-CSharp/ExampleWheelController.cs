﻿using System;
using UnityEngine;

// Token: 0x02000013 RID: 19
public class ExampleWheelController : MonoBehaviour
{
	// Token: 0x06000095 RID: 149 RVA: 0x00004262 File Offset: 0x00002462
	private void Start()
	{
		this.m_Rigidbody = base.GetComponent<Rigidbody>();
		this.m_Rigidbody.maxAngularVelocity = 100f;
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00004280 File Offset: 0x00002480
	private void Update()
	{
		if (global::Input.GetKey(KeyCode.UpArrow))
		{
			this.m_Rigidbody.AddRelativeTorque(new Vector3(-1f * this.acceleration, 0f, 0f), ForceMode.Acceleration);
		}
		else if (global::Input.GetKey(KeyCode.DownArrow))
		{
			this.m_Rigidbody.AddRelativeTorque(new Vector3(1f * this.acceleration, 0f, 0f), ForceMode.Acceleration);
		}
		float value = -this.m_Rigidbody.angularVelocity.x / 100f;
		if (this.motionVectorRenderer)
		{
			this.motionVectorRenderer.material.SetFloat(ExampleWheelController.Uniforms._MotionAmount, Mathf.Clamp(value, -0.25f, 0.25f));
		}
	}

	// Token: 0x0400006B RID: 107
	public float acceleration;

	// Token: 0x0400006C RID: 108
	public Renderer motionVectorRenderer;

	// Token: 0x0400006D RID: 109
	private Rigidbody m_Rigidbody;

	// Token: 0x0200025E RID: 606
	private static class Uniforms
	{
		// Token: 0x04000ED5 RID: 3797
		internal static readonly int _MotionAmount = Shader.PropertyToID("_MotionAmount");
	}
}
