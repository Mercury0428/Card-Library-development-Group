﻿using System;
using UnityEngine;

// Token: 0x02000088 RID: 136
public class AudioRotate : MonoBehaviour
{
	// Token: 0x06000474 RID: 1140 RVA: 0x0001C115 File Offset: 0x0001A315
	public void VelocityMultiplierIntensity(float value)
	{
		this._velocityMultiplierIntensity = value;
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x0001C11E File Offset: 0x0001A31E
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x0001C127 File Offset: 0x0001A327
	public void RandomIntensity(float value)
	{
		this._randomIntensity = value;
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x0001C130 File Offset: 0x0001A330
	public void OnAudio(float audioVelocity)
	{
		float num = audioVelocity * this.velocityMultiplier * this._velocityMultiplierIntensity;
		if (this.random && this._randomIntensity >= 0.5f)
		{
			this.destination.x = Mathf.PerlinNoise(Time.realtimeSinceStartup * 1.5f, Time.realtimeSinceStartup * 3f) * this.velocity.x * num;
			this.destination.y = Mathf.PerlinNoise(Time.realtimeSinceStartup * 0.5f, Time.realtimeSinceStartup) * this.velocity.y * num;
			this.destination.z = Mathf.PerlinNoise(Time.realtimeSinceStartup * 0.3f, Time.realtimeSinceStartup * 2f) * this.velocity.z * num;
		}
		else
		{
			this.destination.x = this.velocity.x * num;
			this.destination.y = this.velocity.y * num;
			this.destination.z = this.velocity.z * num;
		}
		this.target.localRotation = Quaternion.Lerp(this.target.localRotation, Quaternion.Euler(this.destination), Time.deltaTime * this.speed * this._speedIntensity);
	}

	// Token: 0x04000528 RID: 1320
	public Transform target;

	// Token: 0x04000529 RID: 1321
	public Vector3 velocity;

	// Token: 0x0400052A RID: 1322
	public float velocityMultiplier = 1f;

	// Token: 0x0400052B RID: 1323
	protected float _velocityMultiplierIntensity = 1f;

	// Token: 0x0400052C RID: 1324
	public float speed = 1f;

	// Token: 0x0400052D RID: 1325
	protected float _speedIntensity = 1f;

	// Token: 0x0400052E RID: 1326
	public bool random = true;

	// Token: 0x0400052F RID: 1327
	protected float _randomIntensity = 1f;

	// Token: 0x04000530 RID: 1328
	private Vector3 destination;
}
