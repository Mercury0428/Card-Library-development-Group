﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Malee
{
	// Token: 0x02000228 RID: 552
	[Serializable]
	public abstract class ReorderableArray<T> : ICloneable, IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable
	{
		// Token: 0x0600111F RID: 4383 RVA: 0x0006379F File Offset: 0x0006199F
		public ReorderableArray() : this(0)
		{
		}

		// Token: 0x06001120 RID: 4384 RVA: 0x000637A8 File Offset: 0x000619A8
		public ReorderableArray(int length)
		{
			this.array = new List<T>(length);
		}

		// Token: 0x170002DA RID: 730
		public T this[int index]
		{
			get
			{
				return this.array[index];
			}
			set
			{
				this.array[index] = value;
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x06001123 RID: 4387 RVA: 0x000637E4 File Offset: 0x000619E4
		public int Length
		{
			get
			{
				return this.array.Count;
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x06001124 RID: 4388 RVA: 0x0000821B File Offset: 0x0000641B
		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06001125 RID: 4389 RVA: 0x000637E4 File Offset: 0x000619E4
		public int Count
		{
			get
			{
				return this.array.Count;
			}
		}

		// Token: 0x06001126 RID: 4390 RVA: 0x000637F1 File Offset: 0x000619F1
		public object Clone()
		{
			return new List<T>(this.array);
		}

		// Token: 0x06001127 RID: 4391 RVA: 0x000637FE File Offset: 0x000619FE
		public void CopyFrom(IEnumerable<T> value)
		{
			this.array.Clear();
			this.array.AddRange(value);
		}

		// Token: 0x06001128 RID: 4392 RVA: 0x00063817 File Offset: 0x00061A17
		public bool Contains(T value)
		{
			return this.array.Contains(value);
		}

		// Token: 0x06001129 RID: 4393 RVA: 0x00063825 File Offset: 0x00061A25
		public int IndexOf(T value)
		{
			return this.array.IndexOf(value);
		}

		// Token: 0x0600112A RID: 4394 RVA: 0x00063833 File Offset: 0x00061A33
		public void Insert(int index, T item)
		{
			this.array.Insert(index, item);
		}

		// Token: 0x0600112B RID: 4395 RVA: 0x00063842 File Offset: 0x00061A42
		public void RemoveAt(int index)
		{
			this.array.RemoveAt(index);
		}

		// Token: 0x0600112C RID: 4396 RVA: 0x00063850 File Offset: 0x00061A50
		public void Add(T item)
		{
			this.array.Add(item);
		}

		// Token: 0x0600112D RID: 4397 RVA: 0x0006385E File Offset: 0x00061A5E
		public void Clear()
		{
			this.array.Clear();
		}

		// Token: 0x0600112E RID: 4398 RVA: 0x0006386B File Offset: 0x00061A6B
		public void CopyTo(T[] array, int arrayIndex)
		{
			this.array.CopyTo(array, arrayIndex);
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x0006387A File Offset: 0x00061A7A
		public bool Remove(T item)
		{
			return this.array.Remove(item);
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x00063888 File Offset: 0x00061A88
		public T[] ToArray()
		{
			return this.array.ToArray();
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x00063895 File Offset: 0x00061A95
		public IEnumerator<T> GetEnumerator()
		{
			return this.array.GetEnumerator();
		}

		// Token: 0x06001132 RID: 4402 RVA: 0x00063895 File Offset: 0x00061A95
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.array.GetEnumerator();
		}

		// Token: 0x04000DB8 RID: 3512
		[SerializeField]
		private List<T> array = new List<T>();
	}
}
