﻿using System;
using UnityEngine;

namespace Malee
{
	// Token: 0x02000227 RID: 551
	public class ReorderableAttribute : PropertyAttribute
	{
		// Token: 0x06001119 RID: 4377 RVA: 0x00063720 File Offset: 0x00061920
		public ReorderableAttribute() : this(null)
		{
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x00063729 File Offset: 0x00061929
		public ReorderableAttribute(string elementNameProperty) : this(true, true, true, elementNameProperty, null, null)
		{
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x00063737 File Offset: 0x00061937
		public ReorderableAttribute(string elementNameProperty, string elementIconPath) : this(true, true, true, elementNameProperty, null, elementIconPath)
		{
		}

		// Token: 0x0600111C RID: 4380 RVA: 0x00063745 File Offset: 0x00061945
		public ReorderableAttribute(string elementNameProperty, string elementNameOverride, string elementIconPath) : this(true, true, true, elementNameProperty, elementNameOverride, elementIconPath)
		{
		}

		// Token: 0x0600111D RID: 4381 RVA: 0x00063753 File Offset: 0x00061953
		public ReorderableAttribute(bool add, bool remove, bool draggable, string elementNameProperty = null, string elementIconPath = null) : this(add, remove, draggable, elementNameProperty, null, elementIconPath)
		{
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x00063763 File Offset: 0x00061963
		public ReorderableAttribute(bool add, bool remove, bool draggable, string elementNameProperty = null, string elementNameOverride = null, string elementIconPath = null)
		{
			this.add = add;
			this.remove = remove;
			this.draggable = draggable;
			this.sortable = true;
			this.elementNameProperty = elementNameProperty;
			this.elementNameOverride = elementNameOverride;
			this.elementIconPath = elementIconPath;
		}

		// Token: 0x04000DAE RID: 3502
		public bool add;

		// Token: 0x04000DAF RID: 3503
		public bool remove;

		// Token: 0x04000DB0 RID: 3504
		public bool draggable;

		// Token: 0x04000DB1 RID: 3505
		public bool singleLine;

		// Token: 0x04000DB2 RID: 3506
		public bool paginate;

		// Token: 0x04000DB3 RID: 3507
		public bool sortable;

		// Token: 0x04000DB4 RID: 3508
		public int pageSize;

		// Token: 0x04000DB5 RID: 3509
		public string elementNameProperty;

		// Token: 0x04000DB6 RID: 3510
		public string elementNameOverride;

		// Token: 0x04000DB7 RID: 3511
		public string elementIconPath;
	}
}
