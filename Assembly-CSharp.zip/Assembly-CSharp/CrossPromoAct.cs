﻿using System;
using System.Collections;
using System.Collections.Generic;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000005 RID: 5
public class CrossPromoAct : MonoBehaviour
{
	// Token: 0x06000011 RID: 17 RVA: 0x00002984 File Offset: 0x00000B84
	private void Start()
	{
		this.mytrans = base.GetComponent<RectTransform>();
		this.but = base.GetComponent<Button>();
		GameAct diff = GameAct.diff;
		diff.OnReignEnd = (Action)Delegate.Combine(diff.OnReignEnd, new Action(this.CheckRTC));
	}

	// Token: 0x06000012 RID: 18 RVA: 0x000029C4 File Offset: 0x00000BC4
	private void OnApplicationQuit()
	{
		PlayerPrefs.DeleteKey("seenpromoRTC");
	}

	// Token: 0x06000013 RID: 19 RVA: 0x000029D0 File Offset: 0x00000BD0
	private void CheckRTC()
	{
		int month = DateTime.Now.Month;
		int day = DateTime.Now.Day;
		if (month == 9 || (month == 8 && day > 28))
		{
			if (GameAct.diff.GetInt(Variables.dynasty) % 12 != 1)
			{
				return;
			}
			base.StopCoroutine("Alternate");
			if (PlayerPrefs.HasKey("seenpromoRTC"))
			{
				this.ShowIcon();
			}
			else
			{
				this.ShowFull();
			}
			PlayerPrefs.SetInt("seenpromoRTC", 1);
			this.txt.text = ((SpeechAct.diff.lang == "fr") ? "REIGNEZ POUR DE VRAI SUR KICKSTARTER!" : ((SpeechAct.diff.lang == "de") ? "HERRSZCHE WIRKLICH AUF KICKSTARTER!" : "RULE FOR REAL!\nNOW ON KICKSTARTER"));
		}
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002A9C File Offset: 0x00000C9C
	private void CheckPromo()
	{
		this.promos.RemoveAll((Crosspromo it) => PlayerPrefs.HasKey("promo" + it.name));
		if (this.selfpromo == null)
		{
			return;
		}
		if (!this.isGe)
		{
			List<Crosspromo> collection = new List<Crosspromo>(this.promos);
			this.promos = new List<Crosspromo>
			{
				this.selfpromo
			};
			this.promos.AddRange(collection);
			this.selfpromo.start = 5;
			this.selfpromo.recurrence = 3;
		}
		if (this.promos.Count == 0)
		{
			return;
		}
		int @int = GameAct.diff.GetInt(Variables.dynasty);
		if (@int < this.selfpromo.start || (@int - this.selfpromo.start) % this.selfpromo.recurrence != 1)
		{
			return;
		}
		this.curpromo = this.promos[0];
		this.promos.Remove(this.curpromo);
		this.promos.Add(this.curpromo);
		this.icon.sprite = this.curpromo.promoSprite;
		base.StopCoroutine("Alternate");
		if (PlayerPrefs.HasKey("seenpromo" + this.curpromo.name))
		{
			this.ShowIcon();
			PlayerPrefs.SetInt("promo" + this.curpromo.name, 1);
		}
		else
		{
			this.ShowFull();
		}
		PlayerPrefs.SetInt("seenpromo" + this.curpromo.name, 1);
		this.txt.text = this.curpromo.fullPromoText;
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002C3E File Offset: 0x00000E3E
	private IEnumerator AlternatePi()
	{
		string altt = SpeechAct.diff.GetSceneText("likeit0");
		string t = SpeechAct.diff.GetSceneText("likeit1");
		WaitForSeconds swait = new WaitForSeconds(0.5f);
		WaitForSeconds lwait = new WaitForSeconds(4f);
		for (;;)
		{
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return swait;
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return swait;
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return lwait;
		}
		yield break;
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00002C4D File Offset: 0x00000E4D
	private IEnumerator Alternate(string t)
	{
		string altt = this.curpromo.fullPromoText;
		WaitForSeconds swait = new WaitForSeconds(0.5f);
		WaitForSeconds lwait = new WaitForSeconds(4f);
		for (;;)
		{
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return swait;
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return swait;
			this.txt.text = altt;
			yield return swait;
			this.txt.text = t;
			yield return lwait;
		}
		yield break;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00002C63 File Offset: 0x00000E63
	private void UncheckPromo(GameStates state)
	{
		this.HideGroup();
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002C6B File Offset: 0x00000E6B
	private void HideGroup()
	{
		this.StopMove();
		base.StartCoroutine("DoHideGroup");
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00002C7F File Offset: 0x00000E7F
	private void StopMove()
	{
		base.StopCoroutine("DoHideGroup");
		base.StopCoroutine("DoShowIcon");
		base.StopCoroutine("DoShowFull");
		base.StopCoroutine("MoveGroup");
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002CAD File Offset: 0x00000EAD
	private IEnumerator DoHideGroup()
	{
		this.isFull = false;
		this.curpromo = null;
		yield return base.StartCoroutine("MoveGroup", this.hiddenPos);
		this.txt.enabled = false;
		this.icon.enabled = false;
		this.but.enabled = false;
		yield break;
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002CBC File Offset: 0x00000EBC
	private void ShowIcon()
	{
		this.StopMove();
		base.StartCoroutine("DoShowIcon");
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002CD0 File Offset: 0x00000ED0
	private IEnumerator DoShowIcon()
	{
		this.txt.enabled = true;
		this.icon.enabled = true;
		this.but.enabled = true;
		yield return base.StartCoroutine("MoveGroup", this.iconPos);
		this.isFull = false;
		yield return new WaitForSeconds(4f);
		this.HideGroup();
		yield break;
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002CDF File Offset: 0x00000EDF
	private void ShowFull()
	{
		this.StopMove();
		base.StartCoroutine("DoShowFull");
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00002CF3 File Offset: 0x00000EF3
	private IEnumerator DoShowFull()
	{
		this.txt.enabled = true;
		this.icon.enabled = true;
		this.but.enabled = true;
		yield return base.StartCoroutine("MoveGroup", this.fullPos);
		this.isFull = true;
		yield return new WaitForSeconds(6f);
		this.ShowIcon();
		yield break;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00002D02 File Offset: 0x00000F02
	private IEnumerator MoveGroup(int targ)
	{
		float t = 0f;
		Vector2 tpos = new Vector2((float)targ, (float)this.ypos);
		while (t < 1f)
		{
			this.mytrans.anchoredPosition = Vector2.Lerp(this.mytrans.anchoredPosition, tpos, Time.deltaTime * 4f);
			t += Time.deltaTime;
			yield return null;
		}
		this.mytrans.anchoredPosition = tpos;
		yield break;
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002D18 File Offset: 0x00000F18
	public void OpenRtc()
	{
		if (!this.isFull)
		{
			this.ShowFull();
			return;
		}
		PlayerPrefs.SetInt("seenpromoRTC", 1);
		this.HideGroup();
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002D3C File Offset: 0x00000F3C
	public void OpenFirstUrl()
	{
		if (this.promos.Count > 0)
		{
			this.Open(this.promos[0]);
		}
		else
		{
			Application.OpenURL("https://reignsgame.com");
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000022 RID: 34 RVA: 0x00002D94 File Offset: 0x00000F94
	private void Open(Crosspromo promo)
	{
		if (string.IsNullOrEmpty(promo.steamCode))
		{
			SteamFriends.ActivateGameOverlayToWebPage("http://" + promo.mainUrl);
		}
		else
		{
			uint value = 717640U;
			uint.TryParse(promo.steamCode, out value);
			SteamFriends.ActivateGameOverlayToStore(new AppId_t(value), EOverlayToStoreFlag.k_EOverlayToStoreFlag_None);
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00002E04 File Offset: 0x00001004
	public void OpenUrl()
	{
		if (this.curpromo == null)
		{
			return;
		}
		if (!this.isFull)
		{
			this.ShowFull();
			return;
		}
		this.Open(this.curpromo);
		PlayerPrefs.SetInt("promo" + this.curpromo.name, 1);
		this.promos.Remove(this.curpromo);
		this.HideGroup();
	}

	// Token: 0x06000024 RID: 36 RVA: 0x00002E68 File Offset: 0x00001068
	private void CheckServerUpdates()
	{
		base.StopCoroutine("CheckServer");
		base.StartCoroutine("CheckServer");
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002E81 File Offset: 0x00001081
	private IEnumerator CheckGe()
	{
		while (!Application.genuineCheckAvailable)
		{
			yield return new WaitForSeconds(3f);
		}
		this.isGe = Application.genuine;
		yield break;
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002E90 File Offset: 0x00001090
	private IEnumerator CheckServer()
	{
		yield return 0;
		yield return new WaitForSeconds(1f);
		string textFile = Util.GetTextFile("texts/source");
		if (textFile.Contains("http://") || textFile.Contains("https://") || textFile.Contains("\\"))
		{
			yield break;
		}
		string[] array = textFile.Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(new char[]
		{
			';'
		});
		for (int i = 1; i < array.Length; i++)
		{
			Crosspromo newcross = new Crosspromo();
			string[] array3 = array[i].Split(new char[]
			{
				';'
			});
			int j = 0;
			while (j < array3.Length)
			{
				string text = array3[j];
				string text2 = array2[j];
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
				if (num <= 1697318111U)
				{
					if (num != 326936281U)
					{
						if (num != 720132575U)
						{
							if (num != 1697318111U)
							{
								goto IL_2EC;
							}
							if (!(text2 == "start"))
							{
								goto IL_2EC;
							}
							int.TryParse(text, out newcross.start);
							if (newcross.start == 0)
							{
								newcross.start = 25;
							}
						}
						else
						{
							if (!(text2 == "recurrence"))
							{
								goto IL_2EC;
							}
							int.TryParse(text, out newcross.recurrence);
							if (newcross.recurrence == 0)
							{
								newcross.recurrence = 13;
							}
						}
					}
					else
					{
						if (!(text2 == "mainUrl"))
						{
							goto IL_2EC;
						}
						newcross.mainUrl = text;
					}
				}
				else if (num <= 2369371622U)
				{
					if (num != 2271867675U)
					{
						if (num != 2369371622U)
						{
							goto IL_2EC;
						}
						if (!(text2 == "name"))
						{
							goto IL_2EC;
						}
						newcross.name = text;
						newcross.promoSprite = (Sprite)Resources.Load(text, typeof(Sprite));
					}
					else
					{
						if (!(text2 == "andCode"))
						{
							goto IL_2EC;
						}
						newcross.andCode = text;
					}
				}
				else if (num != 3130007370U)
				{
					if (num != 4240195419U)
					{
						goto IL_2EC;
					}
					if (!(text2 == "iosCode"))
					{
						goto IL_2EC;
					}
					newcross.iosCode = text;
				}
				else
				{
					if (!(text2 == "steamCode"))
					{
						goto IL_2EC;
					}
					newcross.steamCode = text;
				}
				IL_310:
				j++;
				continue;
				IL_2EC:
				if (array2[j] == SpeechAct.diff.lang)
				{
					newcross.fullPromoText = text;
					goto IL_310;
				}
				goto IL_310;
			}
			Crosspromo crosspromo = this.promos.Find((Crosspromo it) => it.name == newcross.name);
			if (crosspromo != null)
			{
				this.promos.Remove(crosspromo);
				this.promos.Add(newcross);
			}
			else if (newcross.name == this.gameName)
			{
				this.selfpromo = newcross;
			}
			else
			{
				this.promos.Add(newcross);
			}
		}
		this.CheckPromo();
		yield break;
	}

	// Token: 0x04000024 RID: 36
	public string gameName;

	// Token: 0x04000025 RID: 37
	public Image icon;

	// Token: 0x04000026 RID: 38
	public Text txt;

	// Token: 0x04000027 RID: 39
	public List<Crosspromo> promos;

	// Token: 0x04000028 RID: 40
	private int hiddenPos = 160;

	// Token: 0x04000029 RID: 41
	private int iconPos = 50;

	// Token: 0x0400002A RID: 42
	private int fullPos = -100;

	// Token: 0x0400002B RID: 43
	private int ypos = -140;

	// Token: 0x0400002C RID: 44
	private RectTransform mytrans;

	// Token: 0x0400002D RID: 45
	private Crosspromo curpromo;

	// Token: 0x0400002E RID: 46
	public Crosspromo selfpromo;

	// Token: 0x0400002F RID: 47
	private Button but;

	// Token: 0x04000030 RID: 48
	private bool isGe = true;

	// Token: 0x04000031 RID: 49
	private bool isFull;
}
