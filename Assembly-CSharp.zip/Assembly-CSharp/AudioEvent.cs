﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

// Token: 0x02000086 RID: 134
public class AudioEvent : MonoBehaviour
{
	// Token: 0x17000010 RID: 16
	// (get) Token: 0x0600046A RID: 1130 RVA: 0x0001BDA1 File Offset: 0x00019FA1
	// (set) Token: 0x0600046B RID: 1131 RVA: 0x0001BDA9 File Offset: 0x00019FA9
	public AudioEvent.TriggerEvent onAudio
	{
		get
		{
			return this.m_onAudio;
		}
		set
		{
			this.m_onAudio = value;
		}
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x0001BDB4 File Offset: 0x00019FB4
	private void Update()
	{
		int resolution = AudioSpectrum.Instance.resolution;
		int num = Mathf.Clamp(Mathf.RoundToInt(this.spectrumStart * (float)resolution) - Mathf.RoundToInt((float)resolution * 0.5f), 0, resolution - 1);
		int end = Mathf.Clamp(num + Mathf.RoundToInt((float)resolution * this.spectrumLength), 0, resolution - 1);
		float num2;
		if (this.stereoPan == 0f)
		{
			num2 = this.GetVelocity(AudioSpectrum.Instance.leftChannel, num, end, this.spectrumFalloff);
		}
		else if (this.stereoPan == 1f)
		{
			num2 = this.GetVelocity(AudioSpectrum.Instance.rightChannel, num, end, this.spectrumFalloff);
		}
		else
		{
			num2 = Mathf.Lerp(this.GetVelocity(AudioSpectrum.Instance.leftChannel, num, end, this.spectrumFalloff), this.GetVelocity(AudioSpectrum.Instance.leftChannel, num, end, this.spectrumFalloff), this.stereoPan);
		}
		this.onAudio.Invoke(num2 * this.amplifier);
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x0001BEAC File Offset: 0x0001A0AC
	private float GetVelocity(float[] channel, int start, int end, AnimationCurve falloff)
	{
		if (start == end)
		{
			return 0f;
		}
		float num = 0f;
		float num2 = (float)(end - start);
		float num3 = 0f;
		for (int i = start; i < end; i++)
		{
			float time = num3 / num2;
			num += channel[i] * falloff.Evaluate(time);
			num3 += 1f;
		}
		return num / num2;
	}

	// Token: 0x04000519 RID: 1305
	[Range(0f, 1f)]
	public float spectrumStart = 0.5f;

	// Token: 0x0400051A RID: 1306
	[Range(0f, 1f)]
	public float spectrumLength = 0.25f;

	// Token: 0x0400051B RID: 1307
	[Range(0f, 1f)]
	public float stereoPan = 0.5f;

	// Token: 0x0400051C RID: 1308
	public AnimationCurve spectrumFalloff = new AnimationCurve(new Keyframe[]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.5f, 1f),
		new Keyframe(1f, 0f)
	});

	// Token: 0x0400051D RID: 1309
	public float amplifier = 1f;

	// Token: 0x0400051E RID: 1310
	[FormerlySerializedAs("onAudio")]
	[SerializeField]
	protected AudioEvent.TriggerEvent m_onAudio = new AudioEvent.TriggerEvent();

	// Token: 0x0200031F RID: 799
	[Serializable]
	public class TriggerEvent : UnityEvent<float>
	{
	}
}
