﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200006C RID: 108
public class ObjectiveAct : MonoBehaviour
{
	// Token: 0x060003C3 RID: 963 RVA: 0x000182AC File Offset: 0x000164AC
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnLoad = (Action<Game>)Delegate.Combine(diff.OnLoad, new Action<Game>(this.LoadObjectives));
		GameAct diff2 = GameAct.diff;
		diff2.OnSave = (Action<Game>)Delegate.Combine(diff2.OnSave, new Action<Game>(this.SaveObjectives));
		GameAct diff3 = GameAct.diff;
		diff3.OnInit = (Action)Delegate.Combine(diff3.OnInit, new Action(this.InitObjectives));
		GameAct diff4 = GameAct.diff;
		diff4.OnUpdate = (Action<Card>)Delegate.Combine(diff4.OnUpdate, new Action<Card>(this.CheckObjectives));
		GameAct diff5 = GameAct.diff;
		diff5.OnUpdateCards = (Action)Delegate.Combine(diff5.OnUpdateCards, new Action(this.UpdatAllObjectives));
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x00018378 File Offset: 0x00016578
	public Objective GetObjective(string id)
	{
		return this.objectives.Find((Objective it) => it.name == id);
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x000183AC File Offset: 0x000165AC
	public List<Objective> GetObjectives(bool nostatechange = false)
	{
		Dictionary<string, string[]> languageStrings = this.GetLanguageStrings();
		List<Objective> list = new List<Objective>();
		string[] array = CardReader.diff.GetTempText("objectives").Split(new char[]
		{
			'\n'
		});
		string[] columns = array[0].Split(this.dele, StringSplitOptions.RemoveEmptyEntries);
		for (int i = 1; i < array.Length; i++)
		{
			list.Add(new Objective(array[i].Split(this.dele), columns, list, i, languageStrings, nostatechange));
		}
		return list;
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x0001842C File Offset: 0x0001662C
	private Dictionary<string, string[]> GetLanguageStrings()
	{
		string lang = SpeechAct.diff.lang;
		if (lang == "en")
		{
			return new Dictionary<string, string[]>();
		}
		Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
		string[] array = Util.GetTextFile("texts/objectives_i18n").Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(this.dele);
		for (int i = 1; i < array.Length; i++)
		{
			string[] array3 = array[i].Split(this.dele);
			string[] array4 = new string[3];
			string key = "";
			for (int j = 0; j < array2.Length; j++)
			{
				string a = array2[j];
				if (a == "name")
				{
					key = array3[j];
				}
				else if (a == lang + "_title")
				{
					array4[0] = array3[j];
				}
				else if (a == lang + "_description")
				{
					array4[1] = array3[j];
				}
				else if (a == lang + "_achievement")
				{
					array4[2] = array3[j];
				}
			}
			dictionary.Add(key, array4);
		}
		return dictionary;
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x00018558 File Offset: 0x00016758
	private void UpdatAllObjectives()
	{
		List<Objective> newobjs = this.GetObjectives(true);
		using (List<Objective>.Enumerator enumerator = newobjs.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Objective nob = enumerator.Current;
				Objective objective = this.objectives.Find((Objective it) => it.id == nob.id);
				if (objective == null)
				{
					this.objectives.Add(nob);
				}
				else
				{
					objective.achievement = nob.achievement;
					objective.conditions = nob.conditions;
					objective.description = nob.description;
					objective.name = nob.name;
					objective.title = nob.title;
					objective.pid = nob.pid;
				}
			}
		}
		this.objectives.RemoveAll((Objective it) => newobjs.Find((Objective yt) => yt.id == it.id) == null);
		this.UpdateActives();
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x0001867C File Offset: 0x0001687C
	private void SaveObjectives(Game save)
	{
		save.objectives = this.objectives;
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x0001868A File Offset: 0x0001688A
	private void LoadObjectives(Game save)
	{
		this.objectives = save.objectives;
		this.UpdateActives();
	}

	// Token: 0x060003CA RID: 970 RVA: 0x0001869E File Offset: 0x0001689E
	private void InitObjectives()
	{
		this.objectives = this.GetObjectives(false);
		this.UpdateActives();
		this.firstobjective.visible = true;
	}

	// Token: 0x060003CB RID: 971 RVA: 0x000186C0 File Offset: 0x000168C0
	private void UpdateActives()
	{
		this.firstobjective = this.objectives[0];
		int num = 0;
		this.list1 = new List<Objective>();
		this.list2 = new List<Objective>();
		this.list3 = new List<Objective>();
		foreach (Objective objective in this.objectives)
		{
			if (objective.pid == 1)
			{
				num++;
			}
			switch (num)
			{
			case 1:
				this.list1.Add(objective);
				break;
			case 2:
				this.list2.Add(objective);
				break;
			case 3:
				this.list3.Add(objective);
				break;
			}
		}
	}

	// Token: 0x060003CC RID: 972 RVA: 0x0001878C File Offset: 0x0001698C
	private void CheckObjectives(Card card)
	{
		using (List<Objective>.Enumerator enumerator = this.objectives.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Objective obj = enumerator.Current;
				if (GameAct.diff.TestCond(obj.conditions) && !obj.fulfilled)
				{
					obj.fulfilled = true;
					ObjectiveBox objectiveBox = this.objBoxes.Find((ObjectiveBox it) => it.obj.name == obj.name);
					if (objectiveBox != null)
					{
						objectiveBox.Validate();
					}
					GameAct.diff.PlayModal(ModalTypes.objective, obj, 3f, "", true);
					if (!string.IsNullOrEmpty(obj.achievement))
					{
						GameAct.diff.PlayModal(ModalTypes.custom, this.newcardsPrefab, 3f, obj.achievement, true);
					}
					if (this.OnNewObjective != null)
					{
						this.OnNewObjective();
					}
					base.GetComponent<KingdomAct>().AddAchieve(obj.name, AchieveTypes.objective);
				}
			}
		}
	}

	// Token: 0x060003CD RID: 973 RVA: 0x000188C4 File Offset: 0x00016AC4
	private void UnlockCards(List<Condition> conds)
	{
		foreach (Condition condition in conds)
		{
			if ((condition.value > 0 && condition.bearer == Bearers.none) || (condition.value == 0 && condition.bearer != Bearers.none && condition.condition == Conditions.equal))
			{
				GameAct.diff.LockCards(condition, false);
			}
			if ((condition.value == -1 && condition.bearer == Bearers.none && condition.condition == Conditions.equal) || (condition.value == 0 && condition.bearer != Bearers.none && condition.condition == Conditions.notequal))
			{
				GameAct.diff.LockCardsOutcome(condition, false);
			}
		}
	}

	// Token: 0x060003CE RID: 974 RVA: 0x0001899C File Offset: 0x00016B9C
	private List<Objective> GetNew()
	{
		List<Objective> list = new List<Objective>();
		Objective objective = this.list1.Find((Objective it) => !it.fulfilled);
		if (objective != null && !objective.visible)
		{
			list.Add(objective);
		}
		Objective objective2 = this.list2.Find((Objective it) => !it.fulfilled);
		if (objective2 != null && !objective2.visible)
		{
			list.Add(objective2);
		}
		Objective objective3 = this.list3.Find((Objective it) => !it.fulfilled);
		if (objective3 != null && !objective3.visible)
		{
			list.Add(objective3);
		}
		foreach (Objective objective4 in list)
		{
			objective4.visible = true;
			this.UnlockCards(objective4.conditions);
		}
		return list;
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00018AB8 File Offset: 0x00016CB8
	public List<Objective> GetDisplayed()
	{
		if (this.firstobjective.visible)
		{
			return new List<Objective>
			{
				this.firstobjective
			};
		}
		List<Objective> list = new List<Objective>();
		Objective objective = this.list1.Find((Objective it) => it.visible);
		if (objective != null)
		{
			list.Add(objective);
		}
		Objective objective2 = this.list2.Find((Objective it) => it.visible);
		if (objective2 != null)
		{
			list.Add(objective2);
		}
		Objective objective3 = this.list3.Find((Objective it) => it.visible);
		if (objective3 != null)
		{
			list.Add(objective3);
		}
		foreach (Objective objective4 in list)
		{
			if (!objective4.fulfilled)
			{
				this.UnlockCards(objective4.conditions);
			}
		}
		return list;
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x00018BDC File Offset: 0x00016DDC
	public List<Objective> GetFulfilled()
	{
		List<Objective> list = new List<Objective>();
		if (this.firstobjective.fulfilled)
		{
			list.Add(this.firstobjective);
			list.AddRange(this.list1.FindAll((Objective it) => it.fulfilled));
			list.AddRange(this.list2.FindAll((Objective it) => it.fulfilled));
			list.AddRange(this.list3.FindAll((Objective it) => it.fulfilled));
			return list;
		}
		return list;
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x00018C9D File Offset: 0x00016E9D
	public List<Objective> GetAll()
	{
		return new List<Objective>(this.objectives);
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x00018CAA File Offset: 0x00016EAA
	public void ShowObjectives(Transform par, int cstpos, bool replace = true, bool thenupdate = false, float timer = 2f)
	{
		base.StopAllCoroutines();
		base.StartCoroutine(this.DoShowObjectives(par, cstpos, thenupdate, timer, replace));
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x00018CC6 File Offset: 0x00016EC6
	private IEnumerator DoShowObjectives(Transform par, int cstpos, bool thenupdate, float timer, bool replace)
	{
		if (replace)
		{
			this.DestroyBoxes();
		}
		this.displayedObj = this.GetDisplayed();
		int i = 0;
		if (replace)
		{
			this.objBoxes = new List<ObjectiveBox>();
		}
		WaitForSeconds swait = new WaitForSeconds(0.3f);
		foreach (Objective objective in this.displayedObj)
		{
			ObjectiveBox objectiveBox = this.InstantiateBox(objective, par, replace);
			objectiveBox.name = objective.name;
			objectiveBox.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, (float)(cstpos - 240 - 10 * i));
			base.StartCoroutine(this.ReposObj(objectiveBox, new Vector2(0f, (float)(cstpos + this.displayedObj.Count * 15 - 30 * i))));
			int num = i;
			i = num + 1;
			yield return swait;
		}
		List<Objective>.Enumerator enumerator = default(List<Objective>.Enumerator);
		yield return new WaitForSeconds(timer);
		if (thenupdate)
		{
			yield return base.StartCoroutine(this.DoHideAssigned(par, cstpos));
		}
		yield break;
		yield break;
	}

	// Token: 0x060003D4 RID: 980 RVA: 0x00018CFC File Offset: 0x00016EFC
	private ObjectiveBox InstantiateBox(Objective obj, Transform par, bool replace = true)
	{
		GameObject gameObject = Object.Instantiate<GameObject>(this.objectBoxPrefab);
		gameObject.transform.SetParent(par, false);
		ObjectiveBox component = gameObject.GetComponent<ObjectiveBox>();
		if (replace)
		{
			this.objBoxes.Add(component);
		}
		bool fulfilled = obj.fulfilled;
		component.Init(obj, "", fulfilled, false);
		return component;
	}

	// Token: 0x060003D5 RID: 981 RVA: 0x00018D4C File Offset: 0x00016F4C
	public void HideAssignedAndAdd(Transform par, int cstpos)
	{
		base.StartCoroutine(this.DoHideAssigned(par, cstpos));
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x00018D5D File Offset: 0x00016F5D
	private IEnumerator DoHideAssigned(Transform par, int cstpos)
	{
		int max = this.displayedObj.Count;
		int num;
		for (int i = 0; i < this.displayedObj.Count; i = num + 1)
		{
			if (this.displayedObj[i].fulfilled)
			{
				this.displayedObj[i].visible = false;
				num = max;
				max = num - 1;
				if (!this.objBoxes[i].isActiveAndEnabled)
				{
					yield break;
				}
				this.objBoxes[i].HideRight();
				JukeBox.diff.PlaySound(SFXTypes.ui_achievement_completed, false, false, 2.5f, -1, 1.5f, 1f);
				HapticAct.diff.Tap(iOSHapticFeedback.iOSFeedbackType.Success);
				yield return new WaitForSeconds(0.25f - (float)i * 0.06f);
			}
			num = i;
		}
		List<Objective> newob = this.GetNew();
		max += newob.Count;
		int j = 0;
		WaitForSeconds swait = new WaitForSeconds(0.3f);
		for (int i = 0; i < this.objBoxes.Count; i = num + 1)
		{
			if (this.displayedObj[i].visible)
			{
				if (this.objBoxes[i] == null)
				{
					yield break;
				}
				base.StartCoroutine(this.ReposObj(this.objBoxes[i], new Vector2(0f, (float)(cstpos + max * 15 - 30 * j))));
				num = j;
				j = num + 1;
				yield return swait;
			}
			num = i;
		}
		foreach (Objective obj in newob)
		{
			ObjectiveBox objectiveBox = this.InstantiateBox(obj, par, true);
			objectiveBox.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, (float)(cstpos - 240 - 10 * j));
			base.StartCoroutine(this.ReposObj(objectiveBox, new Vector2(0f, (float)(cstpos + max * 15 - 30 * j))));
			num = j;
			j = num + 1;
			yield return swait;
		}
		List<Objective>.Enumerator enumerator = default(List<Objective>.Enumerator);
		yield break;
		yield break;
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x00018D7A File Offset: 0x00016F7A
	private IEnumerator ReposObj(ObjectiveBox obj, Vector2 tpos)
	{
		float t = 0f;
		if (obj == null)
		{
			yield break;
		}
		RectTransform rect = obj.GetComponent<RectTransform>();
		while (t < 1f)
		{
			if (rect == null)
			{
				yield break;
			}
			rect.anchoredPosition = Vector2.Lerp(rect.anchoredPosition, tpos, 0.4f + t);
			t += Time.deltaTime * 2f;
			yield return null;
		}
		yield break;
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x00018D90 File Offset: 0x00016F90
	public void DestroyBoxes()
	{
		foreach (ObjectiveBox objectiveBox in this.objBoxes)
		{
			if (objectiveBox)
			{
				Object.Destroy(objectiveBox.gameObject);
			}
		}
	}

	// Token: 0x040004A7 RID: 1191
	public Objective firstobjective;

	// Token: 0x040004A8 RID: 1192
	public List<Objective> list1 = new List<Objective>();

	// Token: 0x040004A9 RID: 1193
	public List<Objective> list2 = new List<Objective>();

	// Token: 0x040004AA RID: 1194
	public List<Objective> list3 = new List<Objective>();

	// Token: 0x040004AB RID: 1195
	private char[] dele = new char[]
	{
		';'
	};

	// Token: 0x040004AC RID: 1196
	public List<Objective> objectives;

	// Token: 0x040004AD RID: 1197
	public List<Objective> objectivesActive = new List<Objective>();

	// Token: 0x040004AE RID: 1198
	private List<Objective> displayedObj = new List<Objective>();

	// Token: 0x040004AF RID: 1199
	private List<ObjectiveBox> objBoxes = new List<ObjectiveBox>();

	// Token: 0x040004B0 RID: 1200
	private List<bool> objTypes = new List<bool>();

	// Token: 0x040004B1 RID: 1201
	public GameObject objectBoxPrefab;

	// Token: 0x040004B2 RID: 1202
	public GameObject newcardsPrefab;

	// Token: 0x040004B3 RID: 1203
	public Action OnNewObjective;
}
