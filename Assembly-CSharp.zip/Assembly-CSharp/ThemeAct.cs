﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class ThemeAct : MonoBehaviour
{
	// Token: 0x060004BD RID: 1213 RVA: 0x0001D28B File Offset: 0x0001B48B
	private void Awake()
	{
		if (ThemeAct.diff != null)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		Object.DontDestroyOnLoad(base.gameObject);
		ThemeAct.diff = this;
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x0001D2B7 File Offset: 0x0001B4B7
	public void Play()
	{
		base.GetComponent<AudioSource>().Play();
		base.StartCoroutine("YieldStop");
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x0001D2D0 File Offset: 0x0001B4D0
	private IEnumerator YieldStop()
	{
		yield return new WaitForSeconds(base.GetComponent<AudioSource>().clip.length + 2f);
		ThemeAct.diff = null;
		yield return 0;
		JukeBox.diff.PlayMusic(Bearers.none, false);
		Object.Destroy(base.gameObject);
		yield break;
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x0001D2DF File Offset: 0x0001B4DF
	public void Stop()
	{
		base.StopAllCoroutines();
		base.GetComponent<AudioSource>().Stop();
		Object.Destroy(base.gameObject);
		ThemeAct.diff = null;
	}

	// Token: 0x0400056F RID: 1391
	public static ThemeAct diff;
}
