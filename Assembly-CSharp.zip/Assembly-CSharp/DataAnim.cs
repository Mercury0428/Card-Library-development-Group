﻿using System;
using System.Collections;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200003A RID: 58
public class DataAnim : MonoBehaviour
{
	// Token: 0x060001B6 RID: 438 RVA: 0x0000B494 File Offset: 0x00009694
	private void Awake()
	{
		this.addTrans = this.add.rectTransform;
		this.SwitchGauge(true);
		this.SetData(50);
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x0000B4B6 File Offset: 0x000096B6
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnStart = (Action<GameStates>)Delegate.Combine(diff.OnStart, new Action<GameStates>(this.HideDanger));
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x0000B4DE File Offset: 0x000096DE
	public void Init(Variables va, int amount = 50)
	{
		this.variable = va;
		this.SetData(amount);
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x0000B4F0 File Offset: 0x000096F0
	public void SetWinter(bool ison)
	{
		this.winter = ison;
		this.jaugeCol = (this.winter ? this.winterCol : this.normCol);
		this.CrossFadeColor(this.gaugeGra, this.jaugeCol, 0.5f, false);
		this.arrow.color = this.jaugeCol;
	}

	// Token: 0x060001BA RID: 442 RVA: 0x0000B54C File Offset: 0x0000974C
	public void ShowDataCol(bool yes)
	{
		this.isShown = yes;
		float t = yes ? 0.3f : 0.01f;
		this.jaugeCol = (yes ? (this.winter ? this.winterCol : this.normCol) : this.lockCol);
		this.maskCol = (yes ? this.normMaskCol : this.lockCol);
		this.gaugeGra.enabled = yes;
		this.CrossFadeColor(this.mask, this.maskCol, t, true);
		this.CrossFadeColor(this.gaugeGra, this.jaugeCol, t, true);
	}

	// Token: 0x060001BB RID: 443 RVA: 0x0000B5E8 File Offset: 0x000097E8
	private void CrossFadeColor(Graphic target, Color tcol, float t, bool accentonorigin = true)
	{
		base.StartCoroutine(this.DoCrossFade(target, tcol, t, accentonorigin));
	}

	// Token: 0x060001BC RID: 444 RVA: 0x0000B5FC File Offset: 0x000097FC
	private IEnumerator DoCrossFade(Graphic target, Color tcol, float totaltime, bool intro)
	{
		float t = 0f;
		Color ocol = target.color;
		while (t < 1f)
		{
			float t2 = intro ? Easing.CubicEaseIn(t, 0f, 1f, 1f) : Easing.CubicEaseOut(t, 0f, 1f, 1f);
			target.color = Color.Lerp(ocol, tcol, t2);
			t += Time.deltaTime / totaltime;
			yield return 0;
		}
		target.color = tcol;
		yield break;
	}

	// Token: 0x060001BD RID: 445 RVA: 0x0000B624 File Offset: 0x00009824
	public void SwitchGauge(bool doit = true)
	{
		if (!doit)
		{
			this.isGauge = false;
			this.arrow.enabled = (this.skull.enabled = false);
			this.amount.enabled = (this.add.enabled = true);
			return;
		}
		this.isGauge = true;
		this.arrow.enabled = (this.skull.enabled = true);
		this.amount.enabled = (this.add.enabled = false);
		this.gaugeGra = this.gauge.GetComponent<Graphic>();
	}

	// Token: 0x060001BE RID: 446 RVA: 0x0000B6BC File Offset: 0x000098BC
	public void SetData(int value)
	{
		this.dataShown = value;
		this.dataReal = value;
		this.UpdateAmount();
	}

	// Token: 0x060001BF RID: 447 RVA: 0x0000B6DF File Offset: 0x000098DF
	public void UnLock()
	{
		this.isLock = false;
		this.mask.gameObject.SetActive(true);
		this.UpdateAmount();
		this.lockIcon.enabled = false;
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x0000B70C File Offset: 0x0000990C
	public void Lock()
	{
		if (!this.addTrans)
		{
			this.Awake();
		}
		this.isLock = true;
		this.mask.gameObject.SetActive(false);
		this.lockIcon.enabled = true;
		if (this.isMoving)
		{
			this.moveIcon.enabled = false;
		}
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x0000B764 File Offset: 0x00009964
	public void SetAdd(int value, DataDisplay effect = DataDisplay.none, int strength = 0)
	{
		this.SetData(this.dataReal);
		if (!base.gameObject.activeSelf)
		{
			return;
		}
		value = ((effect == DataDisplay.fullamount) ? (value - this.dataReal) : ((effect == DataDisplay.towards && this.dataReal > 50) ? this.SumUp(this.dataReal, -value * strength) : this.SumUp(this.dataReal, value * strength)));
		if (value == 0 || this.isLock)
		{
			this.addReal = 0;
			this.HideAdd();
			return;
		}
		this.ShowAdd();
		switch (effect)
		{
		case DataDisplay.none:
		case DataDisplay.moving:
		case DataDisplay.fullamount:
		case DataDisplay.towards:
			if (!this.stayHidden)
			{
				this.StopAmountCo();
				this.addShown = (this.addReal = value);
				this.UpdateAdd(false);
				return;
			}
			break;
		case DataDisplay.hidden:
			break;
		case DataDisplay.locked:
			return;
		default:
			return;
		}
		this.ScrambleAmount(value);
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0000B838 File Offset: 0x00009A38
	private int SumUp(int all, int addata)
	{
		int num = all + addata;
		if (num < 1)
		{
			return -all;
		}
		if (num <= 99)
		{
			return addata;
		}
		return 100 - all;
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x0000B85C File Offset: 0x00009A5C
	private void OnEnable()
	{
		this.jaugeCol = (this.winter ? this.winterCol : this.normCol);
		this.maskCol = this.normMaskCol;
		this.CrossFadeColor(this.gaugeGra, this.jaugeCol, 0.3f, true);
		this.CrossFadeColor(this.mask, this.maskCol, 0.3f, true);
		if (this.Moveco != null)
		{
			this.Moveco(this.moveco);
			this.Moveco = (Action<Outcome>)Delegate.Remove(this.Moveco, new Action<Outcome>(this.Move));
		}
		this.addTrans.anchoredPosition = new Vector2(this.addTrans.anchoredPosition.x, (float)this.hiddenAdd);
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x0000B923 File Offset: 0x00009B23
	private void OnDisable()
	{
		if (this.Moveco == null && this.isMoving && this.moveco != null)
		{
			this.Moveco = (Action<Outcome>)Delegate.Combine(this.Moveco, new Action<Outcome>(this.Move));
		}
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x0000B960 File Offset: 0x00009B60
	public void Move(Outcome outco)
	{
		this.moveco = outco;
		if (!base.gameObject.activeInHierarchy)
		{
			this.Moveco = (Action<Outcome>)Delegate.Combine(this.Moveco, new Action<Outcome>(this.Move));
			return;
		}
		this.isMoving = true;
		base.StopCoroutine("DoMove");
		base.StartCoroutine("DoMove", outco);
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x0000B9C3 File Offset: 0x00009BC3
	public void Stop()
	{
		this.isMoving = false;
		this.moveIcon.enabled = false;
		base.StopCoroutine("DoMove");
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x0000B9E3 File Offset: 0x00009BE3
	public void StayHidden()
	{
		this.stayHidden = true;
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x0000B9EC File Offset: 0x00009BEC
	public void DontStayHidden()
	{
		this.stayHidden = false;
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0000B9F5 File Offset: 0x00009BF5
	private void ShowMoveIcon(float val)
	{
		this.moveIcon.enabled = true;
		this.moveIcon.vectorGraphics = ((Mathf.Sign(val) > 0f) ? this.upArrow : this.downArrow);
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0000BA29 File Offset: 0x00009C29
	private IEnumerator DoMove(Outcome outco)
	{
		yield return 0;
		if (!this.isLock)
		{
			this.ShowMoveIcon((float)outco.value);
		}
		for (;;)
		{
			if (GameAct.diff.cardType != CardTypes.duel)
			{
				while (GameAct.diff.state == GameStates.interreign)
				{
					yield return new WaitForSeconds(1f);
				}
				while (InputAct.diff.isInMenu)
				{
					yield return new WaitForSeconds(1f);
				}
				while (this.isLock)
				{
					yield return new WaitForSeconds(1f);
					if (!this.isLock)
					{
						this.ShowMoveIcon((float)outco.value);
					}
				}
				if (outco == null)
				{
					break;
				}
				if (outco.value == 0)
				{
					goto Block_8;
				}
				float abs = (float)Mathf.Abs(outco.value);
				yield return new WaitForSeconds(1f / abs);
				if ((this.dataReal > 0 && outco.value < 0) || (this.dataReal < 100 && outco.value > 0))
				{
					int num = (int)Mathf.Sign((float)outco.value);
					this.dataReal += num;
					this.dataShown += num;
					this.UpdateAmount();
					base.StartCoroutine(this.MoveMoveIcon((float)num, 1f / abs));
					if (this.isVisible)
					{
						this.addShown = this.SumUp(this.dataReal, this.addShown);
						this.addReal = this.SumUp(this.dataReal, this.addReal);
						this.UpdateAdd(false);
					}
				}
			}
			else
			{
				yield return new WaitForSeconds(1f);
			}
		}
		this.Stop();
		yield break;
		Block_8:
		this.Stop();
		yield break;
		yield break;
	}

	// Token: 0x060001CB RID: 459 RVA: 0x0000BA3F File Offset: 0x00009C3F
	private IEnumerator MoveMoveIcon(float sign, float time)
	{
		float t = 0f;
		while (t < 1f)
		{
			this.moveIcon.rectTransform.anchoredPosition = new Vector2(18f, 10f - sign * 6f + 6f * t * sign);
			t += Time.deltaTime * time;
			yield return 0;
		}
		yield break;
	}

	// Token: 0x060001CC RID: 460 RVA: 0x0000BA5C File Offset: 0x00009C5C
	public int ResolveAddition()
	{
		this.dataReal = GameAct.diff.GetInt(this.variable);
		this.StopAmountCo();
		if (this.addReal == 0)
		{
			return this.dataReal;
		}
		this.UpdateAdd(false);
		if (!this.isLock)
		{
			this.dataReal += this.addReal;
		}
		base.StartCoroutine("Exchange");
		return this.dataReal;
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000BAC8 File Offset: 0x00009CC8
	private IEnumerator Exchange()
	{
		this.addReal = 0;
		yield return base.StartCoroutine("ReachData");
		this.addTrans.anchoredPosition = new Vector2(this.addTrans.anchoredPosition.x, (float)this.hiddenAdd);
		yield break;
	}

	// Token: 0x060001CE RID: 462 RVA: 0x0000BAD7 File Offset: 0x00009CD7
	private IEnumerator ReachData()
	{
		this.animated = true;
		this.UpdateAdd(false);
		if (this.addShown == this.addReal)
		{
			yield break;
		}
		yield return 0;
		Color color = (this.dataReal > this.dataShown) ? Color.Lerp(this.maskCol, Color.green, 0.2f) : Color.Lerp(this.maskCol, Color.red, 0.2f);
		this.mask.color = color;
		Color color2 = (this.dataReal > this.dataShown) ? Color.green : Color.red;
		this.gaugeGra.color = color2;
		yield return new WaitForSeconds(0.3f);
		this.CrossFadeColor(this.add, Color.white, 0.4f, true);
		this.CrossFadeColor(this.mask, this.normMaskCol, 0.4f, true);
		this.CrossFadeColor(this.gaugeGra, this.jaugeCol, 0.4f, true);
		while (this.dataShown != this.dataReal)
		{
			this.dataShown = ((this.dataReal < this.dataShown) ? (this.dataShown - 1) : (this.dataShown + 1));
			this.addShown = ((this.addReal < this.addShown) ? (this.addShown - 1) : (this.addShown + 1));
			this.UpdateAdd(true);
			this.UpdateAmount();
			float f = (float)(this.dataShown - this.dataReal);
			yield return new WaitForSeconds(Time.deltaTime * 6f / (1f + Mathf.Abs(f)));
		}
		this.DirectHide();
		this.animated = false;
		yield break;
	}

	// Token: 0x060001CF RID: 463 RVA: 0x0000BAE6 File Offset: 0x00009CE6
	public void OpenEffect(Effect effect)
	{
		base.StopCoroutine("ApplyEffect");
		base.StartCoroutine("ApplyEffect", effect);
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x0000BB00 File Offset: 0x00009D00
	private IEnumerator ApplyEffect(Effect effect)
	{
		while (this.animated)
		{
			yield return 0;
		}
		this.CrossFadeColor(this.mask, this.lockCol, 0.1f, false);
		this.CrossFadeColor(this.gaugeGra, this.lockCol, 0.1f, false);
		this.lockIcon.vectorGraphics = (SVGAsset)Resources.Load("effects/" + effect.tag, typeof(SVGAsset));
		this.lockIcon.enabled = true;
		this.lockIcon.color = this.lockCol;
		yield return new WaitForSeconds(0.12f);
		float t = 0f;
		while (t < 1f)
		{
			this.lockIcon.color = Color.Lerp(this.lockCol, Color.white, Easing.QuadEaseOut(t, 0f, 1f, 1f));
			t += Time.deltaTime * 7f;
			yield return 0;
		}
		t = 0f;
		while (t < 1f)
		{
			this.lockIcon.color = Color.Lerp(Color.white, this.lockCol, Easing.QuadEaseIn(t, 0f, 1f, 1f));
			t += Time.deltaTime * 6f;
			yield return 0;
		}
		this.CrossFadeColor(this.mask, this.normMaskCol, 0.1f, true);
		this.CrossFadeColor(this.gaugeGra, this.jaugeCol, 0.1f, true);
		this.lockIcon.enabled = false;
		yield return new WaitForSeconds(0.12f);
		yield break;
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x0000BB16 File Offset: 0x00009D16
	private void StopAmountCo()
	{
		base.StopCoroutine("Exchange");
		base.StopCoroutine("ReachData");
		base.StopCoroutine("Scramble");
		base.StopCoroutine("Rotate");
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x0000BB44 File Offset: 0x00009D44
	private void DirectHide()
	{
		this.addTrans.anchoredPosition = new Vector2(this.addTrans.anchoredPosition.x, (float)this.hiddenAdd);
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x0000BB70 File Offset: 0x00009D70
	private void UpdateAdd(bool nocol = false)
	{
		if (this.addShown == 0)
		{
			this.DirectHide();
			return;
		}
		this.add.text = ((this.addShown > 0) ? ("+" + this.addShown.ToString()) : this.addShown.ToString());
		if (nocol)
		{
			return;
		}
		this.ArrowUpdate();
		Color tcol = (this.addShown < 0) ? Color.red : Color.green;
		this.CrossFadeColor(this.add, tcol, 0.3f, false);
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x0000BBF8 File Offset: 0x00009DF8
	private void UpdateAmount()
	{
		if (!this.isGauge)
		{
			this.amount.text = this.dataShown.ToString();
		}
		this.gauge.anchoredPosition = new Vector2(0f, -40f + (float)this.dataShown * 0.4f);
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x0000BC4C File Offset: 0x00009E4C
	private void ScrambleAmount(int value)
	{
		this.StopAmountCo();
		this.addShown = value;
		this.addReal = value;
		base.StartCoroutine("Scramble");
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x0000BC7C File Offset: 0x00009E7C
	private void ArrowUpdate()
	{
		this.arrow.vectorGraphics = this.unknownArrow;
		this.arrow.color = this.jaugeCol;
		if (Mathf.Abs(this.addShown) > 14)
		{
			this.arrow.rectTransform.localScale = new Vector3(1.3f, 1.3f);
			return;
		}
		this.arrow.rectTransform.localScale = new Vector3(0.8f, 0.8f);
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x0000BCF9 File Offset: 0x00009EF9
	private IEnumerator Scramble()
	{
		this.CrossFadeColor(this.add, Color.grey, 0.3f, true);
		this.add.text = "?";
		this.ArrowUpdate();
		yield return 0;
		yield break;
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x0000BD08 File Offset: 0x00009F08
	private void HideAdd()
	{
		this.isVisible = false;
		base.StopCoroutine("MoveAdd");
		base.StartCoroutine("MoveAdd", this.hiddenAdd);
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x0000BD33 File Offset: 0x00009F33
	private void ShowAdd()
	{
		this.isVisible = true;
		base.StopCoroutine("MoveAdd");
		base.StartCoroutine("MoveAdd", this.shownAdd);
	}

	// Token: 0x060001DA RID: 474 RVA: 0x0000BD5E File Offset: 0x00009F5E
	private IEnumerator MoveAdd(int yPos)
	{
		float t = 0f;
		Vector2 tpos = new Vector2(this.addTrans.anchoredPosition.x, (float)yPos);
		while (t < 1f)
		{
			this.addTrans.anchoredPosition = Vector2.Lerp(this.addTrans.anchoredPosition, tpos, 0.3f);
			t += Time.deltaTime * 4f;
			yield return 0;
		}
		this.addTrans.anchoredPosition = tpos;
		yield break;
	}

	// Token: 0x060001DB RID: 475 RVA: 0x0000BD74 File Offset: 0x00009F74
	private void HideDanger(GameStates state)
	{
		this.CrossFadeColor(this.skull, Color.clear, 0.3f, true);
	}

	// Token: 0x060001DC RID: 476 RVA: 0x0000BD8D File Offset: 0x00009F8D
	private void ShowDanger(float amount)
	{
		this.CrossFadeColor(this.skull, Color.white, 1f, true);
	}

	// Token: 0x060001DD RID: 477 RVA: 0x0000BDA8 File Offset: 0x00009FA8
	public void UpdateDanger()
	{
		if (this.isLock)
		{
			return;
		}
		if (this.dataReal < 10)
		{
			this.ShowDanger((float)(10 - this.dataReal) / 10f);
			return;
		}
		if (this.dataReal > 90)
		{
			this.ShowDanger((float)(this.dataReal - 90) / 10f);
		}
	}

	// Token: 0x040001EE RID: 494
	public Variables variable;

	// Token: 0x040001EF RID: 495
	public bool isShown;

	// Token: 0x040001F0 RID: 496
	public SVGImage mask;

	// Token: 0x040001F1 RID: 497
	public SVGImage skull;

	// Token: 0x040001F2 RID: 498
	public RectTransform gauge;

	// Token: 0x040001F3 RID: 499
	private Graphic gaugeGra;

	// Token: 0x040001F4 RID: 500
	public SVGImage arrow;

	// Token: 0x040001F5 RID: 501
	public SVGAsset upArrow;

	// Token: 0x040001F6 RID: 502
	public SVGAsset downArrow;

	// Token: 0x040001F7 RID: 503
	public SVGAsset unknownArrow;

	// Token: 0x040001F8 RID: 504
	public bool isLock;

	// Token: 0x040001F9 RID: 505
	private bool isMoving;

	// Token: 0x040001FA RID: 506
	public Text add;

	// Token: 0x040001FB RID: 507
	public Color dangerCol;

	// Token: 0x040001FC RID: 508
	public Color lockCol;

	// Token: 0x040001FD RID: 509
	public Color normCol;

	// Token: 0x040001FE RID: 510
	public Color normMaskCol;

	// Token: 0x040001FF RID: 511
	public Color winterCol;

	// Token: 0x04000200 RID: 512
	private Color jaugeCol;

	// Token: 0x04000201 RID: 513
	private Color maskCol;

	// Token: 0x04000202 RID: 514
	private RectTransform addTrans;

	// Token: 0x04000203 RID: 515
	public Text amount;

	// Token: 0x04000204 RID: 516
	public SVGImage lockIcon;

	// Token: 0x04000205 RID: 517
	public SVGImage moveIcon;

	// Token: 0x04000206 RID: 518
	private int dataReal;

	// Token: 0x04000207 RID: 519
	private int dataShown;

	// Token: 0x04000208 RID: 520
	private int addReal;

	// Token: 0x04000209 RID: 521
	private int addShown;

	// Token: 0x0400020A RID: 522
	private int hiddenAdd = 116;

	// Token: 0x0400020B RID: 523
	private int shownAdd = 44;

	// Token: 0x0400020C RID: 524
	private SVGImage image;

	// Token: 0x0400020D RID: 525
	private bool isGauge;

	// Token: 0x0400020E RID: 526
	private bool stayHidden;

	// Token: 0x0400020F RID: 527
	private bool winter;

	// Token: 0x04000210 RID: 528
	private Action<Outcome> Moveco;

	// Token: 0x04000211 RID: 529
	private Outcome moveco;

	// Token: 0x04000212 RID: 530
	private bool animated;

	// Token: 0x04000213 RID: 531
	private bool isVisible;
}
