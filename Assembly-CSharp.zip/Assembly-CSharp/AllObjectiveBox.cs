﻿using System;

// Token: 0x02000016 RID: 22
public class AllObjectiveBox : ContentBox
{
	// Token: 0x060000A6 RID: 166 RVA: 0x00003D07 File Offset: 0x00001F07
	public override void Validate()
	{
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x000047FF File Offset: 0x000029FF
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
		this.scOb = CardReader.diff.GetComponent<ObjectiveAct>();
		this.scOb.ShowObjectives(base.transform, -20, true, true, 2f);
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x0000482B File Offset: 0x00002A2B
	public void ForceStop()
	{
		ModalAct.diff.ForceClose();
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x00004837 File Offset: 0x00002A37
	public override void Close()
	{
		this.isready = true;
		this.scOb.DestroyBoxes();
	}

	// Token: 0x060000AA RID: 170 RVA: 0x0000484B File Offset: 0x00002A4B
	private bool YieldStart(bool none)
	{
		return this.isready;
	}

	// Token: 0x0400007D RID: 125
	private ObjectiveAct scOb;

	// Token: 0x0400007E RID: 126
	private bool isready;
}
