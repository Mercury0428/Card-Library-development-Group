﻿using System;
using SVGImporter;
using UnityEngine;

// Token: 0x02000085 RID: 133
public class AudioColor : MonoBehaviour
{
	// Token: 0x06000464 RID: 1124 RVA: 0x0001BB31 File Offset: 0x00019D31
	public void VelocityMultiplierIntensity(float value)
	{
		this._velocityMultiplierIntensity = value;
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x0001BB3A File Offset: 0x00019D3A
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x0001BB43 File Offset: 0x00019D43
	public void RandomIntensity(float value)
	{
		this._randomIntensity = value;
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x0001BB4C File Offset: 0x00019D4C
	private void Awake()
	{
		this.destination = this.target.color;
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x0001BB60 File Offset: 0x00019D60
	public void OnAudio(float audioVelocity)
	{
		float num = audioVelocity * this.velocityMultiplier * this._velocityMultiplierIntensity;
		if (this.random && this._randomIntensity >= 0.5f)
		{
			this.destination.r = Mathf.PerlinNoise(Time.realtimeSinceStartup * 1.5f, Time.realtimeSinceStartup * 3f) * this.velocity.r * num;
			this.destination.g = Mathf.PerlinNoise(Time.realtimeSinceStartup * 2f, Time.realtimeSinceStartup * 0.5f) * this.velocity.g * num;
			this.destination.b = Mathf.PerlinNoise(Time.realtimeSinceStartup * 0.2f, Time.realtimeSinceStartup * 0.15f) * this.velocity.b * num;
			if (this.affectAlpha)
			{
				this.destination.a = Mathf.PerlinNoise(Time.realtimeSinceStartup * 2.3f, Time.realtimeSinceStartup * 3.5f) * this.velocity.a * num;
			}
			else
			{
				this.destination.a = this.target.color.a;
			}
		}
		else
		{
			this.destination.r = this.velocity.r * num;
			this.destination.g = this.velocity.g * num;
			this.destination.b = this.velocity.b * num;
			if (this.affectAlpha)
			{
				this.destination.a = this.velocity.a * num;
			}
			else
			{
				this.destination.a = this.target.color.a;
			}
		}
		this.target.color = Color.Lerp(this.target.color, this.destination, Time.deltaTime * this.speed * this._speedIntensity);
	}

	// Token: 0x0400050F RID: 1295
	public SVGRenderer target;

	// Token: 0x04000510 RID: 1296
	public Color velocity;

	// Token: 0x04000511 RID: 1297
	public bool affectAlpha;

	// Token: 0x04000512 RID: 1298
	public float velocityMultiplier = 1f;

	// Token: 0x04000513 RID: 1299
	protected float _velocityMultiplierIntensity = 1f;

	// Token: 0x04000514 RID: 1300
	public float speed = 1f;

	// Token: 0x04000515 RID: 1301
	protected float _speedIntensity = 1f;

	// Token: 0x04000516 RID: 1302
	public bool random = true;

	// Token: 0x04000517 RID: 1303
	protected float _randomIntensity = 1f;

	// Token: 0x04000518 RID: 1304
	private Color destination;
}
