﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000044 RID: 68
public class EffectAct : MonoBehaviour
{
	// Token: 0x06000234 RID: 564 RVA: 0x0000D5C0 File Offset: 0x0000B7C0
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnLoad = (Action<Game>)Delegate.Combine(diff.OnLoad, new Action<Game>(this.LoadEffects));
		GameAct diff2 = GameAct.diff;
		diff2.OnLoadOld = (Action<string>)Delegate.Combine(diff2.OnLoadOld, new Action<string>(this.LoadEffectsOld));
		GameAct diff3 = GameAct.diff;
		diff3.OnSave = (Action<Game>)Delegate.Combine(diff3.OnSave, new Action<Game>(this.SaveEffects));
		GameAct diff4 = GameAct.diff;
		diff4.OnInit = (Action)Delegate.Combine(diff4.OnInit, new Action(this.InitEffects));
		GameAct diff5 = GameAct.diff;
		diff5.OnUpdate = (Action<Card>)Delegate.Combine(diff5.OnUpdate, new Action<Card>(this.CheckEffects));
		GameAct diff6 = GameAct.diff;
		diff6.OnAfterDeath = (Action)Delegate.Combine(diff6.OnAfterDeath, new Action(this.ResetEffects));
		GameAct diff7 = GameAct.diff;
		diff7.OnReignEnd = (Action)Delegate.Combine(diff7.OnReignEnd, new Action(this.CheckEffects));
		GameAct diff8 = GameAct.diff;
		diff8.OnUpdateCards = (Action)Delegate.Combine(diff8.OnUpdateCards, new Action(this.UpdateEffects));
		MetersAct metersAct = this.scMeters;
		metersAct.OnShowOutcome = (Func<Outcome, int>)Delegate.Combine(metersAct.OnShowOutcome, new Func<Outcome, int>(this.AffectValue));
	}

	// Token: 0x06000235 RID: 565 RVA: 0x0000D724 File Offset: 0x0000B924
	private void ResetEffects()
	{
		this.CheckEffects();
		this.effVal = new Dictionary<Variables, Effect>();
	}

	// Token: 0x06000236 RID: 566 RVA: 0x0000D738 File Offset: 0x0000B938
	public Effect GetEffect(string id)
	{
		return this.effects.Find((Effect it) => it.tag == id);
	}

	// Token: 0x06000237 RID: 567 RVA: 0x0000D76C File Offset: 0x0000B96C
	public List<Effect> GetEffects()
	{
		Dictionary<string, string[]> languageStrings = this.GetLanguageStrings();
		List<Effect> list = new List<Effect>();
		string[] array = CardReader.diff.GetTempText("effects").Split(new char[]
		{
			'\n'
		});
		string[] columns = array[0].Split(this.dele, StringSplitOptions.RemoveEmptyEntries);
		for (int i = 1; i < array.Length; i++)
		{
			list.Add(new Effect(array[i].Split(this.dele), columns, languageStrings, this));
		}
		return list;
	}

	// Token: 0x06000238 RID: 568 RVA: 0x0000D7E8 File Offset: 0x0000B9E8
	public int GetType(string typ)
	{
		if (typ == "special" || typ == "-1")
		{
			return -1;
		}
		if (this.types.Contains(typ))
		{
			return this.types.IndexOf(typ);
		}
		this.types.Add(typ);
		int result = this.types.Count - 1;
		this.levels.Add(new List<string>());
		return result;
	}

	// Token: 0x06000239 RID: 569 RVA: 0x0000D858 File Offset: 0x0000BA58
	public int GetLevel(string tag, int typ)
	{
		if (typ == -1)
		{
			return -1;
		}
		if (this.levels[typ].Contains(tag))
		{
			return this.levels[typ].IndexOf(tag);
		}
		this.levels[typ].Add(tag);
		return this.levels[typ].Count - 1;
	}

	// Token: 0x0600023A RID: 570 RVA: 0x0000D8B8 File Offset: 0x0000BAB8
	public bool HasEffect(string tag)
	{
		return this.effects.Find((Effect it) => it.tag == tag && it.active) != null;
	}

	// Token: 0x0600023B RID: 571 RVA: 0x0000D8F0 File Offset: 0x0000BAF0
	public bool HasItemOrBetter_notin(string tag)
	{
		return this.effects.Find((Effect it) => it.tag == tag) != null;
	}

	// Token: 0x0600023C RID: 572 RVA: 0x0000D928 File Offset: 0x0000BB28
	private void UpdateEffects()
	{
		this.types = new List<string>();
		this.levels = new List<List<string>>();
		List<Effect> neweff = this.GetEffects();
		using (List<Effect>.Enumerator enumerator = neweff.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Effect neff = enumerator.Current;
				Effect effect = this.effects.Find((Effect it) => it.tag == neff.tag);
				if (effect == null)
				{
					this.effects.Add(neff);
				}
				else
				{
					effect.description = neff.description;
					effect.outcomes = neff.outcomes;
					effect.title = neff.title;
					effect.alwayshowcard = neff.alwayshowcard;
				}
			}
		}
		this.effects.RemoveAll((Effect it) => neweff.Find((Effect yt) => yt.tag == it.tag) == null);
	}

	// Token: 0x0600023D RID: 573 RVA: 0x0000DA38 File Offset: 0x0000BC38
	private Dictionary<string, string[]> GetLanguageStrings()
	{
		string lang = SpeechAct.diff.lang;
		if (lang == "en")
		{
			return new Dictionary<string, string[]>();
		}
		Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
		string[] array = Util.GetTextFile("texts/effects_i18n").Split(new char[]
		{
			'\n'
		});
		string[] array2 = array[0].Split(this.dele);
		for (int i = 1; i < array.Length; i++)
		{
			string[] array3 = array[i].Split(this.dele);
			string[] array4 = new string[5];
			string key = "";
			for (int j = 0; j < array2.Length; j++)
			{
				string a = array2[j];
				if (a == "tag")
				{
					key = array3[j];
				}
				else if (a == lang + "_title")
				{
					array4[0] = array3[j];
				}
				else if (a == lang + "_description")
				{
					array4[1] = array3[j];
				}
			}
			dictionary.Add(key, array4);
		}
		return dictionary;
	}

	// Token: 0x0600023E RID: 574 RVA: 0x0000DB44 File Offset: 0x0000BD44
	private void LoadEffects(Game save)
	{
		this.effects = save.effects;
		foreach (Effect effect in this.effects)
		{
			if (effect.active)
			{
				this.OpenEffect(effect, 0f, false);
			}
		}
		this.SetListTags();
	}

	// Token: 0x0600023F RID: 575 RVA: 0x0000DBB8 File Offset: 0x0000BDB8
	private void LoadEffectsOld(string gamename)
	{
		this.effects = DataStore.LoadOld<List<Effect>>("effects_" + gamename, false);
		foreach (Effect effect in this.effects)
		{
			if (effect.active)
			{
				this.OpenEffect(effect, 0f, false);
			}
		}
		this.SetListTags();
	}

	// Token: 0x06000240 RID: 576 RVA: 0x0000DC38 File Offset: 0x0000BE38
	private void SetListTags()
	{
		foreach (Effect effect in this.effects)
		{
			this.effectTags.Add(effect.tag);
		}
	}

	// Token: 0x06000241 RID: 577 RVA: 0x0000DC98 File Offset: 0x0000BE98
	private void OpenEffect(Effect effect, float delay = 0f, bool single = false)
	{
		string tag = effect.tag;
		if (tag.EndsWith("_super"))
		{
			if (this.icon != null)
			{
				Object.Destroy(this.icon);
			}
			GameObject gameObject = Object.Instantiate<GameObject>(this.iconSlotPrefab);
			this.icon = gameObject;
			gameObject.GetComponent<SVGImage>().vectorGraphics = (SVGAsset)Resources.Load("effects/" + tag, typeof(SVGAsset));
			gameObject.transform.SetParent(this.icorect.transform, false);
			base.StartCoroutine(this.ShowSlotIcon(effect, single, delay));
		}
		this.nbEffect++;
		if (tag == "noironbank")
		{
			this.effVal.Add(Variables.money, effect);
			return;
		}
		if (tag == "nohand")
		{
			this.effVal.Add(Variables.power, effect);
			return;
		}
		if (!(tag == "faithmilitant"))
		{
			if (tag == "winter")
			{
				this.effVal.Add(Variables.people, effect);
			}
			if (this.OnOpenEffect != null)
			{
				this.OnOpenEffect(effect);
			}
			return;
		}
		this.effVal.Add(Variables.faith, effect);
	}

	// Token: 0x06000242 RID: 578 RVA: 0x0000DDCC File Offset: 0x0000BFCC
	private int AffectValue(Outcome outco)
	{
		if (outco == null)
		{
			return 0;
		}
		Variables variable = outco.variable;
		if (variable - Variables.people > 3)
		{
			return 0;
		}
		if (!this.effVal.ContainsKey(outco.variable) || (outco.variable == Variables.people && !GameAct.diff.GetBool("storm")))
		{
			return outco.value;
		}
		this.scMeters.SendEffect(outco.variable, this.effVal[outco.variable]);
		if (outco.value >= 0)
		{
			return outco.value + 3;
		}
		return outco.value - 3;
	}

	// Token: 0x06000243 RID: 579 RVA: 0x0000DE5F File Offset: 0x0000C05F
	private IEnumerator ShowSlotIcon(Effect effect, bool single, float delay)
	{
		float t = 0f;
		while (t < 1f)
		{
			this.icorect.localScale = Vector3.one * (1.5f - 0.5f * t);
			t += Time.deltaTime * 3f;
			yield return null;
		}
		this.icorect.localScale = Vector3.one;
		yield break;
	}

	// Token: 0x06000244 RID: 580 RVA: 0x0000DE6E File Offset: 0x0000C06E
	private void SaveEffects(Game save)
	{
		save.effects = this.effects;
	}

	// Token: 0x06000245 RID: 581 RVA: 0x0000DE7C File Offset: 0x0000C07C
	private void InitEffects()
	{
		this.effects = this.GetEffects();
		this.SetListTags();
	}

	// Token: 0x06000246 RID: 582 RVA: 0x0000DE90 File Offset: 0x0000C090
	public bool HasLimit(Card card)
	{
		return card.yes_outcomes.Find((Outcome it) => this.effectTags.Contains(it.custom_name) && it.value == 1) != null || card.no_outcomes.Find((Outcome it) => this.effectTags.Contains(it.custom_name) && it.value == 1) != null;
	}

	// Token: 0x06000247 RID: 583 RVA: 0x0000DEC7 File Offset: 0x0000C0C7
	private void CheckEffects()
	{
		this.CheckEffects(null);
	}

	// Token: 0x06000248 RID: 584 RVA: 0x0000DED0 File Offset: 0x0000C0D0
	private void CheckEffects(Card card)
	{
		List<Effect> list = new List<Effect>();
		List<Effect> list2 = new List<Effect>();
		foreach (Effect effect in this.effects)
		{
			if (effect.active)
			{
				if (!GameAct.diff.Has(effect.tag))
				{
					list2.Add(effect);
				}
			}
			else if (GameAct.diff.Has(effect.tag))
			{
				list.Add(effect);
			}
		}
		foreach (Effect obj in list2)
		{
			this.CloseEffect(obj);
		}
		foreach (Effect effect2 in list)
		{
			effect2.active = true;
			this.OpenEffect(effect2, 0f, true);
			if (effect2.alwayshowcard || !effect2.seen)
			{
				GameAct.diff.AddEffectCard(effect2);
			}
			effect2.seen = true;
		}
	}

	// Token: 0x06000249 RID: 585 RVA: 0x0000E018 File Offset: 0x0000C218
	public void CloseEffect(Effect obj)
	{
		string tag = obj.tag;
		GameAct.diff.SetInt(tag, -1);
		obj.active = false;
		this.nbEffect--;
		if (obj.tag.EndsWith("_super") && this.icon != null)
		{
			Object.Destroy(this.icon);
		}
		if (tag == "noironbank")
		{
			this.effVal.Remove(Variables.money);
			return;
		}
		if (tag == "nohand")
		{
			this.effVal.Remove(Variables.power);
			return;
		}
		if (!(tag == "faithmilitant"))
		{
			if (tag == "winter")
			{
				this.effVal.Remove(Variables.people);
			}
			if (this.OnCloseEffect != null)
			{
				this.OnCloseEffect(obj);
			}
			return;
		}
		this.effVal.Remove(Variables.faith);
	}

	// Token: 0x0600024A RID: 586 RVA: 0x0000E0FE File Offset: 0x0000C2FE
	private void SetSpecialBackTempo(Backgrounds back)
	{
		this.specialback = back;
		this.nodung = false;
		this.NewDung(null);
		GameAct diff = GameAct.diff;
		diff.OnUpdate = (Action<Card>)Delegate.Combine(diff.OnUpdate, new Action<Card>(this.NewDung));
	}

	// Token: 0x0600024B RID: 587 RVA: 0x0000E13B File Offset: 0x0000C33B
	private void UnSetSpecialBack()
	{
		this.nodung = true;
		GameAct diff = GameAct.diff;
		diff.OnUpdate = (Action<Card>)Delegate.Remove(diff.OnUpdate, new Action<Card>(this.NewDung));
		BackgroundAct.diff.SetBack(Backgrounds.defaut, false);
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00003D07 File Offset: 0x00001F07
	private void CheckChurch(Bearers bearer)
	{
	}

	// Token: 0x0600024D RID: 589 RVA: 0x0000E178 File Offset: 0x0000C378
	private string ScrambleQuestion(string question)
	{
		int length = question.Length;
		if (length > 7 && (question.Substring(0, 3) == "<i>" || question.Substring(length - 4, 4) == "</i>"))
		{
			return question;
		}
		char[] array = (SpeechAct.diff.lang == "jp") ? this.japanScramble1 : ((SpeechAct.diff.lang == "ru") ? this.russianScramble1 : this.latinScramble1);
		char[] array2 = (SpeechAct.diff.lang == "jp") ? this.japanScramble2 : ((SpeechAct.diff.lang == "ru") ? this.russianScramble2 : this.latinScramble2);
		for (int i = 0; i < array.Length; i++)
		{
			question = this.SwitchChar(question, array[i], array2[i]);
		}
		if (SpeechAct.diff.asiaLayout || SpeechAct.diff.lang == "ko")
		{
			List<char> list = new List<char>
			{
				'<',
				'i',
				'>',
				'/',
				'+'
			};
			for (int j = 0; j < 7; j++)
			{
				if (question.Length > 6)
				{
					int num = Util.RandInt(0, question.Length - 1);
					if (!list.Contains(question[num]))
					{
						question = question.Remove(num, 1);
					}
				}
			}
		}
		return question;
	}

	// Token: 0x0600024E RID: 590 RVA: 0x0000E2F6 File Offset: 0x0000C4F6
	private string SwitchChar(string source, char ch, char byc)
	{
		if (Util.Rand(0f, 1f) > 0.5f)
		{
			return source;
		}
		source = source.Replace(ch, byc);
		return source;
	}

	// Token: 0x0600024F RID: 591 RVA: 0x0000E31B File Offset: 0x0000C51B
	private void NewDung(Card card)
	{
		if (this.nodung)
		{
			return;
		}
		BackgroundAct.diff.SetBack(this.specialback, false);
	}

	// Token: 0x06000250 RID: 592 RVA: 0x0000E337 File Offset: 0x0000C537
	public void OpenSun()
	{
		base.StartCoroutine(this.SunSlide(0f, 0.8f));
	}

	// Token: 0x06000251 RID: 593 RVA: 0x0000E350 File Offset: 0x0000C550
	private IEnumerator SunSlide(float start, float end)
	{
		yield break;
	}

	// Token: 0x06000252 RID: 594 RVA: 0x0000E358 File Offset: 0x0000C558
	private string EyeCurse(string str)
	{
		GameAct.diff.cardSc.GetComponent<CharacterCard>().HellEyes();
		return str;
	}

	// Token: 0x06000253 RID: 595 RVA: 0x0000821B File Offset: 0x0000641B
	private bool PreVisit(int dec)
	{
		return false;
	}

	// Token: 0x06000254 RID: 596 RVA: 0x0000E36F File Offset: 0x0000C56F
	private bool PreCurse(int dec)
	{
		return true;
	}

	// Token: 0x06000255 RID: 597 RVA: 0x00003D07 File Offset: 0x00001F07
	private void InitCurse()
	{
	}

	// Token: 0x06000256 RID: 598 RVA: 0x00003D07 File Offset: 0x00001F07
	private void RemoveIconSlot(Effect eff)
	{
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0000E372 File Offset: 0x0000C572
	public List<Effect> GetLiveEffects()
	{
		return this.effects.FindAll((Effect it) => it.active);
	}

	// Token: 0x06000258 RID: 600 RVA: 0x0000E36F File Offset: 0x0000C56F
	public bool OpenAndSelectBut()
	{
		return true;
	}

	// Token: 0x06000259 RID: 601 RVA: 0x00003D07 File Offset: 0x00001F07
	public void CloseBut()
	{
	}

	// Token: 0x04000242 RID: 578
	public Action<Effect> OnOpenEffect;

	// Token: 0x04000243 RID: 579
	public Action<Effect> OnCloseEffect;

	// Token: 0x04000244 RID: 580
	public WhoAct scWho;

	// Token: 0x04000245 RID: 581
	public MetersAct scMeters;

	// Token: 0x04000246 RID: 582
	private char[] dele = new char[]
	{
		';'
	};

	// Token: 0x04000247 RID: 583
	public List<Effect> effects;

	// Token: 0x04000248 RID: 584
	private GameObject icon;

	// Token: 0x04000249 RID: 585
	private List<string> types = new List<string>();

	// Token: 0x0400024A RID: 586
	private List<List<string>> levels = new List<List<string>>();

	// Token: 0x0400024B RID: 587
	public GameObject iconSlotPrefab;

	// Token: 0x0400024C RID: 588
	public Transform bottomBloc;

	// Token: 0x0400024D RID: 589
	private RectTransform[] backSlots;

	// Token: 0x0400024E RID: 590
	private int nbEffect;

	// Token: 0x0400024F RID: 591
	public RectTransform icorect;

	// Token: 0x04000250 RID: 592
	private List<string> effectTags = new List<string>();

	// Token: 0x04000251 RID: 593
	private Dictionary<Variables, Effect> effVal = new Dictionary<Variables, Effect>();

	// Token: 0x04000252 RID: 594
	private Backgrounds specialback;

	// Token: 0x04000253 RID: 595
	private bool nodung;

	// Token: 0x04000254 RID: 596
	private char[] latinScramble1 = new char[]
	{
		'a',
		'u',
		'e',
		'p',
		'm',
		'n',
		'h',
		'z',
		'k'
	};

	// Token: 0x04000255 RID: 597
	private char[] latinScramble2 = new char[]
	{
		'u',
		'i',
		'o',
		'j',
		'j',
		'p',
		'p',
		'x',
		'h'
	};

	// Token: 0x04000256 RID: 598
	private char[] japanScramble1 = new char[]
	{
		'ラ',
		'ム',
		'了',
		'王',
		'ロ',
		'ン',
		'の',
		'シ',
		'大',
		'ド',
		'ギ',
		'し',
		'中',
		'立',
		'っ',
		'べ',
		'士',
		'こ'
	};

	// Token: 0x04000257 RID: 599
	private char[] japanScramble2 = new char[]
	{
		'ベ',
		'ロ',
		'ト',
		'ェ',
		'ラ',
		'レ',
		'ク',
		'ブ',
		'シ',
		'て',
		'央',
		'い',
		'下',
		'れ',
		'イ',
		'り',
		'手',
		'わ'
	};

	// Token: 0x04000258 RID: 600
	private char[] russianScramble1 = new char[]
	{
		'и',
		'о',
		'к',
		'з',
		'л',
		'ш',
		'г',
		'д',
		'т'
	};

	// Token: 0x04000259 RID: 601
	private char[] russianScramble2 = new char[]
	{
		'а',
		'у',
		'н',
		'н',
		'я',
		'ж',
		'ж',
		'ь',
		'ц'
	};
}
