﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000006 RID: 6
public class DeathBox : ContentBox
{
	// Token: 0x06000028 RID: 40 RVA: 0x00002ED4 File Offset: 0x000010D4
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
		this.description.text = txtid;
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002EE2 File Offset: 0x000010E2
	public override void Validate()
	{
		base.StartCoroutine("PlayAnim");
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002EF0 File Offset: 0x000010F0
	private IEnumerator PlayAnim()
	{
		yield return new WaitForSeconds(0.2f);
		JukeBox.diff.PlaySound(SFXTypes.ui_new_cards, false, false, 2.5f, -1, 1.5f, 1f);
		yield break;
	}

	// Token: 0x04000032 RID: 50
	public Text title;

	// Token: 0x04000033 RID: 51
	public Text description;

	// Token: 0x04000034 RID: 52
	public GameObject starPrefab;
}
