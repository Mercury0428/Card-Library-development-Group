﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000052 RID: 82
public class HapticAct : MonoBehaviour
{
	// Token: 0x060002F8 RID: 760 RVA: 0x000138E5 File Offset: 0x00011AE5
	private void Awake()
	{
		HapticAct.diff = this;
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x000138ED File Offset: 0x00011AED
	public void StartHaptic()
	{
		GameAct gameAct = GameAct.diff;
		gameAct.OnReignEnd = (Action)Delegate.Combine(gameAct.OnReignEnd, new Action(this.Failure));
		this.isOn = true;
	}

	// Token: 0x060002FA RID: 762 RVA: 0x0001391C File Offset: 0x00011B1C
	public void StopHaptic()
	{
		GameAct gameAct = GameAct.diff;
		gameAct.OnReignEnd = (Action)Delegate.Remove(gameAct.OnReignEnd, new Action(this.Failure));
		this.isOn = false;
	}

	// Token: 0x060002FB RID: 763 RVA: 0x0001394B File Offset: 0x00011B4B
	private void Start()
	{
		this.StopHaptic();
	}

	// Token: 0x060002FC RID: 764 RVA: 0x00013953 File Offset: 0x00011B53
	private bool LightChange(int dec)
	{
		iOSHapticFeedback.Instance.Trigger(iOSHapticFeedback.iOSFeedbackType.SelectionChange);
		return false;
	}

	// Token: 0x060002FD RID: 765 RVA: 0x00013961 File Offset: 0x00011B61
	private void NormalChange(Card card)
	{
		iOSHapticFeedback.Instance.Trigger(iOSHapticFeedback.iOSFeedbackType.ImpactMedium);
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0001396E File Offset: 0x00011B6E
	public void Tap(iOSHapticFeedback.iOSFeedbackType type = iOSHapticFeedback.iOSFeedbackType.ImpactLight)
	{
		if (!this.isOn)
		{
			return;
		}
		iOSHapticFeedback.Instance.Trigger(type);
	}

	// Token: 0x060002FF RID: 767 RVA: 0x00013984 File Offset: 0x00011B84
	public void BigChange()
	{
		if (!this.isOn)
		{
			return;
		}
		iOSHapticFeedback.Instance.Trigger(iOSHapticFeedback.iOSFeedbackType.Failure);
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0001399A File Offset: 0x00011B9A
	private void Failure()
	{
		iOSHapticFeedback.Instance.Trigger(iOSHapticFeedback.iOSFeedbackType.Warning);
	}

	// Token: 0x06000301 RID: 769 RVA: 0x000139A7 File Offset: 0x00011BA7
	public void OpenGlitch()
	{
		if (!this.isOn)
		{
			return;
		}
		base.StopCoroutine("ThreeGlitch");
		base.StartCoroutine("ThreeGlitch");
	}

	// Token: 0x06000302 RID: 770 RVA: 0x000139C9 File Offset: 0x00011BC9
	public void StopGlitch()
	{
		base.StopCoroutine("ThreeGlitch");
	}

	// Token: 0x06000303 RID: 771 RVA: 0x000139D6 File Offset: 0x00011BD6
	private IEnumerator ThreeGlitch()
	{
		for (;;)
		{
			float amo = Util.Rand(0.4f, 1.7f);
			yield return new WaitForSeconds(amo);
			if (amo < 0.8f)
			{
				this.NormalChange(null);
			}
			else if (amo < 1.2f)
			{
				iOSHapticFeedback.Instance.Trigger(iOSHapticFeedback.iOSFeedbackType.Success);
			}
			else if (amo < 1.5f)
			{
				this.BigChange();
			}
			else
			{
				this.Failure();
			}
		}
		yield break;
	}

	// Token: 0x040003CD RID: 973
	public static HapticAct diff;

	// Token: 0x040003CE RID: 974
	private bool isOn = true;
}
