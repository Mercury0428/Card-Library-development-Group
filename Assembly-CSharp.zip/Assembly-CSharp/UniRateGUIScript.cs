﻿using System;
using System.Text;
using UnityEngine;

// Token: 0x020000A3 RID: 163
public class UniRateGUIScript : MonoBehaviour
{
	// Token: 0x060004FE RID: 1278 RVA: 0x0001E328 File Offset: 0x0001C528
	private void OnGUI()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(string.Format(this.bundleIDString, UniRate.Instance.applicationBundleID));
		stringBuilder.Append(string.Format(this.appIDString, UniRate.Instance.appStoreID));
		stringBuilder.Append(string.Format(this.appNameString, UniRate.Instance.applicationName));
		stringBuilder.Append(string.Format(this.appVersionString, UniRate.Instance.applicationVersion));
		stringBuilder.Append(string.Format(this.usesUntilPromptString, UniRate.Instance.usesUntilPrompt));
		stringBuilder.Append(string.Format(this.usedString, UniRate.Instance.usesCount));
		stringBuilder.Append(string.Format(this.eventsUntilPromptString, UniRate.Instance.eventsUntilPrompt));
		stringBuilder.Append(string.Format(this.eventsHappenedString, UniRate.Instance.eventCount));
		stringBuilder.Append(string.Format(this.daysUntilPromptString, UniRate.Instance.daysUntilPrompt));
		stringBuilder.Append(string.Format(this.daysUsedString, UniRate.Instance.usedDays));
		stringBuilder.Append(string.Format(this.usesPerWeekToPromptString, UniRate.Instance.usesPerWeekForPrompt));
		stringBuilder.Append(string.Format(this.usesPerWeekString, UniRate.Instance.usesPerWeek));
		if (UniRate.Instance.waitingByRemindLater)
		{
			stringBuilder.Append(string.Format(this.remindString, UniRate.Instance.leftRemindDays));
		}
		GUI.Label(new Rect(0f, 0f, 300f, 500f), stringBuilder.ToString());
		if (GUI.Button(new Rect(0f, (float)(Screen.height - 50), 100f, 50f), "Rate"))
		{
			UniRate.Instance.RateIfNetworkAvailable();
		}
		if (GUI.Button(new Rect(100f, (float)(Screen.height - 50), 100f, 50f), "Rate Prompt"))
		{
			UniRate.Instance.PromptIfNetworkAvailable();
		}
		if (GUI.Button(new Rect(200f, (float)(Screen.height - 50), 100f, 50f), "LogEvent"))
		{
			UniRate.Instance.LogEvent(true);
		}
		if (GUI.Button(new Rect(300f, (float)(Screen.height - 50), 100f, 50f), "Reset"))
		{
			UniRate.Instance.Reset();
		}
	}

	// Token: 0x040005AE RID: 1454
	private string bundleIDString = "Bundle ID: {0}\n";

	// Token: 0x040005AF RID: 1455
	private string appIDString = "App ID: {0}\n";

	// Token: 0x040005B0 RID: 1456
	private string appNameString = "App Name: {0}\n";

	// Token: 0x040005B1 RID: 1457
	private string appVersionString = "App Version: {0}\n";

	// Token: 0x040005B2 RID: 1458
	private string usesUntilPromptString = "Uses Until Prompt: {0}\n";

	// Token: 0x040005B3 RID: 1459
	private string usedString = "Already Used Count: {0}\n";

	// Token: 0x040005B4 RID: 1460
	private string eventsUntilPromptString = "Events Until Prompt: {0}\n";

	// Token: 0x040005B5 RID: 1461
	private string eventsHappenedString = "Events Happened: {0}\n";

	// Token: 0x040005B6 RID: 1462
	private string daysUntilPromptString = "Days Until Prompt:{0}\n";

	// Token: 0x040005B7 RID: 1463
	private string daysUsedString = "Days From First Use:{0}\n";

	// Token: 0x040005B8 RID: 1464
	private string usesPerWeekToPromptString = "Uses per week to prompt:{0}\n";

	// Token: 0x040005B9 RID: 1465
	private string usesPerWeekString = "Current uses per week:{0}\n";

	// Token: 0x040005BA RID: 1466
	private string remindString = "Remind after:{0} days\n";
}
