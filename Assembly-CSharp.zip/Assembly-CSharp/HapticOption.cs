﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000053 RID: 83
public class HapticOption : MonoBehaviour
{
	// Token: 0x06000305 RID: 773 RVA: 0x000139F4 File Offset: 0x00011BF4
	private void Start()
	{
		HapticAct.diff.StopHaptic();
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000306 RID: 774 RVA: 0x00013A0C File Offset: 0x00011C0C
	public void ChangeHaptic(bool ison)
	{
		if (this.toggleHaptic.isOn)
		{
			PlayerPrefs.DeleteKey("nohaptic");
			HapticAct.diff.StartHaptic();
			HapticAct.diff.BigChange();
		}
		else
		{
			PlayerPrefs.SetInt("nohaptic", 1);
			HapticAct.diff.StopHaptic();
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x040003CF RID: 975
	public Toggle toggleHaptic;
}
