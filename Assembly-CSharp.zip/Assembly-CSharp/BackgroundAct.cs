﻿using System;
using System.Collections;
using System.Collections.Generic;
using SleekRender;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200001E RID: 30
public class BackgroundAct : MonoBehaviour
{
	// Token: 0x060000D6 RID: 214 RVA: 0x0000521C File Offset: 0x0000341C
	private void Start()
	{
		this.curBack = this.backgrounds[0];
		this.scWho = this.who.GetComponent<WhoAct>();
		this.postpro = Camera.main.GetComponent<SleekRenderPostProcess>();
		BackgroundAct.diff = this;
		GameAct gameAct = GameAct.diff;
		gameAct.OnStart = (Action<GameStates>)Delegate.Combine(gameAct.OnStart, new Action<GameStates>(this.FadeToLight));
		InputAct inputAct = InputAct.diff;
		inputAct.OnSwitchMenu = (Action<bool>)Delegate.Combine(inputAct.OnSwitchMenu, new Action<bool>(this.SwitchLight));
		EffectAct component = this.scKi.GetComponent<EffectAct>();
		component.OnOpenEffect = (Action<Effect>)Delegate.Combine(component.OnOpenEffect, new Action<Effect>(this.CheckWinter));
		bool flag = PlayerPrefs.HasKey("forceportrait");
		if (InputAct.diff.isLandscape(false))
		{
			this.isTablet = true;
			return;
		}
		if (flag)
		{
			this.isTablet = true;
			return;
		}
		this.isTablet = false;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x0000530C File Offset: 0x0000350C
	private IEnumerator MoveUI(RectTransform targ, Vector2 diff, float time, float delay)
	{
		yield return new WaitForSeconds(delay);
		float t = 0f;
		Vector2 opos = targ.anchoredPosition;
		while (t < 1f)
		{
			float t2 = Easing.BackEaseIn(t, 0f, 1f, 1f);
			targ.anchoredPosition = Vector2.Lerp(opos, diff, t2);
			t += Time.deltaTime * 8f;
			yield return 0;
		}
		targ.anchoredPosition = diff;
		yield break;
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x0000532A File Offset: 0x0000352A
	public void ShowTop(bool direct = false)
	{
		this.DoMove(this.top, new Vector2(0f, -50f), 3.5f, direct, this.topcorout, 0f);
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00005358 File Offset: 0x00003558
	public void HideTop(bool direct = false)
	{
		this.DoMove(this.top, new Vector2(0f, 70f), 3f, direct, this.topcorout, 0f);
	}

	// Token: 0x060000DA RID: 218 RVA: 0x00005386 File Offset: 0x00003586
	private void DoMove(RectTransform targ, Vector2 diff, float time, bool direct, IEnumerator corout, float delay = 0f)
	{
		if (corout != null)
		{
			base.StopCoroutine(corout);
		}
		corout = null;
		if (direct)
		{
			targ.anchoredPosition = diff;
			return;
		}
		corout = this.MoveUI(targ, diff, time, delay);
		base.StartCoroutine(corout);
	}

	// Token: 0x060000DB RID: 219 RVA: 0x000053B9 File Offset: 0x000035B9
	public void ShowBottom(bool direct = false)
	{
		this.DoMove(this.bottom, new Vector2(0f, 50f), 3.5f, direct, this.botcorout, 0f);
	}

	// Token: 0x060000DC RID: 220 RVA: 0x000053E7 File Offset: 0x000035E7
	public void HideBottom(bool direct = false)
	{
		this.DoMove(this.bottom, new Vector2(0f, -50f), 3f, direct, this.botcorout, 0f);
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00005415 File Offset: 0x00003615
	private void ShowOptions(bool direct = false)
	{
		this.DoMove(this.opki, new Vector2(0f, -300f), 4f, direct, this.optioncorout, 3f);
	}

	// Token: 0x060000DE RID: 222 RVA: 0x00005443 File Offset: 0x00003643
	private void HideOptions(bool direct = false)
	{
		this.DoMove(this.opki, new Vector2(0f, -200f), 3.5f, direct, this.optioncorout, 0f);
	}

	// Token: 0x060000DF RID: 223 RVA: 0x00005474 File Offset: 0x00003674
	public void FadeToBlack()
	{
		SVGImage[] array = this.backCards;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].enabled = false;
		}
		base.StartCoroutine("FadeBackground", this.secondColor);
		base.StartCoroutine("Enlarge", 1600);
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x000054CC File Offset: 0x000036CC
	public void FadeToLight(GameStates state = GameStates.none)
	{
		if (state == GameStates.restart)
		{
			base.StartCoroutine("DelayedFade", false);
			return;
		}
		base.StartCoroutine("DelayedFade", true);
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x000054F7 File Offset: 0x000036F7
	private IEnumerator DelayedFade(bool withdelay)
	{
		if (withdelay)
		{
			this.backUI.CrossFadeColor(new Color(1f, 1f, 1f, 0.0001f), 0.6f, true, true);
		}
		this.HideTop(true);
		this.HideBottom(true);
		float seconds = withdelay ? 0.8f : 0f;
		yield return new WaitForSeconds(seconds);
		this.ShowTop(false);
		this.ShowBottom(false);
		seconds = (withdelay ? 0.5f : 0f);
		yield return new WaitForSeconds(seconds);
		if (withdelay)
		{
			this.backUI.CrossFadeColor(new Color(1f, 1f, 1f, 1f), 0.8f, true, true);
			this.ShowBacks(false);
		}
		base.StartCoroutine("FadeTexts", this.questionColor);
		base.StartCoroutine("FadeBackground", this.mainColor);
		if (this.isTablet)
		{
			base.StartCoroutine("Enlarge", 350);
		}
		else
		{
			base.StartCoroutine("Enlarge", 430);
		}
		yield break;
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x0000550D File Offset: 0x0000370D
	private IEnumerator FadeTexts(Color tcol)
	{
		float t = 0f;
		while (t < 1f)
		{
			this.question.color = (this.who.color = Color.Lerp(this.question.color, tcol, t + 0.05f));
			t += Time.deltaTime * 0.7f;
			yield return null;
		}
		yield break;
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00005523 File Offset: 0x00003723
	private IEnumerator FadeBackground(Color tcol)
	{
		float t = 0f;
		while (t < 1f)
		{
			this.backUI.color = Color.Lerp(this.backUI.color, tcol, t + 0.05f);
			t += Time.deltaTime * 0.7f;
			yield return null;
		}
		yield break;
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x00005539 File Offset: 0x00003739
	private IEnumerator Enlarge(float targ)
	{
		float t = 0f;
		Vector2 tsizebot = new Vector2(targ, this.backBottom.sizeDelta.y);
		Vector2 tsizetop = new Vector2(targ, this.backTop.sizeDelta.y);
		Vector2 tsizeback = new Vector2(targ, this.backUI.rectTransform.sizeDelta.y);
		Vector2 tsizeduel = new Vector2(targ, this.backDuel.sizeDelta.y);
		while (t < 1f)
		{
			this.backBottom.sizeDelta = Vector2.Lerp(this.backBottom.sizeDelta, tsizebot, t + 0.05f);
			this.backTop.sizeDelta = Vector2.Lerp(this.backTop.sizeDelta, tsizetop, t + 0.05f);
			this.backDuel.sizeDelta = Vector2.Lerp(this.backDuel.sizeDelta, tsizeduel, t + 0.05f);
			this.backUI.rectTransform.sizeDelta = Vector2.Lerp(this.backUI.rectTransform.sizeDelta, tsizeback, t + 0.05f);
			t += Time.deltaTime * 0.7f;
			yield return null;
		}
		this.backBottom.sizeDelta = tsizebot;
		this.backTop.sizeDelta = tsizetop;
		this.backDuel.sizeDelta = tsizeduel;
		this.backUI.rectTransform.sizeDelta = tsizeback;
		yield break;
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x00005550 File Offset: 0x00003750
	private void CheckWinter(Effect eff)
	{
		if (this.curBack.winter == null)
		{
			return;
		}
		if (eff.tag == "winter" || eff.tag == "summer")
		{
			base.StartCoroutine("ChangeBack", this.curBack);
		}
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x000055A8 File Offset: 0x000037A8
	private void PlayBackSound(Backgrounds type)
	{
		if (type <= Backgrounds.godseye)
		{
			if (type <= Backgrounds.winterfell)
			{
				switch (type)
				{
				case Backgrounds.defaut:
					goto IL_1DC;
				case (Backgrounds)1:
				case (Backgrounds)3:
					return;
				case Backgrounds.forest:
					JukeBox.diff.PlaySound(SFXTypes.env_forest, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				case Backgrounds.kingslanding:
					JukeBox.diff.PlaySound(SFXTypes.env_kingslanding, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				default:
					switch (type)
					{
					case Backgrounds.tavern:
						JukeBox.diff.PlaySound(SFXTypes.env_tavern, false, false, 2.5f, -1, 1.5f, 1f);
						JukeBox.diff.StopMusic(false);
						return;
					case (Backgrounds)9:
					case (Backgrounds)11:
						return;
					case Backgrounds.wall:
						break;
					case Backgrounds.winterfell:
						JukeBox.diff.PlaySound(SFXTypes.env_winterfell, false, false, 2.5f, -1, 1.5f, 1f);
						return;
					default:
						return;
					}
					break;
				}
			}
			else
			{
				if (type == Backgrounds.maproom)
				{
					goto IL_1BD;
				}
				switch (type)
				{
				case Backgrounds.trone:
					goto IL_1DC;
				case Backgrounds.battle_after:
					JukeBox.diff.PlaySound(SFXTypes.env_battle_after, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				case (Backgrounds)32:
					return;
				case Backgrounds.battle_before:
					JukeBox.diff.PlaySound(SFXTypes.env_battle, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				default:
					if (type != Backgrounds.godseye)
					{
						return;
					}
					break;
				}
			}
			JukeBox.diff.PlaySound(SFXTypes.env_forest_winter, false, false, 2.5f, -1, 1.5f, 1f);
			return;
			IL_1DC:
			JukeBox.diff.PlaySound(SFXTypes.env_throne, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		if (type <= Backgrounds.dungeon)
		{
			if (type == Backgrounds.hills)
			{
				JukeBox.diff.PlaySound(SFXTypes.env_hills, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (type == Backgrounds.boats)
			{
				JukeBox.diff.PlaySound(SFXTypes.env_ocean, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (type != Backgrounds.dungeon)
			{
				return;
			}
			JukeBox.diff.PlaySound(SFXTypes.env_dungeon, false, false, 2.5f, -1, 1.5f, 1f);
			JukeBox.diff.PlaySound(SFXTypes.sfx_enter_dungon, false, false, 2.5f, -1, 1.5f, 1f);
			JukeBox.diff.StopMusic(false);
			return;
		}
		else
		{
			if (type == Backgrounds.eternity)
			{
				JukeBox.diff.PlaySound(SFXTypes.env_dungeon, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (type != Backgrounds.invasion)
			{
				if (type != Backgrounds.tourney)
				{
					return;
				}
				JukeBox.diff.PlaySound(SFXTypes.env_tourney, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
		}
		IL_1BD:
		JukeBox.diff.PlaySound(SFXTypes.env_map_room, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00005837 File Offset: 0x00003A37
	private void CloseBack(Backgrounds type)
	{
		if (type == Backgrounds.tavern || type == Backgrounds.dungeon)
		{
			JukeBox.diff.RestartMusic();
			return;
		}
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00005850 File Offset: 0x00003A50
	private SVGAsset GetBack(Background back)
	{
		if (back.winter != null && GameAct.diff.GetBool("winter"))
		{
			JukeBox.diff.PlaySound(SFXTypes.env_winter, false, false, 2.5f, -1, 1.5f, 1f);
			return back.winter;
		}
		if (back.alternative != null && GameAct.diff.GetInt(Variables.dynasty) % 3 == 1)
		{
			this.PlayBackSound(back.type);
			return back.alternative;
		}
		this.PlayBackSound(back.type);
		return back.image;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x000058E5 File Offset: 0x00003AE5
	private IEnumerator ChangeBack(Background targ)
	{
		SVGImage back2Image = this.ipadBack.transform.GetChild(0).GetComponent<SVGImage>();
		back2Image.vectorGraphics = this.ipadBack.vectorGraphics;
		this.SetBack(this.tarBack, false);
		back2Image.CrossFadeColor(new Color(1f, 1f, 1f, 1E-05f), 2f, true, true);
		if (InputAct.diff.isLandscape(true))
		{
			yield return new WaitForSeconds(2.8f);
		}
		else
		{
			yield return new WaitForSeconds(3.2f);
		}
		this.SetBack(this.tarBack, false);
		back2Image.vectorGraphics = null;
		back2Image.CrossFadeColor(Color.white, 0.01f, true, true);
		yield return new WaitForSeconds(0.02f);
		yield break;
	}

	// Token: 0x060000EA RID: 234 RVA: 0x000058F4 File Offset: 0x00003AF4
	private IEnumerator ChangeColorUi(bool quick)
	{
		float duration = quick ? 0.4f : 0.8f;
		this.backUI.CrossFadeColor(new Color(1f, 1f, 1f, 0.0001f), duration, true, true);
		if (quick)
		{
			yield return new WaitForSeconds(2.5f);
		}
		else if (InputAct.diff.isLandscape(true))
		{
			yield return new WaitForSeconds(3.8f);
		}
		else
		{
			yield return new WaitForSeconds(4.2f);
		}
		this.backUI.CrossFadeColor(Color.white, 0.2f, true, true);
		yield break;
	}

	// Token: 0x060000EB RID: 235 RVA: 0x0000590A File Offset: 0x00003B0A
	private IEnumerator DoTransit(bool quick)
	{
		this.doTrans = true;
		this.HideTop(false);
		this.HideBottom(false);
		if (quick)
		{
			this.backCards[0].enabled = false;
		}
		GameAct.diff.DeleteQuestion();
		Background background = this.backgrounds.Find((Background it) => it.type == this.tarBack);
		if (this.curBack != background)
		{
			base.StartCoroutine("ChangeBack", background);
		}
		base.StartCoroutine("ChangeColorUi", quick);
		RectTransform back = this.ipadBack.rectTransform;
		float speed = quick ? 0.5f : 0.25f;
		float t = 0f;
		Vector2 opos = back.anchoredPosition;
		Vector3 oScale = back.localScale;
		Vector3 vector = (background.spots.Count > this.curSpot) ? background.spots[this.curSpot] : new Vector3(0f, 0f, 1f);
		Vector2 tpos = new Vector2(vector.x, vector.y);
		Vector3 tscale = new Vector3(vector.z, vector.z, 1f);
		while (t < 1f)
		{
			float t2 = Easing.CubicEaseInOut(t, 0f, 1f, 1f);
			back.anchoredPosition = Vector2.LerpUnclamped(opos, tpos, t2);
			back.localScale = Vector3.LerpUnclamped(oScale, tscale, t2);
			t += Time.deltaTime * speed;
			yield return 0;
		}
		if (!quick)
		{
			this.ShowBacks(false);
		}
		else if (GameAct.diff.cardType != CardTypes.end)
		{
			this.backCards[0].enabled = true;
		}
		this.ShowTop(false);
		this.ShowBottom(false);
		yield return new WaitForSeconds(0.02f);
		this.doTrans = false;
		yield break;
	}

	// Token: 0x060000EC RID: 236 RVA: 0x00005920 File Offset: 0x00003B20
	private bool TransitBack(CardTypes lastcard)
	{
		if (lastcard == CardTypes.intercale)
		{
			this.backCards[0].enabled = false;
			return true;
		}
		if (!this.isTransitionning)
		{
			this.isTransitionning = true;
			base.StopCoroutine("DoTransit");
			base.StartCoroutine("DoTransit", this.backCards[0].enabled);
			return false;
		}
		if (this.doTrans)
		{
			return false;
		}
		GameAct gameAct = GameAct.diff;
		gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Remove(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBack));
		this.isTransitionning = false;
		return true;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x000059B4 File Offset: 0x00003BB4
	public void PrepareBackSwitch(string backname, int spot, bool setdef = false, bool hidebackatstart = false)
	{
		try
		{
			this.tarBack = (Backgrounds)Enum.Parse(typeof(Backgrounds), backname);
			if (setdef)
			{
				this.SetBackDirect(0, this.tarBack, true);
			}
			else if (this.tarBack != this.curBack.type || this.curSpot != spot)
			{
				this.curSpot = spot;
				if (hidebackatstart)
				{
					this.backCards[0].enabled = false;
				}
				GameAct gameAct = GameAct.diff;
				gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Combine(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBack));
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00005A64 File Offset: 0x00003C64
	private void GoNext()
	{
		if (this.doTrans)
		{
			this.doTrans = false;
			AnimBut.diff.Lock(false);
		}
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00005A80 File Offset: 0x00003C80
	private IEnumerator DoTransitEnd()
	{
		this.doTrans = true;
		this.HideTop(false);
		this.HideBottom(false);
		this.ShowOptions(false);
		GameAct.diff.DeleteQuestion();
		if (this.allObjInGame != null)
		{
			foreach (object obj in this.allObjInGame)
			{
				Object.Destroy(((Transform)obj).gameObject);
			}
		}
		if (this.scKi.monarch.bearer == Bearers.commander)
		{
			yield return new WaitForSeconds(0.3f);
			this.GoNext();
		}
		else
		{
			this.deadKingGroup.SetActive(true);
			if (GameAct.diff.GetInt(Variables.dynasty) == 0)
			{
				yield return new WaitForSeconds(1f);
			}
			else
			{
				yield return new WaitForSeconds(2.5f);
			}
			AnimBut.diff.UnLock(ControlModes.nextmenu, false, true);
			InputAct.diff.GetActionFocus(new Action(this.GoNext), true);
		}
		this.HideTop(true);
		yield break;
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00005A90 File Offset: 0x00003C90
	private bool TransitBackEnd(CardTypes lastcard)
	{
		if (!this.isTransitionning)
		{
			this.isTransitionning = true;
			base.StopCoroutine("DoTransitEnd");
			base.StartCoroutine("DoTransitEnd");
			return false;
		}
		if (this.doTrans)
		{
			return false;
		}
		this.TurnLight(true);
		this.backCards[0].enabled = true;
		this.deadKingGroup.SetActive(false);
		GameAct gameAct = GameAct.diff;
		gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Remove(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBackEnd));
		this.isTransitionning = false;
		JukeBox.diff.PlayMusic(Bearers.melisandre, false);
		return true;
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00005B2C File Offset: 0x00003D2C
	public void PrepareBackEnd()
	{
		try
		{
			GameAct gameAct = GameAct.diff;
			gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Combine(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBackEnd));
		}
		catch
		{
		}
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00005B74 File Offset: 0x00003D74
	private IEnumerator DoTransitNew()
	{
		this.doTrans = true;
		GameAct.diff.DeleteQuestion();
		yield return new WaitForSeconds(0.5f);
		this.newKingGroup.SetActive(true);
		yield return new WaitForSeconds(1.5f);
		if (this.doTrans)
		{
			this.doTrans = false;
		}
		yield break;
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00005B84 File Offset: 0x00003D84
	private bool TransitBackNew(CardTypes lastcard)
	{
		if (!this.isTransitionning)
		{
			this.backCards[0].enabled = false;
			this.isTransitionning = true;
			base.StopCoroutine("DoTransitNew");
			base.StartCoroutine("DoTransitNew");
			this.scWho.ShowName("", "");
			return false;
		}
		if (this.doTrans)
		{
			return false;
		}
		this.HideOptions(false);
		this.TurnLight(false);
		base.StopCoroutine("DoTransitNew");
		this.newKingGroup.SetActive(false);
		GameAct gameAct = GameAct.diff;
		gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Remove(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBackNew));
		this.isTransitionning = false;
		GameAct.diff.StartReign(true);
		if (this.allObjInGame != null)
		{
			this.scKi.GetComponent<ObjectiveAct>().ShowObjectives(this.allObjInGame, 0, true, false, 2f);
		}
		return true;
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00005C70 File Offset: 0x00003E70
	public void PrepareBackNew()
	{
		GameAct gameAct = GameAct.diff;
		gameAct.OnCardHiding = (Func<CardTypes, bool>)Delegate.Combine(gameAct.OnCardHiding, new Func<CardTypes, bool>(this.TransitBackNew));
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00005C98 File Offset: 0x00003E98
	public void SwitchWithTop(RectTransform target, bool hidetop)
	{
		if (this.othercorout != null)
		{
			base.StopCoroutine(this.othercorout);
			this.othercorout = null;
		}
		this.othercorout = this.DoSwitchTop(target, hidetop);
		base.StartCoroutine(this.othercorout);
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00005CD0 File Offset: 0x00003ED0
	private IEnumerator DoSwitchTop(RectTransform target, bool hidetop)
	{
		Vector2 targ = new Vector2(0f, 0f);
		Vector2 opo = target.anchoredPosition;
		if (hidetop)
		{
			this.HideTop(false);
			yield return new WaitForSeconds(0.3f);
		}
		else
		{
			targ = new Vector2(0f, 120f);
		}
		float t = 0f;
		while (t < 1f)
		{
			target.anchoredPosition = Vector2.Lerp(opo, targ, t);
			t += Time.deltaTime * 3f;
			yield return 0;
		}
		target.anchoredPosition = targ;
		if (!hidetop)
		{
			this.ShowTop(false);
		}
		yield break;
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x00005CED File Offset: 0x00003EED
	private void SwitchLight(bool on)
	{
		if (this.haslight)
		{
			this.postpro.enabled = !on;
		}
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x00005D08 File Offset: 0x00003F08
	public void TurnLight(bool on)
	{
		Behaviour behaviour = this.postpro;
		this.haslight = on;
		behaviour.enabled = on;
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00005D2C File Offset: 0x00003F2C
	public bool isInside()
	{
		if (this.curBack == null)
		{
			return false;
		}
		Backgrounds type = this.curBack.type;
		return type == Backgrounds.tavern || type == Backgrounds.dungeon;
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00005D5B File Offset: 0x00003F5B
	public void SetBackDirect(int spot = 0, Backgrounds back = Backgrounds.defaut, bool becomesDef = false)
	{
		this.SetBack(back, becomesDef);
		this.SetBackDirect(spot);
	}

	// Token: 0x060000FB RID: 251 RVA: 0x00005D6C File Offset: 0x00003F6C
	private void SetBackDirect(int spot = 0)
	{
		if (this.curBack.spots.Count < spot + 1)
		{
			if (this.curBack.spots.Count == 0)
			{
				this.ipadBack.rectTransform.anchoredPosition = new Vector2(0f, 0f);
				this.ipadBack.rectTransform.localScale = new Vector3(1f, 1f, 1f);
				return;
			}
			spot = this.curBack.spots.Count - 1;
		}
		Vector3 vector = this.curBack.spots[spot];
		this.ipadBack.rectTransform.anchoredPosition = new Vector2(vector.x, vector.y);
		this.ipadBack.rectTransform.localScale = new Vector3(vector.z, vector.z, 1f);
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00005E54 File Offset: 0x00004054
	public void SetBack(Backgrounds back = Backgrounds.defaut, bool becomesDef = false)
	{
		Background background = this.curBack;
		if (becomesDef)
		{
			this.curBack = null;
		}
		if (back == Backgrounds.defaut && this.defautBack != null)
		{
			this.curBack = this.defautBack;
		}
		else
		{
			this.curBack = this.backgrounds.Find((Background it) => it.type == back);
			if (becomesDef)
			{
				this.defautBack = this.curBack;
			}
		}
		if (background != null && background.type != this.curBack.type)
		{
			this.CloseBack(background.type);
		}
		this.ipadBack.vectorGraphics = this.GetBack(this.curBack);
	}

	// Token: 0x060000FD RID: 253 RVA: 0x00005F02 File Offset: 0x00004102
	public void HideBack()
	{
		this.backCards[0].enabled = false;
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00005F12 File Offset: 0x00004112
	public void ShowBack()
	{
		this.backCards[0].enabled = true;
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00005F22 File Offset: 0x00004122
	public void ShowBacks(bool keepone = false)
	{
		base.StartCoroutine("DoShowBack", keepone);
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00005F36 File Offset: 0x00004136
	private IEnumerator DoShowBack(bool keepone)
	{
		yield return null;
		yield return null;
		JukeBox.diff.PlaySound(SFXTypes.card_stacking, false, false, 2.5f, -1, 1.5f, 1f);
		float t = 0.2f;
		int num = keepone ? 1 : 0;
		int num2;
		for (int i = num; i < this.backCards.Length; i = num2 + 1)
		{
			yield return new WaitForSeconds(t);
			base.StartCoroutine(this.ShowBack(this.backCards[i], i));
			t -= 0.02f;
			HapticAct.diff.Tap(iOSHapticFeedback.iOSFeedbackType.ImpactLight);
			num2 = i;
		}
		yield return new WaitForSeconds(0.1f);
		HapticAct.diff.BigChange();
		yield break;
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00005F4C File Offset: 0x0000414C
	private IEnumerator ShowBack(SVGImage ba, int id)
	{
		ba.enabled = true;
		float t = 0f;
		Vector2 opos = new Vector2(-300f, 100f);
		Vector2 tpos = Vector2.zero;
		RectTransform trans = ba.GetComponent<RectTransform>();
		while (t < 1f)
		{
			trans.anchoredPosition = Vector2.Lerp(opos, tpos, Easing.QuintEaseOut(t, 0f, 1f, 1f));
			t += Time.deltaTime;
			yield return null;
		}
		trans.anchoredPosition = tpos;
		if (id > 0)
		{
			ba.enabled = false;
		}
		yield break;
	}

	// Token: 0x040000BC RID: 188
	public bool isiPad;

	// Token: 0x040000BD RID: 189
	public List<Background> backgrounds;

	// Token: 0x040000BE RID: 190
	public SVGImage[] backCards;

	// Token: 0x040000BF RID: 191
	public Backgrounds defBack;

	// Token: 0x040000C0 RID: 192
	private Background curBack;

	// Token: 0x040000C1 RID: 193
	private int curSpot;

	// Token: 0x040000C2 RID: 194
	public Text question;

	// Token: 0x040000C3 RID: 195
	public Text who;

	// Token: 0x040000C4 RID: 196
	public WhoAct scWho;

	// Token: 0x040000C5 RID: 197
	public Color mainColor;

	// Token: 0x040000C6 RID: 198
	public Color secondColor;

	// Token: 0x040000C7 RID: 199
	public Color questionColor;

	// Token: 0x040000C8 RID: 200
	public Image backUI;

	// Token: 0x040000C9 RID: 201
	public RectTransform bottom;

	// Token: 0x040000CA RID: 202
	public RectTransform top;

	// Token: 0x040000CB RID: 203
	public RectTransform opki;

	// Token: 0x040000CC RID: 204
	public RectTransform backBottom;

	// Token: 0x040000CD RID: 205
	public RectTransform backTop;

	// Token: 0x040000CE RID: 206
	public RectTransform backDuel;

	// Token: 0x040000CF RID: 207
	public static BackgroundAct diff;

	// Token: 0x040000D0 RID: 208
	public SVGImage ipadBack;

	// Token: 0x040000D1 RID: 209
	private Background defautBack;

	// Token: 0x040000D2 RID: 210
	public GameObject ModalFirst;

	// Token: 0x040000D3 RID: 211
	private bool isTablet;

	// Token: 0x040000D4 RID: 212
	private Action OnGlitch;

	// Token: 0x040000D5 RID: 213
	private Backgrounds tarBack;

	// Token: 0x040000D6 RID: 214
	private bool isTransitionning;

	// Token: 0x040000D7 RID: 215
	private bool doTrans;

	// Token: 0x040000D8 RID: 216
	public GameObject deadKingGroup;

	// Token: 0x040000D9 RID: 217
	public GameObject newKingGroup;

	// Token: 0x040000DA RID: 218
	private Vector2 oriPos;

	// Token: 0x040000DB RID: 219
	private SleekRenderPostProcess postpro;

	// Token: 0x040000DC RID: 220
	public KingdomAct scKi;

	// Token: 0x040000DD RID: 221
	public Transform allObjInGame;

	// Token: 0x040000DE RID: 222
	private IEnumerator topcorout;

	// Token: 0x040000DF RID: 223
	private IEnumerator botcorout;

	// Token: 0x040000E0 RID: 224
	private IEnumerator othercorout;

	// Token: 0x040000E1 RID: 225
	private IEnumerator optioncorout;

	// Token: 0x040000E2 RID: 226
	private bool haslight;
}
