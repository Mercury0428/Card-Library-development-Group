﻿using System;
using UnityEngine;

// Token: 0x02000010 RID: 16
public class LockAct : MonoBehaviour
{
	// Token: 0x06000087 RID: 135 RVA: 0x00003E98 File Offset: 0x00002098
	public void AnimFinished()
	{
		base.gameObject.SetActive(false);
	}
}
