﻿using System;
using System.Collections;
using System.Text;

namespace Midworld
{
	// Token: 0x02000225 RID: 549
	internal class UnityWebRequest
	{
		// Token: 0x170002CE RID: 718
		// (get) Token: 0x060010F9 RID: 4345 RVA: 0x00063241 File Offset: 0x00061441
		// (set) Token: 0x060010FA RID: 4346 RVA: 0x00063249 File Offset: 0x00061449
		public string method { get; set; }

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x060010FB RID: 4347 RVA: 0x00063252 File Offset: 0x00061452
		// (set) Token: 0x060010FC RID: 4348 RVA: 0x0006325A File Offset: 0x0006145A
		public string protocol { get; set; }

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x060010FD RID: 4349 RVA: 0x00063263 File Offset: 0x00061463
		// (set) Token: 0x060010FE RID: 4350 RVA: 0x0006326B File Offset: 0x0006146B
		public Uri uri { get; protected set; }

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x060010FF RID: 4351 RVA: 0x00063274 File Offset: 0x00061474
		// (set) Token: 0x06001100 RID: 4352 RVA: 0x0006327C File Offset: 0x0006147C
		public Hashtable headers { get; protected set; }

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06001101 RID: 4353 RVA: 0x00063285 File Offset: 0x00061485
		// (set) Token: 0x06001102 RID: 4354 RVA: 0x0006328D File Offset: 0x0006148D
		public byte[] body
		{
			get
			{
				return this._body;
			}
			set
			{
				this._body = value;
			}
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x00063296 File Offset: 0x00061496
		public UnityWebRequest(string uri) : this(new Uri(uri))
		{
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x000632A4 File Offset: 0x000614A4
		public UnityWebRequest(Uri uri)
		{
			this.method = "GET";
			this.protocol = "HTTP/1.1";
			this.uri = uri;
			this.headers = new Hashtable();
			this.headers["Host"] = uri.Host;
			this.headers["Connection"] = "Keep-Alive";
			this.headers["Accept-Charset"] = "utf-8";
			this.headers["User-Agent"] = "Mozilla/5.0 (Unity3d)";
			this.headers["Accept-Encoding"] = "gzip, deflate";
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x00063349 File Offset: 0x00061549
		public UnityWebResponse GetResponse()
		{
			return this.GetResponse(null);
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x00063354 File Offset: 0x00061554
		public UnityWebResponse GetResponse(Action<UnityWebResponse> callback)
		{
			UnityWebResponse unityWebResponse = new UnityWebResponse(this);
			if (callback != null)
			{
				unityWebResponse.done = delegate(UnityCoroutine coroutine)
				{
					callback(coroutine as UnityWebResponse);
				};
			}
			return unityWebResponse;
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x00063390 File Offset: 0x00061590
		public string DumpHeaders()
		{
			if (this.headers == null)
			{
				return "";
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(string.Format("{0} {1} {2}", this.method, this.uri.PathAndQuery, this.protocol));
			foreach (object obj in this.headers)
			{
				DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
				if (dictionaryEntry.Value is string[])
				{
					for (int i = 0; i < (dictionaryEntry.Value as string[]).Length; i++)
					{
						stringBuilder.AppendLine(string.Format("{0}: {1}", dictionaryEntry.Key, (dictionaryEntry.Value as string[])[i]));
					}
				}
				else
				{
					stringBuilder.AppendLine(string.Format("{0}: {1}", dictionaryEntry.Key, dictionaryEntry.Value));
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x04000DA4 RID: 3492
		private byte[] _body;
	}
}
