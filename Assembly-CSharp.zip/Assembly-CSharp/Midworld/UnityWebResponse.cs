﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using Ionic.Zlib;

namespace Midworld
{
	// Token: 0x02000226 RID: 550
	internal class UnityWebResponse : UnityCoroutine
	{
		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06001108 RID: 4360 RVA: 0x00063498 File Offset: 0x00061698
		// (set) Token: 0x06001109 RID: 4361 RVA: 0x000634A0 File Offset: 0x000616A0
		public string httpVersion { get; protected set; }

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x0600110A RID: 4362 RVA: 0x000634A9 File Offset: 0x000616A9
		// (set) Token: 0x0600110B RID: 4363 RVA: 0x000634B1 File Offset: 0x000616B1
		public int statusCode { get; protected set; }

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x0600110C RID: 4364 RVA: 0x000634BA File Offset: 0x000616BA
		// (set) Token: 0x0600110D RID: 4365 RVA: 0x000634C2 File Offset: 0x000616C2
		public string reasonPhrase { get; protected set; }

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x0600110E RID: 4366 RVA: 0x000634CB File Offset: 0x000616CB
		// (set) Token: 0x0600110F RID: 4367 RVA: 0x000634D3 File Offset: 0x000616D3
		public Hashtable headers { get; protected set; }

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06001110 RID: 4368 RVA: 0x000634DC File Offset: 0x000616DC
		// (set) Token: 0x06001111 RID: 4369 RVA: 0x000634E4 File Offset: 0x000616E4
		public byte[] bytes { get; protected set; }

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06001112 RID: 4370 RVA: 0x000634ED File Offset: 0x000616ED
		public string text
		{
			get
			{
				if (this.cachedText == null)
				{
					this.cachedText = Encoding.UTF8.GetString(this.bytes);
				}
				return this.cachedText;
			}
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x06001113 RID: 4371 RVA: 0x00063513 File Offset: 0x00061713
		// (set) Token: 0x06001114 RID: 4372 RVA: 0x0006351B File Offset: 0x0006171B
		public Exception error { get; protected set; }

		// Token: 0x06001115 RID: 4373 RVA: 0x00063524 File Offset: 0x00061724
		public UnityWebResponse(UnityWebRequest request)
		{
			UnityWebResponse <>4__this = this;
			ThreadPool.QueueUserWorkItem(delegate(object arg)
			{
				try
				{
					int num = 0;
					TcpClient tcpClient = new TcpClient();
					Uri uri = request.uri;
					tcpClient.Connect(uri.Host, uri.Port);
					bool flag = true;
					Stream stream = null;
					for (;;)
					{
						if (flag)
						{
							tcpClient.SendTimeout = 5000;
							tcpClient.ReceiveTimeout = 5000;
							stream = tcpClient.GetStream();
							if (uri.Scheme == "https")
							{
								stream = new SslStream(stream, false, (object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error) => true);
								(stream as SslStream).AuthenticateAsClient(uri.Host);
							}
						}
						BinaryWriter binaryWriter = new BinaryWriter(stream);
						binaryWriter.Write(Encoding.UTF8.GetBytes(string.Concat(new string[]
						{
							request.method,
							" ",
							uri.PathAndQuery,
							" ",
							request.protocol,
							"\r\n"
						})));
						request.headers["Host"] = uri.Host;
						foreach (object obj in request.headers)
						{
							DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
							if (dictionaryEntry.Key is string && dictionaryEntry.Value is string)
							{
								binaryWriter.Write(Encoding.UTF8.GetBytes(string.Concat(new object[]
								{
									dictionaryEntry.Key,
									": ",
									dictionaryEntry.Value,
									"\r\n"
								})));
							}
							else if (dictionaryEntry.Key is string && dictionaryEntry.Value is string[])
							{
								for (int i = 0; i < (dictionaryEntry.Value as string[]).Length; i++)
								{
									binaryWriter.Write(Encoding.UTF8.GetBytes(string.Concat(new object[]
									{
										dictionaryEntry.Key,
										": ",
										(dictionaryEntry.Value as string[])[i],
										"\r\n"
									})));
								}
							}
						}
						if (request.body != null)
						{
							binaryWriter.Write(Encoding.UTF8.GetBytes("Content-Length:" + request.body.Length + "\r\n\r\n"));
							binaryWriter.Write(request.body);
						}
						else
						{
							binaryWriter.Write(Encoding.UTF8.GetBytes("\r\n"));
						}
						BufferedStream bufferedStream = new BufferedStream(stream);
						List<string> list = new List<string>();
						for (;;)
						{
							string text = <>4__this.ReadLine(bufferedStream);
							if (text.Length == 0)
							{
								break;
							}
							list.Add(text);
						}
						string[] array = list[0].Split(new char[]
						{
							' '
						});
						<>4__this.httpVersion = array[0];
						<>4__this.statusCode = int.Parse(array[1]);
						<>4__this.reasonPhrase = string.Join(" ", array, 2, array.Length - 2);
						<>4__this.headers = new Hashtable();
						for (int j = 1; j < list.Count; j++)
						{
							string key = list[j].Substring(0, list[j].IndexOf(':')).Trim();
							string text2 = list[j].Substring(list[j].IndexOf(':') + 1).Trim();
							if (!<>4__this.headers.ContainsKey(key))
							{
								<>4__this.headers.Add(key, text2);
							}
							else if (<>4__this.headers[key] is string)
							{
								string text3 = <>4__this.headers[key] as string;
								string[] value = new string[]
								{
									text3,
									text2
								};
								<>4__this.headers[key] = value;
							}
							else if (<>4__this.headers[key] is string[])
							{
								string[] array2 = <>4__this.headers[key] as string[];
								string[] array3 = new string[array2.Length + 1];
								array2.CopyTo(array3, 0);
								array3[array2.Length - 1] = text2;
								<>4__this.headers[key] = array3;
							}
						}
						int num2 = -1;
						if (<>4__this.headers.ContainsKey("Content-Length"))
						{
							num2 = int.Parse(<>4__this.headers["Content-Length"] as string);
						}
						string a = null;
						if (<>4__this.headers.ContainsKey("Transfer-Encoding"))
						{
							a = (<>4__this.headers["Transfer-Encoding"] as string).ToLower();
						}
						if (num2 >= 0)
						{
							<>4__this.bytes = new byte[num2];
							for (int k = 0; k < num2; k += bufferedStream.Read(<>4__this.bytes, k, <>4__this.bytes.Length - k))
							{
							}
						}
						else if (a == "chunked")
						{
							MemoryStream memoryStream = new MemoryStream(4096);
							byte[] array4 = new byte[4096];
							for (;;)
							{
								string text4 = <>4__this.ReadLine(bufferedStream);
								if (text4.Length == 0)
								{
									break;
								}
								int num3 = Convert.ToInt32(text4, 16);
								if (num3 == 0)
								{
									break;
								}
								int num4;
								for (int l = 0; l < num3; l += num4)
								{
									num4 = bufferedStream.Read(array4, 0, (num3 - l < array4.Length) ? (num3 - l) : array4.Length);
									memoryStream.Write(array4, 0, num4);
								}
								bufferedStream.ReadByte();
								bufferedStream.ReadByte();
							}
							<>4__this.bytes = memoryStream.ToArray();
							memoryStream.Dispose();
						}
						else
						{
							MemoryStream memoryStream2 = new MemoryStream(4096);
							byte[] array5 = new byte[4096];
							int num5;
							do
							{
								num5 = bufferedStream.Read(array5, 0, array5.Length);
								memoryStream2.Write(array5, 0, num5);
							}
							while (num5 > 0);
							<>4__this.bytes = memoryStream2.ToArray();
							memoryStream2.Dispose();
						}
						<>4__this.cachedText = null;
						if ((<>4__this.statusCode != 301 && <>4__this.statusCode != 302 && <>4__this.statusCode != 303 && <>4__this.statusCode != 307) || !<>4__this.headers.ContainsKey("Location") || num >= 5)
						{
							break;
						}
						string host = uri.Host;
						string relativeUri = <>4__this.headers["Location"] as string;
						uri = new Uri(uri, relativeUri);
						if (host != uri.Host)
						{
							stream.Close();
							tcpClient.Close();
							tcpClient = new TcpClient();
							tcpClient.Connect(uri.Host, uri.Port);
							flag = true;
						}
						else
						{
							flag = false;
						}
						num++;
						if (num >= 5)
						{
							goto IL_7B9;
						}
					}
					if (<>4__this.headers.ContainsKey("Content-Encoding"))
					{
						<>4__this.bytes = UnityWebResponse.Decompress((<>4__this.headers["Content-Encoding"] as string).ToLower(), <>4__this.bytes);
					}
					stream.Close();
					tcpClient.Close();
					IL_7B9:;
				}
				catch (Exception error)
				{
					Exception error2;
					<>4__this.error = error2;
				}
				finally
				{
					<>4__this.isDone = true;
				}
			});
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x00063550 File Offset: 0x00061750
		private string ReadLine(BufferedStream stream)
		{
			List<byte> list = new List<byte>(4096);
			for (;;)
			{
				int num = stream.ReadByte();
				if (num == -1)
				{
					break;
				}
				byte b = (byte)num;
				if (b != 13)
				{
					if (b == 10)
					{
						break;
					}
					list.Add(b);
				}
			}
			return Encoding.UTF8.GetString(list.ToArray());
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x0006359C File Offset: 0x0006179C
		private static byte[] Decompress(string encoding, byte[] data)
		{
			Stream stream;
			if (encoding == "gzip")
			{
				stream = new GZipStream(new MemoryStream(data), CompressionMode.Decompress);
			}
			else
			{
				if (!(encoding == "deflate"))
				{
					return null;
				}
				stream = new DeflateStream(new MemoryStream(data), CompressionMode.Decompress);
			}
			MemoryStream memoryStream = new MemoryStream(data.Length);
			byte[] array = new byte[4096];
			int count;
			while ((count = stream.Read(array, 0, array.Length)) > 0)
			{
				memoryStream.Write(array, 0, count);
			}
			return memoryStream.ToArray();
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x00063618 File Offset: 0x00061818
		public string DumpHeaders()
		{
			if (this.headers == null)
			{
				return "";
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(string.Format("{0} {1} {2}", this.httpVersion, this.statusCode, this.reasonPhrase));
			foreach (object obj in this.headers)
			{
				DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
				if (dictionaryEntry.Value is string)
				{
					stringBuilder.AppendLine(string.Format("{0}: {1}", dictionaryEntry.Key, dictionaryEntry.Value));
				}
				else
				{
					for (int i = 0; i < (dictionaryEntry.Value as string[]).Length; i++)
					{
						stringBuilder.AppendLine(string.Format("{0}: {1}", dictionaryEntry.Key, (dictionaryEntry.Value as string[])[i]));
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x04000DA5 RID: 3493
		private const int TIMEOUT = 5000;

		// Token: 0x04000DA6 RID: 3494
		private const int MAX_REDIRECTION = 5;

		// Token: 0x04000DAC RID: 3500
		private string cachedText;
	}
}
