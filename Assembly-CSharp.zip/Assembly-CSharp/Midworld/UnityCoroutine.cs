﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Midworld
{
	// Token: 0x02000224 RID: 548
	internal class UnityCoroutine : IEnumerator
	{
		// Token: 0x170002CB RID: 715
		// (get) Token: 0x060010EF RID: 4335 RVA: 0x00063124 File Offset: 0x00061324
		// (set) Token: 0x060010F0 RID: 4336 RVA: 0x0006312C File Offset: 0x0006132C
		public bool isDone
		{
			get
			{
				return this._isDone;
			}
			protected set
			{
				this._isDone = value;
				if (this._isDone && !this.isCoroutine && this.done != null)
				{
					this.done(this);
					this.done = null;
				}
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x060010F1 RID: 4337 RVA: 0x00063160 File Offset: 0x00061360
		// (set) Token: 0x060010F2 RID: 4338 RVA: 0x00063168 File Offset: 0x00061368
		public Action<UnityCoroutine> done
		{
			get
			{
				return this._done;
			}
			set
			{
				this._done = value;
				if (this.isDone)
				{
					this._done(this);
					this._done = null;
				}
			}
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x0006318C File Offset: 0x0006138C
		protected UnityCoroutine() : this(null)
		{
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x00063195 File Offset: 0x00061395
		public UnityCoroutine(Action<UnityCoroutine> doneCallback)
		{
			this.done = doneCallback;
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x000631AF File Offset: 0x000613AF
		public void DoSync()
		{
			while (this.MoveNext())
			{
			}
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x000631BC File Offset: 0x000613BC
		public bool MoveNext()
		{
			this.isCoroutine = true;
			if (!this.isDone && this.routines.Count > 0)
			{
				this.routines.Dequeue()();
			}
			if (this.isDone && this.done != null)
			{
				this.done(this);
				this.done = null;
			}
			return !this.isDone;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x00063222 File Offset: 0x00061422
		public void Reset()
		{
			this.routines.Clear();
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x060010F8 RID: 4344 RVA: 0x0006322F File Offset: 0x0006142F
		public object Current
		{
			get
			{
				return this.routines.Count;
			}
		}

		// Token: 0x04000D9C RID: 3484
		private bool _isDone;

		// Token: 0x04000D9D RID: 3485
		private Action<UnityCoroutine> _done;

		// Token: 0x04000D9E RID: 3486
		protected Queue<Action> routines = new Queue<Action>();

		// Token: 0x04000D9F RID: 3487
		private bool isCoroutine;
	}
}
