﻿using System;
using System.Collections;
using System.Collections.Generic;
using Rewired;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Token: 0x02000057 RID: 87
public class InputAct : MonoBehaviour
{
	// Token: 0x0600030E RID: 782 RVA: 0x00013AF4 File Offset: 0x00011CF4
	private void InitMenuNav()
	{
		Inputs inputs = this.curInput;
		if (inputs <= Inputs.keyboard || inputs == Inputs.tv)
		{
			this.eventSys.sendNavigationEvents = true;
		}
	}

	// Token: 0x0600030F RID: 783 RVA: 0x00013B1C File Offset: 0x00011D1C
	public bool NavigationMode()
	{
		return this.curInput != Inputs.mouse && this.curInput != Inputs.touch;
	}

	// Token: 0x06000310 RID: 784 RVA: 0x00013B35 File Offset: 0x00011D35
	public bool isLandscape(bool ignoreForcePortrait = false)
	{
		return (ignoreForcePortrait || !PlayerPrefs.HasKey("forceportrait")) && Mathf.Sqrt((float)(Screen.height * Screen.height + Screen.width * Screen.width)) / Screen.dpi > 8.4f;
	}

	// Token: 0x06000311 RID: 785 RVA: 0x00013B78 File Offset: 0x00011D78
	public void DisableMenuNav(bool closewindows = true)
	{
		this.isInMenu = false;
		if (this.OnSwitchMenu != null)
		{
			this.OnSwitchMenu(false);
		}
		if (closewindows && this.isInventory)
		{
			foreach (CharacterCard characterCard in GameAct.diff.selection)
			{
				characterCard.AddButToNav(true);
			}
			if (this.NavigationMode())
			{
				AutoSelectMe autoSelectMe = (AutoSelectMe)Object.FindObjectOfType(typeof(AutoSelectMe));
				if (autoSelectMe != null)
				{
					autoSelectMe.Activate();
				}
			}
		}
		else
		{
			this.eventSys.sendNavigationEvents = false;
			this.eventSys.SetSelectedGameObject(null);
			this.isInventory = false;
		}
		if (this.scKi != null)
		{
			if (closewindows)
			{
				this.scKi.CloseWindows();
				return;
			}
			InputAct.diff.RestoreSlideFocus();
			if (AnimBut.diff)
			{
				AnimBut.diff.ResetLock(true);
			}
		}
	}

	// Token: 0x06000312 RID: 786 RVA: 0x00013C80 File Offset: 0x00011E80
	public void SetSelect(GameObject go)
	{
		this.eventSys.SetSelectedGameObject(go);
		go.GetComponent<Selectable>().Select();
	}

	// Token: 0x06000313 RID: 787 RVA: 0x00013C99 File Offset: 0x00011E99
	public void SetQuit(GameObject but)
	{
		this.quitBut = but;
		this.suspendQuit = false;
	}

	// Token: 0x06000314 RID: 788 RVA: 0x00013CA9 File Offset: 0x00011EA9
	public void SuspendQuit()
	{
		this.suspendQuit = true;
	}

	// Token: 0x06000315 RID: 789 RVA: 0x00013CB2 File Offset: 0x00011EB2
	public void MenuNav(bool isinmenu = true)
	{
		this.InitMenuNav();
		this.isInMenu = isinmenu;
		if (isinmenu && this.OnSwitchMenu != null)
		{
			this.OnSwitchMenu(true);
		}
	}

	// Token: 0x06000316 RID: 790 RVA: 0x00013CD8 File Offset: 0x00011ED8
	public void OpenEffects()
	{
		if (this.isInMenu)
		{
			return;
		}
		this.DefaultWindow();
		this.scKi.OpenEffects(true);
	}

	// Token: 0x06000317 RID: 791 RVA: 0x00013CF5 File Offset: 0x00011EF5
	public void OpenOptions()
	{
		if (this.isInMenu)
		{
			return;
		}
		if (this.scKi == null)
		{
			return;
		}
		this.DefaultWindow();
		this.scKi.OpenOptions(true);
	}

	// Token: 0x06000318 RID: 792 RVA: 0x00013D21 File Offset: 0x00011F21
	public void OpenStats()
	{
		if (this.isInMenu)
		{
			return;
		}
		if (this.scKi == null)
		{
			return;
		}
		this.DefaultWindow();
		this.scKi.OpenStats(true);
	}

	// Token: 0x06000319 RID: 793 RVA: 0x00013D4D File Offset: 0x00011F4D
	public void OpenInventory()
	{
		if (this.isInventory || this.isInMenu)
		{
			return;
		}
		if (this.scKi == null)
		{
			return;
		}
		AnimBut.diff.UnLock(ControlModes.multichoice, false, true);
		this.MenuNav(false);
		this.isInventory = true;
	}

	// Token: 0x0600031A RID: 794 RVA: 0x00013D8C File Offset: 0x00011F8C
	private void DefaultWindow()
	{
		if (this.isInventory)
		{
			foreach (CharacterCard characterCard in GameAct.diff.selection)
			{
				characterCard.AddButToNav(false);
			}
		}
		AnimBut.diff.UnLock(ControlModes.selectback, false, true);
		this.MenuNav(true);
	}

	// Token: 0x0600031B RID: 795 RVA: 0x00013E00 File Offset: 0x00012000
	private void Awake()
	{
		this.eventSys = base.GetComponent<EventSystem>();
		this.player = ReInput.players.GetPlayer(0);
		InputAct.diff = this;
		float num = (float)Screen.height / (float)Screen.width;
		if (num > 2f || num < 0.5f)
		{
			this.Canvas.GetComponent<CanvasScaler>().referenceResolution = new Vector2(600f, 674f);
		}
	}

	// Token: 0x0600031C RID: 796 RVA: 0x00013E70 File Offset: 0x00012070
	private void Start()
	{
		this.availableInputs = new List<Inputs>
		{
			Inputs.none,
			Inputs.mouse,
			Inputs.keyboard,
			Inputs.xbox,
			Inputs.ps
		};
		if (DataStore.HasFile("input_keep"))
		{
			DataStore.Load<Inputs>("input_keep", new Action<Inputs>(this.SwitchControl), false, false);
		}
	}

	// Token: 0x0600031D RID: 797 RVA: 0x00013ED0 File Offset: 0x000120D0
	private Inputs isPS()
	{
		if (ReInput.controllers.GetLastActiveControllerType() != ControllerType.Joystick)
		{
			return Inputs.keyboard;
		}
		Joystick joystick = (Joystick)this.player.controllers.GetLastActiveController();
		if (joystick == null)
		{
			return Inputs.xbox;
		}
		string a = joystick.hardwareTypeGuid.ToString();
		if (a == "cd9718bf-a87a-44bc-8716-60a0def28a9f" || a == "c3ad3cad-c7cf-4ca8-8c2e-e3df8d9960bb" || a == "c309ca09-51d6-4458-aca5-f506f5a8c1e2" || a == "71dfe6c8-9e81-428f-a58e-c7e664b7fbed" || a == "d2aef070-7caa-42ff-b2dc-daac7e4a62b4")
		{
			return Inputs.ps;
		}
		return Inputs.xbox;
	}

	// Token: 0x0600031E RID: 798 RVA: 0x00013F60 File Offset: 0x00012160
	private void Update()
	{
		if (global::Input.GetKeyUp(KeyCode.Escape))
		{
			if (this.scKi == null)
			{
				this.QuitGame();
			}
			else if (this.isInMenu)
			{
				if (this.quitBut)
				{
					if (this.suspendQuit)
					{
						this.suspendQuit = false;
						return;
					}
					PointerEventData eventData = new PointerEventData(EventSystem.current);
					ExecuteEvents.Execute<ISubmitHandler>(this.quitBut, eventData, ExecuteEvents.submitHandler);
					this.quitBut = null;
				}
			}
			else
			{
				this.OpenOptions();
			}
		}
		if ((global::Input.GetKey(KeyCode.C) || global::Input.GetKey(KeyCode.R) || global::Input.touchCount > 1) && !this.touch2)
		{
			this.touch2 = true;
			base.StartCoroutine("Check2touch");
		}
		switch (this.curInput)
		{
		case Inputs.xbox:
		case Inputs.ps:
		case Inputs.keyboard:
			if (this.player.GetButtonUp("back") && this.isInMenu && this.quitBut)
			{
				if (this.suspendQuit)
				{
					this.suspendQuit = false;
					return;
				}
				PointerEventData eventData2 = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute<ISubmitHandler>(this.quitBut, eventData2, ExecuteEvents.submitHandler);
			}
			if (this.player.GetButtonUp("second"))
			{
				this.OpenStats();
			}
			break;
		case Inputs.touch:
			if (global::Input.touchCount == 1 && this.isInMenu && global::Input.touches[0].phase == TouchPhase.Began && !this.eventSys.IsPointerOverGameObject(global::Input.GetTouch(0).fingerId))
			{
				JukeBox.diff.PlaySound(SFXTypes.ui_error, false, false, 2.5f, -1, 1.5f, 1f);
			}
			break;
		case Inputs.tv:
			if (this.player.GetButtonUp("inventory"))
			{
				if (this.isInMenu)
				{
					if (this.quitBut)
					{
						if (this.suspendQuit)
						{
							this.suspendQuit = false;
							return;
						}
						PointerEventData eventData3 = new PointerEventData(EventSystem.current);
						ExecuteEvents.Execute<ISubmitHandler>(this.quitBut, eventData3, ExecuteEvents.submitHandler);
					}
				}
				else
				{
					this.OpenInventory();
				}
			}
			if (this.player.GetButtonUp("second"))
			{
				this.OpenStats();
			}
			break;
		}
		foreach (Inputs inputs in this.availableInputs)
		{
			if (inputs != this.curInput || this.isSimulating)
			{
				switch (inputs)
				{
				case Inputs.xbox:
					if (this.player.GetButtonUp("select") && this.isPS() == Inputs.xbox)
					{
						this.SwitchControl(Inputs.xbox);
					}
					break;
				case Inputs.ps:
					if (this.player.GetButtonUp("select") && this.isPS() == Inputs.ps)
					{
						this.SwitchControl(Inputs.ps);
					}
					break;
				case Inputs.keyboard:
					if (this.isPS() == Inputs.keyboard && (this.player.GetButtonUp("select") || this.player.GetAxis("horizontal") != 0f))
					{
						this.SwitchControl(Inputs.keyboard);
					}
					break;
				case Inputs.mouse:
					if (global::Input.GetMouseButtonUp(0))
					{
						this.SwitchControl(Inputs.mouse);
					}
					break;
				case Inputs.touch:
					if (global::Input.touchCount > 0 && global::Input.touches[0].phase == TouchPhase.Ended)
					{
						this.SwitchControl(Inputs.touch);
					}
					break;
				case Inputs.tv:
					if (this.player.GetButtonUp("select") && this.isPS() == Inputs.tv)
					{
						this.SwitchControl(Inputs.tv);
					}
					break;
				}
			}
		}
	}

	// Token: 0x0600031F RID: 799 RVA: 0x0001431C File Offset: 0x0001251C
	private IEnumerator Check2touch()
	{
		int i = 0;
		WaitForSeconds swait = new WaitForSeconds(1f);
		while (global::Input.touchCount > 1 || global::Input.GetKey(KeyCode.R) || global::Input.GetKey(KeyCode.C))
		{
			yield return swait;
			int num = i;
			i = num + 1;
			if (i == 3)
			{
				this.OfferReset(false, null);
				this.touch2 = false;
				yield break;
			}
		}
		this.touch2 = false;
		yield break;
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0001432C File Offset: 0x0001252C
	public void OfferReset(bool all = false, string overridetxt = null)
	{
		if (this.DiaPrefab.activeInHierarchy)
		{
			return;
		}
		this.DiaPrefab.SetActive(true);
		if (all)
		{
			this.DiaPrefab.GetComponent<DialogAct>().Init("resetall_label", "reset", new Action(this.OfferResetAllValid), overridetxt);
			return;
		}
		this.DiaPrefab.GetComponent<DialogAct>().Init("reset_label", "reset", new Action(this.OfferResetValid), overridetxt);
	}

	// Token: 0x06000321 RID: 801 RVA: 0x000143A5 File Offset: 0x000125A5
	private void OfferResetAllValid()
	{
		this.ResetGame(true);
	}

	// Token: 0x06000322 RID: 802 RVA: 0x000143AE File Offset: 0x000125AE
	private void OfferResetValid()
	{
		this.ResetGame(false);
	}

	// Token: 0x06000323 RID: 803 RVA: 0x000143B7 File Offset: 0x000125B7
	public void ResetGame(bool all = false)
	{
		DataStore.Reset(true, false);
		if (all)
		{
			SuperPrefs.DeleteAll();
			PlayerPrefs.DeleteAll();
		}
		SceneManager.LoadScene("disclaimer");
	}

	// Token: 0x06000324 RID: 804 RVA: 0x000143D8 File Offset: 0x000125D8
	public void QuitGame()
	{
		if (this.DiaPrefab.activeInHierarchy)
		{
			return;
		}
		this.DiaPrefab.SetActive(true);
		this.DiaPrefab.GetComponent<DialogAct>().Init("quit_label", "quit", new Action(this.QuitGameValid), null);
	}

	// Token: 0x06000325 RID: 805 RVA: 0x00014426 File Offset: 0x00012626
	private void QuitGameValid()
	{
		base.StartCoroutine("DoQuit");
	}

	// Token: 0x06000326 RID: 806 RVA: 0x00014434 File Offset: 0x00012634
	private IEnumerator DoQuit()
	{
		yield return null;
		Application.Quit();
		yield break;
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0001443C File Offset: 0x0001263C
	public void SwitchControl(Inputs input)
	{
		if (this.isSimulating)
		{
			this.StopSimulation();
			base.StopCoroutine("CheckSlide");
			base.StartCoroutine("CheckSlide");
			return;
		}
		this.curInput = input;
		Cursor.visible = (this.curInput == Inputs.mouse);
		GraphicRaycaster component = this.Canvas.GetComponent<GraphicRaycaster>();
		switch (this.curInput)
		{
		case Inputs.xbox:
		case Inputs.ps:
		case Inputs.keyboard:
		case Inputs.tv:
		{
			component.enabled = false;
			this.eventSys.sendNavigationEvents = true;
			AutoSelectMe autoSelectMe = (AutoSelectMe)Object.FindObjectOfType(typeof(AutoSelectMe));
			if (autoSelectMe != null)
			{
				autoSelectMe.Activate();
			}
			break;
		}
		case Inputs.mouse:
		case Inputs.touch:
			component.enabled = true;
			this.eventSys.sendNavigationEvents = false;
			break;
		}
		if (this.curInput != Inputs.none)
		{
			DataStore.Save<Inputs>("input_keep", this.curInput, false, false);
		}
		if (AnimBut.diff)
		{
			AnimBut.diff.ResetLock(false);
		}
		if (this.OnSlideUpdate != null && !this.isInMenu)
		{
			base.StopCoroutine("CheckSlide");
			base.StartCoroutine("CheckSlide");
		}
		if (this.OnSwitchControl != null)
		{
			this.OnSwitchControl(input);
		}
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0001457C File Offset: 0x0001277C
	public void SuspendSlideFocus()
	{
		this.isSuspended = true;
	}

	// Token: 0x06000329 RID: 809 RVA: 0x00014585 File Offset: 0x00012785
	public void RestoreSlideFocus()
	{
		this.isSuspended = false;
	}

	// Token: 0x0600032A RID: 810 RVA: 0x0001458E File Offset: 0x0001278E
	public void RemoveSlideFocus()
	{
		if (this.OnSlideStop != null)
		{
			this.OnSlideStop();
		}
		this.OnSlideUpdate = null;
		this.OnSlideStop = null;
		this.OnSlideStart = null;
		this.OnSlideValid = null;
		this.OnSlideDown = null;
	}

	// Token: 0x0600032B RID: 811 RVA: 0x000145C6 File Offset: 0x000127C6
	public void GetActionFocus(Action action, bool suspendSlide = false)
	{
		this.OnAction = action;
		base.StopCoroutine("CheckAction");
		base.StartCoroutine("CheckAction", suspendSlide);
	}

	// Token: 0x0600032C RID: 812 RVA: 0x000145EC File Offset: 0x000127EC
	public bool GetSlideFocus(Action<Vector2> update, Action stop, Action<Vector2> start, Action<Vector2> valid, Func<bool, bool> down, bool allowCumul = false, float min = 0f, float max = 1f)
	{
		this.RemoveSlideFocus();
		this.OnSlideUpdate = update;
		this.OnSlideStop = stop;
		this.OnSlideStart = start;
		this.OnSlideValid = valid;
		this.OnSlideDown = down;
		this.yMax = max;
		this.yMin = min;
		this.RestoreSlideFocus();
		base.StopCoroutine("CheckSlide");
		base.StartCoroutine("CheckSlide");
		this.nodeadzone = allowCumul;
		return allowCumul && this.curInput != Inputs.touch && this.curInput != Inputs.ps && this.curInput != Inputs.xbox && this.curInput != Inputs.tv;
	}

	// Token: 0x0600032D RID: 813 RVA: 0x00014683 File Offset: 0x00012883
	private IEnumerator CheckSlide()
	{
		float side = 0f;
		Vector2 decal = Vector2.zero;
		WaitForSeconds swait = new WaitForSeconds(0.4f);
		for (;;)
		{
			if (!this.isSuspended)
			{
				while (!this.CheckDown())
				{
					yield return null;
				}
				float tdown = Time.realtimeSinceStartup;
				if (this.curInput == Inputs.touch)
				{
					decal = Vector2.zero;
				}
				bool isActive = false;
				Vector2 lori = Vector2.zero;
				while (!this.CheckUp(isActive, decal, tdown))
				{
					lori = ((this.curInput == Inputs.keyboard) ? Vector2.Lerp(lori, this.ori, Time.deltaTime * 4f) : this.ori);
					decal = this.GetSlidePos() - lori;
					decal.x = ((this.nodeadzone || this.curInput == Inputs.tv) ? Mathf.Clamp(decal.x, -1f, 1f) : ((decal.x < 0f) ? Mathf.Clamp(decal.x + this.stopamo, -1f, 0f) : Mathf.Clamp(decal.x - this.stopamo, 0f, 1f)));
					if (this.CheckBounds(decal))
					{
						float num = Mathf.Sign(decal.x);
						if (!isActive)
						{
							isActive = true;
							side = -num;
						}
						if (isActive && side != num)
						{
							side = num;
							if (this.OnSlideStart != null)
							{
								this.OnSlideStart(decal);
							}
						}
						if (this.curInput != Inputs.touch)
						{
							this.OnSlideUpdate(decal);
						}
					}
					else if (isActive)
					{
						if (this.OnSlideStop != null)
						{
							this.OnSlideStop();
						}
						isActive = false;
					}
					if (this.curInput == Inputs.touch)
					{
						this.OnSlideUpdate(decal);
					}
					yield return null;
				}
				yield return swait;
				lori = default(Vector2);
			}
			else
			{
				yield return null;
			}
		}
		yield break;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x00014694 File Offset: 0x00012894
	private bool CheckDown()
	{
		if (this.isSimulating)
		{
			this.ori = new Vector2(0f, 0f);
			return true;
		}
		if (this.OnSlideDown != null && !this.OnSlideDown(true))
		{
			return false;
		}
		this.ori = Vector2.zero;
		switch (this.curInput)
		{
		case Inputs.keyboard:
			if (global::Input.GetKeyUp(KeyCode.LeftArrow))
			{
				this.ori = new Vector2(0.4f, 0f);
				return true;
			}
			if (global::Input.GetKeyUp(KeyCode.RightArrow))
			{
				this.ori = new Vector2(-0.4f, 0f);
				return true;
			}
			return false;
		case Inputs.mouse:
			this.ori = new Vector2(0.5f, 0.05f);
			return true;
		case Inputs.touch:
			if (global::Input.touchCount == 0)
			{
				return false;
			}
			this.ori = new Vector2(global::Input.touches[0].position.x * 3f, global::Input.touches[0].position.y * 0.3f + 0.5f) / (float)Screen.height;
			return true;
		}
		return true;
	}

	// Token: 0x0600032F RID: 815 RVA: 0x000147C4 File Offset: 0x000129C4
	private Vector2 GetSlidePos()
	{
		if (this.isSimulating)
		{
			float b = Mathf.Lerp(0f, 5f * (Mathf.PingPong(Time.realtimeSinceStartup * 1.4f, 2f) - 1f), Time.deltaTime * 6f);
			this.simulationPos = Mathf.Lerp(this.simulationPos, b, Time.deltaTime * 2f);
			Vector2 vector = new Vector2(this.simulationPos, 0f);
			this.simulationHand.anchoredPosition = vector * 200f;
			return vector;
		}
		switch (this.curInput)
		{
		case Inputs.xbox:
		case Inputs.ps:
			return new Vector2(this.player.GetAxis("horizontal") * 0.5f, this.player.GetAxis("vertical") * 0.1f);
		case Inputs.keyboard:
			if (global::Input.GetKeyUp(KeyCode.LeftArrow))
			{
				this.ori = new Vector2(0.4f, 0f);
			}
			else if (global::Input.GetKeyUp(KeyCode.RightArrow))
			{
				this.ori = new Vector2(-0.4f, 0f);
			}
			return Vector2.zero;
		case Inputs.mouse:
			return new Vector2(global::Input.mousePosition.x, global::Input.mousePosition.y * 0.1f + 0.05f) / (float)Screen.width;
		case Inputs.touch:
			if (global::Input.touchCount == 0)
			{
				return new Vector2(0f, 0f);
			}
			return new Vector2(global::Input.touches[0].position.x * 3f, global::Input.touches[0].position.y * 0.3f + 0.5f) / (float)Screen.height;
		case Inputs.tv:
			return new Vector2(this.player.GetAxis("horizontal") * 0.7f, this.player.GetAxis("vertical") * 0.1f);
		}
		return Vector2.zero;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x000149D4 File Offset: 0x00012BD4
	public Vector2 GetPointerPos()
	{
		Inputs inputs = this.curInput;
		if (inputs == Inputs.mouse)
		{
			return new Vector2(global::Input.mousePosition.x, global::Input.mousePosition.y);
		}
		if (inputs != Inputs.touch)
		{
			return new Vector2(0f, 0f);
		}
		if (global::Input.touchCount > 0)
		{
			return new Vector2(global::Input.touches[0].position.x, global::Input.touches[0].position.y);
		}
		return new Vector2(0f, 0f);
	}

	// Token: 0x06000331 RID: 817 RVA: 0x00014A64 File Offset: 0x00012C64
	public Vector2 GetPointerVirt()
	{
		Inputs inputs = this.curInput;
		if (inputs <= Inputs.ps || inputs == Inputs.tv)
		{
			return new Vector2(-this.player.GetAxis("horizontal"), -this.player.GetAxis("vertical"));
		}
		Vector2 pointerPos = this.GetPointerPos();
		return new Vector2((pointerPos.x - (float)(Screen.width / 2)) / (float)Screen.width, (pointerPos.y - (float)(Screen.height / 2)) / (float)Screen.height);
	}

	// Token: 0x06000332 RID: 818 RVA: 0x00014AE0 File Offset: 0x00012CE0
	private bool CheckUp(bool active, Vector2 decal, float tdown)
	{
		if (this.isSuspended)
		{
			return true;
		}
		if (this.isSimulating)
		{
			return false;
		}
		if (this.isActionFocus)
		{
			return false;
		}
		switch (this.curInput)
		{
		case Inputs.xbox:
		case Inputs.ps:
			if (!this.player.GetButtonUp("select"))
			{
				return false;
			}
			break;
		case Inputs.keyboard:
			if ((!global::Input.GetKeyDown(KeyCode.LeftArrow) || decal.x >= 0f) && (!global::Input.GetKeyDown(KeyCode.RightArrow) || decal.x <= 0f))
			{
				return false;
			}
			break;
		case Inputs.mouse:
			if (!global::Input.GetMouseButtonUp(0))
			{
				return false;
			}
			break;
		case Inputs.touch:
			if (global::Input.touchCount > 0)
			{
				return false;
			}
			break;
		case Inputs.tv:
			if ((this.player.GetAxis("vertical") != 0f && this.player.GetAxis("horizontal") != 0f) || Time.realtimeSinceStartup - tdown < 0.1f)
			{
				return false;
			}
			break;
		}
		if (active && Time.realtimeSinceStartup - tdown > 0.05f)
		{
			this.OnSlideValid(decal);
		}
		else if (this.OnSlideStop != null)
		{
			this.OnSlideStop();
		}
		return true;
	}

	// Token: 0x06000333 RID: 819 RVA: 0x00014C10 File Offset: 0x00012E10
	private bool CheckBounds(Vector2 p)
	{
		if (this.isInMenu || this.isInventory)
		{
			return false;
		}
		float x = p.x;
		Inputs inputs = this.curInput;
		if (inputs != Inputs.mouse)
		{
			if (inputs == Inputs.touch && !this.isSimulating && global::Input.touchCount == 0)
			{
				return false;
			}
		}
		else if (!this.isSimulating)
		{
			float num = global::Input.mousePosition.y / (float)Screen.height;
			if (num > this.yMax || num < this.yMin)
			{
				return false;
			}
		}
		float num2 = Mathf.Abs(x);
		return this.nodeadzone || num2 > this.stopamo * 2f;
	}

	// Token: 0x06000334 RID: 820 RVA: 0x00014CAB File Offset: 0x00012EAB
	public void TapAction()
	{
		this.StopCheckAction();
	}

	// Token: 0x06000335 RID: 821 RVA: 0x00014CB4 File Offset: 0x00012EB4
	private bool StopCheckAction()
	{
		if (this.isInMenu || this.isInventory)
		{
			return false;
		}
		if (AnimBut.diff)
		{
			AnimBut.diff.Tap();
		}
		this.hasClick = true;
		this.isActionFocus = false;
		if (this.OnAction != null)
		{
			this.OnAction();
		}
		this.OnAction = null;
		return true;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x00014D12 File Offset: 0x00012F12
	public IEnumerator CheckAction(bool suspendSlide)
	{
		if (suspendSlide)
		{
			this.isActionFocus = true;
		}
		this.hasClick = false;
		for (;;)
		{
			switch (this.curInput)
			{
			case Inputs.xbox:
			case Inputs.ps:
			case Inputs.tv:
				if (this.player.GetButtonUp("select") && this.StopCheckAction())
				{
					goto Block_7;
				}
				break;
			case Inputs.keyboard:
				if ((this.player.GetButtonUp("select") || global::Input.GetKeyDown(KeyCode.RightArrow)) && this.StopCheckAction())
				{
					goto Block_5;
				}
				break;
			case Inputs.mouse:
			case Inputs.touch:
				if (this.hasClick)
				{
					goto Block_3;
				}
				break;
			}
			yield return null;
		}
		Block_3:
		yield break;
		Block_5:
		yield break;
		Block_7:
		yield break;
		yield break;
	}

	// Token: 0x06000337 RID: 823 RVA: 0x00014D28 File Offset: 0x00012F28
	private void StopSimulation()
	{
		this.isSimulating = false;
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(false);
		}
		if (this.simulationBack)
		{
			this.simulationBack.SetActive(false);
		}
	}

	// Token: 0x06000338 RID: 824 RVA: 0x00014D64 File Offset: 0x00012F64
	public void Simulate(float min, float max)
	{
		this.simulationPos = 0f;
		this.isSimulating = true;
		this.simulationBack.SetActive(true);
		base.StopCoroutine("CheckSlide");
		base.StartCoroutine("CheckSlide");
		if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.next, false, true);
		}
	}

	// Token: 0x06000339 RID: 825 RVA: 0x00014DBF File Offset: 0x00012FBF
	private IEnumerator YieldSimulBut()
	{
		yield return new WaitForSeconds(2f);
		if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.next, false, true);
		}
		yield break;
	}

	// Token: 0x040003DF RID: 991
	public Inputs curInput;

	// Token: 0x040003E0 RID: 992
	public Action<bool> OnSwitchMenu;

	// Token: 0x040003E1 RID: 993
	private Action<Vector2> OnSlideUpdate;

	// Token: 0x040003E2 RID: 994
	private Action OnSlideStop;

	// Token: 0x040003E3 RID: 995
	public Action OnAction;

	// Token: 0x040003E4 RID: 996
	private Action<Vector2> OnSlideValid;

	// Token: 0x040003E5 RID: 997
	private Action<Vector2> OnSlideStart;

	// Token: 0x040003E6 RID: 998
	private Func<bool, bool> OnSlideDown;

	// Token: 0x040003E7 RID: 999
	public Action<Inputs> OnSwitchControl;

	// Token: 0x040003E8 RID: 1000
	private Player player;

	// Token: 0x040003E9 RID: 1001
	public static InputAct diff;

	// Token: 0x040003EA RID: 1002
	private Vector2 tdecal;

	// Token: 0x040003EB RID: 1003
	public bool touching;

	// Token: 0x040003EC RID: 1004
	public Vector2 tpo = Vector2.zero;

	// Token: 0x040003ED RID: 1005
	public bool whiledown;

	// Token: 0x040003EE RID: 1006
	public bool up;

	// Token: 0x040003EF RID: 1007
	private Vector2 cPo;

	// Token: 0x040003F0 RID: 1008
	private float yMin;

	// Token: 0x040003F1 RID: 1009
	private float yMax;

	// Token: 0x040003F2 RID: 1010
	private bool isSuspended;

	// Token: 0x040003F3 RID: 1011
	public GameObject leapPrefab;

	// Token: 0x040003F4 RID: 1012
	private bool isActionFocus;

	// Token: 0x040003F5 RID: 1013
	public bool isSimulating;

	// Token: 0x040003F6 RID: 1014
	private float simulationPos;

	// Token: 0x040003F7 RID: 1015
	public RectTransform simulationHand;

	// Token: 0x040003F8 RID: 1016
	public GameObject simulationBack;

	// Token: 0x040003F9 RID: 1017
	public KingdomAct scKi;

	// Token: 0x040003FA RID: 1018
	private EventSystem eventSys;

	// Token: 0x040003FB RID: 1019
	public GameObject KingdomFirst;

	// Token: 0x040003FC RID: 1020
	public bool isInMenu;

	// Token: 0x040003FD RID: 1021
	public bool isInventory;

	// Token: 0x040003FE RID: 1022
	private GameObject quitBut;

	// Token: 0x040003FF RID: 1023
	private bool suspendQuit;

	// Token: 0x04000400 RID: 1024
	public List<Inputs> availableInputs;

	// Token: 0x04000401 RID: 1025
	private bool touch2;

	// Token: 0x04000402 RID: 1026
	private GameObject dia;

	// Token: 0x04000403 RID: 1027
	public GameObject DiaPrefab;

	// Token: 0x04000404 RID: 1028
	public Transform Canvas;

	// Token: 0x04000405 RID: 1029
	private bool nodeadzone;

	// Token: 0x04000406 RID: 1030
	private Vector2 ori = Vector2.zero;

	// Token: 0x04000407 RID: 1031
	private float stopamo = 0.02f;

	// Token: 0x04000408 RID: 1032
	public bool hasClick;

	// Token: 0x020002E5 RID: 741
	private enum Positions
	{
		// Token: 0x040010C8 RID: 4296
		idle,
		// Token: 0x040010C9 RID: 4297
		down,
		// Token: 0x040010CA RID: 4298
		whiledown,
		// Token: 0x040010CB RID: 4299
		up
	}
}
