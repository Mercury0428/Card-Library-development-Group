﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200001C RID: 28
public class AutoText : MonoBehaviour
{
	// Token: 0x060000C7 RID: 199 RVA: 0x00004F40 File Offset: 0x00003140
	private void Awake()
	{
		this.trans = base.GetComponent<RectTransform>();
		this.txt = base.GetComponent<Graphic>();
		if (this.txt)
		{
			this.txt.enabled = false;
		}
		this.oriPos = this.trans.anchoredPosition;
		this.oriCol = this.txt.color;
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00004FA0 File Offset: 0x000031A0
	private void OnEnable()
	{
		if (this.txt)
		{
			this.txt.enabled = false;
		}
		base.StartCoroutine("Delay");
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x00004FC7 File Offset: 0x000031C7
	private void OnDisable()
	{
		this.trans.anchoredPosition = this.oriPos;
		if (this.txt)
		{
			this.txt.color = this.oriCol;
		}
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00004FF8 File Offset: 0x000031F8
	private IEnumerator Delay()
	{
		yield return null;
		yield return new WaitForSeconds(this.delay);
		if (this.retrieveText)
		{
			base.GetComponent<Text>().text = SpeechAct.diff.GetSceneText(base.name, this.txtId);
		}
		if (this.suspendMove)
		{
			yield break;
		}
		if (this.txt)
		{
			this.txt.enabled = true;
		}
		if (this.clearAndBack != 1f)
		{
			base.StartCoroutine("AlphaAndBack", this.clearAndBack);
		}
		if (this.moveAndBack != Vector2.zero)
		{
			base.StartCoroutine("MoveAndBack", this.moveAndBack);
		}
		if (this.sizeAndBack != 1f)
		{
			base.StartCoroutine("SizeAndBack", this.sizeAndBack);
		}
		yield return new WaitForSeconds(1f);
		if (this.thenalphaback)
		{
			base.StopCoroutine("AlphaAndBack");
			Color color = this.txt.color;
			float a = color.a;
			this.txt.color = new Color(color.r, color.g, color.b, this.clearAndBack);
			base.StopCoroutine("AlphaAndBack");
			base.StartCoroutine("AlphaAndBack", a);
		}
		yield break;
	}

	// Token: 0x060000CB RID: 203 RVA: 0x00005007 File Offset: 0x00003207
	private IEnumerator AlphaAndBack(float a)
	{
		Color ocol = this.txt.color;
		Color ncol = new Color(ocol.r, ocol.g, ocol.b, a);
		float t = 0f;
		while (t < 1f)
		{
			this.txt.color = Color.Lerp(ncol, ocol, 0.1f + t);
			t += Time.deltaTime * 2f * this.speed;
			yield return null;
		}
		this.txt.color = ocol;
		yield break;
	}

	// Token: 0x060000CC RID: 204 RVA: 0x0000501D File Offset: 0x0000321D
	public void MoveDirect()
	{
		base.GetComponent<RectTransform>().anchoredPosition = this.oriPos + this.moveAndBack;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x0000503C File Offset: 0x0000323C
	public void Move()
	{
		if (this.clearAndBack != 1f)
		{
			base.StopCoroutine("AlphaAndBack");
			base.StartCoroutine("AlphaAndBack", this.clearAndBack);
		}
		base.StopCoroutine("DoMove");
		base.StopCoroutine("DoMoveDelay");
		base.StartCoroutine("DoMoveDelay", this.oriPos + this.moveAndBack);
	}

	// Token: 0x060000CE RID: 206 RVA: 0x000050B0 File Offset: 0x000032B0
	public void AnteMove()
	{
		if (this.clearAndBack != 1f)
		{
			Color color = this.txt.color;
			float a = color.a;
			this.txt.color = new Color(color.r, color.g, color.b, this.clearAndBack);
			base.StopCoroutine("AlphaAndBack");
			base.StartCoroutine("AlphaAndBack", a);
		}
		base.StopCoroutine("DoMove");
		base.StopCoroutine("DoMoveDelay");
		base.StartCoroutine("DoMoveDelay", this.oriPos);
	}

	// Token: 0x060000CF RID: 207 RVA: 0x0000514F File Offset: 0x0000334F
	private IEnumerator DoMoveDelay(Vector2 move)
	{
		if (this.delay > 0f)
		{
			yield return new WaitForSeconds(this.delay);
		}
		Vector2 npos = this.trans.anchoredPosition;
		float t = 0f;
		while (t < 1f)
		{
			this.trans.anchoredPosition = Vector2.Lerp(npos, move, 0.1f + t);
			t += Time.deltaTime * this.speed;
			yield return 0;
		}
		this.trans.anchoredPosition = move;
		yield break;
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00005165 File Offset: 0x00003365
	private IEnumerator DoMove(Vector2 move)
	{
		Vector2 npos = this.trans.anchoredPosition;
		float t = 0f;
		while (t < 1f)
		{
			this.trans.anchoredPosition = Vector2.Lerp(npos, move, 0.1f + t);
			t += Time.deltaTime * this.speed;
			yield return 0;
		}
		this.trans.anchoredPosition = move;
		yield break;
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x0000517B File Offset: 0x0000337B
	private IEnumerator MoveAndBack(Vector2 moveAndBack)
	{
		Vector2 opos = this.trans.anchoredPosition;
		Vector2 npos = this.trans.anchoredPosition + moveAndBack;
		float t = 0f;
		while (t < 1f)
		{
			this.trans.anchoredPosition = Vector2.Lerp(npos, opos, 0.1f + t);
			t += Time.deltaTime * this.speed;
			yield return 0;
		}
		this.trans.anchoredPosition = opos;
		yield break;
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x00005191 File Offset: 0x00003391
	private IEnumerator SizeAndBack(float size)
	{
		Vector3 osize = this.trans.localScale;
		Vector3 nsize = new Vector3(size, size, size);
		float t = 0f;
		while (t < 1f)
		{
			this.trans.localScale = Vector3.Lerp(nsize, osize, 0.1f + t);
			t += Time.deltaTime * this.speed;
			yield return 0;
		}
		this.trans.localScale = osize;
		yield break;
	}

	// Token: 0x040000A7 RID: 167
	public Vector2 DefaultTransfo;

	// Token: 0x040000A8 RID: 168
	private Vector2 modifTransfoPos;

	// Token: 0x040000A9 RID: 169
	private Vector2 oriPos;

	// Token: 0x040000AA RID: 170
	public bool retrieveText = true;

	// Token: 0x040000AB RID: 171
	public float clearAndBack = 1f;

	// Token: 0x040000AC RID: 172
	public Vector2 moveAndBack = Vector2.zero;

	// Token: 0x040000AD RID: 173
	public float sizeAndBack = 1f;

	// Token: 0x040000AE RID: 174
	public float speed = 1f;

	// Token: 0x040000AF RID: 175
	private Graphic txt;

	// Token: 0x040000B0 RID: 176
	private RectTransform trans;

	// Token: 0x040000B1 RID: 177
	public float delay;

	// Token: 0x040000B2 RID: 178
	public int txtId;

	// Token: 0x040000B3 RID: 179
	public string suffix;

	// Token: 0x040000B4 RID: 180
	public bool thenalphaback;

	// Token: 0x040000B5 RID: 181
	private Color oriCol;

	// Token: 0x040000B6 RID: 182
	public bool suspendMove;
}
