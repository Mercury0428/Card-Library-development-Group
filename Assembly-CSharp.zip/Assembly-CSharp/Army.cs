﻿using System;
using System.Collections.Generic;
using SVGImporter;

// Token: 0x02000002 RID: 2
[Serializable]
public class Army
{
	// Token: 0x04000001 RID: 1
	public SVGAsset leader;

	// Token: 0x04000002 RID: 2
	public List<SVGAsset> characters;
}
