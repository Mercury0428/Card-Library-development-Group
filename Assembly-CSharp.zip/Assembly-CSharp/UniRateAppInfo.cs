﻿using System;
using System.Collections.Generic;
using UniRateMiniJSON;

// Token: 0x020000A8 RID: 168
public class UniRateAppInfo
{
	// Token: 0x0600054E RID: 1358 RVA: 0x0001F6B8 File Offset: 0x0001D8B8
	public UniRateAppInfo(string jsonResponse)
	{
		Dictionary<string, object> dictionary = Json.Deserialize(jsonResponse) as Dictionary<string, object>;
		if (dictionary != null)
		{
			List<object> list = dictionary["results"] as List<object>;
			if (list != null && list.Count > 0)
			{
				Dictionary<string, object> dictionary2 = list[0] as Dictionary<string, object>;
				if (dictionary2 != null)
				{
					this.bundleId = (dictionary2["bundleId"] as string);
					this.appStoreGenreID = Convert.ToInt32(dictionary2["primaryGenreId"]);
					this.appID = Convert.ToInt32(dictionary2["trackId"]);
					this.version = (dictionary2["version"] as string);
					this.validAppInfo = true;
				}
			}
		}
	}

	// Token: 0x040005F7 RID: 1527
	public bool validAppInfo;

	// Token: 0x040005F8 RID: 1528
	public string bundleId;

	// Token: 0x040005F9 RID: 1529
	public int appStoreGenreID;

	// Token: 0x040005FA RID: 1530
	public int appID;

	// Token: 0x040005FB RID: 1531
	public string version;

	// Token: 0x040005FC RID: 1532
	private const string kAppInfoResultsKey = "results";

	// Token: 0x040005FD RID: 1533
	private const string kAppInfoBundleIdKey = "bundleId";

	// Token: 0x040005FE RID: 1534
	private const string kAppInfoGenreIdKey = "primaryGenreId";

	// Token: 0x040005FF RID: 1535
	private const string kAppInfoAppIdKey = "trackId";

	// Token: 0x04000600 RID: 1536
	private const string kAppInfoVersion = "version";
}
