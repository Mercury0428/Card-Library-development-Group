﻿using System;

// Token: 0x0200000E RID: 14
public class iOSHapticFeedbackAdvanced : iOSHapticFeedback
{
	// Token: 0x0600007E RID: 126 RVA: 0x00003E06 File Offset: 0x00002006
	protected new void Awake()
	{
		base.Awake();
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00003E0E File Offset: 0x0000200E
	public new void Trigger(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		base.TriggerFeedbackGenerator((int)feedbackType, true);
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00003E18 File Offset: 0x00002018
	public void InstantiateFeedbackGenerator(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		base.InstantiateFeedbackGenerator((int)feedbackType);
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00003E21 File Offset: 0x00002021
	public void PrepareFeedbackGenerator(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		base.PrepareFeedbackGenerator((int)feedbackType);
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00003E2A File Offset: 0x0000202A
	public void TriggerFeedbackGenerator(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		this.Trigger(feedbackType);
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00003E33 File Offset: 0x00002033
	public void ReleaseFeedbackGenerator(iOSHapticFeedback.iOSFeedbackType feedbackType)
	{
		base.ReleaseFeedbackGenerator((int)feedbackType);
	}
}
