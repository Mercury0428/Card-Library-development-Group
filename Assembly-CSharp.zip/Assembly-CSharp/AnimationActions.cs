﻿using System;
using UnityEngine;

// Token: 0x02000083 RID: 131
public class AnimationActions : MonoBehaviour
{
	// Token: 0x0600045C RID: 1116 RVA: 0x0001B948 File Offset: 0x00019B48
	public void InvokeAnimationAction(string name)
	{
		if (this.events == null || this.events.Length == 0)
		{
			return;
		}
		for (int i = 0; i < this.events.Length; i++)
		{
			if (this.events[i] != null && this.events[i].actionEvent != null && !(this.events[i].name != name))
			{
				this.events[i].InvokeAnimationAction();
			}
		}
	}

	// Token: 0x04000505 RID: 1285
	public AnimationAction[] events;
}
