﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000051 RID: 81
public class GPGSui : MonoBehaviour
{
	// Token: 0x060002F6 RID: 758 RVA: 0x00003E98 File Offset: 0x00002098
	private void Awake()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x040003C7 RID: 967
	private bool unavailable;

	// Token: 0x040003C8 RID: 968
	public Button gpgsBut;

	// Token: 0x040003C9 RID: 969
	public Button achieveBut;

	// Token: 0x040003CA RID: 970
	public Button leaderBut;

	// Token: 0x040003CB RID: 971
	public Button cloudBut;

	// Token: 0x040003CC RID: 972
	public Button connectBut;
}
