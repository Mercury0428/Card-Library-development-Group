﻿using System;
using UnityEngine;

// Token: 0x02000084 RID: 132
public class AudioCameraZoom : MonoBehaviour
{
	// Token: 0x0600045E RID: 1118 RVA: 0x0001B9B5 File Offset: 0x00019BB5
	public void VelocityMultiplierIntensity(float value)
	{
		this._velocityMultiplierIntensity = value;
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x0001B9BE File Offset: 0x00019BBE
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x0001B9C7 File Offset: 0x00019BC7
	public void RandomIntensity(float value)
	{
		this._randomIntensity = value;
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x0001B9D0 File Offset: 0x00019BD0
	private void Awake()
	{
		if (this.target.orthographic)
		{
			this.destination = this.target.orthographicSize;
			return;
		}
		this.destination = this.target.fieldOfView;
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x0001BA04 File Offset: 0x00019C04
	public void OnAudio(float audioVelocity)
	{
		float num = this.velocity * audioVelocity * this.velocityMultiplier * this._velocityMultiplierIntensity;
		if (this.random && this._randomIntensity >= 0.5f)
		{
			this.destination = Mathf.PerlinNoise(Time.realtimeSinceStartup * 1.5f, Time.realtimeSinceStartup * 3f) * num;
		}
		else
		{
			this.destination = num;
		}
		if (this.target.orthographic)
		{
			this.target.orthographicSize = Mathf.Lerp(this.target.orthographicSize, this.destination, Time.deltaTime * this.speed * this._speedIntensity);
			return;
		}
		this.target.fieldOfView = Mathf.Lerp(this.target.fieldOfView, this.destination, Time.deltaTime * this.speed * this._speedIntensity);
	}

	// Token: 0x04000506 RID: 1286
	public Camera target;

	// Token: 0x04000507 RID: 1287
	public float velocity;

	// Token: 0x04000508 RID: 1288
	public float velocityMultiplier = 1f;

	// Token: 0x04000509 RID: 1289
	protected float _velocityMultiplierIntensity = 1f;

	// Token: 0x0400050A RID: 1290
	public float speed = 1f;

	// Token: 0x0400050B RID: 1291
	protected float _speedIntensity = 1f;

	// Token: 0x0400050C RID: 1292
	public bool random = true;

	// Token: 0x0400050D RID: 1293
	protected float _randomIntensity = 1f;

	// Token: 0x0400050E RID: 1294
	private float destination;
}
