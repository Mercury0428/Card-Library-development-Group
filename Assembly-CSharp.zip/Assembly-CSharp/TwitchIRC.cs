﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x0200009F RID: 159
public class TwitchIRC : MonoBehaviour
{
	// Token: 0x060004DD RID: 1245 RVA: 0x0001DB00 File Offset: 0x0001BD00
	private void StartIRC()
	{
		this.sock = new TcpClient();
		this.sock.Connect(this.server, this.port);
		if (!this.sock.Connected)
		{
			Debug.LogWarning("Failed to connect!");
			return;
		}
		this.stopThreads = false;
		NetworkStream networkStream = this.sock.GetStream();
		StreamReader input = new StreamReader(networkStream);
		StreamWriter output = new StreamWriter(networkStream);
		output.WriteLine("PASS " + this.oauth);
		output.WriteLine("NICK " + this.nickName.ToLower());
		output.Flush();
		this.outProc = new Thread(delegate()
		{
			this.IRCOutputProcedure(output);
		});
		this.outProc.Start();
		this.inProc = new Thread(delegate()
		{
			this.IRCInputProcedure(input, networkStream);
		});
		this.inProc.Start();
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0001DC18 File Offset: 0x0001BE18
	private void IRCInputProcedure(TextReader input, NetworkStream networkStream)
	{
		while (!this.stopThreads)
		{
			if (networkStream.DataAvailable)
			{
				this.buffer = input.ReadLine();
				if (this.buffer.Contains("PRIVMSG #"))
				{
					List<string> obj = this.recievedMsgs;
					lock (obj)
					{
						this.recievedMsgs.Add(this.buffer);
					}
				}
				if (this.buffer.StartsWith("PING "))
				{
					this.SendCommand(this.buffer.Replace("PING", "PONG"));
				}
				if (this.buffer.Split(new char[]
				{
					' '
				})[1] == "001")
				{
					this.SendCommand("JOIN #" + this.nickName.ToLower());
					this.Connected();
				}
			}
		}
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x0001DD14 File Offset: 0x0001BF14
	private void IRCOutputProcedure(TextWriter output)
	{
		Stopwatch stopwatch = new Stopwatch();
		stopwatch.Start();
		while (!this.stopThreads)
		{
			Queue<string> obj = this.commandQueue;
			lock (obj)
			{
				if (this.commandQueue.Count > 0 && stopwatch.ElapsedMilliseconds > 1750L)
				{
					output.WriteLine(this.commandQueue.Peek());
					output.Flush();
					this.commandQueue.Dequeue();
					stopwatch.Reset();
					stopwatch.Start();
				}
			}
		}
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x0001DDB0 File Offset: 0x0001BFB0
	public void SendCommand(string cmd)
	{
		Queue<string> obj = this.commandQueue;
		lock (obj)
		{
			this.commandQueue.Enqueue(cmd);
		}
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0001DDF8 File Offset: 0x0001BFF8
	public void SendMsg(string msg)
	{
		Queue<string> obj = this.commandQueue;
		lock (obj)
		{
			this.commandQueue.Enqueue("PRIVMSG #" + this.nickName.ToLower() + " :" + msg);
		}
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0001DE58 File Offset: 0x0001C058
	private void Start()
	{
		Object.DontDestroyOnLoad(base.gameObject);
		if (this.oauth.Length > 0 && this.nickName.Length > 0)
		{
			this.StartIRC();
		}
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0001DE87 File Offset: 0x0001C087
	private void OnEnable()
	{
		this.stopThreads = false;
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x0001DE90 File Offset: 0x0001C090
	public void Login(string user, string oAuth)
	{
		this.oauth = oAuth;
		this.nickName = user;
		this.StartIRC();
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x0001DEA6 File Offset: 0x0001C0A6
	private void OnDisable()
	{
		this.stopThreads = true;
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0001DEA6 File Offset: 0x0001C0A6
	private void OnDestroy()
	{
		this.stopThreads = true;
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0001DEB0 File Offset: 0x0001C0B0
	public void Disconnect()
	{
		this.stopThreads = true;
		this.inProc.Interrupt();
		this.outProc.Abort();
		this.inProc.Abort();
		this.outProc.Abort();
		this.sock.Close();
		this.commandQueue = new Queue<string>();
		this.recievedMsgs = new List<string>();
		this.buffer = string.Empty;
		if (Object.FindObjectOfType<TwitchLogin>() != null)
		{
			TwitchLogin[] array = Object.FindObjectsOfType<TwitchLogin>();
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Disconnect();
			}
		}
		Debug.Log("Chat Disconnected");
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x0001DF50 File Offset: 0x0001C150
	private void Update()
	{
		List<string> obj = this.recievedMsgs;
		lock (obj)
		{
			if (this.recievedMsgs.Count > 0)
			{
				for (int i = 0; i < this.recievedMsgs.Count; i++)
				{
					this.messageRecievedEvent.Invoke(this.recievedMsgs[i]);
				}
				this.recievedMsgs.Clear();
			}
		}
	}

	// Token: 0x0400059B RID: 1435
	[Tooltip("oAuth Token for Twitch Account")]
	public string oauth;

	// Token: 0x0400059C RID: 1436
	[Tooltip("Twitch Account Username")]
	public string nickName;

	// Token: 0x0400059D RID: 1437
	private string server = "irc.twitch.tv";

	// Token: 0x0400059E RID: 1438
	private int port = 6667;

	// Token: 0x0400059F RID: 1439
	public TwitchIRC.MsgEvent messageRecievedEvent = new TwitchIRC.MsgEvent();

	// Token: 0x040005A0 RID: 1440
	private string buffer = string.Empty;

	// Token: 0x040005A1 RID: 1441
	private bool stopThreads;

	// Token: 0x040005A2 RID: 1442
	private Queue<string> commandQueue = new Queue<string>();

	// Token: 0x040005A3 RID: 1443
	private List<string> recievedMsgs = new List<string>();

	// Token: 0x040005A4 RID: 1444
	private Thread inProc;

	// Token: 0x040005A5 RID: 1445
	private Thread outProc;

	// Token: 0x040005A6 RID: 1446
	public TwitchIRC.didConnect Connected;

	// Token: 0x040005A7 RID: 1447
	public TwitchIRC.didDisconnect Disconnected;

	// Token: 0x040005A8 RID: 1448
	private TcpClient sock;

	// Token: 0x02000327 RID: 807
	public class MsgEvent : UnityEvent<string>
	{
	}

	// Token: 0x02000328 RID: 808
	// (Invoke) Token: 0x060015FB RID: 5627
	public delegate void didConnect();

	// Token: 0x02000329 RID: 809
	// (Invoke) Token: 0x060015FF RID: 5631
	public delegate void didDisconnect();
}
