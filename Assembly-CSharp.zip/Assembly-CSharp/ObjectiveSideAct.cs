﻿using System;
using UnityEngine;

// Token: 0x0200006D RID: 109
public class ObjectiveSideAct : MonoBehaviour
{
	// Token: 0x060003DA RID: 986 RVA: 0x00018E61 File Offset: 0x00017061
	private void OnEnable()
	{
		if ((float)Screen.width / (float)Screen.height < 1.26f)
		{
			return;
		}
		this.scOb.ShowObjectives(base.transform, 0, true, false, 2f);
	}

	// Token: 0x060003DB RID: 987 RVA: 0x00018E91 File Offset: 0x00017091
	private void OnDisable()
	{
		this.scOb.DestroyBoxes();
	}

	// Token: 0x040004B4 RID: 1204
	public ObjectiveAct scOb;
}
