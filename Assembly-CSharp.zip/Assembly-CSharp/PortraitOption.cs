﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000070 RID: 112
public class PortraitOption : MonoBehaviour
{
	// Token: 0x060003E8 RID: 1000 RVA: 0x00003E98 File Offset: 0x00002098
	private void Start()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x0001923E File Offset: 0x0001743E
	public void ChangePortrait(bool isOn)
	{
		base.StartCoroutine("DoChangePortrait");
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x0001924C File Offset: 0x0001744C
	private IEnumerator DoChangePortrait()
	{
		if (this.togglePortrait.isOn)
		{
			PlayerPrefs.SetInt("forceportrait", 1);
			Screen.orientation = ScreenOrientation.Portrait;
		}
		else
		{
			if (!InputAct.diff.isLandscape(true))
			{
				yield break;
			}
			PlayerPrefs.DeleteKey("forceportrait");
			Screen.orientation = ScreenOrientation.LandscapeLeft;
			yield return 0;
			Screen.orientation = ScreenOrientation.AutoRotation;
			Screen.autorotateToLandscapeLeft = (Screen.autorotateToLandscapeRight = true);
			Screen.autorotateToPortrait = (Screen.autorotateToPortraitUpsideDown = false);
		}
		JukeBox.diff.PlaySound(SFXTypes.ui_button_next, false, false, 2.5f, -1, 1.5f, 1f);
		yield break;
	}

	// Token: 0x040004BD RID: 1213
	public Toggle togglePortrait;
}
