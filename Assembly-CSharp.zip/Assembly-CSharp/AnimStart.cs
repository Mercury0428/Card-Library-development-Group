﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000019 RID: 25
public class AnimStart : MonoBehaviour
{
	// Token: 0x060000BA RID: 186 RVA: 0x00004DA4 File Offset: 0x00002FA4
	private void OnEnable()
	{
		this.trans = base.GetComponent<RectTransform>();
		base.StopAllCoroutines();
		float num = 0f;
		foreach (SVGImage svgimage in this.ima)
		{
			base.StartCoroutine(this.Anim(svgimage, num));
			num += 0.2f;
		}
		base.StartCoroutine("YieldAndText");
	}

	// Token: 0x060000BB RID: 187 RVA: 0x00004E2C File Offset: 0x0000302C
	private IEnumerator YieldAndText()
	{
		yield return null;
		Text componentInChildren = base.GetComponentInChildren<Text>();
		if (InputAct.diff.curInput != Inputs.touch)
		{
			componentInChildren.text = SpeechAct.diff.GetSceneText("action_" + InputAct.diff.curInput.ToString());
		}
		yield break;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00004E3B File Offset: 0x0000303B
	private IEnumerator Anim(SVGImage ima, float delay)
	{
		yield return new WaitForSeconds(delay);
		WaitForSeconds swait = new WaitForSeconds(0.4f);
		WaitForSeconds lwait = new WaitForSeconds(1f);
		for (;;)
		{
			ima.CrossFadeAlpha(0.01f, 0.2f, true);
			yield return swait;
			ima.CrossFadeAlpha(1f, 0.3f, true);
			yield return lwait;
		}
		yield break;
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00004E51 File Offset: 0x00003051
	public void HideText()
	{
		this.but.SetActive(false);
		this.trans.anchoredPosition = new Vector2(-566f, this.trans.anchoredPosition.y);
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00004E84 File Offset: 0x00003084
	public void ShowText()
	{
		base.StopCoroutine("DoShowTxt");
		base.StartCoroutine("DoShowTxt");
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00004E9D File Offset: 0x0000309D
	private IEnumerator DoShowTxt()
	{
		yield return null;
		this.but.SetActive(true);
		float t = 0f;
		Vector2 tpo = new Vector2(-616f, this.trans.anchoredPosition.y);
		while (t < 1f)
		{
			this.trans.anchoredPosition = Vector2.Lerp(this.trans.anchoredPosition, tpo, Time.deltaTime * 6f);
			t += Time.deltaTime;
			yield return null;
		}
		this.trans.anchoredPosition = tpo;
		yield break;
	}

	// Token: 0x040000A3 RID: 163
	public List<SVGImage> ima;

	// Token: 0x040000A4 RID: 164
	private RectTransform trans;

	// Token: 0x040000A5 RID: 165
	public GameObject but;
}
