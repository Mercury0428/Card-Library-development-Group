﻿using System;
using System.Text;
using UnityEngine;

namespace GooglePlayInstant
{
	// Token: 0x020001FB RID: 507
	public static class CookieApi
	{
		// Token: 0x06001066 RID: 4198 RVA: 0x00061DBC File Offset: 0x0005FFBC
		public static int GetInstantAppCookieMaxSizeBytes()
		{
			int result;
			using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("android.os.Bundle", Array.Empty<object>()))
			{
				using (AndroidJavaObject androidJavaObject2 = CookieApi.CallMethod("getInstantAppCookieMaxSize", androidJavaObject))
				{
					result = androidJavaObject2.Call<int>("getInt", new object[]
					{
						"result"
					});
				}
			}
			return result;
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x00061E34 File Offset: 0x00060034
		public static string GetInstantAppCookie()
		{
			byte[] instantAppCookieBytes = CookieApi.GetInstantAppCookieBytes();
			if (instantAppCookieBytes != null)
			{
				return Encoding.UTF8.GetString(instantAppCookieBytes);
			}
			return null;
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x00061E58 File Offset: 0x00060058
		public static byte[] GetInstantAppCookieBytes()
		{
			byte[] result;
			using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("android.os.Bundle", Array.Empty<object>()))
			{
				androidJavaObject.Call("putInt", new object[]
				{
					"uid",
					CookieApi.ProcessGetMyUid()
				});
				using (AndroidJavaObject androidJavaObject2 = CookieApi.CallMethod("getInstantAppCookie", androidJavaObject))
				{
					result = androidJavaObject2.Call<byte[]>("getByteArray", new object[]
					{
						"result"
					});
				}
			}
			return result;
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x00061EF4 File Offset: 0x000600F4
		public static bool SetInstantAppCookie(string cookie)
		{
			return CookieApi.SetInstantAppCookieBytes((cookie == null) ? null : Encoding.UTF8.GetBytes(cookie));
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x00061F0C File Offset: 0x0006010C
		public static bool SetInstantAppCookieBytes(byte[] cookie)
		{
			bool result;
			using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("android.os.Bundle", Array.Empty<object>()))
			{
				androidJavaObject.Call("putInt", new object[]
				{
					"uid",
					CookieApi.ProcessGetMyUid()
				});
				androidJavaObject.Call("putByteArray", new object[]
				{
					"cookie",
					cookie
				});
				using (AndroidJavaObject androidJavaObject2 = CookieApi.CallMethod("setInstantAppCookie", androidJavaObject))
				{
					result = androidJavaObject2.Call<bool>("getBoolean", new object[]
					{
						"result"
					});
				}
			}
			return result;
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x00061FC8 File Offset: 0x000601C8
		private static void VerifyContentProvider()
		{
			if (CookieApi._verifiedContentProvider)
			{
				return;
			}
			using (AndroidJavaObject currentActivity = UnityPlayerHelper.GetCurrentActivity())
			{
				using (AndroidJavaObject androidJavaObject = currentActivity.Call<AndroidJavaObject>("getPackageManager", Array.Empty<object>()))
				{
					using (AndroidJavaObject androidJavaObject2 = androidJavaObject.Call<AndroidJavaObject>("resolveContentProvider", new object[]
					{
						"com.google.android.gms.instantapps.provider.api",
						0
					}))
					{
						if (!PlaySignatureVerifier.VerifyGooglePlayServices(androidJavaObject))
						{
							throw new CookieApi.CookieApiException("Failed to verify the signature of Google Play Services.");
						}
						if (androidJavaObject2 == null)
						{
							throw new CookieApi.CookieApiException("Failed to resolve the instant apps content provider.");
						}
						string text = androidJavaObject2.Get<string>("packageName");
						if (!string.Equals(text, "com.google.android.gms"))
						{
							throw new CookieApi.CookieApiException(string.Format("Package \"{0}\" is an invalid instant apps content provider.", text));
						}
					}
				}
			}
			Debug.Log("Verified instant apps content provider.");
			CookieApi._verifiedContentProvider = true;
		}

		// Token: 0x0600106C RID: 4204 RVA: 0x000620BC File Offset: 0x000602BC
		private static AndroidJavaObject CallMethod(string methodName, AndroidJavaObject extrasBundle)
		{
			CookieApi.VerifyContentProvider();
			AndroidJavaObject androidJavaObject3;
			try
			{
				using (AndroidJavaObject currentActivity = UnityPlayerHelper.GetCurrentActivity())
				{
					using (AndroidJavaObject androidJavaObject = currentActivity.Call<AndroidJavaObject>("getContentResolver", Array.Empty<object>()))
					{
						using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.net.Uri"))
						{
							using (AndroidJavaObject androidJavaObject2 = androidJavaClass.CallStatic<AndroidJavaObject>("parse", new object[]
							{
								"content://com.google.android.gms.instantapps.provider.api/"
							}))
							{
								androidJavaObject3 = androidJavaObject.Call<AndroidJavaObject>("call", new object[]
								{
									androidJavaObject2,
									methodName,
									null,
									extrasBundle
								});
							}
						}
					}
				}
			}
			catch (AndroidJavaException innerException)
			{
				throw new CookieApi.CookieApiException(string.Format("Failed to call {0} on the instant apps content provider.", methodName), innerException);
			}
			if (androidJavaObject3 == null)
			{
				throw new CookieApi.CookieApiException(string.Format("Null result calling {0} on the instant apps content provider.", methodName));
			}
			return androidJavaObject3;
		}

		// Token: 0x0600106D RID: 4205 RVA: 0x000621C8 File Offset: 0x000603C8
		private static int ProcessGetMyUid()
		{
			int result;
			using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.os.Process"))
			{
				result = androidJavaClass.CallStatic<int>("myUid", Array.Empty<object>());
			}
			return result;
		}

		// Token: 0x04000D0D RID: 3341
		private const string Authority = "com.google.android.gms.instantapps.provider.api";

		// Token: 0x04000D0E RID: 3342
		private const string ContentAuthority = "content://com.google.android.gms.instantapps.provider.api/";

		// Token: 0x04000D0F RID: 3343
		private const string KeyCookie = "cookie";

		// Token: 0x04000D10 RID: 3344
		private const string KeyResult = "result";

		// Token: 0x04000D11 RID: 3345
		private const string KeyUid = "uid";

		// Token: 0x04000D12 RID: 3346
		private const string MethodGetInstantAppCookie = "getInstantAppCookie";

		// Token: 0x04000D13 RID: 3347
		private const string MethodGetInstantAppCookieMaxSize = "getInstantAppCookieMaxSize";

		// Token: 0x04000D14 RID: 3348
		private const string MethodSetInstantAppCookie = "setInstantAppCookie";

		// Token: 0x04000D15 RID: 3349
		private static bool _verifiedContentProvider;

		// Token: 0x020003D6 RID: 982
		public class CookieApiException : Exception
		{
			// Token: 0x0600188F RID: 6287 RVA: 0x0002D3AB File Offset: 0x0002B5AB
			public CookieApiException(string message, Exception innerException) : base(message, innerException)
			{
			}

			// Token: 0x06001890 RID: 6288 RVA: 0x0004CDBC File Offset: 0x0004AFBC
			public CookieApiException(string message) : base(message)
			{
			}
		}
	}
}
