﻿using System;

namespace GooglePlayInstant
{
	// Token: 0x020001FA RID: 506
	public static class Android
	{
		// Token: 0x04000CE4 RID: 3300
		public const string GooglePlayServicesPackageName = "com.google.android.gms";

		// Token: 0x04000CE5 RID: 3301
		public const string GooglePlayStorePackageName = "com.android.vending";

		// Token: 0x04000CE6 RID: 3302
		public const string ActivityMethodGetIntent = "getIntent";

		// Token: 0x04000CE7 RID: 3303
		public const string ActivityMethodStartActivityForResult = "startActivityForResult";

		// Token: 0x04000CE8 RID: 3304
		public const string BundleClass = "android.os.Bundle";

		// Token: 0x04000CE9 RID: 3305
		public const string BundleMethodGetBoolean = "getBoolean";

		// Token: 0x04000CEA RID: 3306
		public const string BundleMethodGetByteArray = "getByteArray";

		// Token: 0x04000CEB RID: 3307
		public const string BundleMethodGetInt = "getInt";

		// Token: 0x04000CEC RID: 3308
		public const string BundleMethodPutByteArray = "putByteArray";

		// Token: 0x04000CED RID: 3309
		public const string BundleMethodPutInt = "putInt";

		// Token: 0x04000CEE RID: 3310
		public const string ContentResolverMethodCall = "call";

		// Token: 0x04000CEF RID: 3311
		public const string ContextMethodGetContentResolver = "getContentResolver";

		// Token: 0x04000CF0 RID: 3312
		public const string ContextMethodGetPackageManager = "getPackageManager";

		// Token: 0x04000CF1 RID: 3313
		public const string IntentActionMain = "android.intent.action.MAIN";

		// Token: 0x04000CF2 RID: 3314
		public const string IntentActionView = "android.intent.action.VIEW";

		// Token: 0x04000CF3 RID: 3315
		public const string IntentCategoryBrowsable = "android.intent.category.BROWSABLE";

		// Token: 0x04000CF4 RID: 3316
		public const string IntentCategoryDefault = "android.intent.category.DEFAULT";

		// Token: 0x04000CF5 RID: 3317
		public const string IntentCategoryLauncher = "android.intent.category.LAUNCHER";

		// Token: 0x04000CF6 RID: 3318
		public const string IntentClass = "android.content.Intent";

		// Token: 0x04000CF7 RID: 3319
		public const string IntentMethodAddCategory = "addCategory";

		// Token: 0x04000CF8 RID: 3320
		public const string IntentMethodGetStringExtra = "getStringExtra";

		// Token: 0x04000CF9 RID: 3321
		public const string IntentMethodPutExtra = "putExtra";

		// Token: 0x04000CFA RID: 3322
		public const string IntentMethodSetData = "setData";

		// Token: 0x04000CFB RID: 3323
		public const string IntentMethodSetPackage = "setPackage";

		// Token: 0x04000CFC RID: 3324
		public const string ObjectMethodGetClass = "getClass";

		// Token: 0x04000CFD RID: 3325
		public const string PackageInfoFieldSignatures = "signatures";

		// Token: 0x04000CFE RID: 3326
		public const int PackageManagerFieldGetSignatures = 64;

		// Token: 0x04000CFF RID: 3327
		public const string PackageManagerMethodGetPackageInfo = "getPackageInfo";

		// Token: 0x04000D00 RID: 3328
		public const string PackageManagerMethodResolveActivity = "resolveActivity";

		// Token: 0x04000D01 RID: 3329
		public const string PackageManagerMethodResolveContentProvider = "resolveContentProvider";

		// Token: 0x04000D02 RID: 3330
		public const string ProcessClass = "android.os.Process";

		// Token: 0x04000D03 RID: 3331
		public const string ProcessMethodMyUid = "myUid";

		// Token: 0x04000D04 RID: 3332
		public const string ProviderInfoFieldPackageName = "packageName";

		// Token: 0x04000D05 RID: 3333
		public const string SignatureMethodToByteArray = "toByteArray";

		// Token: 0x04000D06 RID: 3334
		public const string UriClass = "android.net.Uri";

		// Token: 0x04000D07 RID: 3335
		public const string UriMethodParse = "parse";

		// Token: 0x04000D08 RID: 3336
		public const string UriBuilderClass = "android.net.Uri$Builder";

		// Token: 0x04000D09 RID: 3337
		public const string UriBuilderMethodAppendQueryParameter = "appendQueryParameter";

		// Token: 0x04000D0A RID: 3338
		public const string UriBuilderMethodAuthority = "authority";

		// Token: 0x04000D0B RID: 3339
		public const string UriBuilderMethodBuild = "build";

		// Token: 0x04000D0C RID: 3340
		public const string UriBuilderMethodScheme = "scheme";
	}
}
