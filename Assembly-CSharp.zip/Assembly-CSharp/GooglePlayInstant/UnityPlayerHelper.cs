﻿using System;
using UnityEngine;

namespace GooglePlayInstant
{
	// Token: 0x020001FE RID: 510
	public static class UnityPlayerHelper
	{
		// Token: 0x0600107A RID: 4218 RVA: 0x00062780 File Offset: 0x00060980
		public static AndroidJavaObject GetCurrentActivity()
		{
			AndroidJavaObject @static;
			using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
			{
				@static = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
			}
			return @static;
		}
	}
}
