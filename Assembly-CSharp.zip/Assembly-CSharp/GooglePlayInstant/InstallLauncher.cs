﻿using System;
using UnityEngine;

namespace GooglePlayInstant
{
	// Token: 0x020001FC RID: 508
	public static class InstallLauncher
	{
		// Token: 0x0600106E RID: 4206 RVA: 0x00062210 File Offset: 0x00060410
		public static void ShowInstallPrompt()
		{
			using (AndroidJavaObject currentActivity = UnityPlayerHelper.GetCurrentActivity())
			{
				using (AndroidJavaObject androidJavaObject = InstallLauncher.CreatePostInstallIntent(currentActivity))
				{
					InstallLauncher.ShowInstallPrompt(currentActivity, 1001, androidJavaObject, null);
				}
			}
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x0006226C File Offset: 0x0006046C
		public static void ShowInstallPrompt(AndroidJavaObject activity, int requestCode, AndroidJavaObject postInstallIntent, string referrer)
		{
		}

		// Token: 0x06001070 RID: 4208 RVA: 0x00062279 File Offset: 0x00060479
		[Obsolete("Use UnityPlayerHelper.GetCurrentActivity() instead.")]
		public static AndroidJavaObject GetCurrentActivity()
		{
			return UnityPlayerHelper.GetCurrentActivity();
		}

		// Token: 0x06001071 RID: 4209 RVA: 0x00062280 File Offset: 0x00060480
		public static AndroidJavaObject CreatePostInstallIntent(AndroidJavaObject activity)
		{
			AndroidJavaObject result;
			using (AndroidJavaObject androidJavaObject = activity.Call<AndroidJavaObject>("getClass", Array.Empty<object>()))
			{
				result = new AndroidJavaObject("android.content.Intent", new object[]
				{
					activity,
					androidJavaObject
				});
			}
			return result;
		}

		// Token: 0x06001072 RID: 4210 RVA: 0x000622D4 File Offset: 0x000604D4
		public static void PutPostInstallIntentStringExtra(AndroidJavaObject postInstallIntent, string extraKey, string extraValue)
		{
			using (postInstallIntent.Call<AndroidJavaObject>("putExtra", new object[]
			{
				extraKey,
				extraValue
			}))
			{
			}
		}

		// Token: 0x06001073 RID: 4211 RVA: 0x00062318 File Offset: 0x00060518
		public static string GetPostInstallIntentStringExtra(string extraKey)
		{
			string result;
			using (AndroidJavaObject currentActivity = UnityPlayerHelper.GetCurrentActivity())
			{
				using (AndroidJavaObject androidJavaObject = currentActivity.Call<AndroidJavaObject>("getIntent", Array.Empty<object>()))
				{
					result = androidJavaObject.Call<string>("getStringExtra", new object[]
					{
						extraKey
					});
				}
			}
			return result;
		}

		// Token: 0x06001074 RID: 4212 RVA: 0x00062388 File Offset: 0x00060588
		private static AndroidJavaObject CreateMarketDetailsUri(string referrer)
		{
			AndroidJavaObject androidJavaObject5;
			using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("android.net.Uri$Builder", Array.Empty<object>()))
			{
				using (androidJavaObject.Call<AndroidJavaObject>("scheme", new object[]
				{
					"market"
				}))
				{
					using (androidJavaObject.Call<AndroidJavaObject>("authority", new object[]
					{
						"details"
					}))
					{
						using (androidJavaObject.Call<AndroidJavaObject>("appendQueryParameter", new object[]
						{
							"id",
							Application.identifier
						}))
						{
							if (!string.IsNullOrEmpty(referrer))
							{
								using (androidJavaObject.Call<AndroidJavaObject>("appendQueryParameter", new object[]
								{
									"referrer",
									referrer
								}))
								{
								}
							}
							androidJavaObject5 = androidJavaObject.Call<AndroidJavaObject>("build", Array.Empty<object>());
						}
					}
				}
			}
			return androidJavaObject5;
		}

		// Token: 0x06001075 RID: 4213 RVA: 0x000624B0 File Offset: 0x000606B0
		private static bool IsLegacyPlayStore(AndroidJavaObject context, AndroidJavaObject installIntent)
		{
			bool result;
			using (AndroidJavaObject androidJavaObject = context.Call<AndroidJavaObject>("getPackageManager", Array.Empty<object>()))
			{
				using (AndroidJavaObject androidJavaObject2 = androidJavaObject.Call<AndroidJavaObject>("resolveActivity", new object[]
				{
					installIntent,
					0
				}))
				{
					result = (androidJavaObject2 == null);
				}
			}
			return result;
		}

		// Token: 0x06001076 RID: 4214 RVA: 0x00062528 File Offset: 0x00060728
		private static void ShowLegacyInstallPrompt(AndroidJavaObject activity, int requestCode, AndroidJavaObject uri)
		{
			using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("android.content.Intent", new object[]
			{
				"android.intent.action.VIEW"
			}))
			{
				using (androidJavaObject.Call<AndroidJavaObject>("addCategory", new object[]
				{
					"android.intent.category.DEFAULT"
				}))
				{
					using (androidJavaObject.Call<AndroidJavaObject>("setPackage", new object[]
					{
						"com.android.vending"
					}))
					{
						using (androidJavaObject.Call<AndroidJavaObject>("setData", new object[]
						{
							uri
						}))
						{
							using (androidJavaObject.Call<AndroidJavaObject>("putExtra", new object[]
							{
								"callerId",
								Application.identifier
							}))
							{
								using (androidJavaObject.Call<AndroidJavaObject>("putExtra", new object[]
								{
									"overlay",
									true
								}))
								{
									activity.Call("startActivityForResult", new object[]
									{
										androidJavaObject,
										requestCode
									});
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x04000D16 RID: 3350
		private const string IntentActionInstantAppInstall = "com.google.android.finsky.action.IA_INSTALL";

		// Token: 0x04000D17 RID: 3351
		private const int IgnoredRequestCode = 1001;
	}
}
