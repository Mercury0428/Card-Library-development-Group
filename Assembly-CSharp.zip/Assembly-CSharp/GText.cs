﻿using System;

// Token: 0x02000075 RID: 117
[Serializable]
public class GText
{
	// Token: 0x06000403 RID: 1027 RVA: 0x00002050 File Offset: 0x00000250
	public GText()
	{
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x00019AE0 File Offset: 0x00017CE0
	public GText(string input)
	{
		if (string.IsNullOrEmpty(input))
		{
			this.isEmpty = true;
			return;
		}
		bool flag = input.Contains("*");
		bool flag2 = input.Contains("%");
		this.genre = ((flag && flag2) ? Genres.all : ((flag && !flag2) ? Genres.mona : ((!flag && flag2) ? Genres.self : Genres.univ)));
		if (this.genre == Genres.univ)
		{
			this.mMsM = input;
			return;
		}
		string[] array = this.TreatInput(input, '*', '(', ')');
		this.mMsM = "";
		if (flag)
		{
			this.mFsM = "";
		}
		if (flag && flag2)
		{
			this.mFsF = "";
		}
		if (flag2)
		{
			this.mMsF = "";
		}
		for (int i = 0; i < array.Length; i++)
		{
			string[] array2 = this.TreatInput(array[i], '%', '[', ']');
			if (array2.Length == 4)
			{
				if (i != 2)
				{
					this.mMsM = this.mMsM + array2[0] + array2[1] + array2[3];
				}
				if (flag2 && i != 2)
				{
					this.mMsF = this.mMsF + array2[0] + array2[2] + array2[3];
				}
				if (flag && i != 1)
				{
					this.mFsM = this.mFsM + array2[0] + array2[1] + array2[3];
				}
				if (flag2 && flag && i != 1)
				{
					this.mFsF = this.mFsF + array2[0] + array2[2] + array2[3];
				}
			}
			else
			{
				if (i != 2)
				{
					this.mMsM += array[i];
				}
				if (flag2 && i != 2)
				{
					this.mMsF += array[i];
				}
				if (flag && i != 1)
				{
					this.mFsM += array[i];
				}
				if (flag && flag2 && i != 1)
				{
					this.mFsF += array[i];
				}
			}
		}
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x00019CC4 File Offset: 0x00017EC4
	public GText TreatName()
	{
		if (this.isEmpty)
		{
			return this;
		}
		this.mMsM = SpeechAct.diff.GenericName(this.mMsM);
		if (!string.IsNullOrEmpty(this.mMsF))
		{
			this.mMsF = SpeechAct.diff.GenericName(this.mMsF);
		}
		if (!string.IsNullOrEmpty(this.mFsF))
		{
			this.mFsF = SpeechAct.diff.GenericName(this.mFsF);
		}
		if (!string.IsNullOrEmpty(this.mFsM))
		{
			this.mFsM = SpeechAct.diff.GenericName(this.mFsM);
		}
		return this;
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x00019D5B File Offset: 0x00017F5B
	public string Get()
	{
		return this.Get(SpeechAct.diff.isMonarkMale, SpeechAct.diff.isSelfMale);
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x00019D78 File Offset: 0x00017F78
	public string Get(bool maleKing, bool maleSelf)
	{
		switch (this.genre)
		{
		case Genres.mona:
			if (!maleKing)
			{
				return this.mFsM;
			}
			return this.mMsM;
		case Genres.self:
			if (!maleSelf)
			{
				return this.mMsF;
			}
			return this.mMsM;
		case Genres.all:
			if (maleKing)
			{
				if (!maleSelf)
				{
					return this.mMsF;
				}
				return this.mMsM;
			}
			else
			{
				if (!maleSelf)
				{
					return this.mFsF;
				}
				return this.mFsM;
			}
			break;
		default:
			return this.mMsM;
		}
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x00019DF0 File Offset: 0x00017FF0
	private string[] TreatInput(string input, char delim, char start, char end)
	{
		if (!input.Contains(delim.ToString()))
		{
			return new string[]
			{
				input
			};
		}
		string[] array = new string[]
		{
			"",
			"",
			"",
			""
		};
		string[] array2 = input.Split(new char[]
		{
			delim
		});
		string[] array3 = array2[0].Split(new char[]
		{
			start
		});
		string[] array4 = array2[1].Split(new char[]
		{
			end
		});
		if (array3.Length == 1)
		{
			array[1] = array3[0];
		}
		else
		{
			array[0] = array3[0];
			array[1] = array3[1];
		}
		if (array4.Length == 1)
		{
			array[2] = array4[0];
		}
		else
		{
			array[2] = array4[0];
			array[3] = array4[1];
		}
		return array;
	}

	// Token: 0x040004D5 RID: 1237
	public Genres genre;

	// Token: 0x040004D6 RID: 1238
	public bool isEmpty;

	// Token: 0x040004D7 RID: 1239
	public string mMsM;

	// Token: 0x040004D8 RID: 1240
	public string mFsM;

	// Token: 0x040004D9 RID: 1241
	public string mFsF;

	// Token: 0x040004DA RID: 1242
	public string mMsF;
}
