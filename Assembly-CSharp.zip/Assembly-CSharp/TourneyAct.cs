﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000099 RID: 153
public class TourneyAct : MonoBehaviour
{
	// Token: 0x060004C2 RID: 1218 RVA: 0x0001D304 File Offset: 0x0001B504
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnRefresh = (Action<Card>)Delegate.Combine(diff.OnRefresh, new Action<Card>(this.CheckTourney));
		this.selfT = base.GetComponent<RectTransform>();
		this.rulerTrans = this.ruler.GetComponent<RectTransform>();
		this.oppoTrans = this.oppo.GetComponent<RectTransform>();
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x0001D368 File Offset: 0x0001B568
	private void CheckTourney(Card card)
	{
		bool flag = card.bearer == Bearers.end;
		if (this.hasTourney)
		{
			if (GameAct.diff.GetInt("nb_jousting") < 1 || flag)
			{
				this.CloseTourney();
			}
			return;
		}
		if (GameAct.diff.GetInt("nb_jousting") > 0)
		{
			this.OpenTourney();
		}
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x0001D3C4 File Offset: 0x0001B5C4
	private void OpenTourney()
	{
		this.Enable();
		this.hasTourney = true;
		this.isJousting = false;
		this.started = false;
		BackgroundAct.diff.SwitchWithTop(this.selfT, true);
		this.rulerTrans.anchoredPosition = this.rulerPos;
		this.oppoTrans.anchoredPosition = this.oppoPos;
		GameAct diff = GameAct.diff;
		diff.OnCardHiding = (Func<CardTypes, bool>)Delegate.Combine(diff.OnCardHiding, new Func<CardTypes, bool>(this.CheckAttack));
		this.ruler.vectorGraphics = this.rulerWait;
		this.ruler.SetNativeSize();
		this.oppo.vectorGraphics = this.oppoWait;
		this.oppo.SetNativeSize();
		JukeBox.diff.StopMusic(false);
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x0001D488 File Offset: 0x0001B688
	private void CloseTourney()
	{
		this.hasTourney = false;
		BackgroundAct.diff.SwitchWithTop(this.selfT, false);
		GameAct diff = GameAct.diff;
		diff.OnCardHiding = (Func<CardTypes, bool>)Delegate.Remove(diff.OnCardHiding, new Func<CardTypes, bool>(this.CheckAttack));
		JukeBox.diff.RestartMusic();
		base.StartCoroutine("DoDisable");
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x0001D4E9 File Offset: 0x0001B6E9
	private IEnumerator DoDisable()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(false);
		}
		base.StopAllCoroutines();
		yield break;
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x0001D4F8 File Offset: 0x0001B6F8
	private void Enable()
	{
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(true);
		}
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x0001D554 File Offset: 0x0001B754
	private bool CheckAttack(CardTypes type)
	{
		if (!this.hasTourney)
		{
			return false;
		}
		string nextCard = GameAct.diff.nextCard;
		if (nextCard == "_jousting_events")
		{
			if (GameAct.diff.GetInt("nb_jousting") > 1)
			{
				this.ResetPos();
			}
		}
		else if (nextCard == "_jousting_results")
		{
			if (this.started)
			{
				this.started = this.isJousting;
				return !this.isJousting;
			}
			this.isJousting = (this.started = true);
			bool flag = GameAct.diff.GetBool("jousting_win");
			int num = Util.RandInt(0, 100);
			if (!flag)
			{
				flag = (num < GameAct.diff.GetInt(Variables.power));
			}
			GameAct.diff.SetBool("jousting_win", flag);
			this.StartJousting(flag);
			return false;
		}
		return true;
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x0001D628 File Offset: 0x0001B828
	private void StartJousting(bool win)
	{
		base.StopCoroutine("DoJoust");
		base.StartCoroutine("DoJoust", win);
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x0001D647 File Offset: 0x0001B847
	private IEnumerator DoJoust(bool win)
	{
		JukeBox.diff.PlaySound(SFXTypes.sfx_tourney_attack, false, false, 2.5f, -1, 1.5f, 1f);
		float t = 0f;
		float a = 0.2f;
		base.StopCoroutine("Animate");
		base.StartCoroutine("Animate");
		while (t < 1f)
		{
			a = Mathf.Clamp(a + Time.deltaTime * 8f, 0f, 2f);
			t += Time.deltaTime * 1.5f * a;
			this.rulerTrans.anchoredPosition = Vector2.Lerp(this.rulerPos, this.rulerTar, t);
			this.oppoTrans.anchoredPosition = Vector2.Lerp(this.oppoPos, this.oppoTar, t);
			yield return 0;
		}
		this.ruler.enabled = false;
		this.oppo.enabled = false;
		this.cloud.enabled = true;
		yield return new WaitForSeconds(0.2f);
		this.cloud.enabled = false;
		this.ruler.enabled = true;
		this.oppo.enabled = true;
		if (win)
		{
			this.ruler.vectorGraphics = this.rulerWon;
			this.ruler.SetNativeSize();
			this.oppo.vectorGraphics = this.oppoLost;
			this.oppo.SetNativeSize();
		}
		else
		{
			this.ruler.vectorGraphics = this.rulerLost;
			this.ruler.SetNativeSize();
			this.oppo.vectorGraphics = this.oppoWon;
			this.oppo.SetNativeSize();
		}
		this.rulerTrans.anchoredPosition = new Vector2(40f, 184f);
		this.oppoTrans.anchoredPosition = new Vector2(-40f, 184f);
		JukeBox.diff.PlaySound(SFXTypes.sfx_crowd_cheer, false, false, 2.5f, -1, 1.5f, 1f);
		yield return new WaitForSeconds(0.8f);
		this.isJousting = false;
		yield break;
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x0001D65D File Offset: 0x0001B85D
	private IEnumerator Animate()
	{
		int num;
		for (int i = 0; i < 3; i = num + 1)
		{
			yield return new WaitForSeconds(0.1f);
			this.ruler.vectorGraphics = this.rulerRun[i];
			this.ruler.SetNativeSize();
			this.oppo.vectorGraphics = this.oppoRun[i];
			this.oppo.SetNativeSize();
			num = i;
		}
		yield break;
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x0001D66C File Offset: 0x0001B86C
	private void ResetPos()
	{
		this.rulerTrans.anchoredPosition = this.rulerPos;
		this.oppoTrans.anchoredPosition = this.oppoPos;
		this.ruler.vectorGraphics = this.rulerWait;
		this.ruler.SetNativeSize();
		this.oppo.vectorGraphics = this.oppoWait;
		this.oppo.SetNativeSize();
	}

	// Token: 0x04000570 RID: 1392
	public List<SVGAsset> rulerRun;

	// Token: 0x04000571 RID: 1393
	public List<SVGAsset> oppoRun;

	// Token: 0x04000572 RID: 1394
	public SVGAsset rulerWait;

	// Token: 0x04000573 RID: 1395
	public SVGAsset oppoWait;

	// Token: 0x04000574 RID: 1396
	public SVGAsset rulerWon;

	// Token: 0x04000575 RID: 1397
	public SVGAsset oppoWon;

	// Token: 0x04000576 RID: 1398
	public SVGAsset rulerLost;

	// Token: 0x04000577 RID: 1399
	public SVGAsset oppoLost;

	// Token: 0x04000578 RID: 1400
	public SVGImage cloud;

	// Token: 0x04000579 RID: 1401
	public SVGImage ruler;

	// Token: 0x0400057A RID: 1402
	private RectTransform rulerTrans;

	// Token: 0x0400057B RID: 1403
	public SVGImage oppo;

	// Token: 0x0400057C RID: 1404
	private RectTransform oppoTrans;

	// Token: 0x0400057D RID: 1405
	private RectTransform selfT;

	// Token: 0x0400057E RID: 1406
	private bool hasTourney;

	// Token: 0x0400057F RID: 1407
	private bool isJousting;

	// Token: 0x04000580 RID: 1408
	private bool started;

	// Token: 0x04000581 RID: 1409
	private Vector2 rulerPos = new Vector2(-120f, 184f);

	// Token: 0x04000582 RID: 1410
	private Vector2 oppoPos = new Vector2(120f, 184f);

	// Token: 0x04000583 RID: 1411
	private Vector2 rulerTar = new Vector2(-20f, 184f);

	// Token: 0x04000584 RID: 1412
	private Vector2 oppoTar = new Vector2(20f, 184f);
}
