﻿using System;
using UnityEngine;

// Token: 0x02000096 RID: 150
public class SVGDebugMesh : MonoBehaviour
{
}
