﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200001A RID: 26
public class AutoSelectMe : MonoBehaviour
{
	// Token: 0x060000C1 RID: 193 RVA: 0x00004EAC File Offset: 0x000030AC
	private void OnEnable()
	{
		this.Activate();
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00004EB4 File Offset: 0x000030B4
	private IEnumerator YieldSelect()
	{
		yield return null;
		base.GetComponent<Selectable>().enabled = true;
		InputAct.diff.SetSelect(base.gameObject);
		yield break;
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00004EC3 File Offset: 0x000030C3
	public void Activate()
	{
		if (InputAct.diff && !InputAct.diff.NavigationMode())
		{
			return;
		}
		base.StartCoroutine("YieldSelect");
	}
}
