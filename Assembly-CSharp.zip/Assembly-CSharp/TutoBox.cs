﻿using System;
using UnityEngine.UI;

// Token: 0x02000027 RID: 39
public class TutoBox : ContentBox
{
	// Token: 0x0600012A RID: 298 RVA: 0x00006780 File Offset: 0x00004980
	public override void Validate()
	{
		base.Validate();
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00003D07 File Offset: 0x00001F07
	public override void Init(object instance, string txtid, bool trig, bool stayHidden = false)
	{
	}

	// Token: 0x0600012C RID: 300 RVA: 0x00006788 File Offset: 0x00004988
	public override void Close()
	{
		base.Close();
	}

	// Token: 0x04000117 RID: 279
	public Text tutoTxt;
}
