﻿using System;
using UnityEngine;

// Token: 0x02000011 RID: 17
public class NewKingAct : MonoBehaviour
{
}
