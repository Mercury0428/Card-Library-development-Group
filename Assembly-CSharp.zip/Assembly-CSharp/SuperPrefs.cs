﻿using System;
using UnityEngine;

// Token: 0x0200003B RID: 59
public class SuperPrefs
{
	// Token: 0x060001DF RID: 479 RVA: 0x0000BE17 File Offset: 0x0000A017
	public static void SetFloat(string name, float value)
	{
		PlayerPrefs.SetFloat(name, value);
	}

	// Token: 0x060001E0 RID: 480 RVA: 0x0000BE20 File Offset: 0x0000A020
	public static void SetInt(string name, int value)
	{
		PlayerPrefs.SetInt(name, value);
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x0000BE29 File Offset: 0x0000A029
	public static void SetString(string name, string value)
	{
		PlayerPrefs.SetString(name, value);
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x0000BE32 File Offset: 0x0000A032
	public static float GetFloat(string name)
	{
		return PlayerPrefs.GetFloat(name);
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x0000BE3A File Offset: 0x0000A03A
	public static int GetInt(string name)
	{
		return PlayerPrefs.GetInt(name);
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x0000BE42 File Offset: 0x0000A042
	public static string GetString(string name)
	{
		return PlayerPrefs.GetString(name);
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x0000BE4A File Offset: 0x0000A04A
	public static void DeleteKey(string name)
	{
		PlayerPrefs.DeleteKey(name);
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x0000BE52 File Offset: 0x0000A052
	public static void DeleteAll()
	{
		PlayerPrefs.DeleteAll();
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x0000BE59 File Offset: 0x0000A059
	public static bool HasKey(string name)
	{
		return PlayerPrefs.HasKey(name);
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x0000BE61 File Offset: 0x0000A061
	public static void Save()
	{
		PlayerPrefs.Save();
	}
}
