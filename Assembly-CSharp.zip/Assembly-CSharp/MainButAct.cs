﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000068 RID: 104
public class MainButAct : MonoBehaviour
{
	// Token: 0x060003B3 RID: 947 RVA: 0x00017AC5 File Offset: 0x00015CC5
	private void OnEnable()
	{
		this.trans = base.GetComponent<RectTransform>();
		this.trans.anchoredPosition = new Vector2(this.trans.anchoredPosition.x, 357f);
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x00017AF8 File Offset: 0x00015CF8
	public void Move()
	{
		this.trans = base.GetComponent<RectTransform>();
		this.opos = new Vector2(this.trans.anchoredPosition.x, 257f);
		base.StopCoroutine("DoMove");
		this.trans.anchoredPosition = new Vector2(this.trans.anchoredPosition.x, 357f);
		base.StartCoroutine("DoMove");
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00017B6D File Offset: 0x00015D6D
	private IEnumerator DoMove()
	{
		float t = 0f;
		while (t < 1f)
		{
			this.trans.anchoredPosition = Vector2.Lerp(this.trans.anchoredPosition, this.opos, Time.deltaTime * 8f);
			t += Time.deltaTime;
			yield return null;
		}
		this.trans.anchoredPosition = this.opos;
		yield break;
	}

	// Token: 0x04000492 RID: 1170
	private RectTransform trans;

	// Token: 0x04000493 RID: 1171
	private Vector2 opos;
}
