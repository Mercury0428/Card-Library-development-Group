﻿using System;

// Token: 0x0200004E RID: 78
public enum GameStates
{
	// Token: 0x0400034A RID: 842
	start,
	// Token: 0x0400034B RID: 843
	restart,
	// Token: 0x0400034C RID: 844
	interreign,
	// Token: 0x0400034D RID: 845
	interaction,
	// Token: 0x0400034E RID: 846
	transition,
	// Token: 0x0400034F RID: 847
	gameover,
	// Token: 0x04000350 RID: 848
	none
}
