﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001DF RID: 479
	[Serializable]
	public class AmbientOcclusionModel : PostProcessingModel
	{
		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06000FDD RID: 4061 RVA: 0x00060610 File Offset: 0x0005E810
		// (set) Token: 0x06000FDE RID: 4062 RVA: 0x00060618 File Offset: 0x0005E818
		public AmbientOcclusionModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06000FDF RID: 4063 RVA: 0x00060621 File Offset: 0x0005E821
		public override void Reset()
		{
			this.m_Settings = AmbientOcclusionModel.Settings.defaultSettings;
		}

		// Token: 0x04000C96 RID: 3222
		[SerializeField]
		private AmbientOcclusionModel.Settings m_Settings = AmbientOcclusionModel.Settings.defaultSettings;

		// Token: 0x020003AA RID: 938
		public enum SampleCount
		{
			// Token: 0x0400143D RID: 5181
			Lowest = 3,
			// Token: 0x0400143E RID: 5182
			Low = 6,
			// Token: 0x0400143F RID: 5183
			Medium = 10,
			// Token: 0x04001440 RID: 5184
			High = 16
		}

		// Token: 0x020003AB RID: 939
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004E7 RID: 1255
			// (get) Token: 0x0600186F RID: 6255 RVA: 0x000774FC File Offset: 0x000756FC
			public static AmbientOcclusionModel.Settings defaultSettings
			{
				get
				{
					return new AmbientOcclusionModel.Settings
					{
						intensity = 1f,
						radius = 0.3f,
						sampleCount = AmbientOcclusionModel.SampleCount.Medium,
						downsampling = true,
						forceForwardCompatibility = false,
						ambientOnly = false,
						highPrecision = false
					};
				}
			}

			// Token: 0x04001441 RID: 5185
			[Range(0f, 4f)]
			[Tooltip("Degree of darkness produced by the effect.")]
			public float intensity;

			// Token: 0x04001442 RID: 5186
			[Min(0.0001f)]
			[Tooltip("Radius of sample points, which affects extent of darkened areas.")]
			public float radius;

			// Token: 0x04001443 RID: 5187
			[Tooltip("Number of sample points, which affects quality and performance.")]
			public AmbientOcclusionModel.SampleCount sampleCount;

			// Token: 0x04001444 RID: 5188
			[Tooltip("Halves the resolution of the effect to increase performance at the cost of visual quality.")]
			public bool downsampling;

			// Token: 0x04001445 RID: 5189
			[Tooltip("Forces compatibility with Forward rendered objects when working with the Deferred rendering path.")]
			public bool forceForwardCompatibility;

			// Token: 0x04001446 RID: 5190
			[Tooltip("Enables the ambient-only mode in that the effect only affects ambient lighting. This mode is only available with the Deferred rendering path and HDR rendering.")]
			public bool ambientOnly;

			// Token: 0x04001447 RID: 5191
			[Tooltip("Toggles the use of a higher precision depth texture with the forward rendering path (may impact performances). Has no effect with the deferred rendering path.")]
			public bool highPrecision;
		}
	}
}
