﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001EF RID: 495
	public abstract class PostProcessingComponentBase
	{
		// Token: 0x06001031 RID: 4145 RVA: 0x0000821B File Offset: 0x0000641B
		public virtual DepthTextureMode GetCameraFlags()
		{
			return DepthTextureMode.None;
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x06001032 RID: 4146
		public abstract bool active { get; }

		// Token: 0x06001033 RID: 4147 RVA: 0x00003D07 File Offset: 0x00001F07
		public virtual void OnEnable()
		{
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x00003D07 File Offset: 0x00001F07
		public virtual void OnDisable()
		{
		}

		// Token: 0x06001035 RID: 4149
		public abstract PostProcessingModel GetModel();

		// Token: 0x04000CC4 RID: 3268
		public PostProcessingContext context;
	}
}
