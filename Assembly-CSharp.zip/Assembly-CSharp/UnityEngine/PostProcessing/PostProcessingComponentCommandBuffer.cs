﻿using System;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001F1 RID: 497
	public abstract class PostProcessingComponentCommandBuffer<T> : PostProcessingComponent<T> where T : PostProcessingModel
	{
		// Token: 0x0600103C RID: 4156
		public abstract CameraEvent GetCameraEvent();

		// Token: 0x0600103D RID: 4157
		public abstract string GetName();

		// Token: 0x0600103E RID: 4158
		public abstract void PopulateCommandBuffer(CommandBuffer cb);
	}
}
