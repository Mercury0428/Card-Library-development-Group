﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E2 RID: 482
	[Serializable]
	public class BuiltinDebugViewsModel : PostProcessingModel
	{
		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06000FE9 RID: 4073 RVA: 0x000606A3 File Offset: 0x0005E8A3
		// (set) Token: 0x06000FEA RID: 4074 RVA: 0x000606AB File Offset: 0x0005E8AB
		public BuiltinDebugViewsModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x06000FEB RID: 4075 RVA: 0x000606B4 File Offset: 0x0005E8B4
		public bool willInterrupt
		{
			get
			{
				return !this.IsModeActive(BuiltinDebugViewsModel.Mode.None) && !this.IsModeActive(BuiltinDebugViewsModel.Mode.EyeAdaptation) && !this.IsModeActive(BuiltinDebugViewsModel.Mode.PreGradingLog) && !this.IsModeActive(BuiltinDebugViewsModel.Mode.LogLut) && !this.IsModeActive(BuiltinDebugViewsModel.Mode.UserLut);
			}
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x000606E7 File Offset: 0x0005E8E7
		public override void Reset()
		{
			this.settings = BuiltinDebugViewsModel.Settings.defaultSettings;
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x000606F4 File Offset: 0x0005E8F4
		public bool IsModeActive(BuiltinDebugViewsModel.Mode mode)
		{
			return this.m_Settings.mode == mode;
		}

		// Token: 0x04000C99 RID: 3225
		[SerializeField]
		private BuiltinDebugViewsModel.Settings m_Settings = BuiltinDebugViewsModel.Settings.defaultSettings;

		// Token: 0x020003B6 RID: 950
		[Serializable]
		public struct DepthSettings
		{
			// Token: 0x170004EF RID: 1263
			// (get) Token: 0x0600187A RID: 6266 RVA: 0x00077930 File Offset: 0x00075B30
			public static BuiltinDebugViewsModel.DepthSettings defaultSettings
			{
				get
				{
					return new BuiltinDebugViewsModel.DepthSettings
					{
						scale = 1f
					};
				}
			}

			// Token: 0x0400146B RID: 5227
			[Range(0f, 1f)]
			[Tooltip("Scales the camera far plane before displaying the depth map.")]
			public float scale;
		}

		// Token: 0x020003B7 RID: 951
		[Serializable]
		public struct MotionVectorsSettings
		{
			// Token: 0x170004F0 RID: 1264
			// (get) Token: 0x0600187B RID: 6267 RVA: 0x00077954 File Offset: 0x00075B54
			public static BuiltinDebugViewsModel.MotionVectorsSettings defaultSettings
			{
				get
				{
					return new BuiltinDebugViewsModel.MotionVectorsSettings
					{
						sourceOpacity = 1f,
						motionImageOpacity = 0f,
						motionImageAmplitude = 16f,
						motionVectorsOpacity = 1f,
						motionVectorsResolution = 24,
						motionVectorsAmplitude = 64f
					};
				}
			}

			// Token: 0x0400146C RID: 5228
			[Range(0f, 1f)]
			[Tooltip("Opacity of the source render.")]
			public float sourceOpacity;

			// Token: 0x0400146D RID: 5229
			[Range(0f, 1f)]
			[Tooltip("Opacity of the per-pixel motion vector colors.")]
			public float motionImageOpacity;

			// Token: 0x0400146E RID: 5230
			[Min(0f)]
			[Tooltip("Because motion vectors are mainly very small vectors, you can use this setting to make them more visible.")]
			public float motionImageAmplitude;

			// Token: 0x0400146F RID: 5231
			[Range(0f, 1f)]
			[Tooltip("Opacity for the motion vector arrows.")]
			public float motionVectorsOpacity;

			// Token: 0x04001470 RID: 5232
			[Range(8f, 64f)]
			[Tooltip("The arrow density on screen.")]
			public int motionVectorsResolution;

			// Token: 0x04001471 RID: 5233
			[Min(0f)]
			[Tooltip("Tweaks the arrows length.")]
			public float motionVectorsAmplitude;
		}

		// Token: 0x020003B8 RID: 952
		public enum Mode
		{
			// Token: 0x04001473 RID: 5235
			None,
			// Token: 0x04001474 RID: 5236
			Depth,
			// Token: 0x04001475 RID: 5237
			Normals,
			// Token: 0x04001476 RID: 5238
			MotionVectors,
			// Token: 0x04001477 RID: 5239
			AmbientOcclusion,
			// Token: 0x04001478 RID: 5240
			EyeAdaptation,
			// Token: 0x04001479 RID: 5241
			FocusPlane,
			// Token: 0x0400147A RID: 5242
			PreGradingLog,
			// Token: 0x0400147B RID: 5243
			LogLut,
			// Token: 0x0400147C RID: 5244
			UserLut
		}

		// Token: 0x020003B9 RID: 953
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004F1 RID: 1265
			// (get) Token: 0x0600187C RID: 6268 RVA: 0x000779B0 File Offset: 0x00075BB0
			public static BuiltinDebugViewsModel.Settings defaultSettings
			{
				get
				{
					return new BuiltinDebugViewsModel.Settings
					{
						mode = BuiltinDebugViewsModel.Mode.None,
						depth = BuiltinDebugViewsModel.DepthSettings.defaultSettings,
						motionVectors = BuiltinDebugViewsModel.MotionVectorsSettings.defaultSettings
					};
				}
			}

			// Token: 0x0400147D RID: 5245
			public BuiltinDebugViewsModel.Mode mode;

			// Token: 0x0400147E RID: 5246
			public BuiltinDebugViewsModel.DepthSettings depth;

			// Token: 0x0400147F RID: 5247
			public BuiltinDebugViewsModel.MotionVectorsSettings motionVectors;
		}
	}
}
