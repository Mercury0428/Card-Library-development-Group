﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001F6 RID: 502
	[Serializable]
	public sealed class ColorGradingCurve
	{
		// Token: 0x06001052 RID: 4178 RVA: 0x00061724 File Offset: 0x0005F924
		public ColorGradingCurve(AnimationCurve curve, float zeroValue, bool loop, Vector2 bounds)
		{
			this.curve = curve;
			this.m_ZeroValue = zeroValue;
			this.m_Loop = loop;
			this.m_Range = bounds.magnitude;
		}

		// Token: 0x06001053 RID: 4179 RVA: 0x00061750 File Offset: 0x0005F950
		public void Cache()
		{
			if (!this.m_Loop)
			{
				return;
			}
			int length = this.curve.length;
			if (length < 2)
			{
				return;
			}
			if (this.m_InternalLoopingCurve == null)
			{
				this.m_InternalLoopingCurve = new AnimationCurve();
			}
			Keyframe key = this.curve[length - 1];
			key.time -= this.m_Range;
			Keyframe key2 = this.curve[0];
			key2.time += this.m_Range;
			this.m_InternalLoopingCurve.keys = this.curve.keys;
			this.m_InternalLoopingCurve.AddKey(key);
			this.m_InternalLoopingCurve.AddKey(key2);
		}

		// Token: 0x06001054 RID: 4180 RVA: 0x00061800 File Offset: 0x0005FA00
		public float Evaluate(float t)
		{
			if (this.curve.length == 0)
			{
				return this.m_ZeroValue;
			}
			if (!this.m_Loop || this.curve.length == 1)
			{
				return this.curve.Evaluate(t);
			}
			return this.m_InternalLoopingCurve.Evaluate(t);
		}

		// Token: 0x04000CDB RID: 3291
		public AnimationCurve curve;

		// Token: 0x04000CDC RID: 3292
		[SerializeField]
		private bool m_Loop;

		// Token: 0x04000CDD RID: 3293
		[SerializeField]
		private float m_ZeroValue;

		// Token: 0x04000CDE RID: 3294
		[SerializeField]
		private float m_Range;

		// Token: 0x04000CDF RID: 3295
		private AnimationCurve m_InternalLoopingCurve;
	}
}
