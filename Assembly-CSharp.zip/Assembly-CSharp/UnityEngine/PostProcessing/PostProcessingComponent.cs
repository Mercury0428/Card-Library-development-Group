﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001F0 RID: 496
	public abstract class PostProcessingComponent<T> : PostProcessingComponentBase where T : PostProcessingModel
	{
		// Token: 0x17000295 RID: 661
		// (get) Token: 0x06001037 RID: 4151 RVA: 0x00061586 File Offset: 0x0005F786
		// (set) Token: 0x06001038 RID: 4152 RVA: 0x0006158E File Offset: 0x0005F78E
		public T model { get; internal set; }

		// Token: 0x06001039 RID: 4153 RVA: 0x00061597 File Offset: 0x0005F797
		public virtual void Init(PostProcessingContext pcontext, T pmodel)
		{
			this.context = pcontext;
			this.model = pmodel;
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x000615A7 File Offset: 0x0005F7A7
		public override PostProcessingModel GetModel()
		{
			return this.model;
		}
	}
}
