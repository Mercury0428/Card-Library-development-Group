﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001CB RID: 459
	public sealed class GetSetAttribute : PropertyAttribute
	{
		// Token: 0x06000F5F RID: 3935 RVA: 0x0005C6BB File Offset: 0x0005A8BB
		public GetSetAttribute(string name)
		{
			this.name = name;
		}

		// Token: 0x04000C62 RID: 3170
		public readonly string name;

		// Token: 0x04000C63 RID: 3171
		public bool dirty;
	}
}
