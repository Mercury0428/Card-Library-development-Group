﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E0 RID: 480
	[Serializable]
	public class AntialiasingModel : PostProcessingModel
	{
		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06000FE1 RID: 4065 RVA: 0x00060641 File Offset: 0x0005E841
		// (set) Token: 0x06000FE2 RID: 4066 RVA: 0x00060649 File Offset: 0x0005E849
		public AntialiasingModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06000FE3 RID: 4067 RVA: 0x00060652 File Offset: 0x0005E852
		public override void Reset()
		{
			this.m_Settings = AntialiasingModel.Settings.defaultSettings;
		}

		// Token: 0x04000C97 RID: 3223
		[SerializeField]
		private AntialiasingModel.Settings m_Settings = AntialiasingModel.Settings.defaultSettings;

		// Token: 0x020003AC RID: 940
		public enum Method
		{
			// Token: 0x04001449 RID: 5193
			Fxaa,
			// Token: 0x0400144A RID: 5194
			Taa
		}

		// Token: 0x020003AD RID: 941
		public enum FxaaPreset
		{
			// Token: 0x0400144C RID: 5196
			ExtremePerformance,
			// Token: 0x0400144D RID: 5197
			Performance,
			// Token: 0x0400144E RID: 5198
			Default,
			// Token: 0x0400144F RID: 5199
			Quality,
			// Token: 0x04001450 RID: 5200
			ExtremeQuality
		}

		// Token: 0x020003AE RID: 942
		[Serializable]
		public struct FxaaQualitySettings
		{
			// Token: 0x04001451 RID: 5201
			[Tooltip("The amount of desired sub-pixel aliasing removal. Effects the sharpeness of the output.")]
			[Range(0f, 1f)]
			public float subpixelAliasingRemovalAmount;

			// Token: 0x04001452 RID: 5202
			[Tooltip("The minimum amount of local contrast required to qualify a region as containing an edge.")]
			[Range(0.063f, 0.333f)]
			public float edgeDetectionThreshold;

			// Token: 0x04001453 RID: 5203
			[Tooltip("Local contrast adaptation value to disallow the algorithm from executing on the darker regions.")]
			[Range(0f, 0.0833f)]
			public float minimumRequiredLuminance;

			// Token: 0x04001454 RID: 5204
			public static AntialiasingModel.FxaaQualitySettings[] presets = new AntialiasingModel.FxaaQualitySettings[]
			{
				new AntialiasingModel.FxaaQualitySettings
				{
					subpixelAliasingRemovalAmount = 0f,
					edgeDetectionThreshold = 0.333f,
					minimumRequiredLuminance = 0.0833f
				},
				new AntialiasingModel.FxaaQualitySettings
				{
					subpixelAliasingRemovalAmount = 0.25f,
					edgeDetectionThreshold = 0.25f,
					minimumRequiredLuminance = 0.0833f
				},
				new AntialiasingModel.FxaaQualitySettings
				{
					subpixelAliasingRemovalAmount = 0.75f,
					edgeDetectionThreshold = 0.166f,
					minimumRequiredLuminance = 0.0833f
				},
				new AntialiasingModel.FxaaQualitySettings
				{
					subpixelAliasingRemovalAmount = 1f,
					edgeDetectionThreshold = 0.125f,
					minimumRequiredLuminance = 0.0625f
				},
				new AntialiasingModel.FxaaQualitySettings
				{
					subpixelAliasingRemovalAmount = 1f,
					edgeDetectionThreshold = 0.063f,
					minimumRequiredLuminance = 0.0312f
				}
			};
		}

		// Token: 0x020003AF RID: 943
		[Serializable]
		public struct FxaaConsoleSettings
		{
			// Token: 0x04001455 RID: 5205
			[Tooltip("The amount of spread applied to the sampling coordinates while sampling for subpixel information.")]
			[Range(0.33f, 0.5f)]
			public float subpixelSpreadAmount;

			// Token: 0x04001456 RID: 5206
			[Tooltip("This value dictates how sharp the edges in the image are kept; a higher value implies sharper edges.")]
			[Range(2f, 8f)]
			public float edgeSharpnessAmount;

			// Token: 0x04001457 RID: 5207
			[Tooltip("The minimum amount of local contrast required to qualify a region as containing an edge.")]
			[Range(0.125f, 0.25f)]
			public float edgeDetectionThreshold;

			// Token: 0x04001458 RID: 5208
			[Tooltip("Local contrast adaptation value to disallow the algorithm from executing on the darker regions.")]
			[Range(0.04f, 0.06f)]
			public float minimumRequiredLuminance;

			// Token: 0x04001459 RID: 5209
			public static AntialiasingModel.FxaaConsoleSettings[] presets = new AntialiasingModel.FxaaConsoleSettings[]
			{
				new AntialiasingModel.FxaaConsoleSettings
				{
					subpixelSpreadAmount = 0.33f,
					edgeSharpnessAmount = 8f,
					edgeDetectionThreshold = 0.25f,
					minimumRequiredLuminance = 0.06f
				},
				new AntialiasingModel.FxaaConsoleSettings
				{
					subpixelSpreadAmount = 0.33f,
					edgeSharpnessAmount = 8f,
					edgeDetectionThreshold = 0.125f,
					minimumRequiredLuminance = 0.06f
				},
				new AntialiasingModel.FxaaConsoleSettings
				{
					subpixelSpreadAmount = 0.5f,
					edgeSharpnessAmount = 8f,
					edgeDetectionThreshold = 0.125f,
					minimumRequiredLuminance = 0.05f
				},
				new AntialiasingModel.FxaaConsoleSettings
				{
					subpixelSpreadAmount = 0.5f,
					edgeSharpnessAmount = 4f,
					edgeDetectionThreshold = 0.125f,
					minimumRequiredLuminance = 0.04f
				},
				new AntialiasingModel.FxaaConsoleSettings
				{
					subpixelSpreadAmount = 0.5f,
					edgeSharpnessAmount = 2f,
					edgeDetectionThreshold = 0.125f,
					minimumRequiredLuminance = 0.04f
				}
			};
		}

		// Token: 0x020003B0 RID: 944
		[Serializable]
		public struct FxaaSettings
		{
			// Token: 0x170004E8 RID: 1256
			// (get) Token: 0x06001872 RID: 6258 RVA: 0x000777C8 File Offset: 0x000759C8
			public static AntialiasingModel.FxaaSettings defaultSettings
			{
				get
				{
					return new AntialiasingModel.FxaaSettings
					{
						preset = AntialiasingModel.FxaaPreset.Default
					};
				}
			}

			// Token: 0x0400145A RID: 5210
			public AntialiasingModel.FxaaPreset preset;
		}

		// Token: 0x020003B1 RID: 945
		[Serializable]
		public struct TaaSettings
		{
			// Token: 0x170004E9 RID: 1257
			// (get) Token: 0x06001873 RID: 6259 RVA: 0x000777E8 File Offset: 0x000759E8
			public static AntialiasingModel.TaaSettings defaultSettings
			{
				get
				{
					return new AntialiasingModel.TaaSettings
					{
						jitterSpread = 0.75f,
						sharpen = 0.3f,
						stationaryBlending = 0.95f,
						motionBlending = 0.85f
					};
				}
			}

			// Token: 0x0400145B RID: 5211
			[Tooltip("The diameter (in texels) inside which jitter samples are spread. Smaller values result in crisper but more aliased output, while larger values result in more stable but blurrier output.")]
			[Range(0.1f, 1f)]
			public float jitterSpread;

			// Token: 0x0400145C RID: 5212
			[Tooltip("Controls the amount of sharpening applied to the color buffer.")]
			[Range(0f, 3f)]
			public float sharpen;

			// Token: 0x0400145D RID: 5213
			[Tooltip("The blend coefficient for a stationary fragment. Controls the percentage of history sample blended into the final color.")]
			[Range(0f, 0.99f)]
			public float stationaryBlending;

			// Token: 0x0400145E RID: 5214
			[Tooltip("The blend coefficient for a fragment with significant motion. Controls the percentage of history sample blended into the final color.")]
			[Range(0f, 0.99f)]
			public float motionBlending;
		}

		// Token: 0x020003B2 RID: 946
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004EA RID: 1258
			// (get) Token: 0x06001874 RID: 6260 RVA: 0x00077830 File Offset: 0x00075A30
			public static AntialiasingModel.Settings defaultSettings
			{
				get
				{
					return new AntialiasingModel.Settings
					{
						method = AntialiasingModel.Method.Fxaa,
						fxaaSettings = AntialiasingModel.FxaaSettings.defaultSettings,
						taaSettings = AntialiasingModel.TaaSettings.defaultSettings
					};
				}
			}

			// Token: 0x0400145F RID: 5215
			public AntialiasingModel.Method method;

			// Token: 0x04001460 RID: 5216
			public AntialiasingModel.FxaaSettings fxaaSettings;

			// Token: 0x04001461 RID: 5217
			public AntialiasingModel.TaaSettings taaSettings;
		}
	}
}
