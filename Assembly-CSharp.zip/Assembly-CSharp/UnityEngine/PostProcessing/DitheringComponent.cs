﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001D5 RID: 469
	public sealed class DitheringComponent : PostProcessingComponentRenderTexture<DitheringModel>
	{
		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000F9D RID: 3997 RVA: 0x0005E70E File Offset: 0x0005C90E
		public override bool active
		{
			get
			{
				return base.model.enabled && !this.context.interrupted;
			}
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x0005E72D File Offset: 0x0005C92D
		public override void OnDisable()
		{
			this.noiseTextures = null;
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x0005E738 File Offset: 0x0005C938
		private void LoadNoiseTextures()
		{
			this.noiseTextures = new Texture2D[64];
			for (int i = 0; i < 64; i++)
			{
				this.noiseTextures[i] = Resources.Load<Texture2D>("Bluenoise64/LDR_LLL1_" + i);
			}
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x0005E77C File Offset: 0x0005C97C
		public override void Prepare(Material uberMaterial)
		{
			int num = this.textureIndex + 1;
			this.textureIndex = num;
			if (num >= 64)
			{
				this.textureIndex = 0;
			}
			float value = Random.value;
			float value2 = Random.value;
			if (this.noiseTextures == null)
			{
				this.LoadNoiseTextures();
			}
			Texture2D texture2D = this.noiseTextures[this.textureIndex];
			uberMaterial.EnableKeyword("DITHERING");
			uberMaterial.SetTexture(DitheringComponent.Uniforms._DitheringTex, texture2D);
			uberMaterial.SetVector(DitheringComponent.Uniforms._DitheringCoords, new Vector4((float)this.context.width / (float)texture2D.width, (float)this.context.height / (float)texture2D.height, value, value2));
		}

		// Token: 0x04000C77 RID: 3191
		private Texture2D[] noiseTextures;

		// Token: 0x04000C78 RID: 3192
		private int textureIndex;

		// Token: 0x04000C79 RID: 3193
		private const int k_TextureCount = 64;

		// Token: 0x0200039C RID: 924
		private static class Uniforms
		{
			// Token: 0x040013C6 RID: 5062
			internal static readonly int _DitheringTex = Shader.PropertyToID("_DitheringTex");

			// Token: 0x040013C7 RID: 5063
			internal static readonly int _DitheringCoords = Shader.PropertyToID("_DitheringCoords");
		}
	}
}
