﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E1 RID: 481
	[Serializable]
	public class BloomModel : PostProcessingModel
	{
		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06000FE5 RID: 4069 RVA: 0x00060672 File Offset: 0x0005E872
		// (set) Token: 0x06000FE6 RID: 4070 RVA: 0x0006067A File Offset: 0x0005E87A
		public BloomModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06000FE7 RID: 4071 RVA: 0x00060683 File Offset: 0x0005E883
		public override void Reset()
		{
			this.m_Settings = BloomModel.Settings.defaultSettings;
		}

		// Token: 0x04000C98 RID: 3224
		[SerializeField]
		private BloomModel.Settings m_Settings = BloomModel.Settings.defaultSettings;

		// Token: 0x020003B3 RID: 947
		[Serializable]
		public struct BloomSettings
		{
			// Token: 0x170004EB RID: 1259
			// (get) Token: 0x06001876 RID: 6262 RVA: 0x00077874 File Offset: 0x00075A74
			// (set) Token: 0x06001875 RID: 6261 RVA: 0x00077866 File Offset: 0x00075A66
			public float thresholdLinear
			{
				get
				{
					return Mathf.GammaToLinearSpace(this.threshold);
				}
				set
				{
					this.threshold = Mathf.LinearToGammaSpace(value);
				}
			}

			// Token: 0x170004EC RID: 1260
			// (get) Token: 0x06001877 RID: 6263 RVA: 0x00077884 File Offset: 0x00075A84
			public static BloomModel.BloomSettings defaultSettings
			{
				get
				{
					return new BloomModel.BloomSettings
					{
						intensity = 0.5f,
						threshold = 1.1f,
						softKnee = 0.5f,
						radius = 4f,
						antiFlicker = false
					};
				}
			}

			// Token: 0x04001462 RID: 5218
			[Min(0f)]
			[Tooltip("Strength of the bloom filter.")]
			public float intensity;

			// Token: 0x04001463 RID: 5219
			[Min(0f)]
			[Tooltip("Filters out pixels under this level of brightness.")]
			public float threshold;

			// Token: 0x04001464 RID: 5220
			[Range(0f, 1f)]
			[Tooltip("Makes transition between under/over-threshold gradual (0 = hard threshold, 1 = soft threshold).")]
			public float softKnee;

			// Token: 0x04001465 RID: 5221
			[Range(1f, 7f)]
			[Tooltip("Changes extent of veiling effects in a screen resolution-independent fashion.")]
			public float radius;

			// Token: 0x04001466 RID: 5222
			[Tooltip("Reduces flashing noise with an additional filter.")]
			public bool antiFlicker;
		}

		// Token: 0x020003B4 RID: 948
		[Serializable]
		public struct LensDirtSettings
		{
			// Token: 0x170004ED RID: 1261
			// (get) Token: 0x06001878 RID: 6264 RVA: 0x000778D4 File Offset: 0x00075AD4
			public static BloomModel.LensDirtSettings defaultSettings
			{
				get
				{
					return new BloomModel.LensDirtSettings
					{
						texture = null,
						intensity = 3f
					};
				}
			}

			// Token: 0x04001467 RID: 5223
			[Tooltip("Dirtiness texture to add smudges or dust to the lens.")]
			public Texture texture;

			// Token: 0x04001468 RID: 5224
			[Min(0f)]
			[Tooltip("Amount of lens dirtiness.")]
			public float intensity;
		}

		// Token: 0x020003B5 RID: 949
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004EE RID: 1262
			// (get) Token: 0x06001879 RID: 6265 RVA: 0x00077900 File Offset: 0x00075B00
			public static BloomModel.Settings defaultSettings
			{
				get
				{
					return new BloomModel.Settings
					{
						bloom = BloomModel.BloomSettings.defaultSettings,
						lensDirt = BloomModel.LensDirtSettings.defaultSettings
					};
				}
			}

			// Token: 0x04001469 RID: 5225
			public BloomModel.BloomSettings bloom;

			// Token: 0x0400146A RID: 5226
			public BloomModel.LensDirtSettings lensDirt;
		}
	}
}
