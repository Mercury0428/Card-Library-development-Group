﻿using System;
using System.Collections.Generic;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001F8 RID: 504
	public sealed class MaterialFactory : IDisposable
	{
		// Token: 0x0600105D RID: 4189 RVA: 0x00061BC9 File Offset: 0x0005FDC9
		public MaterialFactory()
		{
			this.m_Materials = new Dictionary<string, Material>();
		}

		// Token: 0x0600105E RID: 4190 RVA: 0x00061BDC File Offset: 0x0005FDDC
		public Material Get(string shaderName)
		{
			Material material;
			if (!this.m_Materials.TryGetValue(shaderName, out material))
			{
				Shader shader = Shader.Find(shaderName);
				if (shader == null)
				{
					throw new ArgumentException(string.Format("Shader not found ({0})", shaderName));
				}
				material = new Material(shader)
				{
					name = string.Format("PostFX - {0}", shaderName.Substring(shaderName.LastIndexOf("/") + 1)),
					hideFlags = HideFlags.DontSave
				};
				this.m_Materials.Add(shaderName, material);
			}
			return material;
		}

		// Token: 0x0600105F RID: 4191 RVA: 0x00061C58 File Offset: 0x0005FE58
		public void Dispose()
		{
			foreach (KeyValuePair<string, Material> keyValuePair in this.m_Materials)
			{
				GraphicsUtils.Destroy(keyValuePair.Value);
			}
			this.m_Materials.Clear();
		}

		// Token: 0x04000CE2 RID: 3298
		private Dictionary<string, Material> m_Materials;
	}
}
