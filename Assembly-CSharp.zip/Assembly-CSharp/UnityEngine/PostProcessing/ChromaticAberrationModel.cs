﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E3 RID: 483
	[Serializable]
	public class ChromaticAberrationModel : PostProcessingModel
	{
		// Token: 0x17000287 RID: 647
		// (get) Token: 0x06000FEF RID: 4079 RVA: 0x00060717 File Offset: 0x0005E917
		// (set) Token: 0x06000FF0 RID: 4080 RVA: 0x0006071F File Offset: 0x0005E91F
		public ChromaticAberrationModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x00060728 File Offset: 0x0005E928
		public override void Reset()
		{
			this.m_Settings = ChromaticAberrationModel.Settings.defaultSettings;
		}

		// Token: 0x04000C9A RID: 3226
		[SerializeField]
		private ChromaticAberrationModel.Settings m_Settings = ChromaticAberrationModel.Settings.defaultSettings;

		// Token: 0x020003BA RID: 954
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004F2 RID: 1266
			// (get) Token: 0x0600187D RID: 6269 RVA: 0x000779E8 File Offset: 0x00075BE8
			public static ChromaticAberrationModel.Settings defaultSettings
			{
				get
				{
					return new ChromaticAberrationModel.Settings
					{
						spectralTexture = null,
						intensity = 0.1f
					};
				}
			}

			// Token: 0x04001480 RID: 5248
			[Tooltip("Shift the hue of chromatic aberrations.")]
			public Texture2D spectralTexture;

			// Token: 0x04001481 RID: 5249
			[Range(0f, 1f)]
			[Tooltip("Amount of tangential distortion.")]
			public float intensity;
		}
	}
}
