﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E6 RID: 486
	[Serializable]
	public class DitheringModel : PostProcessingModel
	{
		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06001000 RID: 4096 RVA: 0x000607E1 File Offset: 0x0005E9E1
		// (set) Token: 0x06001001 RID: 4097 RVA: 0x000607E9 File Offset: 0x0005E9E9
		public DitheringModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06001002 RID: 4098 RVA: 0x000607F2 File Offset: 0x0005E9F2
		public override void Reset()
		{
			this.m_Settings = DitheringModel.Settings.defaultSettings;
		}

		// Token: 0x04000C9F RID: 3231
		[SerializeField]
		private DitheringModel.Settings m_Settings = DitheringModel.Settings.defaultSettings;

		// Token: 0x020003C7 RID: 967
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004FC RID: 1276
			// (get) Token: 0x06001887 RID: 6279 RVA: 0x00077F24 File Offset: 0x00076124
			public static DitheringModel.Settings defaultSettings
			{
				get
				{
					return default(DitheringModel.Settings);
				}
			}
		}
	}
}
