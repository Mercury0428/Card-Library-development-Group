﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001F2 RID: 498
	public abstract class PostProcessingComponentRenderTexture<T> : PostProcessingComponent<T> where T : PostProcessingModel
	{
		// Token: 0x06001040 RID: 4160 RVA: 0x00003D07 File Offset: 0x00001F07
		public virtual void Prepare(Material material)
		{
		}
	}
}
