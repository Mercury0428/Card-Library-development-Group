﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001EA RID: 490
	[Serializable]
	public class MotionBlurModel : PostProcessingModel
	{
		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06001010 RID: 4112 RVA: 0x000608A5 File Offset: 0x0005EAA5
		// (set) Token: 0x06001011 RID: 4113 RVA: 0x000608AD File Offset: 0x0005EAAD
		public MotionBlurModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x06001012 RID: 4114 RVA: 0x000608B6 File Offset: 0x0005EAB6
		public override void Reset()
		{
			this.m_Settings = MotionBlurModel.Settings.defaultSettings;
		}

		// Token: 0x04000CA3 RID: 3235
		[SerializeField]
		private MotionBlurModel.Settings m_Settings = MotionBlurModel.Settings.defaultSettings;

		// Token: 0x020003CC RID: 972
		[Serializable]
		public struct Settings
		{
			// Token: 0x17000500 RID: 1280
			// (get) Token: 0x0600188B RID: 6283 RVA: 0x0007802C File Offset: 0x0007622C
			public static MotionBlurModel.Settings defaultSettings
			{
				get
				{
					return new MotionBlurModel.Settings
					{
						shutterAngle = 270f,
						sampleCount = 10,
						frameBlending = 0f
					};
				}
			}

			// Token: 0x040014D2 RID: 5330
			[Range(0f, 360f)]
			[Tooltip("The angle of rotary shutter. Larger values give longer exposure.")]
			public float shutterAngle;

			// Token: 0x040014D3 RID: 5331
			[Range(4f, 32f)]
			[Tooltip("The amount of sample points, which affects quality and performances.")]
			public int sampleCount;

			// Token: 0x040014D4 RID: 5332
			[Range(0f, 1f)]
			[Tooltip("The strength of multiple frame blending. The opacity of preceding frames are determined from this coefficient and time differences.")]
			public float frameBlending;
		}
	}
}
