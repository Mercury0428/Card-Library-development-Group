﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E4 RID: 484
	[Serializable]
	public class ColorGradingModel : PostProcessingModel
	{
		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000FF3 RID: 4083 RVA: 0x00060748 File Offset: 0x0005E948
		// (set) Token: 0x06000FF4 RID: 4084 RVA: 0x00060750 File Offset: 0x0005E950
		public ColorGradingModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
				this.OnValidate();
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x0006075F File Offset: 0x0005E95F
		// (set) Token: 0x06000FF6 RID: 4086 RVA: 0x00060767 File Offset: 0x0005E967
		public bool isDirty { get; internal set; }

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000FF7 RID: 4087 RVA: 0x00060770 File Offset: 0x0005E970
		// (set) Token: 0x06000FF8 RID: 4088 RVA: 0x00060778 File Offset: 0x0005E978
		public RenderTexture bakedLut { get; internal set; }

		// Token: 0x06000FF9 RID: 4089 RVA: 0x00060781 File Offset: 0x0005E981
		public override void Reset()
		{
			this.m_Settings = ColorGradingModel.Settings.defaultSettings;
			this.OnValidate();
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x00060794 File Offset: 0x0005E994
		public override void OnValidate()
		{
			this.isDirty = true;
		}

		// Token: 0x04000C9B RID: 3227
		[SerializeField]
		private ColorGradingModel.Settings m_Settings = ColorGradingModel.Settings.defaultSettings;

		// Token: 0x020003BB RID: 955
		public enum Tonemapper
		{
			// Token: 0x04001483 RID: 5251
			None,
			// Token: 0x04001484 RID: 5252
			ACES,
			// Token: 0x04001485 RID: 5253
			Neutral
		}

		// Token: 0x020003BC RID: 956
		[Serializable]
		public struct TonemappingSettings
		{
			// Token: 0x170004F3 RID: 1267
			// (get) Token: 0x0600187E RID: 6270 RVA: 0x00077A14 File Offset: 0x00075C14
			public static ColorGradingModel.TonemappingSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.TonemappingSettings
					{
						tonemapper = ColorGradingModel.Tonemapper.Neutral,
						neutralBlackIn = 0.02f,
						neutralWhiteIn = 10f,
						neutralBlackOut = 0f,
						neutralWhiteOut = 10f,
						neutralWhiteLevel = 5.3f,
						neutralWhiteClip = 10f
					};
				}
			}

			// Token: 0x04001486 RID: 5254
			[Tooltip("Tonemapping algorithm to use at the end of the color grading process. Use \"Neutral\" if you need a customizable tonemapper or \"Filmic\" to give a standard filmic look to your scenes.")]
			public ColorGradingModel.Tonemapper tonemapper;

			// Token: 0x04001487 RID: 5255
			[Range(-0.1f, 0.1f)]
			public float neutralBlackIn;

			// Token: 0x04001488 RID: 5256
			[Range(1f, 20f)]
			public float neutralWhiteIn;

			// Token: 0x04001489 RID: 5257
			[Range(-0.09f, 0.1f)]
			public float neutralBlackOut;

			// Token: 0x0400148A RID: 5258
			[Range(1f, 19f)]
			public float neutralWhiteOut;

			// Token: 0x0400148B RID: 5259
			[Range(0.1f, 20f)]
			public float neutralWhiteLevel;

			// Token: 0x0400148C RID: 5260
			[Range(1f, 10f)]
			public float neutralWhiteClip;
		}

		// Token: 0x020003BD RID: 957
		[Serializable]
		public struct BasicSettings
		{
			// Token: 0x170004F4 RID: 1268
			// (get) Token: 0x0600187F RID: 6271 RVA: 0x00077A7C File Offset: 0x00075C7C
			public static ColorGradingModel.BasicSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.BasicSettings
					{
						postExposure = 0f,
						temperature = 0f,
						tint = 0f,
						hueShift = 0f,
						saturation = 1f,
						contrast = 1f
					};
				}
			}

			// Token: 0x0400148D RID: 5261
			[Tooltip("Adjusts the overall exposure of the scene in EV units. This is applied after HDR effect and right before tonemapping so it won't affect previous effects in the chain.")]
			public float postExposure;

			// Token: 0x0400148E RID: 5262
			[Range(-100f, 100f)]
			[Tooltip("Sets the white balance to a custom color temperature.")]
			public float temperature;

			// Token: 0x0400148F RID: 5263
			[Range(-100f, 100f)]
			[Tooltip("Sets the white balance to compensate for a green or magenta tint.")]
			public float tint;

			// Token: 0x04001490 RID: 5264
			[Range(-180f, 180f)]
			[Tooltip("Shift the hue of all colors.")]
			public float hueShift;

			// Token: 0x04001491 RID: 5265
			[Range(0f, 2f)]
			[Tooltip("Pushes the intensity of all colors.")]
			public float saturation;

			// Token: 0x04001492 RID: 5266
			[Range(0f, 2f)]
			[Tooltip("Expands or shrinks the overall range of tonal values.")]
			public float contrast;
		}

		// Token: 0x020003BE RID: 958
		[Serializable]
		public struct ChannelMixerSettings
		{
			// Token: 0x170004F5 RID: 1269
			// (get) Token: 0x06001880 RID: 6272 RVA: 0x00077ADC File Offset: 0x00075CDC
			public static ColorGradingModel.ChannelMixerSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.ChannelMixerSettings
					{
						red = new Vector3(1f, 0f, 0f),
						green = new Vector3(0f, 1f, 0f),
						blue = new Vector3(0f, 0f, 1f),
						currentEditingChannel = 0
					};
				}
			}

			// Token: 0x04001493 RID: 5267
			public Vector3 red;

			// Token: 0x04001494 RID: 5268
			public Vector3 green;

			// Token: 0x04001495 RID: 5269
			public Vector3 blue;

			// Token: 0x04001496 RID: 5270
			[HideInInspector]
			public int currentEditingChannel;
		}

		// Token: 0x020003BF RID: 959
		[Serializable]
		public struct LogWheelsSettings
		{
			// Token: 0x170004F6 RID: 1270
			// (get) Token: 0x06001881 RID: 6273 RVA: 0x00077B4C File Offset: 0x00075D4C
			public static ColorGradingModel.LogWheelsSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.LogWheelsSettings
					{
						slope = Color.clear,
						power = Color.clear,
						offset = Color.clear
					};
				}
			}

			// Token: 0x04001497 RID: 5271
			[Trackball("GetSlopeValue")]
			public Color slope;

			// Token: 0x04001498 RID: 5272
			[Trackball("GetPowerValue")]
			public Color power;

			// Token: 0x04001499 RID: 5273
			[Trackball("GetOffsetValue")]
			public Color offset;
		}

		// Token: 0x020003C0 RID: 960
		[Serializable]
		public struct LinearWheelsSettings
		{
			// Token: 0x170004F7 RID: 1271
			// (get) Token: 0x06001882 RID: 6274 RVA: 0x00077B88 File Offset: 0x00075D88
			public static ColorGradingModel.LinearWheelsSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.LinearWheelsSettings
					{
						lift = Color.clear,
						gamma = Color.clear,
						gain = Color.clear
					};
				}
			}

			// Token: 0x0400149A RID: 5274
			[Trackball("GetLiftValue")]
			public Color lift;

			// Token: 0x0400149B RID: 5275
			[Trackball("GetGammaValue")]
			public Color gamma;

			// Token: 0x0400149C RID: 5276
			[Trackball("GetGainValue")]
			public Color gain;
		}

		// Token: 0x020003C1 RID: 961
		public enum ColorWheelMode
		{
			// Token: 0x0400149E RID: 5278
			Linear,
			// Token: 0x0400149F RID: 5279
			Log
		}

		// Token: 0x020003C2 RID: 962
		[Serializable]
		public struct ColorWheelsSettings
		{
			// Token: 0x170004F8 RID: 1272
			// (get) Token: 0x06001883 RID: 6275 RVA: 0x00077BC4 File Offset: 0x00075DC4
			public static ColorGradingModel.ColorWheelsSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.ColorWheelsSettings
					{
						mode = ColorGradingModel.ColorWheelMode.Log,
						log = ColorGradingModel.LogWheelsSettings.defaultSettings,
						linear = ColorGradingModel.LinearWheelsSettings.defaultSettings
					};
				}
			}

			// Token: 0x040014A0 RID: 5280
			public ColorGradingModel.ColorWheelMode mode;

			// Token: 0x040014A1 RID: 5281
			[TrackballGroup]
			public ColorGradingModel.LogWheelsSettings log;

			// Token: 0x040014A2 RID: 5282
			[TrackballGroup]
			public ColorGradingModel.LinearWheelsSettings linear;
		}

		// Token: 0x020003C3 RID: 963
		[Serializable]
		public struct CurvesSettings
		{
			// Token: 0x170004F9 RID: 1273
			// (get) Token: 0x06001884 RID: 6276 RVA: 0x00077BFC File Offset: 0x00075DFC
			public static ColorGradingModel.CurvesSettings defaultSettings
			{
				get
				{
					return new ColorGradingModel.CurvesSettings
					{
						master = new ColorGradingCurve(new AnimationCurve(new Keyframe[]
						{
							new Keyframe(0f, 0f, 1f, 1f),
							new Keyframe(1f, 1f, 1f, 1f)
						}), 0f, false, new Vector2(0f, 1f)),
						red = new ColorGradingCurve(new AnimationCurve(new Keyframe[]
						{
							new Keyframe(0f, 0f, 1f, 1f),
							new Keyframe(1f, 1f, 1f, 1f)
						}), 0f, false, new Vector2(0f, 1f)),
						green = new ColorGradingCurve(new AnimationCurve(new Keyframe[]
						{
							new Keyframe(0f, 0f, 1f, 1f),
							new Keyframe(1f, 1f, 1f, 1f)
						}), 0f, false, new Vector2(0f, 1f)),
						blue = new ColorGradingCurve(new AnimationCurve(new Keyframe[]
						{
							new Keyframe(0f, 0f, 1f, 1f),
							new Keyframe(1f, 1f, 1f, 1f)
						}), 0f, false, new Vector2(0f, 1f)),
						hueVShue = new ColorGradingCurve(new AnimationCurve(), 0.5f, true, new Vector2(0f, 1f)),
						hueVSsat = new ColorGradingCurve(new AnimationCurve(), 0.5f, true, new Vector2(0f, 1f)),
						satVSsat = new ColorGradingCurve(new AnimationCurve(), 0.5f, false, new Vector2(0f, 1f)),
						lumVSsat = new ColorGradingCurve(new AnimationCurve(), 0.5f, false, new Vector2(0f, 1f)),
						e_CurrentEditingCurve = 0,
						e_CurveY = true,
						e_CurveR = false,
						e_CurveG = false,
						e_CurveB = false
					};
				}
			}

			// Token: 0x040014A3 RID: 5283
			public ColorGradingCurve master;

			// Token: 0x040014A4 RID: 5284
			public ColorGradingCurve red;

			// Token: 0x040014A5 RID: 5285
			public ColorGradingCurve green;

			// Token: 0x040014A6 RID: 5286
			public ColorGradingCurve blue;

			// Token: 0x040014A7 RID: 5287
			public ColorGradingCurve hueVShue;

			// Token: 0x040014A8 RID: 5288
			public ColorGradingCurve hueVSsat;

			// Token: 0x040014A9 RID: 5289
			public ColorGradingCurve satVSsat;

			// Token: 0x040014AA RID: 5290
			public ColorGradingCurve lumVSsat;

			// Token: 0x040014AB RID: 5291
			[HideInInspector]
			public int e_CurrentEditingCurve;

			// Token: 0x040014AC RID: 5292
			[HideInInspector]
			public bool e_CurveY;

			// Token: 0x040014AD RID: 5293
			[HideInInspector]
			public bool e_CurveR;

			// Token: 0x040014AE RID: 5294
			[HideInInspector]
			public bool e_CurveG;

			// Token: 0x040014AF RID: 5295
			[HideInInspector]
			public bool e_CurveB;
		}

		// Token: 0x020003C4 RID: 964
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004FA RID: 1274
			// (get) Token: 0x06001885 RID: 6277 RVA: 0x00077E84 File Offset: 0x00076084
			public static ColorGradingModel.Settings defaultSettings
			{
				get
				{
					return new ColorGradingModel.Settings
					{
						tonemapping = ColorGradingModel.TonemappingSettings.defaultSettings,
						basic = ColorGradingModel.BasicSettings.defaultSettings,
						channelMixer = ColorGradingModel.ChannelMixerSettings.defaultSettings,
						colorWheels = ColorGradingModel.ColorWheelsSettings.defaultSettings,
						curves = ColorGradingModel.CurvesSettings.defaultSettings
					};
				}
			}

			// Token: 0x040014B0 RID: 5296
			public ColorGradingModel.TonemappingSettings tonemapping;

			// Token: 0x040014B1 RID: 5297
			public ColorGradingModel.BasicSettings basic;

			// Token: 0x040014B2 RID: 5298
			public ColorGradingModel.ChannelMixerSettings channelMixer;

			// Token: 0x040014B3 RID: 5299
			public ColorGradingModel.ColorWheelsSettings colorWheels;

			// Token: 0x040014B4 RID: 5300
			public ColorGradingModel.CurvesSettings curves;
		}
	}
}
