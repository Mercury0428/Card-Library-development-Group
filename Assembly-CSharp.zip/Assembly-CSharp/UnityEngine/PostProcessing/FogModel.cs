﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E8 RID: 488
	[Serializable]
	public class FogModel : PostProcessingModel
	{
		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06001008 RID: 4104 RVA: 0x00060843 File Offset: 0x0005EA43
		// (set) Token: 0x06001009 RID: 4105 RVA: 0x0006084B File Offset: 0x0005EA4B
		public FogModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x00060854 File Offset: 0x0005EA54
		public override void Reset()
		{
			this.m_Settings = FogModel.Settings.defaultSettings;
		}

		// Token: 0x04000CA1 RID: 3233
		[SerializeField]
		private FogModel.Settings m_Settings = FogModel.Settings.defaultSettings;

		// Token: 0x020003CA RID: 970
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004FE RID: 1278
			// (get) Token: 0x06001889 RID: 6281 RVA: 0x00077FC8 File Offset: 0x000761C8
			public static FogModel.Settings defaultSettings
			{
				get
				{
					return new FogModel.Settings
					{
						excludeSkybox = true
					};
				}
			}

			// Token: 0x040014CD RID: 5325
			[Tooltip("Should the fog affect the skybox?")]
			public bool excludeSkybox;
		}
	}
}
