﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001E9 RID: 489
	[Serializable]
	public class GrainModel : PostProcessingModel
	{
		// Token: 0x1700028F RID: 655
		// (get) Token: 0x0600100C RID: 4108 RVA: 0x00060874 File Offset: 0x0005EA74
		// (set) Token: 0x0600100D RID: 4109 RVA: 0x0006087C File Offset: 0x0005EA7C
		public GrainModel.Settings settings
		{
			get
			{
				return this.m_Settings;
			}
			set
			{
				this.m_Settings = value;
			}
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x00060885 File Offset: 0x0005EA85
		public override void Reset()
		{
			this.m_Settings = GrainModel.Settings.defaultSettings;
		}

		// Token: 0x04000CA2 RID: 3234
		[SerializeField]
		private GrainModel.Settings m_Settings = GrainModel.Settings.defaultSettings;

		// Token: 0x020003CB RID: 971
		[Serializable]
		public struct Settings
		{
			// Token: 0x170004FF RID: 1279
			// (get) Token: 0x0600188A RID: 6282 RVA: 0x00077FE8 File Offset: 0x000761E8
			public static GrainModel.Settings defaultSettings
			{
				get
				{
					return new GrainModel.Settings
					{
						colored = true,
						intensity = 0.5f,
						size = 1f,
						luminanceContribution = 0.8f
					};
				}
			}

			// Token: 0x040014CE RID: 5326
			[Tooltip("Enable the use of colored grain.")]
			public bool colored;

			// Token: 0x040014CF RID: 5327
			[Range(0f, 1f)]
			[Tooltip("Grain strength. Higher means more visible grain.")]
			public float intensity;

			// Token: 0x040014D0 RID: 5328
			[Range(0.3f, 3f)]
			[Tooltip("Grain particle size.")]
			public float size;

			// Token: 0x040014D1 RID: 5329
			[Range(0f, 1f)]
			[Tooltip("Controls the noisiness response curve based on scene luminance. Lower values mean less noise in dark areas.")]
			public float luminanceContribution;
		}
	}
}
