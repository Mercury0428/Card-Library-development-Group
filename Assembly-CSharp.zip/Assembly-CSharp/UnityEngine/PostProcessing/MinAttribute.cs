﻿using System;

namespace UnityEngine.PostProcessing
{
	// Token: 0x020001CC RID: 460
	public sealed class MinAttribute : PropertyAttribute
	{
		// Token: 0x06000F60 RID: 3936 RVA: 0x0005C6CA File Offset: 0x0005A8CA
		public MinAttribute(float min)
		{
			this.min = min;
		}

		// Token: 0x04000C64 RID: 3172
		public readonly float min;
	}
}
