﻿using System;

// Token: 0x02000031 RID: 49
public enum CardTypes
{
	// Token: 0x04000187 RID: 391
	none,
	// Token: 0x04000188 RID: 392
	character,
	// Token: 0x04000189 RID: 393
	selection,
	// Token: 0x0400018A RID: 394
	effect,
	// Token: 0x0400018B RID: 395
	end,
	// Token: 0x0400018C RID: 396
	intercale,
	// Token: 0x0400018D RID: 397
	custom,
	// Token: 0x0400018E RID: 398
	duel
}
