﻿using System;
using System.Collections.Generic;

// Token: 0x02000064 RID: 100
[Serializable]
public class Reign
{
	// Token: 0x06000380 RID: 896 RVA: 0x00016188 File Offset: 0x00014388
	public Reign(string[] elements, string[] columns, char dele, Dictionary<string, string[]> i18n)
	{
		new string[2];
		this.id = -1;
		int i = 0;
		while (i < columns.Length)
		{
			string text = elements[i];
			string text2 = columns[i];
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num <= 1352703673U)
			{
				if (num <= 655211490U)
				{
					if (num != 135217627U)
					{
						if (num != 542584942U)
						{
							if (num == 655211490U)
							{
								if (text2 == "antagonists")
								{
									if (!string.IsNullOrEmpty(text))
									{
										this.PopulateBearers(text, this.antagonists, false, null);
									}
								}
							}
						}
						else if (text2 == "custom")
						{
							this.startActions.AddRange(Outcome.TreatOutcome(text));
						}
					}
					else if (text2 == "exclusive")
					{
						goto IL_2D8;
					}
				}
				else if (num <= 964706600U)
				{
					if (num != 926444256U)
					{
						if (num == 964706600U)
						{
							if (text2 == "court")
							{
								if (!string.IsNullOrEmpty(text))
								{
									this.PopulateBearers(text, this.court, true, this.functions);
								}
							}
						}
					}
					else if (text2 == "id")
					{
						if (i18n.Count > 0 && i18n.ContainsKey(text))
						{
							string[] array = i18n[text];
						}
						int.TryParse(text, out this.id);
					}
				}
				else if (num != 1254074961U)
				{
					if (num == 1352703673U)
					{
						if (text2 == "weight")
						{
							if (text == "max")
							{
								this.weight = -1;
							}
							else
							{
								int.TryParse(text, out this.weight);
							}
						}
					}
				}
				else if (text2 == "lockturn")
				{
					if (text == "del")
					{
						this.lockturn = -1;
					}
					else
					{
						int.TryParse(text, out this.lockturn);
					}
				}
			}
			else if (num <= 2519938542U)
			{
				if (num != 2162217143U)
				{
					if (num != 2504339532U)
					{
						if (num == 2519938542U)
						{
							if (text2 == "people")
							{
								this.startActions.Add(new Outcome(Variables.people, text, DataDisplay.fullamount));
							}
						}
					}
					else if (text2 == "unhappy")
					{
						if (!string.IsNullOrEmpty(text))
						{
							this.PopulateBearers(text, this.unhappy, false, null);
						}
					}
				}
				else if (text2 == "conditions")
				{
					this.conditions = Condition.TreatCondition(text);
				}
			}
			else if (num <= 3780168015U)
			{
				if (num != 3259168183U)
				{
					if (num == 3780168015U)
					{
						if (text2 == "money")
						{
							this.startActions.Add(new Outcome(Variables.money, text, DataDisplay.fullamount));
						}
					}
				}
				else if (text2 == "faith")
				{
					this.startActions.Add(new Outcome(Variables.faith, text, DataDisplay.fullamount));
				}
			}
			else if (num != 4115604294U)
			{
				if (num == 4269779792U)
				{
					if (text2 == "bearer")
					{
						try
						{
							this.bearer = (Bearers)Enum.Parse(typeof(Bearers), text);
							goto IL_418;
						}
						catch
						{
							this.bearer = Bearers.anyone;
							goto IL_418;
						}
						goto IL_2D8;
					}
				}
			}
			else if (text2 == "power")
			{
				this.startActions.Add(new Outcome(Variables.power, text, DataDisplay.fullamount));
			}
			IL_418:
			i++;
			continue;
			IL_2D8:
			this.exclusive = !string.IsNullOrEmpty(text);
			goto IL_418;
		}
	}

	// Token: 0x06000381 RID: 897 RVA: 0x000165CC File Offset: 0x000147CC
	private void PopulateBearers(string raw, List<Bearers> target, bool withfunc = false, List<Bearers> assign = null)
	{
		foreach (string text in raw.Split(new string[]
		{
			" and "
		}, StringSplitOptions.RemoveEmptyEntries))
		{
			if (text.Contains(">") && withfunc)
			{
				string[] array2 = text.Split(new string[]
				{
					">"
				}, StringSplitOptions.RemoveEmptyEntries);
				target.Add((Bearers)Enum.Parse(typeof(Bearers), array2[0]));
				assign.Add((Bearers)Enum.Parse(typeof(Bearers), array2[1]));
			}
			else if (withfunc)
			{
				target.Add((Bearers)Enum.Parse(typeof(Bearers), text));
				assign.Add(Bearers.none);
			}
			else
			{
				target.Add((Bearers)Enum.Parse(typeof(Bearers), text));
			}
		}
	}

	// Token: 0x06000382 RID: 898 RVA: 0x000166B0 File Offset: 0x000148B0
	public Reign(Reign model, int startReign)
	{
		this.end = startReign;
		this.start = startReign;
		this.id = model.id;
		this.bearer = model.bearer;
		this.name = model.name;
		this.court = model.court;
		this.functions = model.functions;
		this.allies = model.allies;
		this.antagonists = model.antagonists;
		this.startActions = model.startActions;
		this.exclusive = model.exclusive;
		this.unhappy = model.unhappy;
	}

	// Token: 0x04000463 RID: 1123
	public Bearers bearer = Bearers.none;

	// Token: 0x04000464 RID: 1124
	public string name;

	// Token: 0x04000465 RID: 1125
	public string nickId;

	// Token: 0x04000466 RID: 1126
	public string endCard;

	// Token: 0x04000467 RID: 1127
	public bool isDead;

	// Token: 0x04000468 RID: 1128
	public int start;

	// Token: 0x04000469 RID: 1129
	public int end;

	// Token: 0x0400046A RID: 1130
	public List<Objective> achievements;

	// Token: 0x0400046B RID: 1131
	public List<Bearers> court = new List<Bearers>();

	// Token: 0x0400046C RID: 1132
	public List<Bearers> functions = new List<Bearers>();

	// Token: 0x0400046D RID: 1133
	public List<Bearers> allies = new List<Bearers>();

	// Token: 0x0400046E RID: 1134
	public List<Bearers> antagonists = new List<Bearers>();

	// Token: 0x0400046F RID: 1135
	public List<Bearers> unhappy = new List<Bearers>();

	// Token: 0x04000470 RID: 1136
	public List<Condition> conditions;

	// Token: 0x04000471 RID: 1137
	public List<Outcome> startActions = new List<Outcome>();

	// Token: 0x04000472 RID: 1138
	public int lockturn;

	// Token: 0x04000473 RID: 1139
	public int id;

	// Token: 0x04000474 RID: 1140
	public int weight;

	// Token: 0x04000475 RID: 1141
	public bool exclusive;
}
