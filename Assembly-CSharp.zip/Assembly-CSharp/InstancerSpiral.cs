﻿using System;
using UnityEngine;

// Token: 0x0200008F RID: 143
public class InstancerSpiral : MonoBehaviour
{
	// Token: 0x06000494 RID: 1172 RVA: 0x0001C9D6 File Offset: 0x0001ABD6
	public void OuterRadiusIntensity(float value)
	{
		this._outerRadiusIntensity = value;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x0001C9DF File Offset: 0x0001ABDF
	public void InnerRadiusIntensity(float value)
	{
		this._innerRadiusIntensity = value;
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x0001C9E8 File Offset: 0x0001ABE8
	public void SpaceIntensity(float value)
	{
		this._spaceIntensity = value;
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x0001C9F1 File Offset: 0x0001ABF1
	public void SpeedIntensity(float value)
	{
		this._speedIntensity = value;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x0001C9FC File Offset: 0x0001ABFC
	private void Update()
	{
		float t = Time.deltaTime * this.speed * this._speedIntensity;
		float num = this.space * 0.017453292f * this._spaceIntensity;
		float num2 = (float)this.instancer.instances.Length;
		float a = this.outerRadius * this._outerRadiusIntensity;
		float b = this.innerRadius * this._innerRadiusIntensity;
		for (int i = 0; i < this.instancer.instances.Length; i++)
		{
			float t2 = (float)i / num2;
			float f = (float)i * num;
			float num3 = Mathf.Lerp(a, b, t2);
			this.destination.x = Mathf.Cos(f) * num3;
			this.destination.y = Mathf.Sin(f) * num3;
			this.instancer.instances[i].transform.localPosition = Vector3.Lerp(this.instancer.instances[i].transform.localPosition, this.destination, t);
		}
	}

	// Token: 0x04000554 RID: 1364
	public Instancer instancer;

	// Token: 0x04000555 RID: 1365
	public float outerRadius = 1f;

	// Token: 0x04000556 RID: 1366
	protected float _outerRadiusIntensity = 1f;

	// Token: 0x04000557 RID: 1367
	public float innerRadius;

	// Token: 0x04000558 RID: 1368
	protected float _innerRadiusIntensity = 1f;

	// Token: 0x04000559 RID: 1369
	public float space = 30f;

	// Token: 0x0400055A RID: 1370
	protected float _spaceIntensity = 1f;

	// Token: 0x0400055B RID: 1371
	public float speed = 1f;

	// Token: 0x0400055C RID: 1372
	protected float _speedIntensity = 1f;

	// Token: 0x0400055D RID: 1373
	private Vector3 destination;
}
