﻿using System;

// Token: 0x02000059 RID: 89
public enum MusicContexts
{
	// Token: 0x0400040A RID: 1034
	normal,
	// Token: 0x0400040B RID: 1035
	war,
	// Token: 0x0400040C RID: 1036
	duel,
	// Token: 0x0400040D RID: 1037
	lovestory,
	// Token: 0x0400040E RID: 1038
	dungeon,
	// Token: 0x0400040F RID: 1039
	game,
	// Token: 0x04000410 RID: 1040
	catastrophe,
	// Token: 0x04000411 RID: 1041
	song
}
