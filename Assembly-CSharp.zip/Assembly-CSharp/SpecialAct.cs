﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000073 RID: 115
public class SpecialAct : MonoBehaviour
{
	// Token: 0x060003FD RID: 1021 RVA: 0x000197F0 File Offset: 0x000179F0
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnCardClose = (Action<int>)Delegate.Combine(diff.OnCardClose, new Action<int>(this.Decision));
		GameAct diff2 = GameAct.diff;
		diff2.OnRefresh = (Action<Card>)Delegate.Combine(diff2.OnRefresh, new Action<Card>(this.NewCard));
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x0001984C File Offset: 0x00017A4C
	private void Decision(int decision)
	{
		Card card = GameAct.diff.card;
		if (card == null)
		{
			return;
		}
		string a = card.name;
		if (a == "_end_walkers")
		{
			if (card.bearer != Bearers.walker)
			{
				JukeBox.diff.PlayMusic(Bearers.walker, false);
			}
			return;
		}
		if (!(a == "ratereigns"))
		{
			if (card.id == 979 && decision == -1)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_catone, false, false, 2.5f, -1, 1.5f, 1f);
			}
			Bearers bearer = card.bearer;
			if (bearer != Bearers.drogon)
			{
				if (bearer != Bearers.dungeon)
				{
					if (bearer != Bearers.rhaegal)
					{
						return;
					}
				}
				else
				{
					this.PlayStep();
					a = card.bearerVariation;
					if (a == "leftbroke")
					{
						if (decision == 1)
						{
							JukeBox.diff.PlaySound(SFXTypes.sfx_dungeon_break_wall, false, false, 2.5f, -1, 1.5f, 1f);
						}
						return;
					}
					if (a == "door")
					{
						if (decision == 1)
						{
							JukeBox.diff.PlaySound(SFXTypes.sfx_dungeon_enter, false, false, 2.5f, -1, 1.5f, 1f);
						}
						return;
					}
					if (!(a == "rightbroke"))
					{
						return;
					}
					if (decision == -1)
					{
						JukeBox.diff.PlaySound(SFXTypes.sfx_dungeon_break_wall, false, false, 2.5f, -1, 1.5f, 1f);
					}
					return;
				}
			}
			if (!string.IsNullOrEmpty(card.bearerVariation) && decision == 1)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_dragon_wake, false, false, 2.5f, -1, 1.5f, 1f);
			}
			return;
		}
		if (decision == 1)
		{
			UniRate.Instance.RateIfNetworkAvailable();
		}
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x000199D4 File Offset: 0x00017BD4
	private void NewCard(Card card)
	{
		Bearers bearer = card.bearer;
		if (bearer != Bearers.drogon)
		{
			if (bearer != Bearers.crowd)
			{
				if (bearer != Bearers.rhaegal)
				{
					if (card.id == 977)
					{
						JukeBox.diff.PlaySound(SFXTypes.sfx_cattwo, false, false, 2.5f, -1, 1.5f, 1f);
					}
					return;
				}
			}
			else
			{
				string name = card.name;
				if (name == "_resulttalkone" || name == "_resulttalkww" || name == "_1555" || name == "_1562" || name == "_northmencrowd" || name == "_meetpoor")
				{
					JukeBox.diff.PlaySound(SFXTypes.sfx_crowd, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				}
				return;
			}
		}
		JukeBox.diff.PlaySound(SFXTypes.sfx_dragon_sleep, false, false, 2.5f, -1, 1.5f, 1f);
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x00019ABF File Offset: 0x00017CBF
	private void PlayStep()
	{
		base.StopCoroutine("DoPlayStep");
		base.StartCoroutine("DoPlayStep");
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x00019AD8 File Offset: 0x00017CD8
	private IEnumerator DoPlayStep()
	{
		yield return new WaitForSeconds(Util.Rand(0.15f, 0.25f));
		if (GameAct.diff.card != null && GameAct.diff.card.bearer != Bearers.dungeon)
		{
			yield break;
		}
		JukeBox.diff.PlayAttenuatedSound(SFXTypes.sfx_footstep_dungeon, Util.Rand(0.5f, 1f));
		yield return new WaitForSeconds(Util.Rand(0.35f, 0.45f));
		if (GameAct.diff.card != null && GameAct.diff.card.bearer != Bearers.dungeon)
		{
			yield break;
		}
		JukeBox.diff.PlayAttenuatedSound(SFXTypes.sfx_footstep_dungeon, Util.Rand(0.25f, 0.75f));
		yield break;
	}
}
