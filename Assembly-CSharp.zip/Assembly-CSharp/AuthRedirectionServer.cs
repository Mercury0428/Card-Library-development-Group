﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;

// Token: 0x02000009 RID: 9
internal class AuthRedirectionServer
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000037 RID: 55 RVA: 0x000032CF File Offset: 0x000014CF
	// (set) Token: 0x06000038 RID: 56 RVA: 0x000032D7 File Offset: 0x000014D7
	public string AuthorizationCode
	{
		get
		{
			return this.authorizationCode;
		}
		private set
		{
			this.authorizationCode = value;
		}
	}

	// Token: 0x06000039 RID: 57 RVA: 0x000032E0 File Offset: 0x000014E0
	public bool StartServer(int port)
	{
		try
		{
			Debug.Log("Starting a server...");
			this.server = new TcpListener(IPAddress.Parse("127.0.0.1"), port);
			this.server.Start();
			this.listenThread = new Thread(new ThreadStart(this.Listen));
			this.listenThread.Start();
			Debug.Log("The server is started.");
		}
		catch (Exception message)
		{
			Debug.LogError(message);
			if (this.server != null)
			{
				this.server.Stop();
			}
			this.server = null;
			return false;
		}
		return true;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x0000337C File Offset: 0x0000157C
	private void Listen()
	{
		while (this.AuthorizationCode == null)
		{
			try
			{
				TcpClient tcpClient = this.server.AcceptTcpClient();
				NetworkStream stream = tcpClient.GetStream();
				stream.ReadTimeout = 2000;
				MemoryStream memoryStream = new MemoryStream();
				byte[] array = new byte[4096];
				int count;
				while ((count = stream.Read(array, 0, array.Length)) > 0)
				{
					memoryStream.Write(array, 0, count);
					memoryStream.Flush();
					string @string = Encoding.UTF8.GetString(memoryStream.ToArray());
					if (@string.Contains("\r\n\r\n"))
					{
						string text = @string.Substring(0, @string.IndexOf("\r\n")).Split(new char[]
						{
							' '
						})[1];
						if (text.IndexOf("/?code=") == -1)
						{
							byte[] bytes = Encoding.UTF8.GetBytes("HTTP/1.1 404 Not Found\r\n\r\n\r\n");
							stream.Write(bytes, 0, bytes.Length);
							break;
						}
						text = text.Substring(text.IndexOf("/?code=") + 7);
						this.AuthorizationCode = text;
						byte[] bytes2 = Encoding.UTF8.GetBytes("<html><head></head><body>Please close this window.</body></html>\r\n");
						byte[] bytes3 = Encoding.UTF8.GetBytes("HTTP/1.1 200 OK\r\nConnection: Close\r\nContent-Type: text/html\r\nContent-Length: " + bytes2.Length + "\r\n\r\n\r\n");
						stream.Write(bytes3, 0, bytes3.Length);
						stream.Write(bytes2, 0, bytes2.Length);
						break;
					}
				}
				tcpClient.Close();
				memoryStream.Dispose();
			}
			catch (Exception)
			{
			}
		}
	}

	// Token: 0x0600003B RID: 59 RVA: 0x0000350C File Offset: 0x0000170C
	public void StopServer()
	{
		try
		{
			Debug.Log("Stopping the server...");
			this.server.Stop();
			this.listenThread.Abort();
			Debug.Log("The server is stopped.");
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
		finally
		{
			this.server = null;
			this.listenThread = null;
		}
	}

	// Token: 0x04000043 RID: 67
	private string authorizationCode;

	// Token: 0x04000044 RID: 68
	private TcpListener server;

	// Token: 0x04000045 RID: 69
	private Thread listenThread;
}
