﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000008 RID: 8
public class FaceAct : MonoBehaviour
{
	// Token: 0x06000032 RID: 50 RVA: 0x0000314D File Offset: 0x0000134D
	private void Awake()
	{
		FaceAct.diff = this;
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00003155 File Offset: 0x00001355
	private void Start()
	{
		EffectAct effectAct = this.scEff;
		effectAct.OnOpenEffect = (Action<Effect>)Delegate.Combine(effectAct.OnOpenEffect, new Action<Effect>(this.CheckFace));
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00003180 File Offset: 0x00001380
	public Vector2 GetFacePos(float trust)
	{
		if (!this.hasEffect)
		{
			return new Vector2(0f, 0f);
		}
		if (this.isFacedetecting)
		{
			return new Vector2(this.facepos.y * trust, (-this.facepos.x + 0.08f) * trust);
		}
		if (trust > 0f)
		{
			return new Vector2(0f, 0f);
		}
		if (Vector2.SqrMagnitude(this.simul - this.targ) < 0.001f)
		{
			this.simul = new Vector2(Util.Rand(-0.18f, 0.18f), Util.Rand(-0.18f, 0.18f));
		}
		this.targ = Vector2.Lerp(this.targ, this.simul, 0.15f);
		return this.targ;
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00003254 File Offset: 0x00001454
	private void CheckFace(Effect eff)
	{
		if (eff.tag != "facedetect_keep" || this.hasEffect)
		{
			return;
		}
		this.hasEffect = true;
	}

	// Token: 0x0400003A RID: 58
	public EffectAct scEff;

	// Token: 0x0400003B RID: 59
	public bool isFacedetecting;

	// Token: 0x0400003C RID: 60
	public Text demotext;

	// Token: 0x0400003D RID: 61
	private Vector3 facepos = new Vector3(0f, 0f, 0f);

	// Token: 0x0400003E RID: 62
	public static FaceAct diff;

	// Token: 0x0400003F RID: 63
	private Vector2 simul = new Vector2(0f, 0f);

	// Token: 0x04000040 RID: 64
	private Vector2 targ = new Vector2(0f, 0f);

	// Token: 0x04000041 RID: 65
	private bool hasEffect;

	// Token: 0x04000042 RID: 66
	private bool abletodetect;
}
