﻿using System;
using System.Collections;
using System.Collections.Generic;
using SVGImporter;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class BattleAct : MonoBehaviour
{
	// Token: 0x06000002 RID: 2 RVA: 0x00002058 File Offset: 0x00000258
	private void Start()
	{
		GameAct diff = GameAct.diff;
		diff.OnUpdate = (Action<Card>)Delegate.Combine(diff.OnUpdate, new Action<Card>(this.CheckBattle));
		GameAct diff2 = GameAct.diff;
		diff2.OnRefresh = (Action<Card>)Delegate.Combine(diff2.OnRefresh, new Action<Card>(this.CheckNoBattle));
		this.selfT = base.GetComponent<RectTransform>();
		foreach (object obj in this.mickeys)
		{
			Transform transform = (Transform)obj;
			this.mickImg.Add(transform.GetComponent<SVGImage>());
			this.mickTrans.Add(transform.GetComponent<RectTransform>());
			this.mickSide.Add(true);
		}
		this.cloudTrans = this.cloud.GetComponent<RectTransform>();
		this.cloudY = this.cloudTrans.anchoredPosition.y;
		this.cloudTrans.anchoredPosition = new Vector2(0f, this.cloudY);
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002174 File Offset: 0x00000374
	private void CheckBattle(Card card)
	{
		if (GameAct.diff.GetInt("inc_battle") != 1 || this.hasBattle)
		{
			return;
		}
		string nextCard = GameAct.diff.nextCard;
		if (nextCard.StartsWith("_brawl"))
		{
			this.curBat = BattleAct.BatType.brawl;
			this.curRuler = this.rulerBrawl;
			this.curOppo = this.classicBrawl;
			JukeBox.diff.PlaySound(SFXTypes.sfx_tavern_fight_loop, false, false, 2.5f, -1, 1.5f, 1f);
			JukeBox.diff.StopMusic(false);
		}
		else if (nextCard.StartsWith("_batww"))
		{
			this.curBat = BattleAct.BatType.dead;
			this.curRuler = this.rulerArmy;
			this.curOppo = this.deadArmy;
			JukeBox.diff.PlaySound(SFXTypes.env_battle, false, false, 2.5f, -1, 1.5f, 1f);
		}
		else
		{
			this.curBat = BattleAct.BatType.classic;
			this.curRuler = this.rulerArmy;
			this.curOppo = this.classicArmy;
			JukeBox.diff.PlaySound(SFXTypes.env_battle, false, false, 2.5f, -1, 1.5f, 1f);
			JukeBox.diff.StopMusic(false);
		}
		this.OpenBattle();
	}

	// Token: 0x06000004 RID: 4 RVA: 0x000022A0 File Offset: 0x000004A0
	private void CheckNoBattle(Card card)
	{
		if (!this.hasBattle)
		{
			return;
		}
		bool flag = card != null && card.bearer == Bearers.end;
		if (GameAct.diff.GetInt("inc_battle") == 0 || flag)
		{
			this.CloseBattle();
		}
	}

	// Token: 0x06000005 RID: 5 RVA: 0x000022E8 File Offset: 0x000004E8
	private void OpenBattle()
	{
		GameAct diff = GameAct.diff;
		diff.OnValidSelection = (Action<Card>)Delegate.Combine(diff.OnValidSelection, new Action<Card>(this.PlayCard));
		this.hasBattle = true;
		BackgroundAct.diff.SwitchWithTop(this.selfT, true);
		this.ReposCharac(true);
		this.RefreshPower();
		this.Enable();
		this.ruler.vectorGraphics = this.curRuler.leader;
		this.ruler.SetNativeSize();
		this.oppo.vectorGraphics = this.curOppo.leader;
		this.oppo.SetNativeSize();
		this.moveCloud = false;
		base.StartCoroutine("AnimCloud");
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0000239C File Offset: 0x0000059C
	private void CloseBattle()
	{
		GameAct diff = GameAct.diff;
		diff.OnValidSelection = (Action<Card>)Delegate.Remove(diff.OnValidSelection, new Action<Card>(this.PlayCard));
		JukeBox.diff.FadeOutAmbient();
		this.hasBattle = false;
		BackgroundAct.diff.SwitchWithTop(this.selfT, false);
		base.StopCoroutine("DoRefresh");
		base.StopCoroutine("AnimCloud");
		if (this.curBat == BattleAct.BatType.brawl)
		{
			JukeBox.diff.PlaySound(SFXTypes.sfx_crowd_cheer, false, false, 2.5f, -1, 1.5f, 1f);
			JukeBox.diff.RestartMusic();
		}
		else
		{
			if (this.curBat == BattleAct.BatType.classic)
			{
				JukeBox.diff.RestartMusic();
			}
			if (GameAct.diff.GetInt(Variables.power) > 50)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_won, false, false, 2.5f, -1, 1.5f, 1f);
			}
			else
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_loss, false, false, 2.5f, -1, 1.5f, 1f);
			}
		}
		base.StartCoroutine("DoDisable");
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000024AF File Offset: 0x000006AF
	private IEnumerator DoDisable()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(false);
		}
		base.StopAllCoroutines();
		yield break;
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000024C0 File Offset: 0x000006C0
	private void Enable()
	{
		foreach (object obj in base.transform)
		{
			((Transform)obj).gameObject.SetActive(true);
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x0000251C File Offset: 0x0000071C
	private void PlayCard(Card ca)
	{
		if (this.curBat == BattleAct.BatType.brawl)
		{
			JukeBox.diff.PlaySound(SFXTypes.sfx_tavern_punch, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		Bearers bearer = ca.bearer;
		if (bearer <= Bearers.militant)
		{
			if (bearer <= Bearers.drogon)
			{
				if (bearer == Bearers.soldier)
				{
					JukeBox.diff.PlaySound(SFXTypes.sfx_battle_soldier, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				}
				if (bearer != Bearers.drogon)
				{
					return;
				}
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_dragon, false, false, 2.5f, -1, 1.5f, 1f);
				base.StopCoroutine("DragonAnim");
				base.StartCoroutine("DragonAnim");
				return;
			}
			else
			{
				if (bearer == Bearers.pyromancer)
				{
					JukeBox.diff.PlaySound(SFXTypes.sfx_battle_pyromancer, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				}
				if (bearer == Bearers.scorpion)
				{
					JukeBox.diff.PlaySound(SFXTypes.sfx_battle_scorpion, false, false, 2.5f, -1, 1.5f, 1f);
					return;
				}
				if (bearer != Bearers.militant)
				{
					return;
				}
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_militant, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
		}
		else if (bearer <= Bearers.kingsguard)
		{
			if (bearer == Bearers.banker)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_banker, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (bearer == Bearers.commoner_male)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_commoner_male, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (bearer != Bearers.kingsguard)
			{
				return;
			}
			JukeBox.diff.PlaySound(SFXTypes.sfx_battle_kingsguard, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
		else
		{
			if (bearer == Bearers.freefolk)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_freefolk, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (bearer == Bearers.archer)
			{
				JukeBox.diff.PlaySound(SFXTypes.sfx_battle_archer, false, false, 2.5f, -1, 1.5f, 1f);
				return;
			}
			if (bearer != Bearers.lannister_soldier)
			{
				return;
			}
			JukeBox.diff.PlaySound(SFXTypes.sfx_battle_lannister_soldier, false, false, 2.5f, -1, 1.5f, 1f);
			return;
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002749 File Offset: 0x00000949
	private IEnumerator DragonAnim()
	{
		Vector2 oriPos = new Vector2(-400f, 250f);
		float t = 0f;
		while (t < 1f)
		{
			float y = 250f - Mathf.Sin(t * 3.1415927f) * 68f;
			float x = Mathf.Lerp(-400f, 400f, t);
			this.dragon.anchoredPosition = new Vector2(x, y);
			t += Time.deltaTime * 0.7f;
			yield return 0;
		}
		this.dragon.anchoredPosition = oriPos;
		yield break;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00002758 File Offset: 0x00000958
	private void RefreshPower()
	{
		base.StopCoroutine("DoRefresh");
		base.StartCoroutine("DoRefresh");
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002771 File Offset: 0x00000971
	private IEnumerator DoRefresh()
	{
		yield return new WaitForSeconds(1f);
		int lastpower = 50;
		float amo = 0f;
		float t = 0f;
		for (;;)
		{
			int @int = GameAct.diff.GetInt(Variables.power);
			if (@int == lastpower)
			{
				yield return new WaitForSeconds(0.5f);
			}
			else
			{
				lastpower = @int;
				amo = ((float)@int - 50f) * 2f;
				t = 0f;
				this.moveCloud = true;
				while (t < 1f)
				{
					this.cloudTrans.anchoredPosition = Vector2.Lerp(this.cloudTrans.anchoredPosition, new Vector2(amo, this.cloudY), Time.deltaTime * 3f);
					t += Time.deltaTime * 2f;
					yield return 0;
				}
				this.moveCloud = false;
				this.cloudTrans.anchoredPosition = new Vector2(amo, this.cloudY);
			}
		}
		yield break;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00002780 File Offset: 0x00000980
	private IEnumerator AnimCloud()
	{
		for (;;)
		{
			foreach (SVGAsset vectorGraphics in this.clouds)
			{
				this.cloud.vectorGraphics = vectorGraphics;
				this.cloud.SetNativeSize();
				if (this.moveCloud)
				{
					this.ReposCharac(false);
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					yield return new WaitForSeconds(0.3f);
				}
			}
			List<SVGAsset>.Enumerator enumerator = default(List<SVGAsset>.Enumerator);
		}
		yield break;
		yield break;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00002790 File Offset: 0x00000990
	private void ReposCharac(bool init = false)
	{
		if (init)
		{
			this.cloudTrans.anchoredPosition = new Vector2(0f, this.cloudY);
		}
		Vector3 vector = new Vector3(4.5f, 4.5f, 1f);
		Vector3 vector2 = new Vector3(-4.5f, 4.5f, 1f);
		float num = (float)(this.mickTrans.Count - 1) / 2f;
		for (int i = 0; i < this.mickTrans.Count; i++)
		{
			this.mickTrans[i].anchoredPosition = new Vector2((25f - num) * ((float)i - num) + Util.Rand(-3f, 3f), 186f);
			bool flag = this.mickSide[i];
			this.mickSide[i] = (this.mickTrans[i].anchoredPosition.x < this.cloudTrans.anchoredPosition.x);
			if (init || flag != this.mickSide[i] || Util.Rand(0f, 1f) < 0.1f)
			{
				this.mickImg[i].vectorGraphics = (this.mickSide[i] ? this.curRuler.characters[Util.RandInt(0, this.curRuler.characters.Count)] : this.curOppo.characters[Util.RandInt(0, this.curOppo.characters.Count)]);
				this.mickImg[i].SetNativeSize();
			}
			this.mickTrans[i].localScale = (this.mickSide[i] ? vector : vector2);
		}
	}

	// Token: 0x04000003 RID: 3
	private BattleAct.BatType curBat;

	// Token: 0x04000004 RID: 4
	private Army curRuler;

	// Token: 0x04000005 RID: 5
	private Army curOppo;

	// Token: 0x04000006 RID: 6
	public RectTransform dragon;

	// Token: 0x04000007 RID: 7
	public SVGImage ruler;

	// Token: 0x04000008 RID: 8
	public SVGImage oppo;

	// Token: 0x04000009 RID: 9
	public SVGImage cloud;

	// Token: 0x0400000A RID: 10
	private RectTransform cloudTrans;

	// Token: 0x0400000B RID: 11
	private float cloudY;

	// Token: 0x0400000C RID: 12
	public Army rulerArmy;

	// Token: 0x0400000D RID: 13
	public Army deadArmy;

	// Token: 0x0400000E RID: 14
	public Army classicArmy;

	// Token: 0x0400000F RID: 15
	public Army rulerBrawl;

	// Token: 0x04000010 RID: 16
	public Army classicBrawl;

	// Token: 0x04000011 RID: 17
	public List<SVGAsset> clouds;

	// Token: 0x04000012 RID: 18
	public Transform mickeys;

	// Token: 0x04000013 RID: 19
	private List<SVGImage> mickImg = new List<SVGImage>();

	// Token: 0x04000014 RID: 20
	private List<RectTransform> mickTrans = new List<RectTransform>();

	// Token: 0x04000015 RID: 21
	private List<bool> mickSide = new List<bool>();

	// Token: 0x04000016 RID: 22
	private bool hasBattle;

	// Token: 0x04000017 RID: 23
	private RectTransform selfT;

	// Token: 0x04000018 RID: 24
	private bool moveCloud;

	// Token: 0x0200022A RID: 554
	public enum BatType
	{
		// Token: 0x04000DD3 RID: 3539
		classic,
		// Token: 0x04000DD4 RID: 3540
		dead,
		// Token: 0x04000DD5 RID: 3541
		brawl
	}
}
