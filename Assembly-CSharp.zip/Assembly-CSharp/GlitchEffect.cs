﻿using System;
using UnityEngine;
using UnityStandardAssets.ImageEffects;

// Token: 0x02000050 RID: 80
public class GlitchEffect : ImageEffectBase
{
	// Token: 0x060002F4 RID: 756 RVA: 0x000135BC File Offset: 0x000117BC
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		base.material.SetFloat("_Intensity", this.intensity);
		base.material.SetFloat("_ColorIntensity", this.colorIntensity);
		base.material.SetTexture("_DispTex", this.displacementMap);
		this.flicker += Time.deltaTime * this.colorIntensity;
		if (this.flicker > this.flickerTime)
		{
			base.material.SetFloat("filterRadius", Random.Range(-3f, 3f) * this.colorIntensity);
			base.material.SetVector("direction", Quaternion.AngleAxis((float)Random.Range(0, 360) * this.colorIntensity, Vector3.forward) * Vector4.one);
			this.flicker = 0f;
			this.flickerTime = Random.value;
		}
		if (this.colorIntensity == 0f)
		{
			base.material.SetFloat("filterRadius", 0f);
		}
		this.glitchup += Time.deltaTime * this.flipIntensity;
		if (this.glitchup > this.glitchupTime)
		{
			if (Random.value < 0.1f * this.flipIntensity)
			{
				base.material.SetFloat("flip_up", Random.Range(0f, 1f) * this.flipIntensity);
			}
			else
			{
				base.material.SetFloat("flip_up", 0f);
			}
			this.glitchup = 0f;
			this.glitchupTime = Random.value / 10f;
		}
		if (this.flipIntensity == 0f)
		{
			base.material.SetFloat("flip_up", 0f);
		}
		this.glitchdown += Time.deltaTime * this.flipIntensity;
		if (this.glitchdown > this.glitchdownTime)
		{
			if (Random.value < 0.1f * this.flipIntensity)
			{
				base.material.SetFloat("flip_down", 1f - Random.Range(0f, 1f) * this.flipIntensity);
			}
			else
			{
				base.material.SetFloat("flip_down", 1f);
			}
			this.glitchdown = 0f;
			this.glitchdownTime = Random.value / 10f;
		}
		if (this.flipIntensity == 0f)
		{
			base.material.SetFloat("flip_down", 1f);
		}
		if ((double)Random.value < 0.05 * (double)this.intensity)
		{
			base.material.SetFloat("displace", Random.value * this.intensity);
			base.material.SetFloat("scale", 1f - Random.value * this.intensity);
		}
		else
		{
			base.material.SetFloat("displace", 0f);
		}
		Graphics.Blit(source, destination, base.material);
	}

	// Token: 0x040003BD RID: 957
	public Texture2D displacementMap;

	// Token: 0x040003BE RID: 958
	private float glitchup;

	// Token: 0x040003BF RID: 959
	private float glitchdown;

	// Token: 0x040003C0 RID: 960
	private float flicker;

	// Token: 0x040003C1 RID: 961
	private float glitchupTime = 0.05f;

	// Token: 0x040003C2 RID: 962
	private float glitchdownTime = 0.05f;

	// Token: 0x040003C3 RID: 963
	private float flickerTime = 0.5f;

	// Token: 0x040003C4 RID: 964
	[Header("Glitch Intensity")]
	[Range(0f, 1f)]
	public float intensity;

	// Token: 0x040003C5 RID: 965
	[Range(0f, 1f)]
	public float flipIntensity;

	// Token: 0x040003C6 RID: 966
	[Range(0f, 1f)]
	public float colorIntensity;
}
