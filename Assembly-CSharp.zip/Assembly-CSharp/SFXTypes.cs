﻿using System;

// Token: 0x02000048 RID: 72
public enum SFXTypes
{
	// Token: 0x040002CF RID: 719
	card_discard_left = 2,
	// Token: 0x040002D0 RID: 720
	card_discard_right = 12,
	// Token: 0x040002D1 RID: 721
	card_stacking = 22,
	// Token: 0x040002D2 RID: 722
	card_swipe_left = 24,
	// Token: 0x040002D3 RID: 723
	card_swipe_right = 34,
	// Token: 0x040002D4 RID: 724
	env_battle = 44,
	// Token: 0x040002D5 RID: 725
	env_battle_after = 46,
	// Token: 0x040002D6 RID: 726
	env_death_melisandre = 48,
	// Token: 0x040002D7 RID: 727
	env_dungeon = 50,
	// Token: 0x040002D8 RID: 728
	env_forest = 52,
	// Token: 0x040002D9 RID: 729
	env_forest_winter = 54,
	// Token: 0x040002DA RID: 730
	env_hills = 56,
	// Token: 0x040002DB RID: 731
	env_kingslanding = 58,
	// Token: 0x040002DC RID: 732
	env_map_room = 60,
	// Token: 0x040002DD RID: 733
	env_ocean = 62,
	// Token: 0x040002DE RID: 734
	env_tavern = 64,
	// Token: 0x040002DF RID: 735
	env_throne = 66,
	// Token: 0x040002E0 RID: 736
	env_tourney = 68,
	// Token: 0x040002E1 RID: 737
	env_winter = 70,
	// Token: 0x040002E2 RID: 738
	env_winterfell = 72,
	// Token: 0x040002E3 RID: 739
	sfx_dragon_sleep = 74,
	// Token: 0x040002E4 RID: 740
	sfx_dragon_wake = 76,
	// Token: 0x040002E5 RID: 741
	sfx_dream_start = 78,
	// Token: 0x040002E6 RID: 742
	sfx_enter_dungon = 80,
	// Token: 0x040002E7 RID: 743
	sfx_kill_character = 82,
	// Token: 0x040002E8 RID: 744
	sfx_transition = 84,
	// Token: 0x040002E9 RID: 745
	sfx_winter_gust = 86,
	// Token: 0x040002EA RID: 746
	ui_achievement_completed = 94,
	// Token: 0x040002EB RID: 747
	ui_achievement_unlock = 96,
	// Token: 0x040002EC RID: 748
	ui_ageup = 98,
	// Token: 0x040002ED RID: 749
	ui_button_next = 106,
	// Token: 0x040002EE RID: 750
	ui_character_select = 118,
	// Token: 0x040002EF RID: 751
	ui_character_transition = 120,
	// Token: 0x040002F0 RID: 752
	ui_death_characters = 122,
	// Token: 0x040002F1 RID: 753
	ui_death_characters_select = 124,
	// Token: 0x040002F2 RID: 754
	ui_death_drone = 126,
	// Token: 0x040002F3 RID: 755
	ui_death_melisandre_start = 128,
	// Token: 0x040002F4 RID: 756
	ui_death_start = 130,
	// Token: 0x040002F5 RID: 757
	ui_death_stats_start = 132,
	// Token: 0x040002F6 RID: 758
	ui_death_stats_whoosh = 134,
	// Token: 0x040002F7 RID: 759
	ui_death_whoosh_text_banner_fall = 136,
	// Token: 0x040002F8 RID: 760
	ui_deathwish = 138,
	// Token: 0x040002F9 RID: 761
	ui_effect_received = 140,
	// Token: 0x040002FA RID: 762
	ui_error = 142,
	// Token: 0x040002FB RID: 763
	ui_high_score = 144,
	// Token: 0x040002FC RID: 764
	ui_high_score_menu = 146,
	// Token: 0x040002FD RID: 765
	ui_intro = 148,
	// Token: 0x040002FE RID: 766
	ui_inventory_close = 150,
	// Token: 0x040002FF RID: 767
	ui_inventory_open = 152,
	// Token: 0x04000300 RID: 768
	ui_inventory_select = 154,
	// Token: 0x04000301 RID: 769
	ui_menu_close = 156,
	// Token: 0x04000302 RID: 770
	ui_menu_open = 158,
	// Token: 0x04000303 RID: 771
	ui_new_cards = 160,
	// Token: 0x04000304 RID: 772
	ui_score_army_decrease = 162,
	// Token: 0x04000305 RID: 773
	ui_score_army_increase = 164,
	// Token: 0x04000306 RID: 774
	ui_score_bank_decrease = 166,
	// Token: 0x04000307 RID: 775
	ui_score_bank_increase = 168,
	// Token: 0x04000308 RID: 776
	ui_score_church_decrease = 170,
	// Token: 0x04000309 RID: 777
	ui_score_church_increase = 172,
	// Token: 0x0400030A RID: 778
	ui_score_people_decrease = 174,
	// Token: 0x0400030B RID: 779
	ui_score_people_increase = 176,
	// Token: 0x0400030C RID: 780
	sfx_battle_archer = 250,
	// Token: 0x0400030D RID: 781
	sfx_battle_banker = 252,
	// Token: 0x0400030E RID: 782
	sfx_battle_commoner_male = 254,
	// Token: 0x0400030F RID: 783
	sfx_battle_crowd = 256,
	// Token: 0x04000310 RID: 784
	sfx_battle_dragon = 258,
	// Token: 0x04000311 RID: 785
	sfx_battle_freefolk = 260,
	// Token: 0x04000312 RID: 786
	sfx_battle_kingsguard = 262,
	// Token: 0x04000313 RID: 787
	sfx_battle_lannister_soldier = 264,
	// Token: 0x04000314 RID: 788
	sfx_battle_militant = 266,
	// Token: 0x04000315 RID: 789
	sfx_battle_pyromancer = 268,
	// Token: 0x04000316 RID: 790
	sfx_battle_scorpion = 270,
	// Token: 0x04000317 RID: 791
	sfx_battle_soldier = 272,
	// Token: 0x04000318 RID: 792
	sfx_crowd_cheer = 274,
	// Token: 0x04000319 RID: 793
	sfx_tavern_fight_loop = 290,
	// Token: 0x0400031A RID: 794
	sfx_tavern_punch = 292,
	// Token: 0x0400031B RID: 795
	sfx_weirwood_full_reveal = 298,
	// Token: 0x0400031C RID: 796
	ui_character_reveal = 332,
	// Token: 0x0400031D RID: 797
	sfx_battle_loss = 422,
	// Token: 0x0400031E RID: 798
	sfx_battle_won = 432,
	// Token: 0x0400031F RID: 799
	sfx_tourney_attack = 456,
	// Token: 0x04000320 RID: 800
	sfx_travel_arrival_horn = 464,
	// Token: 0x04000321 RID: 801
	sfx_travel_carriage_move = 466,
	// Token: 0x04000322 RID: 802
	sfx_travel_distant_scream = 472,
	// Token: 0x04000323 RID: 803
	sfx_crowd = 574,
	// Token: 0x04000324 RID: 804
	sfx_dungeon_break_wall = 694,
	// Token: 0x04000325 RID: 805
	sfx_dungeon_enter = 696,
	// Token: 0x04000326 RID: 806
	sfx_dungeon_kick_door = 698,
	// Token: 0x04000327 RID: 807
	sfx_footstep_dungeon = 840,
	// Token: 0x04000328 RID: 808
	sfx_catone = 1046,
	// Token: 0x04000329 RID: 809
	sfx_cattwo = 1048,
	// Token: 0x0400032A RID: 810
	none
}
