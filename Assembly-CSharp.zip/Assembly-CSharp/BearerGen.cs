﻿using System;
using System.Collections.Generic;
using System.Linq;
using SVGImporter;
using UnityEngine;

// Token: 0x0200002F RID: 47
[Serializable]
public class BearerGen
{
	// Token: 0x06000155 RID: 341 RVA: 0x00008ED8 File Offset: 0x000070D8
	public BearerGen(Bearers be)
	{
		this.bearer = be;
		foreach (SVGAsset svgasset in Resources.LoadAll("bearers/" + be.ToString(), typeof(SVGAsset)).Cast<SVGAsset>().ToArray<SVGAsset>())
		{
			string a = svgasset.name.Substring(0, svgasset.name.Length - 1);
			if (!(a == "back"))
			{
				if (!(a == "body"))
				{
					if (!(a == "cloth"))
					{
						if (!(a == "hair"))
						{
							if (a == "eyes")
							{
								this.eyes.Add(svgasset);
							}
						}
						else
						{
							this.hairs.Add(svgasset);
						}
					}
					else
					{
						this.clothes.Add(svgasset);
					}
				}
				else
				{
					this.bodies.Add(svgasset);
				}
			}
			else
			{
				this.backs.Add(svgasset);
			}
		}
	}

	// Token: 0x0400016C RID: 364
	public Bearers bearer;

	// Token: 0x0400016D RID: 365
	public List<SVGAsset> backs = new List<SVGAsset>();

	// Token: 0x0400016E RID: 366
	public List<SVGAsset> bodies = new List<SVGAsset>();

	// Token: 0x0400016F RID: 367
	public List<SVGAsset> clothes = new List<SVGAsset>();

	// Token: 0x04000170 RID: 368
	public List<SVGAsset> hairs = new List<SVGAsset>();

	// Token: 0x04000171 RID: 369
	public List<SVGAsset> eyes = new List<SVGAsset>();
}
