﻿using System;
using System.Collections;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000034 RID: 52
public class EffectCard : CardAct
{
	// Token: 0x0600019D RID: 413 RVA: 0x0000B280 File Offset: 0x00009480
	private void Awake()
	{
		base._Awake();
	}

	// Token: 0x0600019E RID: 414 RVA: 0x0000B288 File Offset: 0x00009488
	private void Start()
	{
		if (SpeechAct.diff.asiaLayout)
		{
			this.description.fontSize = 13;
			this.description.horizontalOverflow = HorizontalWrapMode.Overflow;
			return;
		}
		this.description.fontSize = 15;
		this.description.horizontalOverflow = HorizontalWrapMode.Wrap;
	}

	// Token: 0x0600019F RID: 415 RVA: 0x0000B2D4 File Offset: 0x000094D4
	public void InitEffect(Effect effect, int dec)
	{
		this.icon.vectorGraphics = (SVGAsset)Resources.Load("effects/" + effect.tag, typeof(SVGAsset));
		this.title.text = effect.title;
		this.description.text = effect.description;
		this.question.text = SpeechAct.diff.GetSceneText("effects");
		base.InitCard(effect.tag, effect.title, effect.description, dec, true);
		JukeBox.diff.PlaySound(SFXTypes.ui_effect_received, false, false, 2.5f, -1, 1.5f, 1f);
		base.StartCoroutine("LateAudio", effect.tag);
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000B399 File Offset: 0x00009599
	private IEnumerator LateAudio(string tag)
	{
		yield return new WaitForSeconds(0.4f);
		AudioClip type = (AudioClip)Resources.Load("effects_sfx/" + tag, typeof(AudioClip));
		JukeBox.diff.PlaySound(type, false, false, 2.5f);
		yield break;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000B3A8 File Offset: 0x000095A8
	public override void HideCard()
	{
		GameAct.diff.HideOutcome();
		base.HideCard();
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000B3BA File Offset: 0x000095BA
	public override void HideFond()
	{
		base.HideFond();
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00003D07 File Offset: 0x00001F07
	public override void ShowDecision(int dec)
	{
	}

	// Token: 0x040001DC RID: 476
	public SVGImage icon;

	// Token: 0x040001DD RID: 477
	public Text title;

	// Token: 0x040001DE RID: 478
	public Text description;

	// Token: 0x040001DF RID: 479
	public EffectAct scEf;

	// Token: 0x040001E0 RID: 480
	public Text question;
}
