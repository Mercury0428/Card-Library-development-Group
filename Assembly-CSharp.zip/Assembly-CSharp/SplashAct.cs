﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000077 RID: 119
public class SplashAct : MonoBehaviour
{
	// Token: 0x06000422 RID: 1058 RVA: 0x0001ABE6 File Offset: 0x00018DE6
	private void Start()
	{
		base.StartCoroutine(this.DoSplash());
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x0001ABF5 File Offset: 0x00018DF5
	private IEnumerator DoSplash()
	{
		yield return new WaitForSeconds(2f);
		SceneManager.LoadScene("disclaimer");
		yield break;
	}
}
