﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000040 RID: 64
public class DisclaimerAct : MonoBehaviour
{
	// Token: 0x06000201 RID: 513 RVA: 0x0000C8EF File Offset: 0x0000AAEF
	private void Awake()
	{
		this.isAlreadyLoaded = (Time.time != 0f);
	}

	// Token: 0x06000202 RID: 514 RVA: 0x0000C908 File Offset: 0x0000AB08
	public void Start()
	{
		base.StartCoroutine("Demarre");
		if (InputAct.diff.isLandscape(false))
		{
			Screen.orientation = ScreenOrientation.LandscapeLeft;
			Screen.autorotateToLandscapeLeft = (Screen.autorotateToLandscapeRight = true);
			Screen.autorotateToPortrait = (Screen.autorotateToPortraitUpsideDown = false);
			Screen.orientation = ScreenOrientation.AutoRotation;
		}
		if (Screen.fullScreen)
		{
			if (DataStore.HasFile("resol_keep"))
			{
				return;
			}
			DataStore.Save<List<int>>("resol_keep", new List<int>
			{
				Screen.currentResolution.width,
				Screen.currentResolution.height
			}, false, false);
		}
	}

	// Token: 0x06000203 RID: 515 RVA: 0x0000C99D File Offset: 0x0000AB9D
	private IEnumerator Demarre()
	{
		AnimBut.diff.Lock(true);
		if (InputAct.diff.isLandscape(false))
		{
			Screen.orientation = ScreenOrientation.LandscapeLeft;
			yield return 0;
			Screen.orientation = ScreenOrientation.AutoRotation;
			Screen.autorotateToLandscapeLeft = (Screen.autorotateToLandscapeRight = true);
			Screen.autorotateToPortrait = (Screen.autorotateToPortraitUpsideDown = false);
		}
		yield return new WaitForSeconds(0.2f);
		float t = 0f;
		WaitForSeconds swait = new WaitForSeconds(0.2f);
		while (t < 1f && !SocialAct.diff.socialReadyOrNot)
		{
			t += 0.2f;
			yield return swait;
		}
		foreach (object obj in this.Canvas)
		{
			Transform transform = (Transform)obj;
			transform.gameObject.SetActive(true);
			if (transform.name == "logo")
			{
				transform.Find("pcStart").gameObject.SetActive(true);
			}
		}
		yield return new WaitForSeconds(4f);
		ThemeAct.diff.Play();
		yield return new WaitForSeconds(1.5f);
		if (this.isAlreadyLoaded)
		{
			this.StartGame();
			yield break;
		}
		if (!DataStore.HasFile("input_keep"))
		{
			this.knowninput.SetActive(false);
			this.unknowninput.SetActive(true);
		}
		else if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.next, false, true);
		}
		InputAct.diff.GetActionFocus(new Action(this.StartGame), false);
		if (AnimBut.diff)
		{
			AnimBut.diff.UnLock(ControlModes.next, false, true);
		}
		yield break;
	}

	// Token: 0x06000204 RID: 516 RVA: 0x0000C9AC File Offset: 0x0000ABAC
	public void StartGame()
	{
		base.StartCoroutine("DoStart");
	}

	// Token: 0x06000205 RID: 517 RVA: 0x0000C9BA File Offset: 0x0000ABBA
	private IEnumerator DoStart()
	{
		this.loadText.SetActive(true);
		if (AnimBut.diff)
		{
			AnimBut.diff.Lock(false);
		}
		yield return new WaitForSeconds(1f);
		SceneManager.LoadSceneAsync("reigns_pc");
		yield break;
	}

	// Token: 0x04000229 RID: 553
	public GameObject loadText;

	// Token: 0x0400022A RID: 554
	public GameObject knowninput;

	// Token: 0x0400022B RID: 555
	public GameObject unknowninput;

	// Token: 0x0400022C RID: 556
	public Transform Canvas;

	// Token: 0x0400022D RID: 557
	private bool isAlreadyLoaded;
}
