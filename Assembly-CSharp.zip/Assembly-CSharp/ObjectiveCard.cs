﻿using System;

// Token: 0x02000037 RID: 55
public class ObjectiveCard : CardAct
{
	// Token: 0x060001B0 RID: 432 RVA: 0x0000B280 File Offset: 0x00009480
	private void Awake()
	{
		base._Awake();
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x0000B486 File Offset: 0x00009686
	public override void InitCard(string yesText, string noText, string otherText, int decision, bool withanim = true)
	{
		base.InitCard(yesText, noText, otherText, decision, true);
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x0000B47E File Offset: 0x0000967E
	public override void HideCard()
	{
		base.HideCard();
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x0000B3BA File Offset: 0x000095BA
	public override void HideFond()
	{
		base.HideFond();
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x00003D07 File Offset: 0x00001F07
	public override void ShowDecision(int dec)
	{
	}
}
