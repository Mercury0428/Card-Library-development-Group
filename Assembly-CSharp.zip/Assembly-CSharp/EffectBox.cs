﻿using System;
using SVGImporter;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000022 RID: 34
public class EffectBox : MonoBehaviour
{
	// Token: 0x06000111 RID: 273 RVA: 0x00006280 File Offset: 0x00004480
	public void Init(Effect effect)
	{
		this.icon.vectorGraphics = (SVGAsset)Resources.Load("effects/" + effect.tag, typeof(SVGAsset));
		this.title.text = effect.title;
		this.description.text = effect.description;
	}

	// Token: 0x06000112 RID: 274 RVA: 0x000062E0 File Offset: 0x000044E0
	private int SetData(Sprite img, float val, int n)
	{
		this.outcoSlots[n].gameObject.SetActive(true);
		this.outcoSlots[n].sprite = img;
		this.outcoSlots[n].GetComponentInChildren<Text>().text = ((val > 0f) ? ("+" + val.ToString()) : val.ToString());
		n++;
		return n;
	}

	// Token: 0x040000EA RID: 234
	public SVGImage icon;

	// Token: 0x040000EB RID: 235
	public Text title;

	// Token: 0x040000EC RID: 236
	public Text description;

	// Token: 0x040000ED RID: 237
	public Image[] outcoSlots;

	// Token: 0x040000EE RID: 238
	public Sprite imgChurch;

	// Token: 0x040000EF RID: 239
	public Sprite imgKing;

	// Token: 0x040000F0 RID: 240
	public Sprite imgPeople;

	// Token: 0x040000F1 RID: 241
	public Sprite imgIntrigue;

	// Token: 0x040000F2 RID: 242
	private RectTransform thisrect;

	// Token: 0x040000F3 RID: 243
	private string objId;

	// Token: 0x040000F4 RID: 244
	private EffectAct scEf;

	// Token: 0x040000F5 RID: 245
	private Effect effect;
}
